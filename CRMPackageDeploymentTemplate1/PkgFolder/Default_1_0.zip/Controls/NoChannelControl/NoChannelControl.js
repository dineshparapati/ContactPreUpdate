/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../../references/internal/TypeDefinitions/CommonControl/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var OfficeProductivity;
    (function (OfficeProductivity) {
        'use strict';
        var NoChannelControl = (function () {
            /**
             * Empty constructor.
             */
            function NoChannelControl() {
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             */
            NoChannelControl.prototype.init = function (context, notifyOutputChanged, state) {
                this._context = context;
                this.controlUtil = new OfficeProductivity.ControlUtil(context, notifyOutputChanged);
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            NoChannelControl.prototype.updateView = function (context) {
                this._context = context;
                return this.controlUtil.render();
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            NoChannelControl.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                return null;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            NoChannelControl.prototype.destroy = function () {
            };
            return NoChannelControl;
        }());
        OfficeProductivity.NoChannelControl = NoChannelControl;
    })(OfficeProductivity = MscrmControls.OfficeProductivity || (MscrmControls.OfficeProductivity = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="NoChannelControl.ts" />
var MscrmControls;
(function (MscrmControls) {
    var OfficeProductivity;
    (function (OfficeProductivity) {
        'use strict';
        var ControlConstants;
        (function (ControlConstants) {
            ControlConstants.IMAGECONTROL_ID = "ImageControlId";
            ControlConstants.IMAGECONTROL_NAME = "MscrmControls.OfficeProductivity.ImageControl";
            ControlConstants.LABELCONTROL_ID = "LabelControlId";
            ControlConstants.LINKCONTROL_ID = "LinkControlId";
            ControlConstants.LINKCONTROL_NAME = "MscrmControls.OfficeProductivity.LinkControl";
            ControlConstants.IMAGECONTROL_SRC = "/WebResources/msdyn_/img/MSTeamsIntegration.svg";
            ControlConstants.LINKCONTROL_Value = "https://go.microsoft.com/fwlink/?linkid=2018009";
            /* RESX string constants */
            ControlConstants.IMAGECONTROL_ALTTEXT = "IMAGECONTROL_ALTTEXT";
            ControlConstants.LINKCONTROL_ALTTEXT = "LINKCONTROL_ALTTEXT";
            ControlConstants.LINKCONTROL_TEXT = "LINKCONTROL_TEXT";
            ControlConstants.NOCHANNEL_TEXT_1 = "NOCHANNEL_TEXT_1";
            ControlConstants.NOCHANNEL_TEXT_2 = "NOCHANNEL_TEXT_2";
            ControlConstants.MDD_NAME = "NoChannelMDD";
            ControlConstants.EventTeamsLearnMoreLinkClicked = "MsTeamsIntegration.LearnMoreLinkClicked";
        })(ControlConstants = OfficeProductivity.ControlConstants || (OfficeProductivity.ControlConstants = {}));
    })(OfficeProductivity = MscrmControls.OfficeProductivity || (MscrmControls.OfficeProductivity = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var OfficeProductivity;
    (function (OfficeProductivity) {
        'use strict';
        var ControlUtil = (function () {
            function ControlUtil(context, notifyOutputChanged) {
                this._context = context;
                this._notifyOutputChanged = notifyOutputChanged || (function () { });
            }
            /**
             * Creates the complete visualization of the control to be rendered on UI
             * */
            ControlUtil.prototype.render = function () {
                var controls = [];
                //push image control
                controls.push(this.CreateImageElement(this._context));
                //push label control
                controls.push(this.CreateLabelElement(this._context, this._context.resources.getString(OfficeProductivity.ControlConstants.NOCHANNEL_TEXT_1)));
                controls.push(this.CreateLabelLinkElement(this._context));
                return this.createRootContainer(controls, "completePage");
            };
            /**
             * Creates the root container for no channel control visualization
             */
            ControlUtil.prototype.createRootContainer = function (controls, containerSuffix) {
                return this._context.factory.createElement("CONTAINER", {
                    id: "containerWithControls" + containerSuffix,
                    key: "containerWithControls" + containerSuffix,
                    style: {
                        maxWidth: '100%',
                        width: '100%',
                        flexDirection: 'column',
                        margin: '0 3px',
                        whiteSpace: 'normal'
                    }
                }, controls);
            };
            /**
             * Creates the visualization for image
             */
            ControlUtil.prototype.CreateImageElement = function (context) {
                var properties = {
                    parameters: this.GetImageProperties(OfficeProductivity.ControlConstants.IMAGECONTROL_SRC, this._context.resources.getString(OfficeProductivity.ControlConstants.IMAGECONTROL_ALTTEXT))
                };
                return context.factory.createElement("CONTAINER", {
                    id: OfficeProductivity.ControlConstants.IMAGECONTROL_ID + "_container",
                    key: OfficeProductivity.ControlConstants.IMAGECONTROL_ID + "_container",
                    style: {
                        paddingTop: '30px',
                        paddingBottom: '42px',
                        width: '280px',
                        height: '46px',
                        marginLeft: 'auto',
                        marginRight: 'auto'
                    }
                }, context.factory.createComponent(OfficeProductivity.ControlConstants.IMAGECONTROL_NAME, OfficeProductivity.ControlConstants.IMAGECONTROL_ID, properties));
            };
            /**
             * Function to create the properties for image control
             * @param imageBlob - base64 encoded blob of image, used in src field of img tag
             * @param altText - Hover text for the image
             */
            ControlUtil.prototype.GetImageProperties = function (imageBlob, altText) {
                return {
                    imgSrc: {
                        Static: true,
                        Primary: false,
                        Type: "SingleLine.Text",
                        Value: imageBlob,
                        Usage: 1
                    },
                    imgAltText: {
                        Static: true,
                        Primary: false,
                        Type: "SingleLine.Text",
                        Value: altText,
                        Usage: 1
                    }
                };
            };
            /**
             * Creates the visualization for Label
             */
            ControlUtil.prototype.CreateLabelElement = function (context, labelText) {
                return context.factory.createElement("CONTAINER", {
                    id: OfficeProductivity.ControlConstants.LABELCONTROL_ID,
                    key: OfficeProductivity.ControlConstants.LABELCONTROL_ID,
                    style: {
                        paddingBottom: '14px',
                    }
                }, labelText);
            };
            /**
             * Creates the visualization for Link
             */
            ControlUtil.prototype.CreateLabelLinkElement = function (context) {
                var _this = this;
                var linkText = context.resources.getString(OfficeProductivity.ControlConstants.LINKCONTROL_TEXT);
                var learn_link = context.factory.createElement("HYPERLINK", {
                    id: OfficeProductivity.ControlConstants.LINKCONTROL_ID,
                    key: OfficeProductivity.ControlConstants.LINKCONTROL_ID,
                    role: "link",
                    target: "_blank",
                    tabIndex: 0,
                    onclick: function (event) { return _this.logTelemetry(event); },
                    href: OfficeProductivity.ControlConstants.LINKCONTROL_Value,
                    title: linkText,
                    accessibilityLabel: linkText,
                    style: {
                        textDecoration: "none",
                        color: "#4275b2"
                    },
                }, linkText);
                var noChannelLabel_2 = context.factory.createElement("LABEL", {
                    id: OfficeProductivity.ControlConstants.LABELCONTROL_ID,
                    key: OfficeProductivity.ControlConstants.LABELCONTROL_ID
                }, [context.resources.getString(OfficeProductivity.ControlConstants.NOCHANNEL_TEXT_2).replace("{0}", ""), learn_link]);
                return noChannelLabel_2;
            };
            /* utility to log telemetry for link click */
            ControlUtil.prototype.logTelemetry = function (event) {
                // log telemetry for this activity
                var parameters = [
                    { name: "ComponentName", value: OfficeProductivity.ControlConstants.MDD_NAME + OfficeProductivity.ControlConstants.LINKCONTROL_NAME }
                ];
                this._context.reporting.reportSuccess(OfficeProductivity.ControlConstants.EventTeamsLearnMoreLinkClicked, parameters);
            };
            return ControlUtil;
        }());
        OfficeProductivity.ControlUtil = ControlUtil;
    })(OfficeProductivity = MscrmControls.OfficeProductivity || (MscrmControls.OfficeProductivity = {}));
})(MscrmControls || (MscrmControls = {}));
;
//# sourceMappingURL=NoChannelControl.js.map