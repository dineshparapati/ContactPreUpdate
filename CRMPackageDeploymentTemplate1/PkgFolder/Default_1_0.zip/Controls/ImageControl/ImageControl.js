/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../../references/internal/TypeDefinitions/CommonControl/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var OfficeProductivity;
    (function (OfficeProductivity) {
        'use strict';
        var ImageControl = (function () {
            /**
             * Empty constructor.
             */
            function ImageControl() {
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            ImageControl.prototype.init = function (context, notifyOutputChanged, state) {
                this._context = context;
                this.imageElement = new OfficeProductivity.ImageElement(context, notifyOutputChanged);
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            ImageControl.prototype.updateView = function (context) {
                return this.imageElement.render();
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            ImageControl.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                return null;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            ImageControl.prototype.destroy = function () {
            };
            return ImageControl;
        }());
        OfficeProductivity.ImageControl = ImageControl;
    })(OfficeProductivity = MscrmControls.OfficeProductivity || (MscrmControls.OfficeProductivity = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="ImageControl.ts" />
var MscrmControls;
(function (MscrmControls) {
    var OfficeProductivity;
    (function (OfficeProductivity) {
        'use strict';
        var ImageElement = (function () {
            function ImageElement(context, notifyOutputChanged) {
                this._context = context;
                this._notifyOutputChanged = notifyOutputChanged || (function () { });
                // reading the control's src value
                this.imgSrc = this._context.parameters.imgSrc.raw;
                this.imgAltText = this._context.parameters.imgAltText.raw;
            }
            ImageElement.prototype.render = function () {
                // reading the control's src value
                this.imgSrc = this._context.parameters.imgSrc.raw;
                this.imgAltText = this._context.parameters.imgAltText.raw;
                return this.createImageElement(this.imgSrc);
            };
            /**
             * Creates the visualization foafter image
             */
            ImageElement.prototype.createImageElement = function (imgSrc) {
                var properties = {
                    id: "img_offcieproductivity",
                    title: this.imgAltText,
                    accessibilityLabel: this.imgAltText,
                    source: this.imgSrc,
                    style: {
                        width: "100%",
                        height: "100%",
                        justifyContent: "center",
                        alignItems: "center"
                    },
                    altText: this.imgAltText
                };
                var imageControl = this._context.factory.createElement("IMG", properties);
                return this._context.factory.createElement("CONTAINER", {
                    tabIndex: 0,
                    style: {
                        width: "100%",
                        height: "inherit",
                        justifyContent: "center",
                        alignItems: "center"
                    },
                    key: "imageContainer"
                }, imageControl);
            };
            return ImageElement;
        }());
        OfficeProductivity.ImageElement = ImageElement;
    })(OfficeProductivity = MscrmControls.OfficeProductivity || (MscrmControls.OfficeProductivity = {}));
})(MscrmControls || (MscrmControls = {}));
;
//# sourceMappingURL=ImageControl.js.map