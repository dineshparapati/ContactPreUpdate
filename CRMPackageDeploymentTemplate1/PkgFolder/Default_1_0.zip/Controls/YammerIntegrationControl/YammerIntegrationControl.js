/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../../references/internal/TypeDefinitions/CommonControl/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var YammerIntegration;
    (function (YammerIntegration) {
        'use strict';
        var YammerIntegrationControl = (function () {
            /**
             * Empty constructor.
             */
            function YammerIntegrationControl() {
                this.yammerDialogCloseEvent = "YammerDialogClose";
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            YammerIntegrationControl.prototype.init = function (context, notifyOutputChanged, state) {
                this.yammerContext = new YammerIntegration.YammerContext(context);
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            YammerIntegrationControl.prototype.updateView = function (context) {
                this.yammerContext.init();
                var contentGenerator = this.yammerContext.getContentRenderer();
                if (contentGenerator !== null) {
                    return contentGenerator.render(this.yammerContext);
                }
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            YammerIntegrationControl.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                return null;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            YammerIntegrationControl.prototype.destroy = function () {
                YammerIntegration.TelemetryHelper.report(this.yammerDialogCloseEvent, this.yammerContext.getContext(), "Yammer Dialog Closed");
            };
            return YammerIntegrationControl;
        }());
        YammerIntegration.YammerIntegrationControl = YammerIntegrationControl;
    })(YammerIntegration = MscrmControls.YammerIntegration || (MscrmControls.YammerIntegration = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="YammerIntegrationControl.ts" />
var MscrmControls;
(function (MscrmControls) {
    var YammerIntegration;
    (function (YammerIntegration) {
        'use strict';
        var EmbedErrors = (function () {
            function EmbedErrors() {
                this.yammerErrorElement = "YammerErrorElement";
                this.yammerErrorContainer = "YammerErrorContainer";
                this.headerLabel = "header_label";
                this.yammerIcon = "YammerIcon";
                this.yammerIconType = 336;
            }
            EmbedErrors.prototype.render = function (yammerContext) {
                var children = [];
                var errorMsg = this.getErrorMessage(yammerContext);
                children.push(yammerContext.getContext().factory.createElement("MICROSOFTICON", {
                    id: this.yammerIcon,
                    key: this.yammerIcon,
                    type: this.yammerIconType,
                    style: {
                        color: yammerContext.getContext().theming.colors.grays.gray05,
                        marginBottom: yammerContext.getContext().theming.measures.measure200,
                        fontSize: yammerContext.getContext().theming.fontsizes.font225
                    }
                }));
                children.push(yammerContext.getContext().factory.createElement("CONTAINER", {
                    id: this.headerLabel,
                    key: this.headerLabel,
                    accessibilityLabel: errorMsg,
                    style: {
                        fontSize: yammerContext.getContext().theming.fontsizes.font100,
                        fontColor: yammerContext.getContext().theming.colors.grays.gray05,
                        fontWeight: yammerContext.getContext().theming.fontfamilies.regular,
                        paddingLeft: yammerContext.getContext().theming.measures.measure150,
                        paddingRight: yammerContext.getContext().theming.measures.measure150,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "normal",
                        textAlign: "center",
                        flex: "1 1 auto",
                        width: "100%"
                    }
                }, errorMsg));
                var yammerErrorElement = yammerContext.getContext().factory.createElement("CONTAINER", {
                    id: this.yammerErrorElement,
                    key: this.yammerErrorElement,
                    style: {
                        "width": "100%",
                        "justifyContent": "center",
                        "alignItems": "center",
                        "margin": "-3rem 4rem 0 4rem",
                        "flexDirection": "column"
                    }
                }, children);
                return yammerContext.getContext().factory.createElement("CONTAINER", {
                    id: this.yammerErrorContainer,
                    key: this.yammerErrorContainer,
                    style: {
                        "width": "100%",
                        "height": "calc(" + yammerContext.getViewportSize().height + "px - 6.5rem)",
                        "alignItems": "center"
                    }
                }, yammerErrorElement);
            };
            EmbedErrors.prototype.getErrorMessage = function (yammerContext) {
                var errorCode = yammerContext.getErrorCode();
                var errorParams = null;
                if (errorCode.startsWith("[") && errorCode.endsWith("]")) {
                    errorParams = JSON.parse(yammerContext.getErrorCode());
                    errorCode = errorParams[0];
                    errorParams.shift();
                }
                var errorMsg = Xrm.Utility.getResourceString(Yammer.Constants.CommonWebResource, errorCode);
                if (errorParams !== null && errorParams.length > 0) {
                    errorMsg = EmbedErrors.format(errorMsg, errorParams);
                }
                return errorMsg;
            };
            EmbedErrors.format = function (str, args) {
                return str.replace(EmbedErrors.Regex, function (item) {
                    var intVal = parseInt(item.substring(1, item.length - 1));
                    var replace;
                    if (intVal >= 0) {
                        replace = args[intVal];
                    }
                    else if (intVal === -1) {
                        replace = "{";
                    }
                    else if (intVal === -2) {
                        replace = "}";
                    }
                    else {
                        replace = "";
                    }
                    return replace;
                });
            };
            ;
            return EmbedErrors;
        }());
        EmbedErrors.Regex = new RegExp("{-?[0-9]+}", "g");
        YammerIntegration.EmbedErrors = EmbedErrors;
    })(YammerIntegration = MscrmControls.YammerIntegration || (MscrmControls.YammerIntegration = {}));
})(MscrmControls || (MscrmControls = {}));
;
var MscrmControls;
(function (MscrmControls) {
    var YammerIntegration;
    (function (YammerIntegration) {
        var TelemetryConstants;
        (function (TelemetryConstants) {
            TelemetryConstants.EventName = "YammerEventName";
            TelemetryConstants.StartTime = "StartTime";
            TelemetryConstants.EndTime = "EndTime";
            TelemetryConstants.ExecutionTime = "ExecutionTime";
            TelemetryConstants.EventErrorCount = "ErrorCount";
            TelemetryConstants.EventErrorMessage = "ErrorMessage";
        })(TelemetryConstants = YammerIntegration.TelemetryConstants || (YammerIntegration.TelemetryConstants = {}));
    })(YammerIntegration = MscrmControls.YammerIntegration || (MscrmControls.YammerIntegration = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var YammerIntegration;
    (function (YammerIntegration) {
        var TelemetryHelper = (function () {
            function TelemetryHelper() {
            }
            TelemetryHelper.createEvent = function (eventName) {
                var event = new YammerIntegration.YammerEvent();
                var eventParameters = new Array();
                TelemetryHelper.addEventParameter(event, YammerIntegration.TelemetryConstants.EventName, eventName);
                event.eventName = eventName;
                var startTime = new Date();
                TelemetryHelper.addEventParameter(event, YammerIntegration.TelemetryConstants.StartTime, startTime);
                event.startTime = startTime;
                event.errorCount = 0;
                event.eventParameters = eventParameters;
                return event;
            };
            TelemetryHelper.addEventParameter = function (event, name, value) {
                try {
                    if (!Yammer.Util.IsNull(event) && !Yammer.Util.IsNull(event.eventName) && !Yammer.Util.IsNull(event.eventParameters) && !Yammer.Util.IsNull(name)) {
                        if (!Yammer.Util.IsNull(value)) {
                            var item = {
                                name: name,
                                value: value
                            };
                            event.eventParameters.push(item);
                        }
                        else {
                            var item = {
                                name: name + "_Time",
                                value: new Date()
                            };
                            event.eventParameters.push(item);
                        }
                    }
                }
                catch (Exception) {
                    console.assert(false, Exception.message);
                }
            };
            TelemetryHelper.report = function (componentName, context, name, value) {
                if (Yammer.Util.IsNull(componentName)) {
                    return false;
                }
                try {
                    var yammerEvent = TelemetryHelper.createEvent(componentName);
                    if (!Yammer.Util.IsNull(name)) {
                        TelemetryHelper.addEventParameter(yammerEvent, name, value);
                    }
                    if (context) {
                        TelemetryHelper.reportEvent(yammerEvent, context);
                    }
                    else {
                        TelemetryHelper.reportEvent(yammerEvent);
                    }
                }
                catch (Exception) {
                    console.assert(false, Exception.message);
                }
            };
            TelemetryHelper.reportErrorEvent = function (componentName, context, value) {
                if (Yammer.Util.IsNull(componentName)) {
                    return false;
                }
                try {
                    var yammerEvent = TelemetryHelper.createEvent(componentName);
                    if (!Yammer.Util.IsNull(value)) {
                        TelemetryHelper.addError(yammerEvent, value);
                    }
                    if (context) {
                        TelemetryHelper.reportEvent(yammerEvent, context);
                    }
                    else {
                        TelemetryHelper.reportEvent(yammerEvent);
                    }
                }
                catch (Exception) {
                    console.assert(false, Exception.message);
                }
            };
            TelemetryHelper.updateEventExecutionTime = function (event) {
                if (Yammer.Util.IsNull(event)) {
                    return false;
                }
                var currentEventName = event.eventName;
                var start = event.startTime;
                var end = new Date();
                try {
                    if (Yammer.Util.IsNull(currentEventName) || Yammer.Util.IsNull(start) || Yammer.Util.IsNull(event.eventParameters)) {
                        return false;
                    }
                    TelemetryHelper.addEventParameter(event, YammerIntegration.TelemetryConstants.EndTime, end);
                    TelemetryHelper.addEventParameter(event, YammerIntegration.TelemetryConstants.ExecutionTime, (end.valueOf() - start.valueOf()));
                    TelemetryHelper.addEventParameter(event, YammerIntegration.TelemetryConstants.EventErrorCount, event.errorCount);
                    return true;
                }
                catch (Exception) {
                    console.assert(false, Exception.message);
                    return false;
                }
            };
            TelemetryHelper.addError = function (event, value) {
                var errorCount = 0;
                try {
                    if (!Yammer.Util.IsNull(event) && !Yammer.Util.IsNull(event.eventParameters)) {
                        var errorCount_1 = event.errorCount;
                        event.errorCount = errorCount_1 + 1;
                        TelemetryHelper.addEventParameter(event, YammerIntegration.TelemetryConstants.EventErrorMessage + (errorCount_1 + 1), value);
                    }
                }
                catch (Exception) {
                    console.assert(false, Exception.message);
                }
            };
            TelemetryHelper.isErrorEvent = function (event) {
                try {
                    if (!Yammer.Util.IsNull(event) && !Yammer.Util.IsNull(event.errorCount)) {
                        return event.errorCount > 0;
                    }
                }
                catch (Exception) {
                    console.assert(false, Exception.message);
                }
                return false;
            };
            TelemetryHelper.reportEvent = function (event, context) {
                if (Yammer.Util.IsNull(event) && Yammer.Util.IsNull(event.eventParameters)) {
                    return;
                }
                try {
                    if (context && context.reporting) {
                        TelemetryHelper.updateEventExecutionTime(event);
                        if (!TelemetryHelper.isErrorEvent(event)) {
                            context.reporting.reportSuccess(event.eventName, event.eventParameters);
                        }
                        else {
                            context.reporting.reportFailure(event.eventName, Error(event.eventName), "Check the stacktrace", event.eventParameters);
                        }
                    }
                    else if (Xrm && Xrm.Reporting) {
                        TelemetryHelper.updateEventExecutionTime(event);
                        if (!TelemetryHelper.isErrorEvent(event)) {
                            Xrm.Reporting.reportSuccess(event.eventName, event.eventParameters);
                        }
                        else {
                            Xrm.Reporting.reportFailure(event.eventName, Error(event.eventName), "Check the stacktrace", event.eventParameters);
                        }
                    }
                }
                catch (Exception) {
                    console.assert(false, Exception.message);
                }
            };
            return TelemetryHelper;
        }());
        YammerIntegration.TelemetryHelper = TelemetryHelper;
    })(YammerIntegration = MscrmControls.YammerIntegration || (MscrmControls.YammerIntegration = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var YammerIntegration;
    (function (YammerIntegration) {
        var YammerEvent = (function () {
            function YammerEvent() {
            }
            return YammerEvent;
        }());
        YammerIntegration.YammerEvent = YammerEvent;
    })(YammerIntegration = MscrmControls.YammerIntegration || (MscrmControls.YammerIntegration = {}));
})(MscrmControls || (MscrmControls = {}));
var Yammer;
(function (Yammer) {
    var YammerConfiguration = (function () {
        function YammerConfiguration(feedType, yammerNetwork, yammerGroupId, yammerEmailAddress, entityId, entityType, entityName, yammerPostMethod) {
            this.config_useSSo = true;
            this.config_header = false;
            this.config_defaultGroupId = "";
            this.container = "";
            this.network = "";
            this.objectProperties = {};
            this.users = [];
            this.feedId = "";
            this.feedType = "";
            this.isPrivate = false;
            this.objectProperties_type = "";
            this.objectProperties_title = "";
            this.objectProperties_url = "";
            this.objectProperties_description = "";
            this.container = '.' + YammerConfiguration.YammerEmbedContainer;
            this.config_defaultGroupId = yammerGroupId;
            this.network = yammerNetwork;
            this.objectProperties_url = this.createNavigationUrl(entityType, entityId);
            this.objectProperties_type = entityType;
            this.objectProperties_title = entityName;
            this.feedType = feedType;
            this.yammerPostMethod = yammerPostMethod;
            this.users[0] = {
                email: "'" + yammerEmailAddress + "'"
            };
        }
        YammerConfiguration.prototype.createNavigationUrl = function (entityType, entityId) {
            var entityUrl = Xrm.Utility.getGlobalContext().getClientUrl();
            if (entityUrl) {
                entityUrl = entityUrl + "/main.aspx?etn=" + entityType;
                entityUrl = entityUrl + "&id=" + encodeURI(entityId).toLowerCase();
                entityUrl = entityUrl + "&pagetype=entityrecord";
            }
            return entityUrl;
        };
        YammerConfiguration.prototype.getYammerConfiguration = function () {
            var yammerConfiguration = {};
            yammerConfiguration = {
                config: {
                    use_sso: this.config_useSSo,
                    header: this.config_header
                },
                container: this.container,
                network: this.network
            };
            if (!Yammer.Util.IsNull(this.config_defaultGroupId) && parseInt(this.config_defaultGroupId) !== 0) {
                yammerConfiguration.config.defaultGroupId = this.config_defaultGroupId;
            }
            //Setting this in case of only feed type open-graph
            if (this.feedType === Yammer.Constants.FeedType_OpenGraph) {
                yammerConfiguration.feedType = this.feedType;
                yammerConfiguration.objectProperties = {
                    title: this.objectProperties_title,
                    type: this.objectProperties_type,
                    url: this.objectProperties_url,
                    description: this.objectProperties_description
                };
                if (this.yammerPostMethod === Yammer.Constants.YammerPostMethod_Private) {
                    yammerConfiguration.private = true;
                    yammerConfiguration.users = this.users;
                }
            }
            ;
            //Setting this in case of only feed type group
            if (this.feedType === Yammer.Constants.FeedType_Group && !Yammer.Util.IsNull(this.config_defaultGroupId) && parseInt(this.config_defaultGroupId) !== 0) {
                yammerConfiguration.feedType = this.feedType;
                yammerConfiguration.feedId = this.config_defaultGroupId;
            }
            return yammerConfiguration;
        };
        return YammerConfiguration;
    }());
    YammerConfiguration.YammerEmbedContainer = "YammerEmbedContainer";
    Yammer.YammerConfiguration = YammerConfiguration;
})(Yammer || (Yammer = {}));
var MscrmControls;
(function (MscrmControls) {
    var YammerIntegration;
    (function (YammerIntegration) {
        'use strict';
        var YammerContext = (function () {
            function YammerContext(context) {
                this.openYammerDialogEvent = "OpenYammerDialog";
                this.context = context;
            }
            YammerContext.prototype.init = function () {
                if (this.context.parameters) {
                    if (this.context.parameters.feedType && this.context.parameters.feedType.raw) {
                        this.feedType = this.context.parameters.feedType.raw;
                    }
                    if (this.context.parameters.yammerNetwork && this.context.parameters.yammerNetwork.raw) {
                        this.yammerNetwork = this.context.parameters.yammerNetwork.raw;
                    }
                    if (this.context.parameters.yammerGroupId && this.context.parameters.yammerGroupId.raw) {
                        this.yammerGroupId = this.context.parameters.yammerGroupId.raw;
                    }
                    if (this.context.parameters.yammerUserId && this.context.parameters.yammerUserId.raw) {
                        this.yammerUserId = this.context.parameters.yammerUserId.raw;
                    }
                    if (this.context.parameters.yammerEmailAddress && this.context.parameters.yammerEmailAddress.raw) {
                        this.yammerEmailAddress = this.context.parameters.yammerEmailAddress.raw;
                    }
                    if (this.context.parameters.postFollowed && !Yammer.Util.IsNull(this.context.parameters.postFollowed.raw)) {
                        this.postFollowed = parseInt(this.context.parameters.postFollowed.raw);
                    }
                    if (this.context.parameters.yammerPostState && !Yammer.Util.IsNull(this.context.parameters.yammerPostState.raw)) {
                        this.yammerPostState = parseInt(this.context.parameters.yammerPostState.raw);
                    }
                    if (this.context.parameters.domainName && this.context.parameters.domainName.raw) {
                        this.domainName = this.context.parameters.domainName.raw;
                    }
                    if (this.context.parameters.errorCode && this.context.parameters.errorCode.raw) {
                        this.errorCode = this.context.parameters.errorCode.raw;
                    }
                    if (this.context.parameters.entityId && this.context.parameters.entityId.raw) {
                        this.entityId = this.context.parameters.entityId.raw;
                    }
                    if (this.context.parameters.entityName && this.context.parameters.entityName.raw) {
                        this.entityName = this.context.parameters.entityName.raw;
                    }
                    if (this.context.parameters.entityType && this.context.parameters.entityType.raw) {
                        this.entityType = this.context.parameters.entityType.raw;
                    }
                    if (this.context.parameters.yammerPostMethod && !Yammer.Util.IsNull(this.context.parameters.yammerPostMethod.raw)) {
                        this.yammerPostMethod = parseInt(this.context.parameters.yammerPostMethod.raw);
                    }
                }
                this.logTelemetry();
                this.validate();
            };
            YammerContext.prototype.logTelemetry = function () {
                if (!Yammer.Util.IsNull(this.feedType)) {
                    if (this.feedType === Yammer.Constants.FeedType_Group) {
                        this.yammerOpenedFrom = "Dashboard";
                    }
                    else if (this.feedType === Yammer.Constants.FeedType_OpenGraph) {
                        this.yammerOpenedFrom = "Entity";
                    }
                    YammerIntegration.TelemetryHelper.report(this.openYammerDialogEvent, this.context, "Open yammer dialog called from: " + this.yammerOpenedFrom);
                }
                else {
                    YammerIntegration.TelemetryHelper.report(this.openYammerDialogEvent, this.context, "Open yammer dialog: feed type should not be null");
                }
            };
            YammerContext.prototype.validate = function () {
                if (this.feedType === Yammer.Constants.FeedType_OpenGraph && Yammer.Util.IsNull(this.errorCode)) {
                    if (this.isUserDataAvailable() && this.isYammerInPrivateMode()) {
                        if (!this.postFollowed) {
                            this.errorCode = "Web.Tools.Yammer.NoFollowNoPermission";
                            YammerIntegration.TelemetryHelper.reportErrorEvent(YammerContext.YammerErrorEvent, this.context, "An error occurred due to Entity is not followed and User has clicked on Yammer button");
                        }
                        else {
                            if (this.yammerPostState !== Yammer.Constants.YammerPostState_Followed) {
                                this.errorCode = "Web.Tools.Yammer.FollowNotInYammer";
                                YammerIntegration.TelemetryHelper.reportErrorEvent(YammerContext.YammerErrorEvent, this.context, "An error occurred due to Entity is followed but before Yammer Configuration, So Entity should get unfollowed and Followed again to see Yammer Feed");
                            }
                        }
                    }
                }
            };
            YammerContext.prototype.isYammerInPrivateMode = function () {
                return this.yammerPostMethod === Yammer.Constants.YammerPostMethod_Private;
            };
            YammerContext.prototype.getContentRenderer = function () {
                if (Yammer.Util.IsNull(this.domainName)) {
                    return null;
                }
                if (!Yammer.Util.IsNull(this.errorCode)) {
                    if (this.errorCode === "YammerIntegration_Error_Text") {
                        YammerIntegration.TelemetryHelper.reportErrorEvent(YammerContext.YammerErrorEvent, this.context, "A Network error occurred");
                    }
                    return new YammerIntegration.EmbedErrors();
                }
                else {
                    if (this.isUserDataAvailable()) {
                        return new YammerIntegration.EmbedYammerFeeds();
                    }
                    else {
                        return new YammerIntegration.EmbedYammerLogin();
                    }
                }
            };
            YammerContext.prototype.isUserDataAvailable = function () {
                return !Yammer.Util.IsNull(this.yammerUserId) && !Yammer.Util.IsNull(this.yammerEmailAddress);
            };
            YammerContext.prototype.getContext = function () {
                return this.context;
            };
            YammerContext.prototype.getYammerUserId = function () {
                return this.yammerUserId;
            };
            YammerContext.prototype.setYammerUserId = function (yammerUserId) {
                this.yammerUserId = yammerUserId;
            };
            YammerContext.prototype.getYammerEmailAddress = function () {
                return this.yammerEmailAddress;
            };
            YammerContext.prototype.setYammerEmailAddress = function (yammerEmailAddress) {
                this.yammerEmailAddress = yammerEmailAddress;
            };
            YammerContext.prototype.getYammerConfiguration = function () {
                return new Yammer.YammerConfiguration(this.feedType, this.yammerNetwork, this.yammerGroupId, this.yammerEmailAddress, this.entityId, this.entityType, this.entityName, this.yammerPostMethod).getYammerConfiguration();
            };
            YammerContext.prototype.getDomainName = function () {
                return this.domainName;
            };
            YammerContext.prototype.getErrorCode = function () {
                return this.errorCode;
            };
            YammerContext.prototype.setErrorCode = function (errorCode) {
                this.errorCode = errorCode;
            };
            YammerContext.prototype.getViewportSize = function () {
                if (window.innerWidth != null) {
                    return {
                        width: window.innerWidth,
                        height: window.innerHeight
                    };
                }
                // For IE (or any browser) in Standards mode
                var document = window.document;
                if (document.compatMode == "CSS1Compat") {
                    return {
                        width: document.documentElement.clientWidth,
                        height: document.documentElement.clientHeight
                    };
                }
                // For browsers in Quirks mode
                return {
                    width: document.body.clientWidth,
                    height: document.body.clientHeight
                };
            };
            return YammerContext;
        }());
        YammerContext.YammerErrorEvent = "YammerErrorEvent";
        YammerIntegration.YammerContext = YammerContext;
    })(YammerIntegration = MscrmControls.YammerIntegration || (MscrmControls.YammerIntegration = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var YammerIntegration;
    (function (YammerIntegration) {
        'use strict';
        var EmbedYammerLogin = (function () {
            function EmbedYammerLogin() {
            }
            EmbedYammerLogin.prototype.render = function (yammerContext) {
                var children = [];
                children.push(this.createContent(yammerContext));
                return yammerContext.getContext().factory.createElement("CONTAINER", {
                    id: EmbedYammerLogin.YammerControlContainer,
                    key: EmbedYammerLogin.YammerControlContainer,
                    style: {
                        "width": "100%",
                        "justifyContent": "center",
                        "height": "calc(" + yammerContext.getViewportSize().height + "px - 6.5rem)",
                        "alignItems": "center"
                    }
                }, children);
            };
            EmbedYammerLogin.prototype.createContent = function (yammerContext) {
                var _this = this;
                return yammerContext.getContext().factory.createElement("CONTAINER", {
                    id: EmbedYammerLogin.ContainerId,
                    className: EmbedYammerLogin.ContainerClassName,
                    key: EmbedYammerLogin.ContainerKey,
                    style: {
                        "width": "10rem",
                        "justifyContent": "center",
                        "height": "4rem",
                        "marginTop": "-3rem"
                    },
                    onLoad: this.loadIframe(EmbedYammerLogin.YammerPlatformEmbedJsSdkUrl, function () { _this.showYammerLoginDialog(yammerContext); })
                });
            };
            EmbedYammerLogin.prototype.loadIframe = function (url, callback) {
                var script = document.createElement("script");
                script.type = "text/javascript";
                script.onload = function () { return callback(); };
                script.src = url;
                this.setYammerAppId();
                script.setAttribute("data-app-id", EmbedYammerLogin.YammerAppId);
                document.getElementsByTagName("body")[0].appendChild(script);
            };
            EmbedYammerLogin.prototype.setYammerAppId = function () {
                if (Xrm.Page.context && Xrm.Page.context.getClientUrl) {
                    var clientUrl = Xrm.Page.context.getClientUrl();
                    if (clientUrl.endsWith(EmbedYammerLogin.TieOrg)) {
                        EmbedYammerLogin.YammerAppId = EmbedYammerLogin.TieYammerAppId;
                    }
                }
            };
            EmbedYammerLogin.prototype.showYammerLoginDialog = function (yammerContext) {
                var YammerFeedContainer = document.querySelector("." + EmbedYammerLogin.ContainerClassName);
                if (!YammerFeedContainer.hasChildNodes()) {
                    window.yam.connect.loginButton('.' + EmbedYammerLogin.ContainerId, function (resp) {
                        YammerIntegration.TelemetryHelper.reportErrorEvent(EmbedYammerLogin.FirstTimeYammerLoginEvent, null, "Yammer Login button has shown to the new User who has not logged into Yammer before");
                        if (resp.authResponse) {
                            window.yam.platform.request({
                                url: EmbedYammerLogin.ApiCurrentJson,
                                method: "GET",
                                success: function (user) {
                                    var userId = user.id;
                                    var emailAddress = user.email;
                                    var entity = {
                                        "yammeruserid": "" + userId,
                                        "yammeremailaddress": emailAddress
                                    };
                                    var emailAddresses = "";
                                    if (!Yammer.Util.IsNull(Xrm.Page.data.attributes.get(Yammer.Constants.Param_DomainName))) {
                                        emailAddresses = Xrm.Page.data.attributes.get(Yammer.Constants.Param_DomainName).getValue();
                                    }
                                    if (!Yammer.Util.IsNull(emailAddresses) && EmbedYammerLogin.isUserMatched(emailAddress, emailAddresses)) {
                                        Xrm.WebApi.updateRecord(Yammer.Constants.Entity_SystemUser, Xrm.Page.context.userSettings.userId, entity).then(function (resp) {
                                            Xrm.Page.data.attributes.get(Yammer.Constants.Param_YammerUserId).setValue("" + userId);
                                            Xrm.Page.data.attributes.get(Yammer.Constants.Param_YammerEmailAddress).setValue(emailAddress);
                                            YammerIntegration.TelemetryHelper.report(EmbedYammerLogin.EmbedYammerLoginSuccessEvent, null, "YammerUserId and YammerEmailAddress data updated into the CRM DB for the user");
                                        }, function (fail) {
                                            YammerIntegration.TelemetryHelper.reportErrorEvent(EmbedYammerLogin.EmbedYammerLoginErrorEvent, null, "Error while updating record into CRM DB for YammerUserId and YammerEmailAddress: " + fail);
                                        });
                                    }
                                    else {
                                        window.yam.platform.logout(function () {
                                            var errorCodeWithParams = [];
                                            errorCodeWithParams[0] = Yammer.Constants.Resx_UserLoginMismatch;
                                            errorCodeWithParams[1] = emailAddress;
                                            Xrm.Page.data.attributes.get(Yammer.Constants.Param_ErrorCode).setValue(JSON.stringify(errorCodeWithParams));
                                            YammerIntegration.TelemetryHelper.reportErrorEvent(YammerIntegration.YammerContext.YammerErrorEvent, null, "An error occurred due to different email address used to sign in to Yammer");
                                        });
                                    }
                                },
                                error: function (user) {
                                    YammerIntegration.TelemetryHelper.reportErrorEvent(EmbedYammerLogin.EmbedYammerLoginErrorEvent, null, "Error while retrieving user's data from Yammer");
                                }
                            });
                        }
                    });
                }
            };
            EmbedYammerLogin.isUserMatched = function (yammerEmailAddress, domainName) {
                var emailAddressArray = JSON.parse(Xrm.Page.data.attributes.get(Yammer.Constants.Param_DomainName).getValue());
                if (emailAddressArray && yammerEmailAddress) {
                    for (var _i = 0, emailAddressArray_1 = emailAddressArray; _i < emailAddressArray_1.length; _i++) {
                        var emailAddress = emailAddressArray_1[_i];
                        if (emailAddress && yammerEmailAddress.toLowerCase() === emailAddress.toLowerCase()) {
                            return true;
                        }
                    }
                }
                return false;
            };
            return EmbedYammerLogin;
        }());
        EmbedYammerLogin.YammerControlContainer = "YammerControlContainer";
        EmbedYammerLogin.YammerPlatformEmbedJsSdkUrl = "https://c64.assets-yammer.com/assets/platform_js_sdk.js";
        EmbedYammerLogin.ContainerId = "YammerLoginContainer";
        EmbedYammerLogin.ContainerClassName = "YammerLoginContainer";
        EmbedYammerLogin.ContainerKey = "YammerLoginContainer";
        EmbedYammerLogin.EmbedYammerLoginErrorEvent = "EmbedYammerLoginErrorEvent";
        EmbedYammerLogin.EmbedYammerLoginSuccessEvent = "EmbedYammerLoginSuccessEvent";
        EmbedYammerLogin.FirstTimeYammerLoginEvent = "FirstTimeYammerLoginEvent";
        EmbedYammerLogin.ApiCurrentJson = "users/current.json";
        EmbedYammerLogin.YammerAppId = "e3HEvk9cqzVW4yyn8tIM3g";
        EmbedYammerLogin.TieYammerAppId = "Tu9tmRGd1QnzIxztDsfg";
        EmbedYammerLogin.TieOrg = "tie.com";
        YammerIntegration.EmbedYammerLogin = EmbedYammerLogin;
    })(YammerIntegration = MscrmControls.YammerIntegration || (MscrmControls.YammerIntegration = {}));
})(MscrmControls || (MscrmControls = {}));
;
var MscrmControls;
(function (MscrmControls) {
    var YammerIntegration;
    (function (YammerIntegration) {
        'use strict';
        var EmbedYammerFeeds = (function () {
            function EmbedYammerFeeds() {
            }
            EmbedYammerFeeds.prototype.render = function (yammerContext) {
                var children = [];
                children.push(this.createContent(yammerContext));
                //The below block code is required for keyboard users. This will loop the focus between yammer close button and yammer iframe region.			
                var hiddenLabel1 = yammerContext.getContext().factory.createElement("LABEL", {
                    id: "hidden_label1",
                    key: "hidden_label1",
                    accessibilityHidden: true,
                    onFocus: function () {
                        var buttonCollection = document.getElementsByTagName("button");
                        for (var i = 0; i < buttonCollection.length; i++) {
                            if (buttonCollection[i].id.indexOf(EmbedYammerFeeds.CloseIconName) != -1) {
                                buttonCollection[i].focus();
                            }
                        }
                    },
                    tabIndex: 0
                });
                var hiddenLabel2 = yammerContext.getContext().factory.createElement("LABEL", {
                    id: "hidden_label2",
                    key: "hidden_label2",
                    accessibilityHidden: true,
                    onFocus: function () {
                        document.getElementById("embed-feed").focus();
                    },
                    tabIndex: 0
                });
                children.push(hiddenLabel1);
                children.push(hiddenLabel2);
                return yammerContext.getContext().factory.createElement("CONTAINER", {
                    id: EmbedYammerFeeds.YammerControlContainer,
                    key: EmbedYammerFeeds.YammerControlContainer,
                    style: {
                        "width": "100%",
                        "justifyContent": "center",
                        "height": "calc(" + yammerContext.getViewportSize().height + "px - 6.5rem)"
                    }
                }, children);
            };
            EmbedYammerFeeds.prototype.createContent = function (yammerContext) {
                var _this = this;
                return yammerContext.getContext().factory.createElement("CONTAINER", {
                    id: EmbedYammerFeeds.ContainerId,
                    className: EmbedYammerFeeds.ContainerClassName,
                    key: EmbedYammerFeeds.ContainerKey,
                    style: {
                        "width": "inherit",
                        "height": "inherit"
                    },
                    onLoad: this.loadIframe(EmbedYammerFeeds.YammerPlatformEmbedJsSdkUrl, function (yammerConfiguration) { _this.renderYammerFeeds(yammerConfiguration, yammerContext); }, yammerContext.getYammerConfiguration())
                });
            };
            EmbedYammerFeeds.prototype.loadIframe = function (url, callback, yammerConfiguration) {
                var script = document.createElement("script");
                script.type = "text/javascript";
                script.onload = function () { return callback(yammerConfiguration); };
                script.src = url;
                document.getElementsByTagName("body")[0].appendChild(script);
            };
            EmbedYammerFeeds.prototype.renderYammerFeeds = function (yammerConfiguration, yammerContext) {
                var YammerFeedContainer = document.querySelector("." + EmbedYammerFeeds.ContainerClassName);
                if (!YammerFeedContainer.hasChildNodes()) {
                    window.yam.connect.embedFeed(yammerConfiguration);
                }
            };
            return EmbedYammerFeeds;
        }());
        EmbedYammerFeeds.YammerControlContainer = "YammerControlContainer";
        EmbedYammerFeeds.YammerPlatformEmbedJsSdkUrl = "https://c64.assets-yammer.com/assets/platform_js_sdk.js";
        EmbedYammerFeeds.ContainerId = "YammerEmbedContainer";
        EmbedYammerFeeds.ContainerClassName = "YammerEmbedContainer";
        EmbedYammerFeeds.ContainerKey = "YammerEmbedContainer";
        EmbedYammerFeeds.CloseIconName = "dialogCloseIconButton";
        YammerIntegration.EmbedYammerFeeds = EmbedYammerFeeds;
    })(YammerIntegration = MscrmControls.YammerIntegration || (MscrmControls.YammerIntegration = {}));
})(MscrmControls || (MscrmControls = {}));
;
var Yammer;
(function (Yammer) {
    var Util;
    (function (Util) {
        function IsNull(value) {
            return typeof (value) === 'undefined' || typeof (value) === 'unknown' || value === null;
        }
        Util.IsNull = IsNull;
    })(Util = Yammer.Util || (Yammer.Util = {}));
})(Yammer || (Yammer = {}));
var Yammer;
(function (Yammer) {
    'use strict';
    var Constants;
    (function (Constants) {
        Constants.Entity_SystemUser = "systemuser";
        Constants.Entity_Organization = "organization";
        Constants.Entity_PostFollow = "postfollow";
        Constants.Entity_PostConfig = "msdyn_postconfig";
        Constants.SystemUser_SystemUserId = "systemuserid";
        Constants.SystemUser_YammerEmailAddress = "yammeremailaddress";
        Constants.SystemUser_YammerUserId = "yammeruserid";
        Constants.SystemUser_WindowsLiveId = "windowsliveid";
        Constants.SystemUser_InternalEmailAddress = "internalemailaddress";
        Constants.SystemUser_PersonalEmailAddress = "personalemailaddress";
        Constants.SystemUser_MobileAlertEmail = "mobilealertemail";
        Constants.Organization_YammerNetworkPermalink = "yammernetworkpermalink";
        Constants.Organization_YammerGroupid = "yammergroupid";
        Constants.Organization_YammerOAuthAccessTokenExpired = "yammeroauthaccesstokenexpired";
        Constants.Organization_YammerPostMethod = "yammerpostmethod";
        Constants.Fetch_YammerOrgDetails = "?$select=" + Constants.Organization_YammerNetworkPermalink + "," + Constants.Organization_YammerGroupid + "," + Constants.Organization_YammerOAuthAccessTokenExpired + "," + Constants.Organization_YammerPostMethod;
        Constants.Fetch_YammerSystemUserDetails = "?$select=" + Constants.SystemUser_YammerUserId + "," + Constants.SystemUser_YammerEmailAddress + "," + Constants.SystemUser_SystemUserId + "," + Constants.SystemUser_WindowsLiveId + "," + Constants.SystemUser_InternalEmailAddress + "," + Constants.SystemUser_PersonalEmailAddress + "," + Constants.SystemUser_MobileAlertEmail;
        Constants.PostFollow_YammerPostState = "yammerpoststate";
        Constants.PostFollow_PostFollowId = "postfollowid";
        Constants.PostFollow_RegardingObjectId = "_regardingobjectid_value";
        Constants.PostFollow_OwnerId = "_ownerid_value";
        Constants.YammerPostMethod_Private = 1;
        Constants.YammerPostState_Followed = 1;
        Constants.Param_FeedType = "param_feedType";
        Constants.Param_YammerNetwork = "param_yammerNetwork";
        Constants.Param_YammerGroupId = "param_yammerGroupId";
        Constants.Param_YammerUserId = "param_yammerUserId";
        Constants.Param_YammerEmailAddress = "param_yammerEmailAddress";
        Constants.Param_DomainName = "param_domainName";
        Constants.Param_ErrorCode = "param_errorCode";
        Constants.Param_PostFollowed = "param_postFollowed";
        Constants.Param_YammerPostState = "param_yammerPostState";
        Constants.Param_EntityId = "param_entityId";
        Constants.Param_YammerPostMethod = "param_yammerPostMethod";
        Constants.FeedType_OpenGraph = "open-graph";
        Constants.FeedType_Group = "group";
        Constants.CommonWebResource = "msdyn_/Resources/YammerIntegration";
        Constants.Resx_GenericErrorCode = "YammerIntegration_Error_Text";
        Constants.Resx_UserLoginMismatch = "Error_Message_0x8004b016";
        Constants.Resx_Processing = "Msg_Progress_MOCA_Dialog";
        Constants.FCB_YammerPostsOnUCI = "YammerPostsOnUCI";
    })(Constants = Yammer.Constants || (Yammer.Constants = {}));
})(Yammer || (Yammer = {}));
//# sourceMappingURL=YammerIntegrationControl.js.map