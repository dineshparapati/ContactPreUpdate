var MscrmControls;
(function (MscrmControls) {
    var EKSearch;
    (function (EKSearch) {
        var EmbeddedKnowledgeSearchConstants = (function () {
            function EmbeddedKnowledgeSearchConstants() {
            }
            return EmbeddedKnowledgeSearchConstants;
        }());
        // Constants for element ids
        EmbeddedKnowledgeSearchConstants.DualListContainerId = "EKSEntityDualListContainer";
        EmbeddedKnowledgeSearchConstants.DualListId = "EKSEntityDualList";
        EmbeddedKnowledgeSearchConstants.MainContainerId = "EKSMainContainer";
        // Constants for urls
        EmbeddedKnowledgeSearchConstants.UpdateEntityUrl = "/api/data/v9.0/EntityDefinitions";
        EmbeddedKnowledgeSearchConstants.BatchUrl = "/api/data/v9.0/$batch";
        EmbeddedKnowledgeSearchConstants.KMSettingsFilter = "?$select=kmsettings";
        // Entity names
        EmbeddedKnowledgeSearchConstants.Organization = "organization";
        EKSearch.EmbeddedKnowledgeSearchConstants = EmbeddedKnowledgeSearchConstants;
    })(EKSearch = MscrmControls.EKSearch || (MscrmControls.EKSearch = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var EKSearch;
    (function (EKSearch) {
        'use strict';
        var EKSearchControl = (function () {
            function EKSearchControl() {
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             */
            EKSearchControl.prototype.init = function (context, notifyOutputChanged, state) {
                this._context = context;
                EKSearch.EmbeddedKnowledgeSearchStyles.initialize(this._context.theming, this._context.client.isRTL);
                this._notifyOutputChanged = notifyOutputChanged;
                if (this._context.utils.isNullOrUndefined(this._EKSearchModel)) {
                    this._EKSearchModel = new EKSearch.EmbeddedKnowledgeSearchModel(context);
                }
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            EKSearchControl.prototype.updateView = function (context) {
                return this.getChildControls(context);
            };
            EKSearchControl.prototype.getChildControls = function (context) {
                this._context = context;
                var innerBodyContainer = null;
                if (this._context.utils.isNullOrUndefined(this._EKSearchModel)) {
                    this._EKSearchModel = new EKSearch.EmbeddedKnowledgeSearchModel(context);
                }
                else if (this._EKSearchModel.AllEntities.length > 0) {
                    innerBodyContainer = this.RenderMainPage();
                }
                return innerBodyContainer;
            };
            EKSearchControl.prototype.RenderMainPage = function () {
                // Setting properties for dual selection list
                var properties = {
                    "parameters": {
                        JsonOptions: {
                            Usage: 3,
                            Static: true,
                            Type: "SingleLine.Text",
                            Value: JSON.stringify(this._EKSearchModel.AllEntities.map(function (c) {
                                return {
                                    Id: c.LogicalName, DisplayName: c.DisplayName
                                };
                            })),
                            Attributes: {
                                DisplayName: null,
                                LogicalName: "all_attributes",
                                Type: "string",
                                IsSecured: false,
                                RequiredLevel: 0,
                                MaxLength: 2147483647,
                                EntityLogicalName: "",
                                Format: "text",
                                ImeMode: -1,
                                Behavior: null
                            }
                        },
                        Selection: {
                            Usage: 3,
                            Static: true,
                            Type: "SingleLine.Text",
                            Value: this._EKSearchModel.SelectedEntities,
                            Callback: this.DualListSelectionCallback.bind(this),
                            Attributes: {
                                DisplayName: null,
                                LogicalName: "cc_selectedAttributes_id",
                                Type: "string",
                                IsSecured: false,
                                RequiredLevel: 0,
                                MaxLength: 2147483647,
                                EntityLogicalName: "",
                                Format: null,
                                ImeMode: -1,
                                Behavior: null
                            }
                        },
                        SelectionOrderBy: {
                            Value: 2,
                            Usage: 3,
                            Static: true,
                            Type: "Enum",
                            Attributes: {},
                        },
                        OptionSet: {
                            Usage: 3,
                            Static: true,
                            Type: null,
                            attributes: {},
                        }
                    }
                };
                // Creating dual list container
                var dualListContainer = this._context.factory.createElement("CONTAINER", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.DualListContainerId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.DualListContainerId,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.dualListContainer
                }, [this._context.factory.createComponent("MscrmControls.DualListSelection.DualListSelectionControl", EKSearch.EmbeddedKnowledgeSearchConstants.DualListId, properties)]);
                // Creating main container and adding all elements into it
                var mainContainer = this._context.factory.createElement("CONTAINER", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.MainContainerId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.MainContainerId,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.mainContainer
                }, dualListContainer);
                return mainContainer;
            };
            EKSearchControl.prototype.DualListSelectionCallback = function (selectedValues) {
                this._EKSearchModel.SelectedEntities = selectedValues;
                this.notifyOutputChangeAndRequestRerender();
            };
            EKSearchControl.prototype.notifyOutputChangeAndRequestRerender = function () {
                this._notifyOutputChanged();
                this._context.utils.requestRender();
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            EKSearchControl.prototype.getOutputs = function () {
                return null;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            EKSearchControl.prototype.destroy = function () {
            };
            return EKSearchControl;
        }());
        EKSearch.EKSearchControl = EKSearchControl;
    })(EKSearch = MscrmControls.EKSearch || (MscrmControls.EKSearch = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * IMPORTANT!
 * DO NOT MAKE CHANGES TO THIS FILE - THIS FILE IS AUTO-GENERATED FROM ODATA CSDL METADATA DOCUMENT
 * SEE https://msdn.microsoft.com/en-us/library/mt607990.aspx FOR MORE INFORMATION
 */
var ODataContract;
(function (ODataContract) {
    /* tslint:disable:crm-force-fields-private */
    var RetrieveEmbeddedKMSearchCanBeEnabledEntitiesRequest = (function () {
        function RetrieveEmbeddedKMSearchCanBeEnabledEntitiesRequest() {
        }
        RetrieveEmbeddedKMSearchCanBeEnabledEntitiesRequest.prototype.getMetadata = function () {
            var metadata = {
                boundParameter: null,
                parameterTypes: {},
                operationName: "RetrieveEmbeddedKMSearchCanBeEnabledEntities",
                operationType: 1,
            };
            return metadata;
        };
        return RetrieveEmbeddedKMSearchCanBeEnabledEntitiesRequest;
    }());
    ODataContract.RetrieveEmbeddedKMSearchCanBeEnabledEntitiesRequest = RetrieveEmbeddedKMSearchCanBeEnabledEntitiesRequest;
})(ODataContract || (ODataContract = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../TypeDefinitions/AppCommon/Controls/FREShell/libs/FREShell.d.ts" />
/// <reference path="../../../../../references/internal/TypeDefinitions/CommonControl/CommonControl.d.ts" />
/// <reference path="../../ServiceClientCommon/DataContracts/Function/RetrieveEmbeddedKMSearchCanBeEnabledEntitiesRequest.ts" />
/// <reference path="PrivateReferences.ts" />
var MscrmControls;
(function (MscrmControls) {
    var EKSearch;
    (function (EKSearch) {
        var EmbeddedKnowledgeSearchModel = (function () {
            function EmbeddedKnowledgeSearchModel(context) {
                this._allEntities = [];
                this._selectedEntities = "";
                this._initiallySelectedEntities = "";
                this._context = context;
                this.initialize();
            }
            Object.defineProperty(EmbeddedKnowledgeSearchModel.prototype, "AllEntities", {
                get: function () {
                    return this._allEntities;
                },
                set: function (value) {
                    this._allEntities = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EmbeddedKnowledgeSearchModel.prototype, "SelectedEntities", {
                get: function () {
                    return this._selectedEntities;
                },
                set: function (value) {
                    this._selectedEntities = value;
                    this.setSelectedEntitiesAttribute();
                },
                enumerable: true,
                configurable: true
            });
            EmbeddedKnowledgeSearchModel.prototype.initialize = function () {
                var _this = this;
                var request = new ODataContract.RetrieveEmbeddedKMSearchCanBeEnabledEntitiesRequest();
                Xrm.WebApi.online.execute(request).then(function (response) {
                    if (!_this._context.utils.isNullOrUndefined(response)) {
                        response.json().then(function (jsonResponse) {
                            if (!_this._context.utils.isNullOrUndefined(jsonResponse.Result)) {
                                _this.createEntitiesFromJsonResponse(JSON.parse(jsonResponse.Result));
                                _this._context.utils.requestRender();
                            }
                        });
                    }
                }, function (error) {
                    //TODO Log telemetry (Task Id 1131504)
                });
                // Retrieve KM settings from organization table
                this._context.webAPI.retrieveMultipleRecords(EKSearch.EmbeddedKnowledgeSearchConstants.Organization, EKSearch.EmbeddedKnowledgeSearchConstants.KMSettingsFilter).then(function (response) {
                    _this._organizationId = (response.entities)[0].organizationid;
                    _this.intializeKMSettings((response.entities)[0].kmsettings);
                    _this._context.utils.requestRender();
                }, function (error) {
                    //TODO Log telemetry (Task Id 1131504)
                });
                this.setSaveEntitiesBatchUrlAttribute();
                this.setUpdateEntityUrlAttribute();
            };
            EmbeddedKnowledgeSearchModel.prototype.intializeKMSettings = function (kmsettingsxml) {
                if (!this._context.utils.isNullOrUndefined(kmsettingsxml)) {
                    var kmsettings = void 0;
                    if (window.DOMParser) {
                        var parser = new DOMParser();
                        kmsettings = parser.parseFromString(kmsettingsxml, "application/xml");
                    }
                    else {
                        kmsettings = new ActiveXObject("Microsoft.XMLDOM");
                        kmsettings.async = false;
                        kmsettings.loadXML(kmsettingsxml);
                    }
                    if (kmsettings.getElementsByTagName("UseExternalPortal")[0] && kmsettings.getElementsByTagName("UseExternalPortal")[0].childNodes[0]) {
                        var useExternalPortal = kmsettings.getElementsByTagName("UseExternalPortal")[0].childNodes[0].nodeValue == 'true' ? true : false;
                        Xrm.Page.data.attributes.get("radio_use_external_portal").setValue(useExternalPortal);
                    }
                    if (kmsettings.getElementsByTagName("NativeCrmUrl")[0] && kmsettings.getElementsByTagName("NativeCrmUrl")[0].childNodes[0]) {
                        var nativeCrmUrl = kmsettings.getElementsByTagName("NativeCrmUrl")[0].childNodes[0].nodeValue;
                        Xrm.Page.data.attributes.get("textbox_external_portal_url").setValue(nativeCrmUrl);
                    }
                }
            };
            // Method extracts required information from the json data and creates entities out of it
            EmbeddedKnowledgeSearchModel.prototype.createEntitiesFromJsonResponse = function (data) {
                for (var i = 0; i < data.length; i++) {
                    if (this._context.utils.isNullOrUndefined(data[i].UserLocalizedLabel))
                        continue;
                    var entity = new Entity;
                    entity.Id = data[i].MetadataId;
                    entity.LogicalName = data[i].LogicalName;
                    entity.DisplayName = data[i].UserLocalizedLabel;
                    entity.IsKnowledgeManagementEnabled = data[i].IsKnowledgeManagementEnabled;
                    this._allEntities.push(entity);
                    if (entity.IsKnowledgeManagementEnabled) {
                        this._initiallySelectedEntities = this._initiallySelectedEntities + ',' + entity.LogicalName;
                    }
                }
                this._allEntities = this._allEntities.sort(function (a, b) { return a.DisplayName.localeCompare(b.DisplayName); });
                this._selectedEntities = this._initiallySelectedEntities;
                this.setAllEntititesAttribute();
                this.setInitiallySelectedEntitiesAttribute();
                this.setSelectedEntitiesAttribute();
            };
            EmbeddedKnowledgeSearchModel.prototype.setAllEntititesAttribute = function () {
                var allEntities = JSON.stringify(this._allEntities.map(function (entity) {
                    return {
                        Id: entity.Id, DisplayName: entity.DisplayName, LogicalName: entity.LogicalName, IsKnowledgeManagementEnabled: entity.IsKnowledgeManagementEnabled
                    };
                }));
                var allEntitiesAttribute = Xrm.Page.data.attributes.get("allentities");
                allEntitiesAttribute.setValue(allEntities);
            };
            EmbeddedKnowledgeSearchModel.prototype.setInitiallySelectedEntitiesAttribute = function () {
                var initiallySelectedEntitiesAttribute = Xrm.Page.data.attributes.get("initiallyselectedentities");
                initiallySelectedEntitiesAttribute.setValue(this._initiallySelectedEntities);
            };
            EmbeddedKnowledgeSearchModel.prototype.setSelectedEntitiesAttribute = function () {
                var selectedEntitiesAttribute = Xrm.Page.data.attributes.get("selectedentities");
                selectedEntitiesAttribute.setValue(this._selectedEntities);
            };
            EmbeddedKnowledgeSearchModel.prototype.setSaveEntitiesBatchUrlAttribute = function () {
                var saveEntitiesBatchUrlAttribute = Xrm.Page.data.attributes.get("saveentitiesbatchurl");
                saveEntitiesBatchUrlAttribute.setValue(this._context.utils.createCrmUri(EKSearch.EmbeddedKnowledgeSearchConstants.BatchUrl));
            };
            EmbeddedKnowledgeSearchModel.prototype.setUpdateEntityUrlAttribute = function () {
                var updateEntityUrlAttribute = Xrm.Page.data.attributes.get("updateentityurl");
                updateEntityUrlAttribute.setValue(this._context.utils.createCrmUri(EKSearch.EmbeddedKnowledgeSearchConstants.UpdateEntityUrl));
            };
            return EmbeddedKnowledgeSearchModel;
        }());
        EKSearch.EmbeddedKnowledgeSearchModel = EmbeddedKnowledgeSearchModel;
        var Entity = (function () {
            function Entity() {
            }
            return Entity;
        }());
        EKSearch.Entity = Entity;
    })(EKSearch = MscrmControls.EKSearch || (MscrmControls.EKSearch = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var EKSearch;
    (function (EKSearch) {
        'use strict';
        var EmbeddedKnowledgeSearchStyles = (function () {
            function EmbeddedKnowledgeSearchStyles() {
            }
            EmbeddedKnowledgeSearchStyles.initialize = function (theming, isRTL) {
                EmbeddedKnowledgeSearchStyles.dualListContainer = {
                    marginTop: theming.measures.measure150
                };
                EmbeddedKnowledgeSearchStyles.mainContainer = {
                    fontFamily: theming.fontfamilies.regular,
                    color: theming.colors.grays.gray07,
                    display: "block",
                    textAlign: "justify",
                    width: "100%",
                    overflow: "auto"
                };
            };
            return EmbeddedKnowledgeSearchStyles;
        }());
        EmbeddedKnowledgeSearchStyles.dualListContainer = {};
        EmbeddedKnowledgeSearchStyles.mainContainer = {};
        EKSearch.EmbeddedKnowledgeSearchStyles = EmbeddedKnowledgeSearchStyles;
    })(EKSearch = MscrmControls.EKSearch || (MscrmControls.EKSearch = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=EmbeddedKnowledgeSearchControl.js.map