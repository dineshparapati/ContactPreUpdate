/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var LinkedInExtensionControls;
(function (LinkedInExtensionControls) {
    var JQueryHierarchy;
    (function (JQueryHierarchy) {
        'use strict';
        var JQueryHierarchyControl = (function () {
            /**
             * Empty constructor.
             */
            function JQueryHierarchyControl() {
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            JQueryHierarchyControl.prototype.init = function (context, notifyOutputChanged, state, container) {
                this._context = context;
                this._orgChartContext = null;
                this._container = container;
                this._notifyOutputChanged = notifyOutputChanged || (function () { return; });
                this._jqueryHierarchyCtrlOutput = {};
                this._inputParams = new JQueryHierarchy.InputParameters(context);
                this._localizedLabels = this.getLocalizedLabels();
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            JQueryHierarchyControl.prototype.updateView = function (context) {
                // store 'this' belonging to the JQueryHierarchyControl
                var uclientControlThis = this;
                this._inputParams = new JQueryHierarchy.InputParameters(context);
                var options = {
                    'data': this._inputParams.JsonData,
                    'nodeContent': 'title',
                    'draggable': this._inputParams.AllowDragDrop,
                    'pan': this._inputParams.AllowPan,
                    'zoom': this._inputParams.AllowZoom,
                    'loadChildrenFromJsonData': this._inputParams.LoadChildrenFromJsonData,
                    'primaryField': this._inputParams.PrimaryField,
                    'nodeTemplate': this._inputParams.NodeTemplateFn,
                    'createNode': function ($node, data) {
                        $node.on('click', uclientControlThis.nodeClickHandler.bind(uclientControlThis, $node, data, 'singleClick'));
                        $node.on('dblclick', uclientControlThis.nodeClickHandler.bind(uclientControlThis, $node, data, 'dblClick'));
                        $node.keypress(data, uclientControlThis.nodeKeyPressHandler.bind(uclientControlThis, $node));
                        //create a custom event for node focus out
                        $node.on('nodeFocusOut', uclientControlThis.nodeFocusOut.bind(uclientControlThis));
                    },
                    'dropCriteria': function ($draggedNode, $dragZone, $dropZone) {
                        // to stop drop of node under its current parent itself
                        if ($draggedNode.data().nodeData.id && $dragZone.data().nodeData.id == $dropZone.data().nodeData.id) {
                            return false;
                        }
                        return true;
                    },
                    'localizedLabels': this._localizedLabels
                };
                if (this._container && this._container.childElementCount == 1) {
                    // UCI infra is re-rendering the control on user interactions(dbl click). Block such calls and only re-render if the call is via consuming control (CreateComponent -> init)
                    return;
                }
                else {
                    // create a dummy element with id "chart-container"
                    var root = document.createElement("div");
                    root.id = "chart-container";
                    // invoke JQuery control's constructor and get the updated root with class 'orgchart'
                    this._orgChartContext = $().orgchart(root, options);
                    this._orgChartContext.$chart.on('nodedrop.orgchart', uclientControlThis.nodeDrop.bind(uclientControlThis));
                    // append the root to the DOM element received in the standard UCI control.
                    this._container.appendChild(root);
                    // notify the init event with required outputs.
                    this._jqueryHierarchyCtrlOutput.context = this._orgChartContext;
                    this._jqueryHierarchyCtrlOutput.event = 'init';
                    this._notifyOutputChanged();
                }
            };
            JQueryHierarchyControl.prototype.getLocalizedLabels = function () {
                return {
                    'BottomArrowCollapseTitle': this._context.resources.getString(JQueryHierarchy.ResourceKeys.BottomArrowCollapseTitle),
                    'BottomArrowExpandTitle': this._context.resources.getString(JQueryHierarchy.ResourceKeys.BottomArrowExpandTitle),
                    'LeftArrowCollapseTitle': this._context.resources.getString(JQueryHierarchy.ResourceKeys.LeftArrowCollapseTitle),
                    'LeftArrowExpandTitle': this._context.resources.getString(JQueryHierarchy.ResourceKeys.LeftArrowExpandTitle),
                    'TopArrowExpandTitle': this._context.resources.getString(JQueryHierarchy.ResourceKeys.TopArrowExpandTitle),
                    'TopArrowCollapseTitle': this._context.resources.getString(JQueryHierarchy.ResourceKeys.TopArrowCollapseTitle),
                    'RightArrowExpandTitle': this._context.resources.getString(JQueryHierarchy.ResourceKeys.RightArrowExpandTitle),
                    'RightArrowCollapseTitle': this._context.resources.getString(JQueryHierarchy.ResourceKeys.RightArrowCollapseTitle),
                    'ChildrenCollapsedLabel': this._context.resources.getString(JQueryHierarchy.ResourceKeys.ChildrenCollapsedLabel),
                    'ChildrenExpandedLabel': this._context.resources.getString(JQueryHierarchy.ResourceKeys.ChildrenExpandedLabel),
                    'SiblingsCollapsedLabel': this._context.resources.getString(JQueryHierarchy.ResourceKeys.SiblingsCollapsedLabel),
                    'SiblingsExpandedLabel': this._context.resources.getString(JQueryHierarchy.ResourceKeys.SiblingsExpandedLabel),
                    'ParentExpandedLabel': this._context.resources.getString(JQueryHierarchy.ResourceKeys.ParentExpandedLabel),
                    'ParentCollapsedLabel': this._context.resources.getString(JQueryHierarchy.ResourceKeys.ParentCollapsedLabel),
                    'NumberOfDirectReportsLabel': this._context.resources.getString(JQueryHierarchy.ResourceKeys.NumberOfDirectReportsLabel),
                    'OrgChartNavigationHelp': this._context.resources.getString(JQueryHierarchy.ResourceKeys.OrgChartNavigationHelp)
                };
            };
            /**
             * This function handles the keyboard press events.
             */
            JQueryHierarchyControl.prototype.nodeKeyPressHandler = function (currentNode, event) {
                if (event.keyCode == '13') {
                    if ($(event.target).hasClass('focused')) {
                        //handle double click for already focussed nodes
                        this.nodeClickHandler(currentNode, event.data, 'dblClick');
                        // stop the single click event from executing.
                        event.preventDefault();
                    }
                }
            };
            /**
             * This function handles the focus out event for the nodes.
             */
            JQueryHierarchyControl.prototype.nodeFocusOut = function () {
                this._jqueryHierarchyCtrlOutput.event = 'nodeFocusOut';
                this._notifyOutputChanged();
            };
            /**
             * This function handles the single click event for the nodes.
             */
            JQueryHierarchyControl.prototype.nodeClickHandler = function (currentNode, currentNodeData, clickType) {
                this._jqueryHierarchyCtrlOutput.node = currentNode;
                this._jqueryHierarchyCtrlOutput.nodeData = currentNodeData;
                this._jqueryHierarchyCtrlOutput.event = clickType;
                this._notifyOutputChanged();
            };
            /**
             * This function handles the drag and drop event for the nodes.
             */
            JQueryHierarchyControl.prototype.nodeDrop = function (event, dragDropData) {
                this._jqueryHierarchyCtrlOutput.event = event.type;
                this._jqueryHierarchyCtrlOutput.dragDropData = dragDropData;
                this._notifyOutputChanged();
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            JQueryHierarchyControl.prototype.getOutputs = function () {
                return {
                    ControlOutput: this._jqueryHierarchyCtrlOutput
                };
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            JQueryHierarchyControl.prototype.destroy = function () {
                this._notifyOutputChanged = null;
                this._jqueryHierarchyCtrlOutput = null;
            };
            return JQueryHierarchyControl;
        }());
        JQueryHierarchy.JQueryHierarchyControl = JQueryHierarchyControl;
    })(JQueryHierarchy = LinkedInExtensionControls.JQueryHierarchy || (LinkedInExtensionControls.JQueryHierarchy = {}));
})(LinkedInExtensionControls || (LinkedInExtensionControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="JQueryHierarchyControl.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var LinkedInExtensionControls;
(function (LinkedInExtensionControls) {
    var JQueryHierarchy;
    (function (JQueryHierarchy) {
        'use strict';
        var InputParameters = (function () {
            function InputParameters(context) {
                if (context.parameters) {
                    if (context.parameters.JsonData == null || context.parameters.JsonData.raw == null
                        || context.parameters.NodeTemplateFn == null || context.parameters.NodeTemplateFn.raw == null) {
                        throw new Error("One or more mandatory inputs were was not specified");
                    }
                    this.JsonData = context.parameters.JsonData.raw;
                    this.NodeTemplateFn = context.parameters.NodeTemplateFn.raw;
                    this.AllowDragDrop = (context.parameters.AllowDragDrop.raw == null) ? false : context.parameters.AllowDragDrop.raw;
                    this.AllowPan = (context.parameters.AllowPan.raw == null) ? false : context.parameters.AllowPan.raw;
                    this.AllowZoom = (context.parameters.AllowZoom.raw == null) ? false : context.parameters.AllowZoom.raw;
                    this.LoadChildrenFromJsonData = (context.parameters.LoadChildrenFromJsonData == null || context.parameters.LoadChildrenFromJsonData.raw == null) ? false : context.parameters.LoadChildrenFromJsonData.raw;
                    this.PrimaryField = (context.parameters.PrimaryField == null || context.parameters.PrimaryField.raw == null) ? "" : context.parameters.PrimaryField.raw;
                }
            }
            return InputParameters;
        }());
        JQueryHierarchy.InputParameters = InputParameters;
    })(JQueryHierarchy = LinkedInExtensionControls.JQueryHierarchy || (LinkedInExtensionControls.JQueryHierarchy = {}));
})(LinkedInExtensionControls || (LinkedInExtensionControls = {}));
/**

* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
var LinkedInExtensionControls;
(function (LinkedInExtensionControls) {
    var JQueryHierarchy;
    (function (JQueryHierarchy) {
        'use strict';
        var ResourceKeys = (function () {
            function ResourceKeys() {
            }
            Object.defineProperty(ResourceKeys, "BottomArrowCollapseTitle", {
                get: function () {
                    return "BottomArrowCollapseTitle";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "BottomArrowExpandTitle", {
                get: function () {
                    return "BottomArrowExpandTitle";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "LeftArrowCollapseTitle", {
                get: function () {
                    return "LeftArrowCollapseTitle";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "LeftArrowExpandTitle", {
                get: function () {
                    return "LeftArrowExpandTitle";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "TopArrowExpandTitle", {
                get: function () {
                    return "TopArrowExpandTitle";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "TopArrowCollapseTitle", {
                get: function () {
                    return "TopArrowCollapseTitle";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "RightArrowExpandTitle", {
                get: function () {
                    return "RightArrowExpandTitle";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "RightArrowCollapseTitle", {
                get: function () {
                    return "RightArrowCollapseTitle";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "ChildrenCollapsedLabel", {
                get: function () {
                    return "ChildrenCollapsedLabel";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "ChildrenExpandedLabel", {
                get: function () {
                    return "ChildrenExpandedLabel";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "SiblingsCollapsedLabel", {
                get: function () {
                    return "SiblingsCollapsedLabel";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "SiblingsExpandedLabel", {
                get: function () {
                    return "SiblingsExpandedLabel";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "ParentExpandedLabel", {
                get: function () {
                    return "ParentExpandedLabel";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "ParentCollapsedLabel", {
                get: function () {
                    return "ParentCollapsedLabel";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "NumberOfDirectReportsLabel", {
                get: function () {
                    return "NumberOfDirectReportsLabel";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "OrgChartNavigationHelp", {
                get: function () {
                    return "OrgChartNavigationHelp";
                },
                enumerable: true,
                configurable: true
            });
            return ResourceKeys;
        }());
        JQueryHierarchy.ResourceKeys = ResourceKeys;
    })(JQueryHierarchy = LinkedInExtensionControls.JQueryHierarchy || (LinkedInExtensionControls.JQueryHierarchy = {}));
})(LinkedInExtensionControls || (LinkedInExtensionControls = {}));
