/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/**
* Telemetry library that takes dynamic parameter lists as event parameters in addition to fixed required parameters relavent to classify verticals association with Entities
* and pushes to crminsightsdev.cloudapp.net endpoint.  All one needs to do is Register your telemetry event with InsightsEndpoint repo (Events.xml and MdsConfig-CloudService.xml
* and start pushing event data using below APIs
*
* Sample calls for the APIs - caller : non-custom control eg: Ribbon commands
* AppsTelemetryUtility.reportData(EventList.EntitlementEvent, ModuleList.service, EntityList.entitlement, "Activation", null, { "CurrentState": "Activate", "UpdateMode": "Mouse"})
* AppsTelemetryUtility.reportData("CSHEntitlements", "Service", "Entitlement", "Deactivate", null, { "CurrentState": "Inactive", "UpdateMode": "KeyBoard"})
* Similarly ReportSuccess and Report Failure calls using either Enums (preferred) or string values.
* AppsTelemetryUtility.reportSuccess(EventList.EntitlementEvent, ModuleList.service, EntityList.entitlement, "TestAction", null, { "CurrentState": "Activate", "UpdateMode": "Mouse"})
* AppsTelemetryUtility.reportFailure(EventList.EntitlementEvent, ModuleList.service, EntityList.entitlement, "TestAction", null, { "CurrentState": "Activate", "UpdateMode": "Mouse"})
*
* Sample calls for the APIs - caller Custom Controls
* AppsTelemetryUtility.ReportSuccess(EventList.SubjectEvent, ModuleList.service, EntityList.CSSEvent, "AddBreak", this.context, {"Duration": 30, "Timezone": "PST"});
* AppsTelemetryUtility.ReportFailure("CSH_Subject", "Service", "Subject", "AddChild", this.context, {"name": "myRegarding", "parent": "myEntity"});
*
* In above samples for non-custom control calls, null is expected to be passed as part of event call for two reasons 1. Generic API for custom & non-custom control
*/
var AppsTelemetryLib;
(function (AppsTelemetryLib) {
    'use strict';
    /**
    * To format the outer payload for telemetry data according to the event schema
    */
    var TelemetryPayload = (function () {
        function TelemetryPayload() {
        }
        return TelemetryPayload;
    }());
    AppsTelemetryLib.TelemetryPayload = TelemetryPayload;
    /**
    * To format the inner payload for telemetry data according to the event schema
    */
    var TelemetryParameter = (function () {
        function TelemetryParameter() {
        }
        return TelemetryParameter;
    }());
    AppsTelemetryLib.TelemetryParameter = TelemetryParameter;
    /**
    * Declaring this key value pair to make it easy for callers
    */
    var ExtraParams = (function () {
        function ExtraParams() {
        }
        return ExtraParams;
    }());
    AppsTelemetryLib.ExtraParams = ExtraParams;
    /**
    * ENUMs tracking EventTypes
    */
    var EventTypes = (function () {
        function EventTypes() {
        }
        return EventTypes;
    }());
    EventTypes.Success = "Success";
    EventTypes.Failure = "Failure";
    EventTypes.EventData = "EventData";
    AppsTelemetryLib.EventTypes = EventTypes;
    /**
    * ENUMs tracking Vertical Events. Callers of Client Telemetry APIs can use ENUMs to pass required parameters
    * Currently listed with registered Customer Service Module List
    */
    var EventList = (function () {
        function EventList() {
        }
        return EventList;
    }());
    EventList.QueueEvent = "CSHQueues";
    EventList.RoutingRuleEvent = "CSHRoutingRules";
    EventList.ARCEvent = "CSHAutoRecordCreation";
    EventList.SubjectEvent = "CSHSubject";
    EventList.HSEvent = "CSHHolidaySchedule";
    EventList.CSSEvent = "CSHCustomerServiceSchedule";
    EventList.SettingsEvent = "CSHSettings";
    EventList.EntitlementEvent = "CSHEntitlements";
    EventList.IncidentEvent = "CSHIncident";
    EventList.EventAgnostic = "CSHMisc";
    AppsTelemetryLib.EventList = EventList;
    /**
    * ENUMs tracking Vertical/Module List
    */
    var ModuleList = (function () {
        function ModuleList() {
        }
        return ModuleList;
    }());
    ModuleList.service = "Service";
    ModuleList.sales = "Sales";
    ModuleList.marketing = "Marketing";
    ModuleList.verticalAgnostic = "VerticalAgnostic";
    AppsTelemetryLib.ModuleList = ModuleList;
    /**
    * ENUMs tracking Entity List
    * Currently listing entities list part of Customer Service Module shipping in Enterprise Release
    */
    var EntityList = (function () {
        function EntityList() {
        }
        return EntityList;
    }());
    EntityList.queue = "Queue";
    EntityList.queueItem = "QueueItem";
    EntityList.convertRule = "ConvertRule";
    EntityList.convertRuleItem = "ConvertRuleItem";
    EntityList.routingRule = "RoutingRule";
    EntityList.routingRuleItem = "RoutingRuleItem";
    EntityList.entitlement = "Entitlement";
    EntityList.entitlementTemplate = "EntitlementTemplate";
    EntityList.sla = "SLA";
    EntityList.slaItem = "SLAItem";
    EntityList.calendar = "Calendar";
    EntityList.calendarRule = "CalendarRule";
    EntityList.subject = "Subject";
    EntityList.incident = "Incident";
    EntityList.organization = "organization";
    AppsTelemetryLib.EntityList = EntityList;
    /**
    * ENUMs tracking Action
    */
    var Action = (function () {
        function Action() {
        }
        return Action;
    }());
    Action.create = "Create";
    Action.update = "Update";
    Action.retrieve = "Retrieve";
    Action.delete = "Delete";
    Action.clickedGridCommand = "ClickedGridCommand";
    AppsTelemetryLib.Action = Action;
    var AppsTelemetryUtility = (function () {
        function AppsTelemetryUtility() {
        }
        /**
        * @function reportEventData send telemetry data to the crminsightsdev.cloudapp.net endpoint.
        * @description send telemetry data to the telemetry endpoint.
        * @param appName - service / sales / any other XRM based app
        * @param context -  A reference to the context of custom entity; null for non-custom entity calls
        */
        AppsTelemetryUtility.reportData = function (eventName, appName, entityName, actionName, context, eventSpecificParams) {
            var telemetrydata = AppsTelemetryUtility.getTelemetryData(eventName, EventTypes.EventData, appName, entityName, actionName, context, eventSpecificParams);
            // Async calls be made to reportEvent call and error scenarios are expected to be handled within reportEvent infra
            if (context != null && context.reporting != null) {
                context.reporting.reportEvent(telemetrydata);
            }
            else {
                Xrm.Reporting.reportEvent(telemetrydata);
            }
        };
        ;
        AppsTelemetryUtility.reportFailure = function (eventName, appName, entityName, actionName, context, eventSpecificParams) {
            var telemetrydata = AppsTelemetryUtility.getTelemetryData(eventName, EventTypes.Failure, appName, entityName, actionName, context, eventSpecificParams);
            if (context != null && context.reporting != null) {
                context.reporting.reportEvent(telemetrydata);
            }
            else {
                Xrm.Reporting.reportEvent(telemetrydata);
            }
        };
        ;
        AppsTelemetryUtility.reportError = function (eventName, appName, entityName, actionName, context, errorMessage, errorTrace) {
            var eventSpecificParams = {};
            eventSpecificParams["errorMessage"] = errorMessage;
            eventSpecificParams["errorTrace"] = errorTrace ? JSON.stringify(errorTrace, Object.getOwnPropertyNames(errorTrace)) : "";
            AppsTelemetryUtility.reportFailure(eventName, appName, entityName, actionName, context, eventSpecificParams);
        };
        ;
        AppsTelemetryUtility.reportSuccess = function (eventName, appName, entityName, actionName, context, eventSpecificParams) {
            var telemetrydata = AppsTelemetryUtility.getTelemetryData(eventName, EventTypes.Success, appName, entityName, actionName, context, eventSpecificParams);
            if (context != null && context.reporting != null) {
                context.reporting.reportEvent(telemetrydata);
            }
            else {
                Xrm.Reporting.reportEvent(telemetrydata);
            }
        };
        ;
        AppsTelemetryUtility.getTelemetryData = function (_eventName, _telemetryDatatype, _appName, _entityName, _actionName, _context, _eventSpecificParams) {
            var payload = {
                eventName: _eventName,
                eventParameters: []
            };
            var para1 = { name: "EventType", value: _telemetryDatatype };
            var para2 = { name: "appName", value: _appName };
            var para3 = { name: "entityName", value: _entityName };
            var para4 = { name: "actionName", value: _actionName };
            var para5 = { name: "context", value: _context };
            payload.eventParameters.push(para1);
            payload.eventParameters.push(para2);
            payload.eventParameters.push(para3);
            payload.eventParameters.push(para4);
            payload.eventParameters.push(para5);
            var __eventSpecificParams = JSON.stringify(_eventSpecificParams);
            var para6 = { name: "eventSpecificParams", value: __eventSpecificParams };
            payload.eventParameters.push(para6);
            return payload;
        };
        return AppsTelemetryUtility;
    }());
    AppsTelemetryLib.AppsTelemetryUtility = AppsTelemetryUtility;
})(AppsTelemetryLib || (AppsTelemetryLib = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../../references/internal/TypeDefinitions/CommonControl/CommonControl.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../../../../ClientUtility/Client/Common/AppsTelemetrylib.ts" />
/// <reference path="../../../../TypeDefinitions/AppCommon/Controls/FREShell/libs/FREShell.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DualListWrapper;
        (function (DualListWrapper) {
            'use strict';
            var DualListWrapperControl = (function () {
                /**
                 * Empty constructor.
                 */
                function DualListWrapperControl() {
                    this.SERVICE_CONFIG_ENTITYTYPENAME = "e1adb62d-88f2-4126-9448-99355384a332";
                    this.CASE_SETTINGS_ENTITYTYPENAME = "abad25f5-beae-4458-bf4a-92efc1c7da72";
                    this._controlId = "CC_DualList";
                    this._dualListControlIdOrKey = "SvcConfigSETTINGS_DUALLIST_CONTAINER";
                    this.DualListSETTINGS_BLANK_CONTAINER = "SvcConfigSETTINGSBlankContainer";
                    this._slaEnabledEntitySelectedValue = DualListWrapper.DualListHelper.getDefaultEntityLogicalName();
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                DualListWrapperControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                DualListWrapperControl.prototype.updateView = function (context) {
                    this._context = context;
                    var innerBodyContainer;
                    if (this._context.utils.isNullOrUndefined(this._dualListDataHandler) && this._context.page && this._context.page.entityTypeName) {
                        this._dualListDataHandler = new DualListWrapper.DualListDataHandler(this._context);
                        innerBodyContainer = this.renderBlankContainerPage();
                    }
                    else {
                        innerBodyContainer = this.buildDualListSelectionControl();
                    }
                    return innerBodyContainer;
                };
                /**
                * This function returns empty container.
                * @returns The "Container" containing all controls of Service settings page
                */
                DualListWrapperControl.prototype.renderBlankContainerPage = function () {
                    var blankContainer = this._context.factory.createElement("CONTAINER", {
                        key: this.DualListSETTINGS_BLANK_CONTAINER,
                        id: this.DualListSETTINGS_BLANK_CONTAINER
                    }, []);
                    return blankContainer;
                };
                DualListWrapperControl.prototype.buildDualListSelectionControl = function () {
                    var entityTypeName = this._context.page.entityTypeName;
                    var properties = "";
                    switch (entityTypeName) {
                        case this.SERVICE_CONFIG_ENTITYTYPENAME:
                            properties = this.populateServiceSettingsParameters();
                            break;
                        case this.CASE_SETTINGS_ENTITYTYPENAME:
                            properties = this.populateCaseSettingsParameters();
                            break;
                        default:
                            break;
                    }
                    var dualListContainer = this._context.factory.createElement("CONTAINER", {
                        id: this._dualListControlIdOrKey,
                        key: this._dualListControlIdOrKey
                    }, this._context.factory.createComponent("MscrmControls.DualListSelection.DualListSelectionControl", "DualListSelectionControl", properties));
                    return dualListContainer;
                };
                DualListWrapperControl.prototype.populateCaseSettingsParameters = function () {
                    var properties = {
                        "parameters": {
                            JsonOptions: {
                                Usage: 3,
                                Static: true,
                                Type: "SingleLine.Text",
                                Value: JSON.stringify(this._dualListDataHandler.getCaseAvailableAttributes().map(function (c) {
                                    return {
                                        Id: c.LogicalName, DisplayName: c.DisplayName
                                    };
                                })),
                                Attributes: {
                                    DisplayName: null,
                                    LogicalName: "all_attributes",
                                    Type: "string",
                                    IsSecured: false,
                                    RequiredLevel: 0,
                                    MaxLength: 2147483647,
                                    EntityLogicalName: "",
                                    Format: "text",
                                    ImeMode: -1,
                                    Behavior: null
                                }
                            },
                            Selection: {
                                Usage: 3,
                                Static: true,
                                Type: "SingleLine.Text",
                                Value: this._dualListDataHandler.getCaseSelectedAttributes(),
                                Callback: this.callBackOnDualListSelectionChangeForCase.bind(this),
                                Attributes: {
                                    DisplayName: null,
                                    LogicalName: "cc_selectedAttributes_id",
                                    Type: "string",
                                    IsSecured: false,
                                    RequiredLevel: 0,
                                    MaxLength: 2147483647,
                                    EntityLogicalName: "",
                                    Format: null,
                                    ImeMode: -1,
                                    Behavior: null
                                }
                            },
                            SelectionOrderBy: {
                                Value: 2,
                                Usage: 3,
                                Static: true,
                                Type: "Enum",
                                Attributes: {},
                            },
                            OptionSet: {
                                Usage: 3,
                                Static: true,
                                Type: null,
                                attributes: {},
                            }
                        }
                    };
                    return properties;
                };
                DualListWrapperControl.prototype.populateServiceSettingsParameters = function () {
                    var mappingEntities = this._dualListDataHandler.getServiceConfigMappingForEntity(this._slaEnabledEntitySelectedValue);
                    var mappedEntities = this._dualListDataHandler.getServiceConfigMappedAttributesOfEntity(this._slaEnabledEntitySelectedValue);
                    var properties = {
                        "parameters": {
                            JsonOptions: {
                                Usage: 3,
                                Static: true,
                                Type: "SingleLine.Text",
                                Value: JSON.stringify(mappingEntities.mappingItems.map(function (c) {
                                    return {
                                        Id: c.Id,
                                        DisplayName: c.DisplayName
                                    };
                                })),
                                Attributes: {
                                    DisplayName: null,
                                    LogicalName: "all_attributes",
                                    Type: "string",
                                    IsSecured: false,
                                    RequiredLevel: 0,
                                    MaxLength: 2147483647,
                                    EntityLogicalName: "",
                                    Format: "text",
                                    ImeMode: -1,
                                    Behavior: null
                                }
                            },
                            Selection: {
                                Usage: 3,
                                Static: true,
                                Type: "SingleLine.Text",
                                Value: mappedEntities,
                                Callback: this.callBackOnDualListSelectionChange.bind(this),
                                Attributes: {
                                    DisplayName: null,
                                    LogicalName: "cc_selectedAttributes_id",
                                    Type: "string",
                                    IsSecured: false,
                                    RequiredLevel: 0,
                                    MaxLength: 2147483647,
                                    EntityLogicalName: "",
                                    Format: null,
                                    ImeMode: -1,
                                    Behavior: null
                                }
                            },
                            SelectionOrderBy: {
                                Usage: 3,
                                Static: true,
                                Type: "Enum",
                                Raw: "0",
                                Attributes: {},
                            },
                            OptionSet: {
                                Usage: 3,
                                Static: true,
                                Type: null,
                                attributes: {},
                            }
                        }
                    };
                    return properties;
                };
                DualListWrapperControl.prototype.callBackOnDualListSelectionChangeForCase = function (newValue) {
                    this._dualListDataHandler.setCaseSelectedAttributes(newValue);
                    this.notifyOutputChangeAndRequestRerender();
                };
                DualListWrapperControl.prototype.notifyOutputChangeAndRequestRerender = function () {
                    this._notifyOutputChanged();
                    this._context.utils.requestRender();
                };
                /**
                 * This function gets executed when there is selection change in dual list control.
                 * @param newValue
                 */
                DualListWrapperControl.prototype.callBackOnDualListSelectionChange = function (newValue) {
                    this._dualListDataHandler.setServiceConfigMappingForEntity(this._slaEnabledEntitySelectedValue, { mappedAttributes: newValue });
                    this.notifyOutputChangeAndRequestRerender();
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                DualListWrapperControl.prototype.getOutputs = function () {
                    var selection = "";
                    if (this._context && this._context.page) {
                        if (this._context.page.entityTypeName === this.SERVICE_CONFIG_ENTITYTYPENAME) {
                            selection = this._dualListDataHandler.getServiceConfigMappedAttributesOfEntity(this._slaEnabledEntitySelectedValue);
                        }
                        else {
                            selection = this._dualListDataHandler.getCaseSelectedAttributes();
                        }
                    }
                    return {
                        Selection: selection
                    };
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                DualListWrapperControl.prototype.destroy = function () {
                };
                return DualListWrapperControl;
            }());
            DualListWrapper.DualListWrapperControl = DualListWrapperControl;
        })(DualListWrapper = AppCommon.DualListWrapper || (AppCommon.DualListWrapper = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="DualListWrapper.ts" /> 
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DualListWrapper;
        (function (DualListWrapper) {
            'use strict';
            var DualListHelper = (function () {
                function DualListHelper() {
                }
                /**
                 * This method returns the entities URL
                 */
                DualListHelper.getEntitiesUrl = function () {
                    return "/api/data/v9.0/EntityDefinitions?$select=MetadataId,DisplayName,LogicalName&$filter=IsSLAEnabled eq true";
                };
                /**
                 * This method returns the Appmodules URL
                 */
                DualListHelper.getAppModulesURL = function (appId) {
                    return "/api/data/v9.0/appmodules/Microsoft.Dynamics.CRM.RetrieveUnpublishedMultiple?$select=appmoduleidunique&$filter=appmoduleid eq " + appId;
                };
                DualListHelper.getAppModuleComponents = function (appUniqueId) {
                    return "/api/data/v9.0/appmodulecomponents?$select=objectid&$filter=componenttype eq 1 and _appmoduleidunique_value eq " + appUniqueId;
                };
                DualListHelper.getAttributesOfEntityURL = function (entityName) {
                    return "/api/data/v9.0/EntityDefinitions(LogicalName='" + entityName + "')/Attributes/Microsoft.Dynamics.CRM.StatusAttributeMetadata?$select=LogicalName&$expand=OptionSet";
                };
                DualListHelper.getDefaultEntityLogicalName = function () {
                    return "incident";
                };
                DualListHelper.getorgSettingsUpdateValueRequest = function () {
                    return "?$select=suppresssla,autoapplysla,autoapplydefaultoncasecreate,autoapplydefaultoncaseupdate,slapausestates";
                };
                DualListHelper.getAllAttributesOfIncidentEntityRequest = function () {
                    return "/api/data/v9.0/EntityDefinitions(LogicalName='incident')/Attributes?$filter=IsValidForUpdate ne false and IsLogical ne true  and LogicalName ne 'parentcaseid' and LogicalName ne 'masterid'";
                };
                DualListHelper.getEntityMapIdForIncidentEntityRequest = function () {
                    return "?$filter=sourceentityname eq 'incident' and targetentityname eq 'incident'";
                };
                DualListHelper.getSelectedAttributesRequest = function (entityMapId) {
                    return "/api/data/v9.0/entitymaps(" + entityMapId + ")/entity_map_attribute_maps?$select=sourceattributename,targetattributename,attributemapid,issystem";
                };
                return DualListHelper;
            }());
            DualListWrapper.DualListHelper = DualListHelper;
        })(DualListWrapper = AppCommon.DualListWrapper || (AppCommon.DualListWrapper = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DualListWrapper;
        (function (DualListWrapper) {
            'use strict';
            var BoolOrgSettings;
            (function (BoolOrgSettings) {
                BoolOrgSettings[BoolOrgSettings["suppresssla"] = 0] = "suppresssla";
                BoolOrgSettings[BoolOrgSettings["autoapplysla"] = 1] = "autoapplysla";
                BoolOrgSettings[BoolOrgSettings["autoapplydefaultoncasecreate"] = 2] = "autoapplydefaultoncasecreate";
                BoolOrgSettings[BoolOrgSettings["autoapplydefaultoncaseupdate"] = 3] = "autoapplydefaultoncaseupdate";
            })(BoolOrgSettings = DualListWrapper.BoolOrgSettings || (DualListWrapper.BoolOrgSettings = {}));
            var OrgSettingsSavedAttempt;
            (function (OrgSettingsSavedAttempt) {
                OrgSettingsSavedAttempt[OrgSettingsSavedAttempt["SUCCESS"] = 0] = "SUCCESS";
                OrgSettingsSavedAttempt[OrgSettingsSavedAttempt["FAILURE"] = 1] = "FAILURE";
            })(OrgSettingsSavedAttempt = DualListWrapper.OrgSettingsSavedAttempt || (DualListWrapper.OrgSettingsSavedAttempt = {}));
            var BoolOrgValues;
            (function (BoolOrgValues) {
                BoolOrgValues[BoolOrgValues["YES"] = 0] = "YES";
                BoolOrgValues[BoolOrgValues["NO"] = 1] = "NO";
            })(BoolOrgValues = DualListWrapper.BoolOrgValues || (DualListWrapper.BoolOrgValues = {}));
        })(DualListWrapper = AppCommon.DualListWrapper || (AppCommon.DualListWrapper = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DualListWrapper;
        (function (DualListWrapper) {
            var DualListDataHandler = (function () {
                /**
                * constructor of Service settings data handler
                */
                function DualListDataHandler(context) {
                    this.SERVICE_CONFIG_ENTITYTYPENAME = "e1adb62d-88f2-4126-9448-99355384a332";
                    this.CASE_SETTINGS_ENTITYTYPENAME = "abad25f5-beae-4458-bf4a-92efc1c7da72";
                    this._slaEntitiesInDefaultApp = null;
                    // this property is used to hold the entity object ids available in current app
                    this._entityIDsInCurrentApp = null;
                    this._origOrgSettingsSLA = [];
                    this._currentOrgSettingsSLA = [];
                    this._attributeMapIds = [];
                    this._entitiesMappingDetails = {};
                    this._entityStatusOptions = {};
                    this.SvcConfigSETTINGS_ZeroValue = "0";
                    this._currentSelectedAttributes = "";
                    this._allAvailableAttributes = [];
                    this._systemRequiredAttributes = "";
                    this._businessRequiredAttributes = "";
                    this._originalSelectedAttributes = "";
                    this._slaEnabledEntitiesInCurrentApp = [];
                    this._context = context;
                    this._initializeRequestsCounter = 0;
                    this._expectedTotalResponseCount = 3;
                    this.init();
                }
                /**
                 * This function returns the mapped attributes of entity name which is passed
                 * @param entityName
                 */
                DualListDataHandler.prototype.getServiceConfigMappedAttributesOfEntity = function (entityName) {
                    return this._context.utils.isNullOrUndefined(this._entitiesMappingDetails[entityName]) ? "" : this._entitiesMappingDetails[entityName].mappedAttributes;
                };
                /**
                 * Returns true or false for given boolean org setting
                 * @param name
                 */
                DualListDataHandler.prototype.getSvcConfigOrgSetting = function (name) {
                    return this._origOrgSettingsSLA[name];
                };
                /**
                 * Update the boolean setting to given value
                 * @param name
                 * @param value
                 */
                DualListDataHandler.prototype.setSvcConfigOrgSetting = function (name, value) {
                    this._currentOrgSettingsSLA[name] = value;
                };
                /**
                 * retrieves SLA enabled entities in current app context
                 */
                DualListDataHandler.prototype.getSLAEnabledEntities = function () {
                    return this._slaEnabledEntitiesInCurrentApp;
                };
                /**
                * returns available attributes
                */
                DualListDataHandler.prototype.getCaseAvailableAttributes = function () {
                    return this._allAvailableAttributes;
                };
                /**
                 * returns selected attributes
                 */
                DualListDataHandler.prototype.getCaseSelectedAttributes = function () {
                    return this._currentSelectedAttributes;
                };
                // sets the selected attributes
                DualListDataHandler.prototype.setCaseSelectedAttributes = function (attributes) {
                    this._currentSelectedAttributes = attributes;
                };
                /**
                 * fetches status mapping information for the newly selected entity
                 * @param logicalName
                 */
                DualListDataHandler.prototype.fetchMappingForEntity = function (logicalName) {
                    var _this = this;
                    var mappingDetails = { mappingItems: [] };
                    if (this._context.utils.isNullOrUndefined(this._entityStatusOptions[logicalName])) {
                        var attributesURL = this._context.utils.createCrmUri(DualListWrapper.DualListHelper.getAttributesOfEntityURL(logicalName));
                        this.sendRequest(attributesURL).then(function (data) {
                            if (!_this._context.utils.isNullOrUndefined(data) && !_this._context.utils.isNullOrUndefined(data.value) && data.value.length > 0) {
                                if (!_this._context.utils.isNullOrUndefined(data.value[0].OptionSet) && !_this._context.utils.isNullOrUndefined(data.value[0].OptionSet.Options) && data.value[0].OptionSet.Options.length > 0) {
                                    var options = data.value[0].OptionSet.Options;
                                    for (var i = 0; i < options.length; i++) {
                                        if (!_this._context.utils.isNullOrUndefined(options[i])) {
                                            if (options[i].State == _this.SvcConfigSETTINGS_ZeroValue) {
                                                var option = options[i];
                                                var label = option.Label.UserLocalizedLabel.Label;
                                                var id = options[i].Value;
                                                mappingDetails.mappingItems.push({ Id: id, DisplayName: label });
                                            }
                                        }
                                    }
                                    _this._entityStatusOptions[logicalName] = mappingDetails;
                                    _this._initializeRequestsCounter++;
                                    _this.checkRequestCounterForRerendering();
                                }
                            }
                        }, function (error) {
                            var errMessage = "Retrieval of Entity Attributes call Failed.";
                            _this.reportErrorTelemetry(_this._context, errMessage, error);
                        });
                    }
                    else {
                        this.checkRequestCounterForRerendering();
                    }
                };
                /**
                 * returns status mapping information for the newly selected entity
                 * @param logicalName
                 */
                DualListDataHandler.prototype.getServiceConfigMappingForEntity = function (logicalName) {
                    return this._entityStatusOptions[logicalName];
                };
                /**
                 * Updates mapping information for the given entity
                 * @param logicalName
                 * @param mappingDetails
                 */
                DualListDataHandler.prototype.setServiceConfigMappingForEntity = function (logicalName, mappingDetails) {
                    this._entitiesMappingDetails[logicalName] = mappingDetails;
                };
                /**
                * This method will do initialisation of data
                */
                DualListDataHandler.prototype.init = function () {
                    var entityTypeName = this._context.page.entityTypeName;
                    var properties = "";
                    switch (entityTypeName) {
                        case this.SERVICE_CONFIG_ENTITYTYPENAME:
                            this.retrieveSLAEnabledEntitiesForCurrentApp();
                            this.fetchMappingForEntity(DualListWrapper.DualListHelper.getDefaultEntityLogicalName());
                            this.retrieveOrgSettingValues();
                            break;
                        case this.CASE_SETTINGS_ENTITYTYPENAME:
                            this.initializeHandler();
                            break;
                    }
                };
                /**
                 * This function retrives the SLA Enabled Entities for the current app
                 */
                DualListDataHandler.prototype.retrieveSLAEnabledEntitiesForCurrentApp = function () {
                    this.retrieveSLAEnabledEntitiesInDefaultApp();
                    this.getEntitiesInCurrentApp();
                };
                /**
         * This method will be called from CaseSettingsAttributes constructor to initialize the handler with selected and all available attributes details
         */
                DualListDataHandler.prototype.initializeHandler = function () {
                    var _this = this;
                    // call to get the entitymapid of incident
                    this._context.webAPI.retrieveMultipleRecords("entitymap", DualListWrapper.DualListHelper.getEntityMapIdForIncidentEntityRequest()).then(function (data) {
                        try {
                            _this._initializeRequestsCounter = _this._initializeRequestsCounter + 1;
                            if (data.entities.length == 0) {
                                var emptyEntityMapIdMessage = "entitymapid not found";
                            }
                            else {
                                _this._entityMapIdForIncidentEntity = data.entities["0"].entitymapid;
                                // once entitymapid of incident is available, fetch the selected attributes list
                                var selectedAttributesUrl = _this._context.utils.createCrmUri(DualListWrapper.DualListHelper.getSelectedAttributesRequest(_this._entityMapIdForIncidentEntity));
                                _this.getSelectedAttributesRequest(selectedAttributesUrl).then(function (innerCallData) {
                                    try {
                                        _this.initializeSelectedAttributesData(innerCallData);
                                        _this._initializeRequestsCounter = _this._initializeRequestsCounter + 1;
                                        _this.checkRequestCounterForRerendering();
                                    }
                                    catch (innerCallDataExpcetion) {
                                        var errorMessage = "Error fetching the selected attributes.";
                                        _this.reportErrorTelemetry(_this._context, errorMessage, innerCallDataExpcetion);
                                    }
                                }, function (innerCallError) {
                                    var innerCallErrorMessage = "Retrieval of System Required Attributes Failed.";
                                    _this.reportErrorTelemetry(_this._context, innerCallErrorMessage, innerCallError);
                                });
                            }
                        }
                        catch (entityMapExpcetion) {
                            var errorMessage = "Error retreiving the EntityMap.";
                            _this.reportErrorTelemetry(_this._context, errorMessage, entityMapExpcetion);
                        }
                    }, function (error) {
                        var errMessage = "Retrieval of entitymapid Failed.";
                        _this.reportErrorTelemetry(_this._context, errMessage, error);
                    });
                    // call to get all the attributes from incident entitydefinition
                    var allAttribuesUrl = DualListWrapper.DualListHelper.getAllAttributesOfIncidentEntityRequest();
                    this.getAllAttributesRequest(this._context.utils.createCrmUri(allAttribuesUrl)).then(function (allAttributesData) {
                        try {
                            if (allAttributesData.value.length == 0) {
                                var allAttributesDataEmptyMessage = "Attribues not found";
                            }
                            else {
                                _this.initializeAllAttributesData(allAttributesData);
                                _this._initializeRequestsCounter = _this._initializeRequestsCounter + 1;
                                _this.checkRequestCounterForRerendering();
                            }
                        }
                        catch (allAttributesExpcetion) {
                            var errorMessage = "Error Fetching all the available attributes from incident entitydefination.";
                            _this.reportErrorTelemetry(_this._context, errorMessage, allAttributesExpcetion);
                        }
                    }, function (allAttributesError) {
                        var allAttributesErrorMessage = "Retrieval of all attributes call Failed.";
                        _this.reportErrorTelemetry(_this._context, allAttributesErrorMessage, allAttributesError);
                    });
                };
                DualListDataHandler.prototype.getSelectedAttributesRequest = function (selectedAttributesUrl) {
                    return $.ajax({
                        url: selectedAttributesUrl,
                        type: 'GET',
                        async: true,
                        beforeSend: function (request) {
                            request.setRequestHeader("OData-MaxVersion", "4.0");
                            request.setRequestHeader("OData-Version", "4.0");
                            request.setRequestHeader("Accept", "application/json");
                            request.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                            request.setRequestHeader("Cache-Control", " no-cache, no-store, must-revalidate");
                            request.setRequestHeader("Pragma", " no-cache");
                            request.setRequestHeader("Expires", "0");
                            request.setRequestHeader("If-None-Match", "");
                        }
                    });
                };
                /**
                * Used to initialize the selected attributes details
                */
                DualListDataHandler.prototype.initializeSelectedAttributesData = function (myDataJson) {
                    var records = myDataJson.value;
                    this._attributeMapIds = [];
                    for (var i = 0; i < records.length; i++) {
                        var record = records[i];
                        if (record.sourceattributename == record.targetattributename) {
                            var attribute = {
                                "Id": record.sourceattributename,
                                "AttributeMapId": record.attributemapid,
                                "issystem": record.issystem
                            };
                            this._attributeMapIds.push(attribute);
                        }
                    }
                    // set the system required attributes
                    this._systemRequiredAttributes = this._attributeMapIds
                        .filter(function (d) { return d.issystem == true; })
                        .map(function (a) { return a.Id; }).join(",");
                };
                /**
                * Ajax call request to fetch the All attributes list
                */
                DualListDataHandler.prototype.getAllAttributesRequest = function (getAllUrl) {
                    return $.ajax({
                        url: getAllUrl,
                        type: 'GET',
                        async: true,
                        beforeSend: function (request) {
                            request.setRequestHeader("OData-MaxVersion", "4.0");
                            request.setRequestHeader("OData-Version", "4.0");
                            request.setRequestHeader("Accept", "application/json");
                            request.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                        }
                    });
                };
                /**
                * Used to initialize the All available attributes details
                */
                DualListDataHandler.prototype.initializeAllAttributesData = function (myDataJson) {
                    var records = myDataJson.value;
                    this._allAvailableAttributes = [];
                    for (var i = 0; i < records.length; i++) {
                        var record = records[i];
                        if (this.validateAllAttributesRecord(record)) {
                            var that = this;
                            var attribute = {
                                LogicalName: record.LogicalName,
                                DisplayName: (record.DisplayName.LocalizedLabels.filter(function (a) { return a.LanguageCode == that._context.orgSettings.languageId; }))[0].Label,
                                isApplicationRequired: (record.RequiredLevel.Value == "ApplicationRequired") ? true : false
                            };
                            this._allAvailableAttributes.push(attribute);
                        }
                    }
                    this._allAvailableAttributes = this._allAvailableAttributes.sort(function (a, b) { return a.DisplayName.localeCompare(b.DisplayName); });
                    this.initializeBusinessRequiredAttributes();
                };
                /**
                 * set the business required attributes if systemRequiredAttributes list is already available
                 */
                DualListDataHandler.prototype.initializeBusinessRequiredAttributes = function () {
                    if (this._systemRequiredAttributes != "") {
                        var that = this;
                        this._businessRequiredAttributes = this._allAvailableAttributes
                            .filter(function (d) { return (d.isApplicationRequired == true && that._systemRequiredAttributes.split(",").indexOf(d.LogicalName) < 0); })
                            .map(function (a) { return a.LogicalName; }).join(",");
                    }
                };
                /**
                * performs the validation of the available attributes to ignore/display the record in available items list
                */
                DualListDataHandler.prototype.validateAllAttributesRecord = function (record) {
                    // if record is not having valid description then donot show the record in available items list
                    if (record.Description.LocalizedLabels.length > 0) {
                        // if record is not having valid display name then donot show the record in available items list
                        if (record.DisplayName.LocalizedLabels.length > 0) {
                            // if isvalidforcreate is not equal to true then donot show the record in available items list
                            if (record.IsValidForCreate) {
                                if (this.validatateImeMode(record)) {
                                    if (this.validatateYomi(record)) {
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                    return false;
                };
                /**
                 * validates imemode and returns the response to the caller
                 */
                DualListDataHandler.prototype.validatateImeMode = function (record) {
                    // Not able to get the Imemode value for actualserviceunits, billedserviceunits, timezoneruleversionnumber, utcconversiontimezonecode attributes from api call, hence hardcoded
                    if (record.LogicalName == "actualserviceunits" || record.LogicalName == "billedserviceunits" || record.LogicalName == "timezoneruleversionnumber" || record.LogicalName == "utcconversiontimezonecode") {
                        return false;
                    }
                    else if (this._context.utils.isNullOrUndefined(record["ImeMode"])) {
                        return true;
                    }
                    else if (record.ImeMode == "Disabled") {
                        return false;
                    }
                    else {
                        return true;
                    }
                };
                /**
                 * for non japanese langauge if there YomiOf attribute is having some value then return false
                 */
                DualListDataHandler.prototype.validatateYomi = function (record) {
                    // 
                    if (this._context.orgSettings.languageId != 1041 && !this._context.utils.isNullOrUndefined(record["YomiOf"]) && record.YomiOf != null) {
                        return false;
                    }
                    else {
                        return true;
                    }
                };
                /*
                * This method retrieve OrgSettings
                */
                DualListDataHandler.prototype.retrieveOrgSettingValues = function () {
                    var _this = this;
                    this._context.webAPI.retrieveMultipleRecords("organization", DualListWrapper.DualListHelper.getorgSettingsUpdateValueRequest()).then(function (data) {
                        try {
                            _this._organizationId = data.entities["0"].organizationid;
                            _this.setOrigandCurrOrgSettingsValue(data);
                            _this._initializeRequestsCounter = _this._initializeRequestsCounter + 1;
                            _this.checkRequestCounterForRerendering();
                        }
                        catch (statusUpdateValueexpcetion) {
                            var errorMessage = "Error Fetching StatusUpdate Value from Organization.";
                            _this.reportErrorTelemetry(_this._context, errorMessage, statusUpdateValueexpcetion);
                        }
                    }, function (error) {
                        var errMessage = "Retrieval of StatusUpdateValues call Failed.";
                        _this.reportErrorTelemetry(_this._context, errMessage, error);
                    });
                };
                /*
                * Setting the Original and current OrgSettings values when data is retreived.
                */
                DualListDataHandler.prototype.setOrigandCurrOrgSettingsValue = function (data) {
                    this._origOrgSettingsSLA[0] = data.entities["0"].suppresssla;
                    this._origOrgSettingsSLA[1] = data.entities["0"].autoapplysla;
                    this._origOrgSettingsSLA[2] = data.entities["0"].autoapplydefaultoncasecreate;
                    this._origOrgSettingsSLA[3] = data.entities["0"].autoapplydefaultoncaseupdate;
                    this._currentOrgSettingsSLA[0] = data.entities["0"].suppresssla;
                    this._currentOrgSettingsSLA[1] = data.entities["0"].autoapplysla;
                    this._currentOrgSettingsSLA[2] = data.entities["0"].autoapplydefaultoncasecreate;
                    this._currentOrgSettingsSLA[3] = data.entities["0"].autoapplydefaultoncaseupdate;
                    this._currentSLAPauseState = data.entities["0"].slapausestates;
                    this._origSLAPauseState = data.entities["0"].slapausestates;
                    if (!this._context.utils.isNullOrUndefined(data.entities["0"].slapausestates)) {
                        this._xmlDocument = (new DOMParser()).parseFromString(data.entities["0"].slapausestates, "text/xml");
                        this.setMappedAttributesOfEntities();
                    }
                };
                /**
                 * This function will parse the XML response of mapped entities and store in a variable
                 */
                DualListDataHandler.prototype.setMappedAttributesOfEntities = function () {
                    if (this._xmlDocument.documentElement.childNodes != null && this._xmlDocument.documentElement.childNodes.length > 0) {
                        for (var index = 0; index < this._xmlDocument.documentElement.childNodes.length; index++) {
                            if (this.validateChildNodes(index)) {
                                var entityName = this._xmlDocument.documentElement.childNodes[index].attributes.getNamedItem("value").nodeValue;
                                var result = this._xmlDocument.documentElement.childNodes[index].textContent;
                                result = result.replace(/;/g, ",");
                                this._entitiesMappingDetails[entityName] = { mappedAttributes: result };
                            }
                        }
                    }
                };
                /**
                 * This function validates the null check conditions for nodes.
                 * @param index
                 */
                DualListDataHandler.prototype.validateChildNodes = function (index) {
                    return this._xmlDocument.documentElement.childNodes[index] != null && this._xmlDocument.documentElement.childNodes[index].attributes != null && this._xmlDocument.documentElement.childNodes[index].attributes.getNamedItem("value") != null;
                };
                /**
                 * This method is used to fetch the SLA Enabled Entities with OData call. //TODO Change func name
                 */
                DualListDataHandler.prototype.retrieveSLAEnabledEntitiesInDefaultApp = function () {
                    var _this = this;
                    var fetchEntitiesUrl = this._context.utils.createCrmUri(DualListWrapper.DualListHelper.getEntitiesUrl());
                    this.sendRequest(fetchEntitiesUrl).then(function (data) {
                        var entities = data.value;
                        _this._slaEntitiesInDefaultApp = {};
                        for (var index = 0; index < entities.length; index++) {
                            var currentEntity = entities[index];
                            if (_this.validateEntity(currentEntity)) {
                                _this._slaEntitiesInDefaultApp[currentEntity.MetadataId] =
                                    {
                                        DisplayName: currentEntity.DisplayName.LocalizedLabels[0].Label,
                                        LogicalName: currentEntity.LogicalName
                                    };
                            }
                        }
                        _this.filterSLAEnabledEntitiesForApp();
                    }, function (error) {
                        var errMessage = "Retrieval of EntityDefinitios call Failed.";
                        _this.reportErrorTelemetry(_this._context, errMessage, error);
                    });
                };
                /**
                * The function will make odata call and get the app module components with the help of app unique id.
                **/
                DualListDataHandler.prototype.getEntitiesInCurrentApp = function () {
                    //fetching all entities from the current app
                    var that = this;
                    var requestUri = that._context.utils.createCrmUri(DualListWrapper.DualListHelper.getAppModulesURL(that._context.page.appId));
                    this.sendRequest(requestUri).then(function (appUniqueIdResp) {
                        var _this = this;
                        if (that._context.utils.isNullOrUndefined(appUniqueIdResp) || that._context.utils.isNullOrUndefined(appUniqueIdResp.value) || appUniqueIdResp.value.length < 1) {
                            var errMessage = "AppModuleIdUnique record is not found in successful response.";
                            this.reportErrorTelemetry(this._context, errMessage, "");
                            return;
                        }
                        var appUniqueIdUnpublished = appUniqueIdResp.value[0].appmoduleidunique;
                        var appModuleComponentsUrl = that._context.utils.createCrmUri(DualListWrapper.DualListHelper.getAppModuleComponents(appUniqueIdUnpublished));
                        that.sendRequest(appModuleComponentsUrl).then(function (respAppModuleRecords) {
                            if (!that._context.utils.isNullOrUndefined(respAppModuleRecords)) {
                                that._entityIDsInCurrentApp = respAppModuleRecords.value.map(function (appModule) { return appModule.objectid; });
                                that.filterSLAEnabledEntitiesForApp();
                            }
                            else {
                                var errMessage = "getAppModuleComponents() has an unsuccessful response.";
                                this.reportErrorTelemetry(this._context, errMessage, "");
                                return;
                            }
                        }, function (error) {
                            var errMessage = "Retrieval of getAppModuleComponents call Failed.";
                            _this.reportErrorTelemetry(_this._context, errMessage, error);
                        });
                    }, function (error) {
                        var errMessage = "Retrieval of getEntitiesInCurrentApp() Failed....";
                        this.reportErrorTelemetry(this._context, errMessage, error);
                    });
                };
                /**
                 * This function helps in setting the SLA Entities
                 */
                DualListDataHandler.prototype.filterSLAEnabledEntitiesForApp = function () {
                    if (this._entityIDsInCurrentApp != null && this._slaEntitiesInDefaultApp != null) {
                        for (var i = 0; i < this._entityIDsInCurrentApp.length; i++) {
                            var objectId = this._entityIDsInCurrentApp[i];
                            var entity = this._slaEntitiesInDefaultApp[objectId];
                            if (!this._context.utils.isNullOrUndefined(entity)) {
                                this._slaEnabledEntitiesInCurrentApp.push({ DisplayName: entity.DisplayName, LogicalName: entity.LogicalName });
                            }
                        }
                        this._initializeRequestsCounter++;
                        this.checkRequestCounterForRerendering();
                    }
                };
                /**
                * This method validates the entity that was being passed to it
                * @param entity The "Input Bag" containing the parameters and other control metadata.
                *.@returns the boolean value
                */
                DualListDataHandler.prototype.validateEntity = function (entity) {
                    if (entity != null && entity.DisplayName != null && entity.DisplayName.LocalizedLabels != null && entity.DisplayName.LocalizedLabels.length > 0) {
                        return true;
                    }
                    else {
                        return false;
                    }
                };
                /**
                * checks for the request counter and if initialize Requests Counter matches with expected Response Counter then it will rerender the page
                */
                DualListDataHandler.prototype.checkRequestCounterForRerendering = function () {
                    var _this = this;
                    if (this._context.page.entityTypeName === this.SERVICE_CONFIG_ENTITYTYPENAME) {
                        if (this._initializeRequestsCounter >= this._expectedTotalResponseCount) {
                            this._context.utils.requestRender();
                        }
                    }
                    else {
                        if (this._initializeRequestsCounter == this._expectedTotalResponseCount) {
                            this._originalSelectedAttributes = "";
                            // before rendering the page initialize the original selected values
                            // this._selectedAttributes is used to hold the onload selected values by filtering out the entitymaps list from allattributes list
                            this._originalSelectedAttributes = this._attributeMapIds
                                .filter(function (d) { return _this._allAvailableAttributes.map(function (a) { return a.LogicalName; }).indexOf(d.Id) > -1; })
                                .map(function (a) { return a.Id; }).join(",");
                            // this._currentSelectedAttributes is used to hold the updated/refreshed values from UI
                            this._currentSelectedAttributes = this._originalSelectedAttributes;
                            this.initializeBusinessRequiredAttributes();
                            this._context.utils.requestRender();
                        }
                    }
                };
                /**
                * This method is used to send request with the specified url
                * @param url The url paramemer.
                */
                DualListDataHandler.prototype.sendRequest = function (url) {
                    return $.ajax({
                        url: encodeURI(url),
                        type: 'GET',
                        async: true,
                        contentType: "application/json",
                        dataType: "json",
                    });
                };
                /**
                * Logs error telemetry
                * @param context The "Input Bag" containing the parameters and other control metadata.
                * @param errorMessage error message to be reported
                * @param errorTrace stack trace information about error
                */
                DualListDataHandler.prototype.reportErrorTelemetry = function (context, errorMessage, errorTrace) {
                    AppsTelemetryLib.AppsTelemetryUtility.reportError(AppsTelemetryLib.EventList.IncidentEvent, AppsTelemetryLib.ModuleList.service, AppsTelemetryLib.EntityList.incident, AppsTelemetryLib.Action.update, context, errorMessage, errorTrace);
                };
                return DualListDataHandler;
            }());
            DualListWrapper.DualListDataHandler = DualListDataHandler;
        })(DualListWrapper = AppCommon.DualListWrapper || (AppCommon.DualListWrapper = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=DualListWrapper.js.map