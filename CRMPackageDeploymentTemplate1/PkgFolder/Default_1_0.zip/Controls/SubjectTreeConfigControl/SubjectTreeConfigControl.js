var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
 * This code was generated from a script.
 * Manual changes to this file will be overwritten if the code is regenerated.
 *
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../../references/internal/TypeDefinitions/CommonControl/CommonControl.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../../../../AppCommon/Client/Controls/FREShell/libs/FREShell.d.ts" />
/// <reference path="../../../../AppCommon/Client/Controls/FREShell/libs/frecommon-lib.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SubjectTreeConfig;
        (function (SubjectTreeConfig) {
            'use strict';
            var Constants = (function () {
                function Constants() {
                }
                return Constants;
            }());
            /**
             * Path for Icon for Subject Tree.
             * Images need be shipped as WebResources.
             */
            Constants.HeaderNormalIconImagePath = "../../WebResources/AppCommon/ControlWS/HeaderIconImages/SubjectTreeConfig.svg";
            Constants.HeaderHighContrastIconImagePath = "../../WebResources/AppCommon/ControlWS/HeaderIconImages/SubjectTreeConfig_HC.svg";
            Constants.SubjectAddButtonIconContainerKey = "SubjectTreeConfigPage.AddButton_label";
            Constants.SubjectAddButtonKey = "SubjectTreeConfigPage.AddButton";
            Constants.SubjectRemoveButtonIconContainerKey = "SubjectTreeConfigPage.RemoveButton_label";
            Constants.SubjectRemoveButtonKey = "SubjectTreeConfigPage.RemoveButton";
            Constants.SubjectEditButtonIconContainerKey = "SubjectTreeConfigPage.EditButton_label";
            Constants.SubjectEditButtonKey = "SubjectTreeConfigPage.EditButton";
            Constants.SubjectHeaderSeparatorContainerKey = "SubjectTreeConfigPage.ButtonSeparator";
            Constants.SubjectHeaderRightContainerKey = "SubjectTreeConfigPage.HeaderRightContainer";
            Constants.SubjectEntityDetailsContainerKey = "SubjectTreeConfigPage.entityDetailsContainer";
            Constants.SubjectTreeViewRightContainer = "SubjectTreeConfigPage.subjectTreeControlContainer";
            Constants.SubjectHeaderRightContainerBodyKey = "SubjectTreeConfigPage.HeaderRightContainerBody";
            Constants.AddSubjectDialogName = "AddSubject";
            Constants.SubjectRetrieveTableName = "subject";
            Constants.EditSubjectDialogName = "EditSubject";
            SubjectTreeConfig.Constants = Constants;
        })(SubjectTreeConfig = AppCommon.SubjectTreeConfig || (AppCommon.SubjectTreeConfig = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SubjectTreeConfig;
        (function (SubjectTreeConfig) {
            'use strict';
            var FREShell = MscrmControls.AppCommon.FREShell;
            var SubjectTreeConfigControl = (function () {
                /**
                 *  constructor.
                 */
                function SubjectTreeConfigControl() {
                    this._context = null;
                    this._freShell = null;
                    this._applyStyles = null;
                    this._treeData = [];
                    this._fetchedNodesFromDB = false;
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 */
                SubjectTreeConfigControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                    var pageTitle = this._context.resources.getString(SubjectTreeConfig.LabelId.CC_SubjectTreeConfig_Name) + " - " + this._context.resources.getString(SubjectTreeConfig.LabelId.MicrosoftDynamics365Text);
                    this._freShell = new FREShell(context, pageTitle);
                    this._applyStyles = new SubjectTreeConfig.SubjectTreeConfigStyles(context);
                    window.onresize = function () {
                        SubjectTreeConfigControl.updateScrollBarUsingWindowResize();
                    };
                    if (!this._fetchedNodesFromDB)
                        this._updateSubjectTreeData();
                    /**
                     * telemetry end points and data to be added...
                     */
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                SubjectTreeConfigControl.prototype.updateView = function (context) {
                    this._context = context;
                    return this.getChildControls();
                };
                /**
                 * Provides child controls to the shell which can then be used to create correct hierarchy of controls.
                 */
                SubjectTreeConfigControl.prototype.getChildControls = function () {
                    var normalIconImagePath = SubjectTreeConfig.Constants.HeaderNormalIconImagePath;
                    var subAreaLabel = this._context.resources.getString(SubjectTreeConfig.LabelId.SubAreaLabel);
                    var theming = this._context.theming;
                    // Create the right container having buttons.
                    var headerRightContainerChild = this.createHeaderRightContainer();
                    var entityImage = this._context.factory.createElement("ENTITYIMAGE", {
                        id: "SubjectTreeImage",
                        key: "SubjectTreeImage",
                        hasPrimaryImageField: true,
                        style: {
                            marginRight: theming.measures.measure075,
                            marginLeft: theming.measures.measure075,
                            marginBottom: theming.measures.measure050,
                            marginTop: theming.measures.measure050,
                            flexDirection: "column",
                            justifyContent: "center"
                        },
                        imageSrc: normalIconImagePath,
                        alt: "SubjectTreeImage"
                    });
                    var subAreaLabelContainer = this._context.factory.createElement("TEXT", {
                        id: "subAreaLabelContainer",
                        style: {
                            lineHeight: "1.4rem",
                            fontSize: theming.measures.measure100,
                            fontFamily: theming.fontfamilies.semibold,
                            color: theming.colors.basecolor.grey.grey7
                        }
                    }, subAreaLabel);
                    var entityTextContainer = this._context.factory.createElement("Container", {
                        id: "entityTextContainer",
                        style: {
                            flexDirection: "column",
                            justifyContent: "center",
                            float: "right",
                            width: "95%",
                            marginLeft: "10px"
                        }
                    }, [subAreaLabelContainer]);
                    var entityImageContainer = this._context.factory.createElement("Container", {
                        id: "entityImageContainer",
                        style: {
                            display: "inline-block",
                            borderRadius: "50%",
                            background: theming.colors.basecolor.blue.blue3
                        }
                    }, [entityImage]);
                    var entityHeader = this._context.factory.createElement("Container", {
                        key: SubjectTreeConfig.Constants.SubjectEntityDetailsContainerKey, id: SubjectTreeConfig.Constants.SubjectEntityDetailsContainerKey,
                        style: {
                            padding: theming.measures.measure100
                        }
                    }, [entityImageContainer, entityTextContainer]);
                    var contentContainerChild;
                    if (this._treeData.length != 0) {
                        var properties = {
                            parameters: {},
                            key: "subjectTreeControl",
                            id: "subjectTreeControl",
                            contextString: "subgrid",
                            configuration: {
                                FormFactor: 3 /* Desktop */,
                                CustomControlId: "MscrmControls.AppCommon.GenericTree.GenericTreeControl",
                                Name: "treeControl-Config",
                                Version: "1.0.0",
                                Parameters: {
                                    value: this.getValueParameter(this.onSelectionChanged.bind(this)),
                                    treeData: {
                                        Static: true,
                                        Type: "IInputNode",
                                        Value: this._treeData,
                                        Primary: false,
                                    }
                                }
                            }
                        };
                        contentContainerChild = this._context.factory.createComponent("MscrmControls.AppCommon.GenericTree.GenericTreeControl", "treeControl", properties);
                    }
                    var subjectTreeControlContainer = this._context.factory.createElement("CONTAINER", {
                        key: SubjectTreeConfig.Constants.SubjectTreeViewRightContainer, id: SubjectTreeConfig.Constants.SubjectTreeViewRightContainer,
                        style: {
                            width: "calc(100% - 1.25rem - 2px)",
                            height: "100%",
                            padding: theming.measures.measure125,
                            border: "1px solid " + theming.colors.basecolor.grey.grey4,
                            borderTop: "4px solid " + theming.colors.basecolor.blue.blue3
                        }
                    }, [contentContainerChild]);
                    var Container = this._context.factory.createElement("CONTAINER", {
                        key: SubjectTreeConfig.Constants.SubjectHeaderRightContainerKey, id: SubjectTreeConfig.Constants.SubjectHeaderRightContainerKey,
                        style: {
                            width: "100%",
                            height: "100%",
                            display: "block"
                        }
                    }, [headerRightContainerChild, entityHeader, subjectTreeControlContainer]);
                    return Container;
                };
                SubjectTreeConfigControl.prototype.getValueParameter = function (callback) {
                    return {
                        Usage: 3,
                        Static: false,
                        Value: [],
                        Type: "IInputNode",
                        Callback: callback,
                    };
                };
                SubjectTreeConfigControl.prototype.onSelectionChanged = function (e) {
                    if (e) {
                        var selectedSubject = {
                            id: e.id,
                            LogicalName: "Subject",
                            name: e.displayValue,
                            entityName: "Subject"
                        };
                        this.selectedSubjectParentId = e.parentId;
                        this.selectedSubject = selectedSubject;
                        this._notifyOutputChanged();
                        if (e.additionalParams && e.additionalParams["dblclick"]) {
                            this.onEditSubjectClick(null);
                        }
                    }
                    else {
                        console.log("Unexpected value recieved: " + e);
                    }
                };
                SubjectTreeConfigControl.prototype._updateSubjectTreeData = function (pagenumber) {
                    var _this = this;
                    this._fetchedNodesFromDB = true;
                    if (!pagenumber) {
                        pagenumber = 1;
                        this._treeData.length = 0;
                    }
                    var fetchAllSubjectRecords = '?$select=title,subjectid,_parentsubject_value,description';
                    var pagenumberSelector = '&$skiptoken=<cookie pagenumber="' + pagenumber.toString() + '"/>';
                    this._context.webAPI.retrieveMultipleRecords(SubjectTreeConfig.Constants.SubjectRetrieveTableName, fetchAllSubjectRecords + pagenumberSelector).then(function (subjectRecordsResponse) {
                        var data = [];
                        if (subjectRecordsResponse.entities.length > 0) {
                            subjectRecordsResponse.entities.forEach(function (subject) {
                                var node = {
                                    displayValue: subject.title,
                                    id: subject.subjectid,
                                    parentId: subject._parentsubject_value,
                                    additionalParams: {
                                        description: subject.description
                                    }
                                };
                                data.push(node);
                            });
                        }
                        if (_this._treeData.length == 0) {
                            _this._treeData = data;
                        }
                        else {
                            _this._treeData = _this._treeData.concat(data);
                        }
                        if (subjectRecordsResponse.nextLink) {
                            _this._updateSubjectTreeData(pagenumber + 1);
                        }
                        else {
                            _this._context.utils.requestRender(_this.alignSubjectTreeControl);
                        }
                    }, function (error) {
                        _this._fetchedNodesFromDB = false;
                        console.log(error);
                    });
                };
                /**
                 *  The below code changes were required to remove the spaces. It is a Hack Fix
                 */
                SubjectTreeConfigControl.prototype.alignSubjectTreeControl = function () {
                    var element = document.querySelector('div[data-id=SubjectTreeControl]');
                    if (element) {
                        element.style.border = '0';
                        var dialog = element.querySelector('div[data-id=dialogTabContainer');
                        var header = element.querySelector('div[data-id="dialogHeader"');
                        if (header && header.parentElement) {
                            header.parentElement.style.display = 'none';
                        }
                        if (dialog && dialog.children.length > 0) {
                            if (dialog.parentElement) {
                                dialog.parentElement.style.padding = '0';
                            }
                            // Hide Parent Scroll Bar
                            dialog.children[0].style.overflow = 'hidden';
                        }
                        SubjectTreeConfigControl.updateScrollBarUsingWindowResize();
                    }
                };
                /**
                 *  Update scroll bar of the generic tree control according to the browser size
                 */
                SubjectTreeConfigControl.updateScrollBarUsingWindowResize = function () {
                    var parentDivElement = document.querySelector('div[data-id=SubjectTreeControl]');
                    var headerDivElement = SubjectTreeConfigControl.getElementsByIDHelper(SubjectTreeConfig.Constants.SubjectHeaderRightContainerBodyKey);
                    var detailsDivElement = SubjectTreeConfigControl.getElementsByIDHelper(SubjectTreeConfig.Constants.SubjectEntityDetailsContainerKey);
                    var treeviewContainer = SubjectTreeConfigControl.getElementsByIDHelper(SubjectTreeConfig.Constants.SubjectTreeViewRightContainer);
                    if (parentDivElement && headerDivElement && detailsDivElement && treeviewContainer) {
                        var parentHeight = parentDivElement.offsetHeight;
                        var headerDivHeight = headerDivElement.offsetHeight;
                        var detailsDivHeight = detailsDivElement.offsetHeight;
                        var paddingTop = 24; // Padding 1.25rem added with 4px top border
                        var height = parentHeight - headerDivHeight - detailsDivHeight - paddingTop;
                        treeviewContainer.style.height = height + "px";
                    }
                };
                /**
                 *  Get elements by ID Helper
                 */
                SubjectTreeConfigControl.getElementsByIDHelper = function (elementUniqueId) {
                    var entityId = Xrm.Page.entityReference.entityType;
                    var elementId = "id-" + entityId + '-1-cc_subject_tree-' + elementUniqueId;
                    var element = document.getElementById(elementId);
                    if (element)
                        return element;
                    return null;
                };
                /**
                 * Creates RightContainer for header
                 */
                SubjectTreeConfigControl.prototype.createHeaderRightContainer = function () {
                    var theming = this._context.theming;
                    var addSubjectButtonIcon = this._context.factory.createElement("MICROSOFTICON", {
                        key: SubjectTreeConfig.Constants.SubjectAddButtonIconContainerKey, id: SubjectTreeConfig.Constants.SubjectAddButtonIconContainerKey,
                        type: 8,
                        style: this._applyStyles.FRERightButtonIconContainer()
                    }, []);
                    var addSubjectButton = this._context.factory.createElement("BUTTON", {
                        key: SubjectTreeConfig.Constants.SubjectAddButtonKey, id: SubjectTreeConfig.Constants.SubjectAddButtonKey,
                        onClick: this.onAddSubjectClick.bind(this),
                        title: this._context.resources.getString(SubjectTreeConfig.LabelId.AddSubjectButtonToolTip), tabindex: "0",
                        style: Object.assign({}, this._applyStyles.FREHeaderRightButtonStyle(), this._applyStyles.SubjectTreeConfigOverriddenButtonStyle())
                    }, [addSubjectButtonIcon, this._context.resources.getString(SubjectTreeConfig.LabelId.AddSubjectButtonLabel)]);
                    var editSubjectButtonIcon = this._context.factory.createElement("MICROSOFTICON", {
                        key: SubjectTreeConfig.Constants.SubjectEditButtonIconContainerKey, id: SubjectTreeConfig.Constants.SubjectEditButtonIconContainerKey,
                        type: 4,
                        style: this._applyStyles.FRERightButtonIconContainer()
                    }, []);
                    var editSubjectButton = this._context.factory.createElement("BUTTON", {
                        key: SubjectTreeConfig.Constants.SubjectEditButtonKey, id: SubjectTreeConfig.Constants.SubjectEditButtonKey,
                        onClick: this.onEditSubjectClick.bind(this),
                        title: this._context.resources.getString(SubjectTreeConfig.LabelId.EditSubjectButtonToolTip), tabindex: "0",
                        style: Object.assign({}, this._applyStyles.FREHeaderRightButtonStyle(), this._applyStyles.SubjectTreeConfigOverriddenButtonStyle())
                    }, [editSubjectButtonIcon, this._context.resources.getString(SubjectTreeConfig.LabelId.EditSubjectButtonLabel)]);
                    var removeSubjectButtonIcon = this._context.factory.createElement("MICROSOFTICON", {
                        key: SubjectTreeConfig.Constants.SubjectRemoveButtonIconContainerKey, id: SubjectTreeConfig.Constants.SubjectRemoveButtonIconContainerKey,
                        type: 7,
                        style: this._applyStyles.FRERightButtonIconContainer()
                    }, []);
                    var removeSubjectButton = this._context.factory.createElement("BUTTON", {
                        key: SubjectTreeConfig.Constants.SubjectRemoveButtonKey, id: SubjectTreeConfig.Constants.SubjectRemoveButtonKey,
                        onClick: this.onRemoveSubjectClick.bind(this),
                        title: this._context.resources.getString(SubjectTreeConfig.LabelId.RemoveSubjectButtonToolTip), tabindex: "0",
                        style: Object.assign({}, this._applyStyles.FREHeaderRightButtonStyle(), this._applyStyles.SubjectTreeConfigOverriddenButtonStyle())
                    }, [removeSubjectButtonIcon, this._context.resources.getString(SubjectTreeConfig.LabelId.RemoveSubjectButtonLabel)]);
                    var headerRightContainer = this._context.factory.createElement("CONTAINER", {
                        key: SubjectTreeConfig.Constants.SubjectHeaderRightContainerBodyKey, id: SubjectTreeConfig.Constants.SubjectHeaderRightContainerBodyKey,
                        style: {
                            width: "100%",
                            height: "40px",
                            background: theming.colors.basecolor.blue.blue3
                        }
                    }, [addSubjectButton, editSubjectButton, removeSubjectButton]);
                    return headerRightContainer;
                };
                SubjectTreeConfigControl.prototype.onAddSubjectClick = function (event) {
                    var dialogOptions = {};
                    dialogOptions.position = 2 /* side */;
                    var dialogArguements = {};
                    dialogArguements["selected_subject"] = this.selectedSubject;
                    var _that = this;
                    this._context.navigation.openDialog(SubjectTreeConfig.Constants.AddSubjectDialogName, dialogOptions, dialogArguements)
                        .then(function (resp) {
                        if (resp.parameters.last_selected_button == "save") {
                            _that._updateSubjectTreeData();
                            var confirmMessage = _that._context.resources.getString(SubjectTreeConfig.LabelId.AddSubjectConfirmation);
                            _that._context.utils.addGlobalNotification(1 /* toast */, 1 /* success */, confirmMessage, "", null).then(function (response) {
                                //Notification displayed successfully
                            }, function (error) {
                                console.error("Error displaying notification : " + error);
                            });
                        }
                        _that.selectedSubject = null;
                    }, function (error) {
                        _that.errorCallback(error);
                    });
                };
                SubjectTreeConfigControl.prototype.onEditSubjectClick = function (event) {
                    var _this = this;
                    var selectedEditSubject = this.selectedSubject;
                    if (selectedEditSubject && selectedEditSubject['name']) {
                        var parentSubjectId_1, parentSubjectName_1, description_1;
                        this._treeData.forEach(function (node) {
                            if (node.id == _this.selectedSubjectParentId) {
                                parentSubjectId_1 = node.id;
                                parentSubjectName_1 = node.displayValue;
                            }
                            if (node.id == selectedEditSubject.id) {
                                description_1 = node.additionalParams.description;
                            }
                        });
                        var selectedSubjectParent = {
                            id: (parentSubjectId_1 == undefined) ? null : parentSubjectId_1,
                            LogicalName: "Subject",
                            name: (parentSubjectName_1 == undefined) ? null : parentSubjectName_1,
                            entityName: "Subject",
                            childName: selectedEditSubject.name,
                            childId: selectedEditSubject.id,
                            description: description_1
                        };
                        var dialogOptions = {};
                        dialogOptions.position = 2 /* side */;
                        var dialogArguements = {};
                        dialogArguements["selected_subject"] = selectedSubjectParent;
                        var _that_1 = this;
                        this._context.navigation.openDialog(SubjectTreeConfig.Constants.EditSubjectDialogName, dialogOptions, dialogArguements)
                            .then(function (resp) {
                            if (resp.parameters.last_selected_button == "save") {
                                _that_1._updateSubjectTreeData();
                                var confirmMessage = _that_1._context.resources.getString(SubjectTreeConfig.LabelId.EditSubjectConfirmation);
                                _that_1._context.utils.addGlobalNotification(1 /* toast */, 1 /* success */, confirmMessage, "", null).then(function (response) {
                                    //Notification displayed successfully
                                }, function (error) {
                                    console.error("Error displaying notification : " + error);
                                });
                            }
                            _that_1.selectedSubject = null;
                        }, function (error) {
                            _that_1.errorCallback(error);
                        });
                    }
                    else {
                        //Open Alert Dialog
                        var alertMessage = {
                            text: this._context.resources.getString(SubjectTreeConfig.LabelId.EditSubjectAlertDescription),
                            confirmButtonLabel: this._context.resources.getString(SubjectTreeConfig.LabelId.OK)
                        };
                        this._context.navigation.openAlertDialog(alertMessage);
                    }
                };
                SubjectTreeConfigControl.prototype.onRemoveSubjectClick = function (event) {
                    if (this.selectedSubject && this.selectedSubject.id) {
                        var _that_2 = this;
                        //Open a confirm dialog
                        var dialogOptions = {};
                        dialogOptions.position = 1 /* center */;
                        var confirmDialogStrings = {
                            title: this._context.resources.getString(SubjectTreeConfig.LabelId.DeleteDialogConfirmationTitle),
                            text: this._context.resources.getString(SubjectTreeConfig.LabelId.DeleteDialogConfirmationDescription),
                            confirmButtonLabel: this._context.resources.getString(SubjectTreeConfig.LabelId.DeleteLabel),
                            cancelButtonLabel: this._context.resources.getString(SubjectTreeConfig.LabelId.CancelLabel)
                        };
                        this._context.navigation.openConfirmDialog(confirmDialogStrings, dialogOptions)
                            .then(function (result) {
                            if (result.confirmed) {
                                _that_2._context.webAPI.deleteRecord("subject", _that_2.selectedSubject.id).then(function (success) {
                                    _that_2._updateSubjectTreeData();
                                    var confirmMessage = _that_2._context.resources.getString(SubjectTreeConfig.LabelId.DeleteSubjectConfrimation);
                                    _that_2._context.utils.addGlobalNotification(1 /* toast */, 1 /* success */, confirmMessage, "", null).then(function (response) {
                                        //Notification displayed successfully
                                    }, function (error) {
                                        console.error("Error displaying notification : " + error);
                                    });
                                }, function (failure) {
                                    _that_2.errorCallback(failure);
                                });
                            }
                            _that_2.selectedSubject = null;
                        });
                    }
                    else {
                        //Open Alert Dialog
                        var alertMessage = {
                            text: this._context.resources.getString(SubjectTreeConfig.LabelId.DeleteSubjectAlertDescription),
                            confirmButtonLabel: this._context.resources.getString(SubjectTreeConfig.LabelId.OK)
                        };
                        this._context.navigation.openAlertDialog(alertMessage);
                    }
                };
                SubjectTreeConfigControl.prototype.errorCallback = function (error) {
                    Mscrm.AppCommon.Common.Utility.actionFailedErrorDialog(error);
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                SubjectTreeConfigControl.prototype.getOutputs = function () {
                    return {
                        selectedSubject: this.selectedSubject
                    };
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                SubjectTreeConfigControl.prototype.destroy = function () {
                    this._context = null;
                    this._freShell = null;
                    this._applyStyles = null;
                };
                return SubjectTreeConfigControl;
            }());
            SubjectTreeConfig.SubjectTreeConfigControl = SubjectTreeConfigControl;
        })(SubjectTreeConfig = AppCommon.SubjectTreeConfig || (AppCommon.SubjectTreeConfig = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
///<reference path="privatereferences.ts" /> 
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SubjectTreeConfig;
        (function (SubjectTreeConfig) {
            'use strict';
            var LabelId = (function () {
                function LabelId() {
                }
                return LabelId;
            }());
            /**
             * Subject Tree Configuration Control ARIA label.
             * Label value: SubjectTreeConfigControl
             */
            LabelId.AreaLabel = "SubjectHomePage.AreaLabel";
            LabelId.SubAreaLabel = "SubjectHomePage.SubAreaLabel";
            LabelId.AddSubjectButtonLabel = "SubjectHomePage.AddSubjectButtonLabel";
            LabelId.AddSubjectButtonToolTip = "SubjectHomePage.AddSubjectButtonToolTip";
            LabelId.EditSubjectButtonLabel = "SubjectHomePage.EditSubjectButtonLabel";
            LabelId.EditSubjectButtonToolTip = "SubjectHomePage.EditSubjectButtonToolTip";
            LabelId.RemoveSubjectButtonLabel = "SubjectHomePage.RemoveSubjectButtonLabel";
            LabelId.RemoveSubjectButtonToolTip = "SubjectHomePage.RemoveSubjectButtonToolTip";
            LabelId.DeleteDialogConfirmationTitle = "SubjectDialogue.DeleteSubjectConfirmationTitle";
            LabelId.DeleteDialogConfirmationDescription = "SubjectDialogue.DeleteSubjectConfirmationDescription";
            LabelId.DeleteLabel = "SubjectDialogue.DeleteLabel";
            LabelId.ConfirmLabel = "SubjectDialogue.ConfirmLabel";
            LabelId.CancelLabel = "SubjectDialogue.CancelLabel";
            LabelId.DeleteSubjectAlertDescription = "SubjectDialogue.DeleteSubjectAlertDescription";
            LabelId.EditSubjectAlertDescription = "SubjectDialogue.EditSubjectAlertDescription";
            LabelId.AddSubjectConfirmation = "SubjectHomePage.AddSubjectConfirmation";
            LabelId.EditSubjectConfirmation = "SubjectHomePage.EditSubjectConfirmation";
            LabelId.DeleteSubjectConfrimation = "SubjectHomePage.DeleteSubjectConfirmation";
            LabelId.OK = "SubjectDialogue.OK";
            LabelId.AdvancedSettingsText = "AdvancedSettingsText";
            LabelId.MicrosoftDynamics365Text = "MicrosoftDynamics365Text";
            LabelId.CC_SubjectTreeConfig_Name = "CC_SubjectTreeConfig_Name";
            SubjectTreeConfig.LabelId = LabelId;
        })(SubjectTreeConfig = AppCommon.SubjectTreeConfig || (AppCommon.SubjectTreeConfig = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SubjectTreeConfig;
        (function (SubjectTreeConfig) {
            'use strict';
            var SubjectTreeConfigStyles = (function (_super) {
                __extends(SubjectTreeConfigStyles, _super);
                function SubjectTreeConfigStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._subjectTreeConfigAddSubjectButtonIcon = {};
                    _this._subjectTreeConfigAddSubjectButtonLabel = {};
                    _this._subjectTreeConfigAddSubjectButtonText = {};
                    _this._subjectTreeConfigEditSubjectButtonIcon = {};
                    _this._subjectTreeConfigEditSubjectButtonLabel = {};
                    _this._subjectTreeConfigEditSubjectButtonText = {};
                    _this._subjectTreeConfigRemoveSubjectButtonIcon = {};
                    _this._subjectTreeConfigRemoveSubjectButtonLabel = {};
                    _this._subjectTreeConfigRemoveSubjectButtonText = {};
                    _this._subjectTreeConfigOverriddenButtonStyle = {};
                    _this._context = context;
                    _this._subjectTreeConfigAddSubjectButtonIcon = null;
                    _this._subjectTreeConfigAddSubjectButtonLabel = null;
                    _this._subjectTreeConfigAddSubjectButtonText = null;
                    _this._subjectTreeConfigEditSubjectButtonIcon = null;
                    _this._subjectTreeConfigEditSubjectButtonLabel = null;
                    _this._subjectTreeConfigEditSubjectButtonText = null;
                    _this._subjectTreeConfigRemoveSubjectButtonIcon = null;
                    _this._subjectTreeConfigRemoveSubjectButtonLabel = null;
                    _this._subjectTreeConfigRemoveSubjectButtonText = null;
                    _this._subjectTreeConfigOverriddenButtonStyle = null;
                    return _this;
                }
                SubjectTreeConfigStyles.prototype.SubjectTreeConfigAddSubjectButtonIcon = function () {
                    if (this._context.utils.isNullOrUndefined(this._subjectTreeConfigAddSubjectButtonIcon)) {
                        this._subjectTreeConfigAddSubjectButtonIcon = {};
                        this._subjectTreeConfigAddSubjectButtonIcon["margin"] = "0px";
                    }
                    return this._subjectTreeConfigAddSubjectButtonIcon;
                };
                SubjectTreeConfigStyles.prototype.SubjectTreeConfigAddSubjectButtonText = function () {
                    if (this._context.utils.isNullOrUndefined(this._subjectTreeConfigAddSubjectButtonText)) {
                        this._subjectTreeConfigAddSubjectButtonText = {};
                        this._subjectTreeConfigAddSubjectButtonText["margin"] = "0px";
                        this._subjectTreeConfigAddSubjectButtonText["fontSize"] = "16px";
                        this._subjectTreeConfigAddSubjectButtonText["color"] = "#0078D7";
                        this._subjectTreeConfigAddSubjectButtonText["letterSpacing"] = "0px";
                        this._subjectTreeConfigAddSubjectButtonText["whiteSpace"] = "nowrap";
                    }
                    return this._subjectTreeConfigAddSubjectButtonText;
                };
                SubjectTreeConfigStyles.prototype.SubjectTreeConfigOverriddenButtonStyle = function () {
                    if (this._context.utils.isNullOrUndefined(this._subjectTreeConfigAddSubjectButtonText)) {
                        this._subjectTreeConfigOverriddenButtonStyle = {};
                        var theming = this._context.theming;
                        this._subjectTreeConfigOverriddenButtonStyle["color"] = theming.colors.base.white;
                        this._subjectTreeConfigOverriddenButtonStyle["width"] = "auto";
                        this._subjectTreeConfigOverriddenButtonStyle["height"] = "40px";
                        this._subjectTreeConfigOverriddenButtonStyle["padding-right"] = theming.measures.measure100;
                        this._subjectTreeConfigOverriddenButtonStyle["padding-left"] = theming.measures.measure100;
                        this._subjectTreeConfigOverriddenButtonStyle["margin-right"] = 0;
                        this._subjectTreeConfigOverriddenButtonStyle["margin-left"] = 0;
                        this._subjectTreeConfigOverriddenButtonStyle["line-height"] = 0;
                        this._subjectTreeConfigOverriddenButtonStyle[":hover"] = {
                            fontFamily: "'SegoeUI', 'Segoe UI'",
                            background: theming.colors.basecolor.blue.blue4
                        };
                        this._subjectTreeConfigOverriddenButtonStyle[":focus"] = {
                            fontFamily: "'SegoeUI', 'Segoe UI'",
                            border: 0
                        };
                    }
                    return this._subjectTreeConfigOverriddenButtonStyle;
                };
                return SubjectTreeConfigStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            SubjectTreeConfig.SubjectTreeConfigStyles = SubjectTreeConfigStyles;
        })(SubjectTreeConfig = AppCommon.SubjectTreeConfig || (AppCommon.SubjectTreeConfig = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="Constants.ts" />
/// <reference path="SubjectTreeConfigControl.ts" />
/// <reference path="LabelId.ts" />
/// <reference path="SubjectTreeConfigStyles.ts" /> 
//# sourceMappingURL=SubjectTreeConfigControl.js.map