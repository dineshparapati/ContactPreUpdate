var ServiceCommon;
(function (ServiceCommon) {
    'use strict';
    //Output related interfaces
    var WeeklyScheduleControlOutput = (function () {
        function WeeklyScheduleControlOutput() {
        }
        return WeeklyScheduleControlOutput;
    }());
    ServiceCommon.WeeklyScheduleControlOutput = WeeklyScheduleControlOutput;
    var WeeklyScheduleControlOutputStatus;
    (function (WeeklyScheduleControlOutputStatus) {
        WeeklyScheduleControlOutputStatus[WeeklyScheduleControlOutputStatus["Error"] = 0] = "Error";
        WeeklyScheduleControlOutputStatus[WeeklyScheduleControlOutputStatus["Success"] = 1] = "Success";
    })(WeeklyScheduleControlOutputStatus = ServiceCommon.WeeklyScheduleControlOutputStatus || (ServiceCommon.WeeklyScheduleControlOutputStatus = {}));
    var WeeklyScheduleControlOutputData = (function () {
        function WeeklyScheduleControlOutputData() {
        }
        return WeeklyScheduleControlOutputData;
    }());
    ServiceCommon.WeeklyScheduleControlOutputData = WeeklyScheduleControlOutputData;
    var WorkRuleMode;
    (function (WorkRuleMode) {
        WorkRuleMode[WorkRuleMode["AllTheSameRules"] = 0] = "AllTheSameRules";
        WorkRuleMode[WorkRuleMode["VaryByDayRules"] = 1] = "VaryByDayRules";
        WorkRuleMode[WorkRuleMode["TwentyX7Support"] = 2] = "TwentyX7Support";
        WorkRuleMode[WorkRuleMode["NotWorking"] = 3] = "NotWorking";
    })(WorkRuleMode = ServiceCommon.WorkRuleMode || (ServiceCommon.WorkRuleMode = {}));
})(ServiceCommon || (ServiceCommon = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/**
* Telemetry library that takes dynamic parameter lists as event parameters in addition to fixed required parameters relavent to classify verticals association with Entities
* and pushes to crminsightsdev.cloudapp.net endpoint.  All one needs to do is Register your telemetry event with InsightsEndpoint repo (Events.xml and MdsConfig-CloudService.xml
* and start pushing event data using below APIs
*
* Sample calls for the APIs - caller : non-custom control eg: Ribbon commands
* AppsTelemetryUtility.reportData(EventList.EntitlementEvent, ModuleList.service, EntityList.entitlement, "Activation", null, { "CurrentState": "Activate", "UpdateMode": "Mouse"})
* AppsTelemetryUtility.reportData("CSHEntitlements", "Service", "Entitlement", "Deactivate", null, { "CurrentState": "Inactive", "UpdateMode": "KeyBoard"})
* Similarly ReportSuccess and Report Failure calls using either Enums (preferred) or string values.
* AppsTelemetryUtility.reportSuccess(EventList.EntitlementEvent, ModuleList.service, EntityList.entitlement, "TestAction", null, { "CurrentState": "Activate", "UpdateMode": "Mouse"})
* AppsTelemetryUtility.reportFailure(EventList.EntitlementEvent, ModuleList.service, EntityList.entitlement, "TestAction", null, { "CurrentState": "Activate", "UpdateMode": "Mouse"})
*
* Sample calls for the APIs - caller Custom Controls
* AppsTelemetryUtility.ReportSuccess(EventList.SubjectEvent, ModuleList.service, EntityList.CSSEvent, "AddBreak", this.context, {"Duration": 30, "Timezone": "PST"});
* AppsTelemetryUtility.ReportFailure("CSH_Subject", "Service", "Subject", "AddChild", this.context, {"name": "myRegarding", "parent": "myEntity"});
*
* In above samples for non-custom control calls, null is expected to be passed as part of event call for two reasons 1. Generic API for custom & non-custom control
*/
var AppsTelemetryLib;
(function (AppsTelemetryLib) {
    'use strict';
    /**
    * To format the outer payload for telemetry data according to the event schema
    */
    var TelemetryPayload = (function () {
        function TelemetryPayload() {
        }
        return TelemetryPayload;
    }());
    AppsTelemetryLib.TelemetryPayload = TelemetryPayload;
    /**
    * To format the inner payload for telemetry data according to the event schema
    */
    var TelemetryParameter = (function () {
        function TelemetryParameter() {
        }
        return TelemetryParameter;
    }());
    AppsTelemetryLib.TelemetryParameter = TelemetryParameter;
    /**
    * Declaring this key value pair to make it easy for callers
    */
    var ExtraParams = (function () {
        function ExtraParams() {
        }
        return ExtraParams;
    }());
    AppsTelemetryLib.ExtraParams = ExtraParams;
    /**
    * ENUMs tracking EventTypes
    */
    var EventTypes = (function () {
        function EventTypes() {
        }
        return EventTypes;
    }());
    EventTypes.Success = "Success";
    EventTypes.Failure = "Failure";
    EventTypes.EventData = "EventData";
    AppsTelemetryLib.EventTypes = EventTypes;
    /**
    * ENUMs tracking Vertical Events. Callers of Client Telemetry APIs can use ENUMs to pass required parameters
    * Currently listed with registered Customer Service Module List
    */
    var EventList = (function () {
        function EventList() {
        }
        return EventList;
    }());
    EventList.QueueEvent = "CSHQueues";
    EventList.RoutingRuleEvent = "CSHRoutingRules";
    EventList.ARCEvent = "CSHAutoRecordCreation";
    EventList.SubjectEvent = "CSHSubject";
    EventList.HSEvent = "CSHHolidaySchedule";
    EventList.CSSEvent = "CSHCustomerServiceSchedule";
    EventList.SettingsEvent = "CSHSettings";
    EventList.EntitlementEvent = "CSHEntitlements";
    EventList.IncidentEvent = "CSHIncident";
    EventList.EventAgnostic = "CSHMisc";
    AppsTelemetryLib.EventList = EventList;
    /**
    * ENUMs tracking Vertical/Module List
    */
    var ModuleList = (function () {
        function ModuleList() {
        }
        return ModuleList;
    }());
    ModuleList.service = "Service";
    ModuleList.sales = "Sales";
    ModuleList.marketing = "Marketing";
    ModuleList.verticalAgnostic = "VerticalAgnostic";
    AppsTelemetryLib.ModuleList = ModuleList;
    /**
    * ENUMs tracking Entity List
    * Currently listing entities list part of Customer Service Module shipping in Enterprise Release
    */
    var EntityList = (function () {
        function EntityList() {
        }
        return EntityList;
    }());
    EntityList.queue = "Queue";
    EntityList.queueItem = "QueueItem";
    EntityList.convertRule = "ConvertRule";
    EntityList.convertRuleItem = "ConvertRuleItem";
    EntityList.routingRule = "RoutingRule";
    EntityList.routingRuleItem = "RoutingRuleItem";
    EntityList.entitlement = "Entitlement";
    EntityList.entitlementTemplate = "EntitlementTemplate";
    EntityList.sla = "SLA";
    EntityList.slaItem = "SLAItem";
    EntityList.calendar = "Calendar";
    EntityList.calendarRule = "CalendarRule";
    EntityList.subject = "Subject";
    EntityList.incident = "Incident";
    EntityList.organization = "organization";
    AppsTelemetryLib.EntityList = EntityList;
    /**
    * ENUMs tracking Action
    */
    var Action = (function () {
        function Action() {
        }
        return Action;
    }());
    Action.create = "Create";
    Action.update = "Update";
    Action.retrieve = "Retrieve";
    Action.delete = "Delete";
    Action.clickedGridCommand = "ClickedGridCommand";
    AppsTelemetryLib.Action = Action;
    var AppsTelemetryUtility = (function () {
        function AppsTelemetryUtility() {
        }
        /**
        * @function reportEventData send telemetry data to the crminsightsdev.cloudapp.net endpoint.
        * @description send telemetry data to the telemetry endpoint.
        * @param appName - service / sales / any other XRM based app
        * @param context -  A reference to the context of custom entity; null for non-custom entity calls
        */
        AppsTelemetryUtility.reportData = function (eventName, appName, entityName, actionName, context, eventSpecificParams) {
            var telemetrydata = AppsTelemetryUtility.getTelemetryData(eventName, EventTypes.EventData, appName, entityName, actionName, context, eventSpecificParams);
            // Async calls be made to reportEvent call and error scenarios are expected to be handled within reportEvent infra
            if (context != null && context.reporting != null) {
                context.reporting.reportEvent(telemetrydata);
            }
            else {
                Xrm.Reporting.reportEvent(telemetrydata);
            }
        };
        ;
        AppsTelemetryUtility.reportFailure = function (eventName, appName, entityName, actionName, context, eventSpecificParams) {
            var telemetrydata = AppsTelemetryUtility.getTelemetryData(eventName, EventTypes.Failure, appName, entityName, actionName, context, eventSpecificParams);
            if (context != null && context.reporting != null) {
                context.reporting.reportEvent(telemetrydata);
            }
            else {
                Xrm.Reporting.reportEvent(telemetrydata);
            }
        };
        ;
        AppsTelemetryUtility.reportError = function (eventName, appName, entityName, actionName, context, errorMessage, errorTrace) {
            var eventSpecificParams = {};
            eventSpecificParams["errorMessage"] = errorMessage;
            eventSpecificParams["errorTrace"] = errorTrace ? JSON.stringify(errorTrace, Object.getOwnPropertyNames(errorTrace)) : "";
            AppsTelemetryUtility.reportFailure(eventName, appName, entityName, actionName, context, eventSpecificParams);
        };
        ;
        AppsTelemetryUtility.reportSuccess = function (eventName, appName, entityName, actionName, context, eventSpecificParams) {
            var telemetrydata = AppsTelemetryUtility.getTelemetryData(eventName, EventTypes.Success, appName, entityName, actionName, context, eventSpecificParams);
            if (context != null && context.reporting != null) {
                context.reporting.reportEvent(telemetrydata);
            }
            else {
                Xrm.Reporting.reportEvent(telemetrydata);
            }
        };
        ;
        AppsTelemetryUtility.getTelemetryData = function (_eventName, _telemetryDatatype, _appName, _entityName, _actionName, _context, _eventSpecificParams) {
            var payload = {
                eventName: _eventName,
                eventParameters: []
            };
            var para1 = { name: "EventType", value: _telemetryDatatype };
            var para2 = { name: "appName", value: _appName };
            var para3 = { name: "entityName", value: _entityName };
            var para4 = { name: "actionName", value: _actionName };
            var para5 = { name: "context", value: _context };
            payload.eventParameters.push(para1);
            payload.eventParameters.push(para2);
            payload.eventParameters.push(para3);
            payload.eventParameters.push(para4);
            payload.eventParameters.push(para5);
            var __eventSpecificParams = JSON.stringify(_eventSpecificParams);
            var para6 = { name: "eventSpecificParams", value: __eventSpecificParams };
            payload.eventParameters.push(para6);
            return payload;
        };
        return AppsTelemetryUtility;
    }());
    AppsTelemetryLib.AppsTelemetryUtility = AppsTelemetryUtility;
})(AppsTelemetryLib || (AppsTelemetryLib = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../../ServiceCommon/CalendarDataInterfaces.ts" />
/// <reference path="../../../../ClientUtility/Client/Common/AppsTelemetryLib.ts"/> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SetWorkHour;
        (function (SetWorkHour) {
            'use strict';
            var SetWorkHourControl = (function () {
                /**
                 * Empty constructor.
                 */
                function SetWorkHourControl() {
                    var _this = this;
                    this._setWorkHoursOutput = null;
                    this._timeSheetDataHandler = null;
                    this.setWorkHoursInfo = {};
                    this.openAlertDialogAndResetValue = function (alertString, resetValueFunc, index, oldValue) {
                        _this._context.navigation.openAlertDialog({ text: alertString }).then(function () {
                            resetValueFunc(index, oldValue);
                        });
                    };
                    // converts offset in HH:MM format
                    this.convertOffsetIntoTime = function (offset) {
                        var time = "";
                        var minutesPart = offset % 60;
                        var hoursPart = (offset - minutesPart) / 60;
                        if (hoursPart.toString().length == 1) {
                            hoursPart = "0" + hoursPart;
                        }
                        if (minutesPart.toString().length == 1) {
                            minutesPart = "0" + minutesPart;
                        }
                        time = hoursPart + ":" + minutesPart;
                        return time;
                    };
                    // On End Time Change at index 
                    this.OnChangeEndTimeAtIndex = function (index, oldEndTimeStr, event) {
                        var newEndTimeStr = event.target.value;
                        if (oldEndTimeStr == newEndTimeStr) {
                            return;
                        }
                        var oldEndTime = _this._timeSheetDataHandler.getEndTimeAtIndex(index);
                        var newEndTime = _this.toDateTime(newEndTimeStr);
                        var startTime = _this._timeSheetDataHandler.getStartTimeAtIndex(index);
                        if (isNaN(newEndTime.getTime())) {
                            _this.resetEndTime(index, oldEndTime);
                            return;
                        }
                        _this._timeSheetDataHandler.setEndTimeAtIndex(index, newEndTime);
                        // reset the value if end time is not greater than start time of current row
                        if (newEndTime <= startTime) {
                            _this.openAlertDialogAndResetValue(SetWorkHour.SetWorkHourLocale.SWH_End_Time_Earlier, _this.resetEndTime, index, oldEndTime);
                            return;
                        }
                        var startTimeWorkHours = _this._timeSheetDataHandler.getStartTime();
                        startTimeWorkHours.setMinutes(startTimeWorkHours.getMinutes() + SetWorkHour.SetWorkHourAddBreakHandlerConstants.ApptStartEvery);
                        // if user is changing end time of last row
                        // difference between the end time and start time of work hour control should be greater than 5 minutes
                        if (index == _this._timeSheetDataHandler.getCalendarRulesLength() - 1 && newEndTime < startTimeWorkHours) {
                            _this.openAlertDialogAndResetValue(SetWorkHour.SetWorkHourLocale.SWH_End_Time_Earlier_Five, _this.resetEndTime, index, oldEndTime);
                            return;
                        }
                        var overlappingCalendarRules;
                        overlappingCalendarRules = _this._timeSheetDataHandler.getOverlappingRulesOnEndTimeChangeAtIndex(index, newEndTime);
                        if (overlappingCalendarRules == null || overlappingCalendarRules.length == 0) {
                            _this._timeSheetDataHandler.changeEndTimeAtIndex(index, newEndTime);
                            _this.refreshOutputAndRerender();
                        }
                        else {
                            _this._context.navigation.openConfirmDialog(_this.getOverlappingAlertDialogString(overlappingCalendarRules)).then(function (result) {
                                if (result.confirmed) {
                                    _this._timeSheetDataHandler.changeEndTimeAtIndex(index, newEndTime);
                                    _this.refreshOutputAndRerender();
                                }
                                else {
                                    _this.resetEndTime(index, oldEndTime);
                                    return;
                                }
                            });
                        }
                    };
                    // On Start Time Change at index 
                    this.OnChangeStartTimeAtIndex = function (index, oldStartTimeStr, event) {
                        var newStartTimeStr = event.target.value;
                        if (oldStartTimeStr == newStartTimeStr) {
                            return;
                        }
                        var oldStartTime = _this._timeSheetDataHandler.getStartTimeAtIndex(index);
                        var newStartTime = _this.toDateTime(newStartTimeStr);
                        var endTime = _this._timeSheetDataHandler.getEndTimeAtIndex(index);
                        if (isNaN(newStartTime.getTime())) {
                            _this.resetStartTime(index, oldStartTime);
                            return;
                        }
                        _this._timeSheetDataHandler.setStartTimeAtIndex(index, newStartTime);
                        // reset the value if start time is not smaller than end time of current row
                        if (newStartTime >= endTime) {
                            _this.openAlertDialogAndResetValue(SetWorkHour.SetWorkHourLocale.SWH_Start_Time_Later, _this.resetStartTime, index, oldStartTime);
                            return;
                        }
                        var endTimeWorkHours = _this._timeSheetDataHandler.getEndTime();
                        endTimeWorkHours.setMinutes(endTimeWorkHours.getMinutes() - SetWorkHour.SetWorkHourAddBreakHandlerConstants.ApptStartEvery);
                        // if user is changing start time of first row
                        // difference between the end time and start time of work hour control should be greater than 5 minutes
                        if (index == 0 && newStartTime > endTimeWorkHours) {
                            _this.openAlertDialogAndResetValue(SetWorkHour.SetWorkHourLocale.SWH_Start_Time_Later_Five, _this.resetStartTime, index, oldStartTime);
                            return;
                        }
                        var overlappingCalendarRules;
                        overlappingCalendarRules = _this._timeSheetDataHandler.getOverlappingRulesOnStartTimeChangeAtIndex(index, newStartTime);
                        if (overlappingCalendarRules == null || overlappingCalendarRules.length == 0) {
                            _this._timeSheetDataHandler.changeStartTimeAtIndex(index, newStartTime);
                            _this.refreshOutputAndRerender();
                        }
                        else {
                            _this._context.navigation.openConfirmDialog(_this.getOverlappingAlertDialogString(overlappingCalendarRules)).then(function (result) {
                                if (result.confirmed) {
                                    _this._timeSheetDataHandler.changeStartTimeAtIndex(index, newStartTime);
                                    _this.refreshOutputAndRerender();
                                }
                                else {
                                    _this.resetStartTime(index, oldStartTime);
                                    return;
                                }
                            });
                        }
                    };
                    this.getOverlappingAlertDialogString = function (overlappingCalendarRules) {
                        var overlappingRangeAlertMessage = SetWorkHour.SetWorkHourLocale.SWH_Time_Overlaps + "\n";
                        var overlappingRanges = _this.getOverlappingRangeString(overlappingCalendarRules);
                        overlappingRangeAlertMessage += overlappingRanges;
                        overlappingRangeAlertMessage += SetWorkHour.SetWorkHourLocale.SWH_Merge_Ranges;
                        var confirmDialogStrings = {
                            title: SetWorkHour.SetWorkHourLocale.SWH_Merge_Ranges,
                            text: overlappingRangeAlertMessage
                        };
                        return confirmDialogStrings;
                    };
                    // returns overlapping range in format StartTime - EndTime
                    this.getOverlappingRangeString = function (overlappingRules) {
                        var overlappingRange = "";
                        for (var i = 0; i < overlappingRules.length; i++) {
                            overlappingRange += _this.convertOffsetIntoTime(overlappingRules[i].offset) + " - " + _this.convertOffsetIntoTime(overlappingRules[i].offset + overlappingRules[i].duration) + "\n";
                        }
                        return overlappingRange;
                    };
                    /**
                     * returns date object
                     * @param time time in format HH:MM
                     */
                    this.toDateTime = function (time) {
                        var convertedDate = new Date(SetWorkHour.SetWorkHourAddBreakHandlerConstants.ApptStartDate);
                        convertedDate.setHours(parseInt(time.substr(0, time.indexOf(":"))));
                        convertedDate.setMinutes(parseInt(time.substr(time.indexOf(":") + 1)));
                        return convertedDate;
                    };
                    this.resetEndTime = function (index, oldEndTime) {
                        _this._timeSheetDataHandler.setEndTimeAtIndex(index, oldEndTime);
                        _this._context.utils.requestRender();
                    };
                    this.resetStartTime = function (index, oldStartTime) {
                        _this._timeSheetDataHandler.setStartTimeAtIndex(index, oldStartTime);
                        _this._context.utils.requestRender();
                    };
                    // break action button handler to segregate calls to InsertBreakAtIndex and DeleteBreakAtIndex methods
                    this.breakActionButtonClicked = function (ruleType, rowId, event) {
                        // if action corresponds to workhour ruletype then call the InsertBreakAtIndex method with rowId
                        // else call the DeleteBreakAtIndex method with rowId
                        // and finally render the page to load the refreshed/recalculated calendarrules/workhours
                        if (ruleType == AppCommon.CalendarRuleType.WorkHour) {
                            _this._timeSheetDataHandler.insertBreakAtIndex(rowId);
                        }
                        else {
                            var calendarRuleSets = _this._timeSheetDataHandler.getCalendarRules();
                            if (calendarRuleSets.length - 1 == rowId + 1) {
                                SetWorkHourControl._lastBreakDeleted = true;
                                SetWorkHourControl._lastRowIndex = rowId - 1;
                            }
                            _this._timeSheetDataHandler.deleteBreakAtIndex(rowId);
                        }
                        _this.refreshOutputAndRerender();
                    };
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                SetWorkHourControl.prototype.init = function (context, notifyOutputChanged, state) {
                    var _this = this;
                    // custom code goes here
                    this._context = context;
                    SetWorkHour.SetWorkHourStyles.initialize(this._context.theming, this._context.client.isRTL);
                    SetWorkHour.SetWorkHourLocale.initialize(function (id) { return _this._context.resources.getString(id); });
                    this.setWorkHoursInfo = this._context.parameters.setWorkHourControlInput.raw;
                    this.updateLeafCalRules();
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                SetWorkHourControl.prototype.updateView = function (context) {
                    if (!this._context.utils.isNullOrUndefined(this._context.parameters.setWorkHourControlInput)) {
                        var setWorkHoursInfo = {};
                        setWorkHoursInfo = this._context.parameters.setWorkHourControlInput.raw;
                        if (!this._context.utils.isNullOrUndefined(setWorkHoursInfo.leafCalRules) && setWorkHoursInfo.leafCalRules.length > 0) {
                            if (this._context.utils.isNullOrUndefined(this._timeSheetDataHandler)) {
                                this._timeSheetDataHandler = new SetWorkHour.TimeSheetDataHandler(setWorkHoursInfo.leafCalRules, this._context);
                                this.notifyOutputChangedWrapper();
                            }
                            return this.getMainContainer();
                        }
                    }
                    return;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                SetWorkHourControl.prototype.getOutputs = function () {
                    var result = { setWorkHourControlOutput: this._setWorkHoursOutput };
                    return result;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                SetWorkHourControl.prototype.destroy = function () {
                };
                SetWorkHourControl.prototype.updateLeafCalRules = function () {
                    // preparing input for setworkhour control
                    var _that = this;
                    if (this.isValidInnerCalendarId(this.setWorkHoursInfo.innerCalendarId)) {
                        this.getCalendarRules(this.setWorkHoursInfo.innerCalendarId).then(function (data) {
                            _that.setWorkHoursInfo.leafCalRules = data.calendar_calendar_rules;
                            if (_that._context.utils.isNullOrUndefined(_that._timeSheetDataHandler)) {
                                _that._timeSheetDataHandler = new SetWorkHour.TimeSheetDataHandler(_that.setWorkHoursInfo.leafCalRules, _that._context);
                                _that.notifyOutputChangedWrapper();
                            }
                        }, function (error) {
                            var errMessage = "Retrieval of calendar rules failed.";
                            SetWorkHourControl.reportErrorTelemetry(_that._context, errMessage);
                        });
                    }
                    else {
                        this.getUserDefaultWorkHours(this.setWorkHoursInfo.resourceId).then(function (data) {
                            _that.setWorkHoursInfo.leafCalRules = _that.getCalendarRuleFromUserSettings(data);
                            if (_that._context.utils.isNullOrUndefined(_that._timeSheetDataHandler)) {
                                _that._timeSheetDataHandler = new SetWorkHour.TimeSheetDataHandler(_that.setWorkHoursInfo.leafCalRules, _that._context);
                                _that.notifyOutputChangedWrapper();
                            }
                        }, function (error) {
                            var errMessage = "Retrieval of user settings failed.";
                            SetWorkHourControl.reportErrorTelemetry(_that._context, errMessage);
                        });
                    }
                };
                // to validate if innerCalendarId is null/empty/undefined
                SetWorkHourControl.prototype.isValidInnerCalendarId = function (innerCalendarId) {
                    if (innerCalendarId == null || innerCalendarId == "") {
                        return false;
                    }
                    else {
                        return true;
                    }
                };
                // to fetch the calendar rules of the given innerCalendarId
                SetWorkHourControl.prototype.getCalendarRules = function (innerCalendarId) {
                    return this._context.webAPI.retrieveRecord("calendar", innerCalendarId, "?$expand=calendar_calendar_rules");
                };
                // to fetch the workday start and stop time from user settings incase of empty/null innerCalendarId
                SetWorkHourControl.prototype.getUserDefaultWorkHours = function (resourceId) {
                    return this._context.webAPI.retrieveRecord("usersettings", resourceId, "?$select=workdaystarttime,workdaystoptime");
                };
                // initialize calendar rules after fetching data from user settings, temporarily returning the cal rule
                SetWorkHourControl.prototype.getCalendarRuleFromUserSettings = function (data) {
                    var calendarRules = new Array();
                    var offset;
                    if (data["workdaystarttime"] == null) {
                        offset = 480;
                    }
                    else {
                        offset = (data["workdaystarttime"].substring(0, 2) * 60) + (data["workdaystarttime"].substring(3, 5) * 1);
                    }
                    var duration;
                    if (data["workdaystoptime"] == null) {
                        duration = 540;
                    }
                    else {
                        var workDayStopTime = (data["workdaystoptime"].substring(0, 2) * 60) + (data["workdaystoptime"].substring(3, 5) * 1);
                        // if Stop Time is less than start time then settings work Day Stop time to 24 hours
                        if (workDayStopTime < offset || workDayStopTime == 0) {
                            workDayStopTime = 24 * 60;
                        }
                        duration = workDayStopTime - offset;
                    }
                    var calRule = {
                        offset: offset,
                        duration: duration,
                        timecode: MscrmControls.AppCommon.TimeCode.Available,
                        subcode: MscrmControls.AppCommon.SubCode.Schedulable,
                        effort: 1
                    };
                    calendarRules.push(calRule);
                    return calendarRules;
                };
                /**
                 * Logs error telemetry
                 * @param context The "Input Bag" containing the parameters and other control metadata.
                 * @param errorMessage error message to be reported
                 * @param errorTrace stack trace information about error
                 */
                SetWorkHourControl.reportErrorTelemetry = function (context, errorMessage, errorTrace) {
                    AppsTelemetryLib.AppsTelemetryUtility.reportError(AppsTelemetryLib.EventList.CSSEvent, AppsTelemetryLib.ModuleList.service, AppsTelemetryLib.EntityList.calendarRule, AppsTelemetryLib.Action.update, context, errorMessage, errorTrace);
                };
                SetWorkHourControl.prototype.notifyOutputChangedWrapper = function () {
                    this.getRuleXMLfromCalRules();
                    this._notifyOutputChanged();
                };
                SetWorkHourControl.prototype.getRuleXMLfromCalRules = function () {
                    if (this._context.utils.isNullOrUndefined(this._setWorkHoursOutput)) {
                        this._setWorkHoursOutput = {
                            startDateTime: this._timeSheetDataHandler.getStartTimeOfTheDay(),
                            endDateTime: this._timeSheetDataHandler.getEndTimeOfTheDay(),
                            ruleXML: this._timeSheetDataHandler.getRuleXML(),
                            isDirty: false
                        };
                    }
                };
                // to generate the main container UI to display the work hours in detail
                SetWorkHourControl.prototype.getMainContainer = function () {
                    // to construct the workhour table header - call to getWorkHoursTableHeader()
                    var tableHeaderContainer = this._context.factory.createElement("TABLEHEADER", {
                        id: SetWorkHour.SetWorkHourConstants.TABLE_HEADER_CONTAINER,
                        key: SetWorkHour.SetWorkHourConstants.TABLE_HEADER_CONTAINER
                    }, this.getWorkHoursTableHeader());
                    // to construct the workhour table body - call to getWorkHourRows()
                    var tableBodyContainer = this._context.factory.createElement("TABLEBODY", {
                        id: SetWorkHour.SetWorkHourConstants.TABLE_BODY_CONTAINER,
                        key: SetWorkHour.SetWorkHourConstants.TABLE_BODY_CONTAINER
                    }, this.getWorkHourRows());
                    // to construct the workhour table
                    var tableContainer = this._context.factory.createElement("TABLE", {
                        id: SetWorkHour.SetWorkHourConstants.TABLE_CONTAINER,
                        key: SetWorkHour.SetWorkHourConstants.TABLE_CONTAINER,
                        style: SetWorkHour.SetWorkHourStyles.table
                    }, [tableHeaderContainer, tableBodyContainer]);
                    var mainContainer = this._context.factory.createElement("CONTAINER", {
                        id: SetWorkHour.SetWorkHourConstants.MAIN_CONTAINER,
                        key: SetWorkHour.SetWorkHourConstants.MAIN_CONTAINER,
                        style: SetWorkHour.SetWorkHourStyles.mainContainer
                    }, [this.getTitleDetails(), tableContainer, this.getWorkHourSummary()]);
                    return mainContainer;
                };
                // to construct the workhours table row header
                SetWorkHourControl.prototype.getWorkHoursTableHeader = function () {
                    // to construct the first column of the header - Type
                    var headerCellToDisplayType = this.createTableHeaderCell(SetWorkHour.SetWorkHourConstants.TABLE_HEADER_CELL_TYPE, SetWorkHour.SetWorkHourConstants.TABLE_HEADER_CELL_TYPE, SetWorkHour.SetWorkHourLocale.SWH_Type, 0);
                    // to construct the second column of the header - Start
                    var headerCellToDisplayStart = this.createTableHeaderCell(SetWorkHour.SetWorkHourConstants.TABLE_HEADER_CELL_START, SetWorkHour.SetWorkHourConstants.TABLE_HEADER_CELL_START, SetWorkHour.SetWorkHourLocale.SWH_Start, 1);
                    // to construct the third column of the header - End
                    var headerCellToDisplayEnd = this.createTableHeaderCell(SetWorkHour.SetWorkHourConstants.TABLE_HEADER_CELL_END, SetWorkHour.SetWorkHourConstants.TABLE_HEADER_CELL_END, SetWorkHour.SetWorkHourLocale.SWH_End, 1);
                    // to construct the fourth column of the header - Buttons
                    var headerCellToDisplayButtons = this.createTableHeaderCell(SetWorkHour.SetWorkHourConstants.TABLE_HEADER_CELL_BUTTON, SetWorkHour.SetWorkHourConstants.TABLE_HEADER_CELL_BUTTON, SetWorkHour.SetWorkHourConstants.EMPTY_SPACE_STRING, 0);
                    // to construct the table row
                    return this.createTableRow(SetWorkHour.SetWorkHourConstants.TABLE_HEADER_ROW, SetWorkHour.SetWorkHourConstants.TABLE_HEADER_ROW, [headerCellToDisplayType, headerCellToDisplayStart, headerCellToDisplayEnd, headerCellToDisplayButtons], SetWorkHour.SetWorkHourStyles.tableHeaderRow);
                };
                // to construct the workhours rows
                SetWorkHourControl.prototype.getWorkHourRows = function () {
                    var rowsContainer = new Array();
                    var _calendarRuleSet = this._timeSheetDataHandler.getCalendarRules();
                    for (var rowId = 0; rowId < _calendarRuleSet.length; rowId++) {
                        var startTime = this.convertOffsetIntoTime(_calendarRuleSet[rowId].offset);
                        var endTime = this.convertOffsetIntoTime(_calendarRuleSet[rowId].offset + _calendarRuleSet[rowId].duration);
                        var ruleType = _calendarRuleSet[rowId].calendarRuleType;
                        var rowContainer = this.getRowContainer(startTime, endTime, ruleType, rowId);
                        rowsContainer.push(rowContainer);
                    }
                    return rowsContainer;
                };
                // to generate the work hour row container in detail with calendar type, start time, end time and button
                SetWorkHourControl.prototype.getRowContainer = function (startTime, endTime, ruleType, rowId) {
                    // to construct the first column of the row - Type
                    var tableCellForType = this.getTypeCell(rowId, ruleType);
                    // to construct the second column of the row - Start
                    var tableCellForStart = this.getStartTimeCell(rowId, startTime, ruleType);
                    // to construct the third column of the row - End
                    var tableCellForEnd = this.getEndTimeCell(rowId, endTime, ruleType);
                    // to construct the fourth column of the row - Buttons
                    var tableCellForButtons = this.getActionCell(rowId, ruleType);
                    // to construct the table row
                    var rowContainer = this.createTableRow(SetWorkHour.SetWorkHourConstants.TABLE_ROW_CONTAINER + rowId, SetWorkHour.SetWorkHourConstants.TABLE_ROW_CONTAINER + rowId, [tableCellForType, tableCellForStart, tableCellForEnd, tableCellForButtons]);
                    return rowContainer;
                };
                // to construct the first column of the row - Type
                SetWorkHourControl.prototype.getTypeCell = function (rowId, ruleType) {
                    var labelForType = this._context.factory.createElement("LABEL", {
                        id: SetWorkHour.SetWorkHourConstants.LABEL_CELL_TYPE + rowId,
                        key: SetWorkHour.SetWorkHourConstants.LABEL_CELL_TYPE + rowId
                    }, ruleType == AppCommon.CalendarRuleType.WorkHour ? SetWorkHour.SetWorkHourLocale.SWH_WorkHours : SetWorkHour.SetWorkHourLocale.SWH_Break);
                    var containerForLabelType = this._context.factory.createElement("CONTAINER", {
                        id: SetWorkHour.SetWorkHourConstants.CELL_TYPE_CONTAINER + rowId,
                        key: SetWorkHour.SetWorkHourConstants.CELL_TYPE_CONTAINER + rowId,
                        style: ruleType == AppCommon.CalendarRuleType.WorkHour ? SetWorkHour.SetWorkHourStyles.tableCellFirstContainerWorkHourRow : SetWorkHour.SetWorkHourStyles.tableCellFirstContainerBreakRow
                    }, labelForType);
                    return this.createTableRowHeaderCell(SetWorkHour.SetWorkHourConstants.TABLE_BODY_CELL_TYPE + rowId, SetWorkHour.SetWorkHourConstants.TABLE_BODY_CELL_TYPE + rowId, containerForLabelType);
                };
                // to construct the second column of the row - Start
                SetWorkHourControl.prototype.getStartTimeCell = function (rowId, startTime, ruleType) {
                    var textInputForStart = this._context.factory.createElement("TEXTINPUT", {
                        id: SetWorkHour.SetWorkHourConstants.LABEL_CELL_START + rowId,
                        key: SetWorkHour.SetWorkHourConstants.LABEL_CELL_START + rowId,
                        value: startTime,
                        onBlur: this.OnChangeStartTimeAtIndex.bind(this, rowId, startTime),
                        style: SetWorkHour.SetWorkHourStyles.widthForTextbox
                    });
                    var containerForTextInputStart = this._context.factory.createElement("CONTAINER", {
                        id: SetWorkHour.SetWorkHourConstants.CELL_START_CONTAINER + rowId,
                        key: SetWorkHour.SetWorkHourConstants.CELL_START_CONTAINER + rowId,
                        style: ruleType == AppCommon.CalendarRuleType.WorkHour ? SetWorkHour.SetWorkHourStyles.tableCellMiddleContainerWorkHourRow : SetWorkHour.SetWorkHourStyles.tableCellMiddleContainerBreakRow
                    }, textInputForStart);
                    return this.createTableBodyCell(SetWorkHour.SetWorkHourConstants.TABLE_BODY_CELL_START + rowId, SetWorkHour.SetWorkHourConstants.TABLE_BODY_CELL_START + rowId, containerForTextInputStart);
                };
                // to construct the third column of the row - End
                SetWorkHourControl.prototype.getEndTimeCell = function (rowId, endTime, ruleType) {
                    var textInputForEnd = this._context.factory.createElement("TEXTINPUT", {
                        id: SetWorkHour.SetWorkHourConstants.LABEL_CELL_END + rowId,
                        key: SetWorkHour.SetWorkHourConstants.LABEL_CELL_END + rowId,
                        value: endTime,
                        onBlur: this.OnChangeEndTimeAtIndex.bind(this, rowId, endTime),
                        style: SetWorkHour.SetWorkHourStyles.widthForTextbox
                    }, endTime);
                    var containerForTextInputEnd = this._context.factory.createElement("CONTAINER", {
                        id: SetWorkHour.SetWorkHourConstants.CELL_END_CONTAINER + rowId,
                        key: SetWorkHour.SetWorkHourConstants.CELL_END_CONTAINER + rowId,
                        style: ruleType == AppCommon.CalendarRuleType.WorkHour ? SetWorkHour.SetWorkHourStyles.tableCellMiddleContainerWorkHourRow : SetWorkHour.SetWorkHourStyles.tableCellMiddleContainerBreakRow
                    }, textInputForEnd);
                    return this.createTableBodyCell(SetWorkHour.SetWorkHourConstants.TABLE_BODY_CELL_END + rowId, SetWorkHour.SetWorkHourConstants.TABLE_BODY_CELL_END + rowId, containerForTextInputEnd);
                };
                // to construct the fourth column of the row - Buttons
                SetWorkHourControl.prototype.getActionCell = function (rowId, ruleType) {
                    var that = this;
                    var button = this._context.factory.createElement("BUTTON", {
                        id: SetWorkHour.SetWorkHourConstants.LABEL_CELL_BUTTON + rowId,
                        key: SetWorkHour.SetWorkHourConstants.LABEL_CELL_BUTTON + rowId,
                        onClick: function (event) {
                            that.breakActionButtonClicked(ruleType, rowId, event);
                        },
                        title: (ruleType == AppCommon.CalendarRuleType.WorkHour) ? SetWorkHour.SetWorkHourLocale.SWH_AddBreakTitle : SetWorkHour.SetWorkHourLocale.SWH_DeleteTitle,
                        disabled: (ruleType == AppCommon.CalendarRuleType.WorkHour ? this.IsDurationLessThanMinWorkHour(rowId) : false),
                        style: SetWorkHour.SetWorkHourStyles.actionControl
                    }, ruleType == AppCommon.CalendarRuleType.WorkHour ? SetWorkHour.SetWorkHourLocale.SWH_AddBreak : SetWorkHour.SetWorkHourLocale.SWH_Delete);
                    var buttonContainer = this._context.factory.createElement("CONTAINER", {
                        id: SetWorkHour.SetWorkHourConstants.CELL_BUTTON_CONTAINER + rowId,
                        key: SetWorkHour.SetWorkHourConstants.CELL_BUTTON_CONTAINER + rowId,
                        style: ruleType == AppCommon.CalendarRuleType.WorkHour ? SetWorkHour.SetWorkHourStyles.tableCellLastContainerWorkHourRow : SetWorkHour.SetWorkHourStyles.tableCellLastContainerBreakRow
                    }, button);
                    return this.createTableBodyCell(SetWorkHour.SetWorkHourConstants.TABLE_BODY_CELL_BUTTON + rowId, SetWorkHour.SetWorkHourConstants.TABLE_BODY_CELL_BUTTON + rowId, buttonContainer);
                };
                // calculates the workhour duration and returns true if duration is less than or equal to 10 mins,
                // which inturn be used to disable the add break button
                SetWorkHourControl.prototype.IsDurationLessThanMinWorkHour = function (rowId) {
                    var calRule = this._timeSheetDataHandler.getCalendarRuleAtIndex(rowId);
                    if (calRule.duration <= SetWorkHour.SetWorkHourAddBreakHandlerConstants.ADDBREAK_MIN_WORKHOUR_DURATION) {
                        return true;
                    }
                    return false;
                };
                // helper function to create a table row with the given set of parameters
                SetWorkHourControl.prototype.createTableRow = function (id, key, children, style) {
                    return this._context.factory.createElement("TABLEROW", {
                        id: id,
                        key: key,
                        style: style
                    }, children);
                };
                // helper function to create a table cell with the given set of parameters
                SetWorkHourControl.prototype.createTableBodyCell = function (id, key, children, style) {
                    return this._context.factory.createElement("TABLECELL", {
                        id: id,
                        key: key,
                        style: this._context.utils.isNullOrUndefined(style) ? SetWorkHour.SetWorkHourStyles.tableCell : style
                    }, children);
                };
                // helper function to create a table header cell with the given set of parameters
                SetWorkHourControl.prototype.createTableHeaderCell = function (id, key, children, columnId) {
                    return this._context.factory.createElement("TABLEHEADERCELL", {
                        id: id,
                        key: key,
                        style: columnId == 1 ? SetWorkHour.SetWorkHourStyles.tableHeaderMiddleCell : SetWorkHour.SetWorkHourStyles.tableHeaderOuterCell
                    }, children);
                };
                // helper function to create a table row header cell with the given set of parameters
                SetWorkHourControl.prototype.createTableRowHeaderCell = function (id, key, children, style) {
                    return this._context.factory.createElement("TABLEHEADERCELL", {
                        id: id,
                        key: key,
                        style: this._context.utils.isNullOrUndefined(style) ? SetWorkHour.SetWorkHourStyles.tableCell : style
                    }, children);
                };
                // get total summary of workhours
                SetWorkHourControl.prototype.getWorkHourSummary = function () {
                    var labelWorkHourSummary = this._context.factory.createElement("LABEL", {
                        id: SetWorkHour.SetWorkHourConstants.LABEL_WORKHOUR_SUMMARY,
                        key: SetWorkHour.SetWorkHourConstants.LABEL_WORKHOUR_SUMMARY,
                        role: "alert",
                        style: SetWorkHour.SetWorkHourStyles.workHourSummaryLabel
                    }, this._timeSheetDataHandler.getWorkHourSummary());
                    return this._context.factory.createElement("CONTAINER", {
                        id: SetWorkHour.SetWorkHourConstants.WORKHOUR_SUMMARY_CONTAINER,
                        key: SetWorkHour.SetWorkHourConstants.WORKHOUR_SUMMARY_CONTAINER
                    }, labelWorkHourSummary);
                };
                // get title details of workhours control
                SetWorkHourControl.prototype.getTitleDetails = function () {
                    var labelWorkHourTitle = this._context.factory.createElement("LABEL", {
                        id: SetWorkHour.SetWorkHourConstants.LABEL_WORKHOUR_TITLE,
                        key: SetWorkHour.SetWorkHourConstants.LABEL_WORKHOUR_TITLE,
                        style: SetWorkHour.SetWorkHourStyles.workHourTitleLabel
                    }, SetWorkHour.SetWorkHourLocale.SWH_EnterWorkHoursAndBreaks);
                    return this._context.factory.createElement("CONTAINER", {
                        id: SetWorkHour.SetWorkHourConstants.WORKHOUR_TITLE_CONTAINER,
                        key: SetWorkHour.SetWorkHourConstants.WORKHOUR_TITLE_CONTAINER
                    }, labelWorkHourTitle);
                };
                // to refresh output bag and re-render the page.
                SetWorkHourControl.prototype.refreshOutputAndRerender = function () {
                    this._setWorkHoursOutput.ruleXML = this._timeSheetDataHandler.getRuleXML();
                    this._setWorkHoursOutput.startDateTime = this._timeSheetDataHandler.getStartTimeOfTheDay();
                    this._setWorkHoursOutput.endDateTime = this._timeSheetDataHandler.getEndTimeOfTheDay();
                    this._setWorkHoursOutput.isDirty = true;
                    this._notifyOutputChanged();
                    this._context.utils.requestRender(this.deleteBreakCallBack);
                };
                /**
                 * call back function after deleting last break row
                 */
                SetWorkHourControl.prototype.deleteBreakCallBack = function () {
                    if (SetWorkHourControl._lastBreakDeleted) {
                        var props = this.props;
                        var id = props.descriptor.DomId + "-" + props.controlId + "-" + SetWorkHour.SetWorkHourConstants.LABEL_CELL_BUTTON + SetWorkHourControl._lastRowIndex;
                        var element = document.getElementById(id);
                        if (element) {
                            element.focus();
                        }
                        SetWorkHourControl._lastBreakDeleted = false;
                    }
                };
                return SetWorkHourControl;
            }());
            SetWorkHour.SetWorkHourControl = SetWorkHourControl;
        })(SetWorkHour = AppCommon.SetWorkHour || (AppCommon.SetWorkHour = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CalendarRuleType;
        (function (CalendarRuleType) {
            CalendarRuleType[CalendarRuleType["Break"] = 0] = "Break";
            CalendarRuleType[CalendarRuleType["WorkHour"] = 1] = "WorkHour";
        })(CalendarRuleType = AppCommon.CalendarRuleType || (AppCommon.CalendarRuleType = {}));
        var Day;
        (function (Day) {
            Day[Day["NONE"] = -1] = "NONE";
            Day[Day["SUN"] = 0] = "SUN";
            Day[Day["MON"] = 1] = "MON";
            Day[Day["TUE"] = 2] = "TUE";
            Day[Day["WED"] = 3] = "WED";
            Day[Day["THU"] = 4] = "THU";
            Day[Day["FRI"] = 5] = "FRI";
            Day[Day["SAT"] = 6] = "SAT";
        })(Day = AppCommon.Day || (AppCommon.Day = {}));
        var TimeCode;
        (function (TimeCode) {
            TimeCode[TimeCode["Available"] = 0] = "Available";
            TimeCode[TimeCode["Busy"] = 1] = "Busy";
            TimeCode[TimeCode["Unavailable"] = 2] = "Unavailable";
            TimeCode[TimeCode["Filter"] = 3] = "Filter";
        })(TimeCode = AppCommon.TimeCode || (AppCommon.TimeCode = {}));
        var SubCode;
        (function (SubCode) {
            SubCode[SubCode["Unspecified"] = 0] = "Unspecified";
            SubCode[SubCode["Schedulable"] = 1] = "Schedulable";
            SubCode[SubCode["Committed"] = 2] = "Committed";
            SubCode[SubCode["Uncommitted"] = 3] = "Uncommitted";
            SubCode[SubCode["Break"] = 4] = "Break";
            SubCode[SubCode["Holiday"] = 5] = "Holiday";
            SubCode[SubCode["Vacation"] = 6] = "Vacation";
            SubCode[SubCode["Appointment"] = 7] = "Appointment";
            SubCode[SubCode["ResourceStartTime"] = 8] = "ResourceStartTime";
            SubCode[SubCode["ResourceServiceRestriction"] = 9] = "ResourceServiceRestriction";
            SubCode[SubCode["ResourceCapacity"] = 10] = "ResourceCapacity";
            SubCode[SubCode["ServiceRestriction"] = 11] = "ServiceRestriction";
            SubCode[SubCode["ServiceCost"] = 12] = "ServiceCost";
        })(SubCode = AppCommon.SubCode || (AppCommon.SubCode = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SetWorkHour;
        (function (SetWorkHour) {
            'use strict';
            var SetWorkHourStyles = (function () {
                function SetWorkHourStyles() {
                }
                SetWorkHourStyles.initialize = function (theming, isRTL) {
                    SetWorkHourStyles.tableHeaderOuterCell = {
                        fontFamily: theming.fontfamilies.semibold,
                        fontSize: theming.fontsizes.font100,
                        color: theming.colors.basecolor.grey.grey7,
                        lineHeight: theming.measures.measure100,
                        height: "2rem",
                        alignItems: "center",
                        verticalAlign: "middle",
                        paddingLeft: theming.measures.measure050,
                        paddingTop: theming.measures.measure025,
                        paddingBottom: theming.measures.measure025,
                        width: "20%"
                    };
                    SetWorkHourStyles.tableHeaderMiddleCell = {
                        fontFamily: theming.fontfamilies.semibold,
                        fontSize: theming.fontsizes.font100,
                        color: theming.colors.basecolor.grey.grey7,
                        lineHeight: theming.measures.measure100,
                        height: "2rem",
                        alignItems: "center",
                        verticalAlign: "middle",
                        paddingLeft: theming.measures.measure050,
                        paddingTop: theming.measures.measure025,
                        paddingBottom: theming.measures.measure025,
                        width: "30%"
                    };
                    SetWorkHourStyles.tableHeaderRow = {
                        backgroundColor: theming.colors.basecolor.grey.grey3,
                        borderBottomWidth: theming.measures.measure050,
                        borderStyle: "solid",
                        lineHeight: "1.4rem",
                        borderColor: theming.colors.basecolor.white
                    };
                    SetWorkHourStyles.table = {
                        borderSpacing: "10px",
                        marginTop: theming.measures.measure050,
                        marginBottom: theming.measures.measure050,
                        width: "99%"
                    };
                    SetWorkHourStyles.widthForTextbox = {
                        width: "90%"
                    };
                    SetWorkHourStyles.tableCell = {
                        fontFamily: theming.fontfamilies.regular,
                        fontSize: theming.fontsizes.font100,
                        color: theming.colors.basecolor.grey.grey5,
                        lineHeight: theming.measures.measure100,
                        verticalAlign: "middle"
                    };
                    SetWorkHourStyles.mainContainer = {
                        width: "100%",
                        display: "flex",
                        flexDirection: "column"
                    };
                    SetWorkHourStyles.workHourSummaryLabel = {
                        width: "100%",
                        fontFamily: theming.fontfamilies.regular,
                        fontSize: theming.fontsizes.font100,
                        lineHeight: theming.measures.measure100,
                        color: theming.colors.basecolor.grey.grey5
                    };
                    SetWorkHourStyles.actionControl = {
                        fontFamily: theming.fontfamilies.regular,
                        fontSize: theming.fontsizes.font100,
                        lineHeight: theming.measures.measure100,
                        background: "none",
                        border: "none",
                        display: "inline",
                        margin: "0",
                        padding: "0",
                        outline: "none",
                        outlineOffset: "0",
                        color: theming.colors.basecolor.blue.blue4
                    };
                    SetWorkHourStyles.workHourTitleLabel = {
                        fontFamily: theming.fontfamilies.semibold,
                        fontSize: theming.fontsizes.font100,
                        color: theming.colors.basecolor.grey.grey7,
                        lineHeight: theming.measures.measure100
                    };
                    SetWorkHourStyles.tableCellFirstContainerBreakRow = {
                        borderStyle: "solid",
                        borderWidth: "1px 0 1px 1px",
                        borderColor: theming.colors.basecolor.grey.grey3,
                        backgroundColor: theming.colors.basecolor.white,
                        paddingLeft: theming.measures.measure050,
                        paddingTop: theming.measures.measure025,
                        paddingBottom: theming.measures.measure025,
                        marginBottom: theming.measures.measure025,
                        height: theming.measures.measure200,
                        alignItems: "center"
                    };
                    SetWorkHourStyles.tableCellLastContainerBreakRow = {
                        borderStyle: "solid",
                        borderWidth: "1px 1px 1px 0",
                        borderColor: theming.colors.basecolor.grey.grey3,
                        backgroundColor: theming.colors.basecolor.white,
                        paddingLeft: theming.measures.measure050,
                        paddingTop: theming.measures.measure025,
                        paddingBottom: theming.measures.measure025,
                        marginBottom: theming.measures.measure025,
                        height: theming.measures.measure200,
                        alignItems: "center"
                    };
                    SetWorkHourStyles.tableCellMiddleContainerBreakRow = {
                        borderStyle: "solid",
                        borderWidth: "1px 0",
                        borderColor: theming.colors.basecolor.grey.grey3,
                        backgroundColor: theming.colors.basecolor.white,
                        paddingLeft: theming.measures.measure050,
                        paddingTop: theming.measures.measure025,
                        paddingBottom: theming.measures.measure025,
                        marginBottom: theming.measures.measure025,
                        height: theming.measures.measure200,
                        alignItems: "center"
                    };
                    SetWorkHourStyles.tableCellFirstContainerWorkHourRow = {
                        borderStyle: "solid",
                        borderWidth: "1px 0 1px 1px",
                        borderColor: theming.colors.basecolor.grey.grey3,
                        backgroundColor: theming.colors.basecolor.grey.grey1,
                        paddingLeft: theming.measures.measure050,
                        paddingTop: theming.measures.measure025,
                        paddingBottom: theming.measures.measure025,
                        marginBottom: theming.measures.measure025,
                        height: theming.measures.measure200,
                        alignItems: "center"
                    };
                    SetWorkHourStyles.tableCellLastContainerWorkHourRow = {
                        borderStyle: "solid",
                        borderWidth: "1px 1px 1px 0",
                        borderColor: theming.colors.basecolor.grey.grey3,
                        backgroundColor: theming.colors.basecolor.grey.grey1,
                        paddingLeft: theming.measures.measure050,
                        paddingTop: theming.measures.measure025,
                        paddingBottom: theming.measures.measure025,
                        marginBottom: theming.measures.measure025,
                        height: theming.measures.measure200,
                        alignItems: "center"
                    };
                    SetWorkHourStyles.tableCellMiddleContainerWorkHourRow = {
                        borderStyle: "solid",
                        borderWidth: "1px 0",
                        borderColor: theming.colors.basecolor.grey.grey3,
                        backgroundColor: theming.colors.basecolor.grey.grey1,
                        paddingLeft: theming.measures.measure050,
                        paddingTop: theming.measures.measure025,
                        paddingBottom: theming.measures.measure025,
                        marginBottom: theming.measures.measure025,
                        height: theming.measures.measure200,
                        alignItems: "center"
                    };
                };
                return SetWorkHourStyles;
            }());
            SetWorkHour.SetWorkHourStyles = SetWorkHourStyles;
        })(SetWorkHour = AppCommon.SetWorkHour || (AppCommon.SetWorkHour = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SetWorkHour;
        (function (SetWorkHour) {
            'use strict';
            var SetWorkHourLocale = (function () {
                function SetWorkHourLocale() {
                }
                /*
                 * Initializes the Set Work Hours labels.
                */
                SetWorkHourLocale.initialize = function (getString) {
                    SetWorkHourLocale.SWH_Type = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_Type);
                    SetWorkHourLocale.SWH_Start = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_Start);
                    SetWorkHourLocale.SWH_End = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_End);
                    SetWorkHourLocale.SWH_WorkHours = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_WorkHours);
                    SetWorkHourLocale.SWH_Break = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_Break);
                    SetWorkHourLocale.SWH_AddBreak = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_AddBreak);
                    SetWorkHourLocale.SWH_Delete = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_Delete);
                    SetWorkHourLocale.SWH_Total = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_Total);
                    SetWorkHourLocale.SWH_Working = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_Working);
                    SetWorkHourLocale.SWH_Breaks = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_Breaks);
                    SetWorkHourLocale.SWH_Hours = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_Hours);
                    SetWorkHourLocale.SWH_Minutes = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_Minutes);
                    SetWorkHourLocale.SWH_Hour = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_Hour);
                    SetWorkHourLocale.SWH_Minute = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_Minute);
                    SetWorkHourLocale.SWH_EnterWorkHoursAndBreaks = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_EnterWorkHoursAndBreaks);
                    SetWorkHourLocale.SWH_End_Time_Earlier = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_End_Time_Earlier);
                    SetWorkHourLocale.SWH_Start_Time_Later = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_Start_Time_Later);
                    SetWorkHourLocale.SWH_End_Time_Earlier_Five = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_End_Time_Earlier_Five);
                    SetWorkHourLocale.SWH_Start_Time_Later_Five = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_Start_Time_Later_Five);
                    SetWorkHourLocale.SWH_Merge_Ranges = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_Merge_Ranges);
                    SetWorkHourLocale.SWH_Time_Overlaps = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_Time_Overlaps);
                    SetWorkHourLocale.SWH_Time_Conflicts = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_Time_Conflicts);
                    SetWorkHourLocale.SWH_AddBreakTitle = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_AddBreakTitle);
                    SetWorkHourLocale.SWH_DeleteTitle = getString(SetWorkHour.SetWorkHourLabelId.ResourceKey_SWH_DeleteTitle);
                };
                return SetWorkHourLocale;
            }());
            SetWorkHour.SetWorkHourLocale = SetWorkHourLocale;
        })(SetWorkHour = AppCommon.SetWorkHour || (AppCommon.SetWorkHour = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SetWorkHour;
        (function (SetWorkHour) {
            'use strict';
            var SetWorkHourLabelId = (function () {
                function SetWorkHourLabelId() {
                }
                return SetWorkHourLabelId;
            }());
            SetWorkHourLabelId.ResourceKey_SWH_Type = "CC_SWH_Type";
            SetWorkHourLabelId.ResourceKey_SWH_Start = "CC_SWH_Start";
            SetWorkHourLabelId.ResourceKey_SWH_End = "CC_SWH_End";
            SetWorkHourLabelId.ResourceKey_SWH_WorkHours = "CC_SWH_WorkHours";
            SetWorkHourLabelId.ResourceKey_SWH_Break = "CC_SWH_Break";
            SetWorkHourLabelId.ResourceKey_SWH_AddBreak = "CC_SWH_AddBreak";
            SetWorkHourLabelId.ResourceKey_SWH_Delete = "CC_SWH_Delete";
            SetWorkHourLabelId.ResourceKey_SWH_Total = "CC_SWH_Total";
            SetWorkHourLabelId.ResourceKey_SWH_Working = "CC_SWH_Working";
            SetWorkHourLabelId.ResourceKey_SWH_Breaks = "CC_SWH_Breaks";
            SetWorkHourLabelId.ResourceKey_SWH_Hours = "CC_SWH_Hours";
            SetWorkHourLabelId.ResourceKey_SWH_Minutes = "CC_SWH_Minutes";
            SetWorkHourLabelId.ResourceKey_SWH_Hour = "CC_SWH_Hour";
            SetWorkHourLabelId.ResourceKey_SWH_Minute = "CC_SWH_Minute";
            SetWorkHourLabelId.ResourceKey_SWH_EnterWorkHoursAndBreaks = "CC_SWH_EnterWorkHoursAndBreaks";
            SetWorkHourLabelId.ResourceKey_Start_Time_Later = "Start_Time_Later";
            SetWorkHourLabelId.ResourceKey_End_Time_Earlier = "End_Time_Earlier";
            SetWorkHourLabelId.ResourceKey_Start_Time_Later_Five = "Start_Time_Later_Five";
            SetWorkHourLabelId.ResourceKey_End_Time_Earlier_Five = "End_Time_Earlier_Five";
            SetWorkHourLabelId.ResourceKey_Merge_Ranges = "Merge_Ranges";
            SetWorkHourLabelId.ResourceKey_Time_Overlaps = "Time_Overlaps";
            SetWorkHourLabelId.ResourceKey_Time_Conflicts = "Time_Conflicts";
            SetWorkHourLabelId.ResourceKey_SWH_AddBreakTitle = "CC_SWH_AddBreakTitle";
            SetWorkHourLabelId.ResourceKey_SWH_DeleteTitle = "CC_SWH_DeleteTitle";
            SetWorkHour.SetWorkHourLabelId = SetWorkHourLabelId;
        })(SetWorkHour = AppCommon.SetWorkHour || (AppCommon.SetWorkHour = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="SetWorkHourControl.ts" />
/// <reference path="SetWorkHourInterfaces.ts" />
/// <reference path="SetWorkHourStyles.ts" />
/// <reference path="SetWorkHourLocale.ts" />
/// <reference path="SetWorkHourLabelId.ts" /> 
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SetWorkHour;
        (function (SetWorkHour) {
            'use strict';
        })(SetWorkHour = AppCommon.SetWorkHour || (AppCommon.SetWorkHour = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SetWorkHour;
        (function (SetWorkHour) {
            'use strict';
            var SetWorkHourConstants;
            (function (SetWorkHourConstants) {
                //keys and ids
                SetWorkHourConstants.TABLE_HEADER_CELL_TYPE = "tableHeaderCellType";
                SetWorkHourConstants.TABLE_HEADER_CELL_START = "tableHeaderCellStart";
                SetWorkHourConstants.TABLE_HEADER_CELL_END = "tableHeaderCellEnd";
                SetWorkHourConstants.TABLE_HEADER_CELL_BUTTON = "tableHeaderCellButton";
                SetWorkHourConstants.TABLE_HEADER_ROW = "tableHeaderRow";
                SetWorkHourConstants.TABLE_HEADER_CONTAINER = "tableHeaderContainer";
                SetWorkHourConstants.TABLE_BODY_CONTAINER = "tableBodyContainer";
                SetWorkHourConstants.TABLE_CONTAINER = "tableContainer";
                SetWorkHourConstants.RULEXML_TEXBOX = "ruleXMLTexbox";
                SetWorkHourConstants.RULEXML_CONTAINER = "ruleXMLContainer";
                SetWorkHourConstants.MAIN_CONTAINER = "mainContainer";
                SetWorkHourConstants.TABLE_BODY_CELL_TYPE = "tableBodyCellType";
                SetWorkHourConstants.TABLE_BODY_CELL_START = "tableBodyCellStart";
                SetWorkHourConstants.TABLE_BODY_CELL_END = "tableBodyCellEnd";
                SetWorkHourConstants.TABLE_BODY_CELL_BUTTON = "tableBodyCellButton";
                SetWorkHourConstants.TABLE_ROW_CONTAINER = "tableRowContainer";
                SetWorkHourConstants.LABEL_CELL_TYPE = "labelCellType";
                SetWorkHourConstants.LABEL_CELL_START = "labelCellStart";
                SetWorkHourConstants.LABEL_CELL_END = "labelCellEnd";
                SetWorkHourConstants.LABEL_CELL_BUTTON = "labelCellButton";
                SetWorkHourConstants.CELL_TYPE_CONTAINER = "cellTypeContainer";
                SetWorkHourConstants.CELL_START_CONTAINER = "cellStartContainer";
                SetWorkHourConstants.CELL_END_CONTAINER = "cellEndContainer";
                SetWorkHourConstants.CELL_BUTTON_CONTAINER = "cellButtonContainer";
                SetWorkHourConstants.EMPTY_SPACE_STRING = " ";
                SetWorkHourConstants.LABEL_WORKHOUR_SUMMARY = "labelWorkHourSummary";
                SetWorkHourConstants.WORKHOUR_SUMMARY_CONTAINER = "workHourSummaryContainer";
                SetWorkHourConstants.LABEL_WORKHOUR_TITLE = "labelWorkHourTitle";
                SetWorkHourConstants.WORKHOUR_TITLE_CONTAINER = "workHourTitleContainer";
            })(SetWorkHourConstants = SetWorkHour.SetWorkHourConstants || (SetWorkHour.SetWorkHourConstants = {}));
            var SetWorkHourAddBreakHandlerConstants;
            (function (SetWorkHourAddBreakHandlerConstants) {
                SetWorkHourAddBreakHandlerConstants.ADDBREAK_MIN_WORKHOUR_DURATION = 10;
                SetWorkHourAddBreakHandlerConstants.ADDBREAK_SHORTER_BREAK_DURATION = 5;
                SetWorkHourAddBreakHandlerConstants.ADDBREAK_LONGER_BREAK_DURATION = 30;
                SetWorkHourAddBreakHandlerConstants.ADDBREAK_MIN_WORKHOUR_DURATION_LONGER_BREAK = 180;
                SetWorkHourAddBreakHandlerConstants.ApptStartEvery = 5;
                SetWorkHourAddBreakHandlerConstants.ApptStartDate = "1980-01-01T08:00:00";
            })(SetWorkHourAddBreakHandlerConstants = SetWorkHour.SetWorkHourAddBreakHandlerConstants || (SetWorkHour.SetWorkHourAddBreakHandlerConstants = {}));
        })(SetWorkHour = AppCommon.SetWorkHour || (AppCommon.SetWorkHour = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SetWorkHour;
        (function (SetWorkHour) {
            'use strict';
            var TimeSheetDataHandler = (function () {
                //Constructor
                function TimeSheetDataHandler(rules, context) {
                    var _this = this;
                    /**
                     * returns Start Time as index
                     *@param index rowID
                     */
                    this.getStartTimeAtIndex = function (index) {
                        var startTimeOffset = _this._calendarRuleSet[index].offset;
                        return _this.getDateTimeForOffset(startTimeOffset);
                    };
                    /**
                     * returns End Time as index
                     *@param index rowID
                     */
                    this.getEndTimeAtIndex = function (index) {
                        var endTimeOffset = _this._calendarRuleSet[index].offset + _this._calendarRuleSet[index].duration;
                        return _this.getDateTimeForOffset(endTimeOffset);
                    };
                    /**
                     * returns Date Time object converted from offset
                     *@param offset offset
                     */
                    this.getDateTimeForOffset = function (offset) {
                        var minutes = offset % 60;
                        var hours = (offset - minutes) / 60;
                        var DateTime = new Date(SetWorkHour.SetWorkHourAddBreakHandlerConstants.ApptStartDate);
                        DateTime.setHours(hours);
                        DateTime.setMinutes(minutes);
                        return DateTime;
                    };
                    // returns string containing overlapping ranges to show to user
                    this.getOverlappingRulesOnStartTimeChangeAtIndex = function (index, newValue) {
                        var overlappingCalendarRules;
                        overlappingCalendarRules = new Array();
                        if (isNaN(newValue.getTime())) {
                            return overlappingCalendarRules;
                        }
                        for (var i = 0; i < index; i++) {
                            var iStartTime = _this.getStartTimeAtIndex(i);
                            if (newValue <= iStartTime) {
                                overlappingCalendarRules.push(_this._calendarRuleSet[i]);
                            }
                        }
                        return overlappingCalendarRules;
                    };
                    // returns string containing overlapping ranges to show to user
                    this.getOverlappingRulesOnEndTimeChangeAtIndex = function (index, newValue) {
                        var overlappingCalendarRules;
                        if (isNaN(newValue.getTime())) {
                            return overlappingCalendarRules;
                        }
                        overlappingCalendarRules = new Array();
                        for (var i = index + 1; i < _this._calendarRuleSet.length; i++) {
                            var iEndTime = _this.getEndTimeAtIndex(i);
                            if (newValue >= iEndTime) {
                                overlappingCalendarRules.push(_this._calendarRuleSet[i]);
                            }
                            else {
                                break;
                            }
                        }
                        return overlappingCalendarRules;
                    };
                    // On Start Time Change at indx 
                    this.changeStartTimeAtIndex = function (index, newStartTime) {
                        if (isNaN(newStartTime.getTime())) {
                            return;
                        }
                        // delete overlapping rows
                        for (var i = 0; i < index; i++) {
                            var iStartTime = _this.getStartTimeAtIndex(i);
                            if (newStartTime <= iStartTime) {
                                _this._calendarRuleSet.splice(i, 1);
                                i--;
                                index--;
                            }
                        }
                        // set start time of index and end time of next row
                        _this.setStartTimeAtIndex(index, newStartTime);
                        _this.setEndTimeAtIndex(index - 1, newStartTime);
                        // if current row and previous row are of same type then merge them
                        if (index > 0 && _this._calendarRuleSet[index].calendarRuleType == _this._calendarRuleSet[index - 1].calendarRuleType) {
                            _this._calendarRuleSet[index - 1].duration += _this._calendarRuleSet[index].duration;
                            _this._calendarRuleSet.splice(index, 1);
                        }
                        // Delete first row if first row is break after merge
                        if (index == 0 && _this._calendarRuleSet[index].calendarRuleType == AppCommon.CalendarRuleType.Break) {
                            _this._calendarRuleSet.splice(index, 1);
                        }
                    };
                    // On End Time Change at indx
                    this.changeEndTimeAtIndex = function (index, newEndTime) {
                        if (isNaN(newEndTime.getTime())) {
                            return;
                        }
                        // delete overlapping rows
                        for (var i = index + 1; i < _this._calendarRuleSet.length; i++) {
                            var iEndTime = _this.getEndTimeAtIndex(i);
                            if (newEndTime >= iEndTime) {
                                _this._calendarRuleSet.splice(i, 1);
                                i--;
                            }
                            else {
                                break;
                            }
                        }
                        // set end time of index and start time of next row
                        _this.setEndTimeAtIndex(index, newEndTime);
                        _this.setStartTimeAtIndex(index + 1, newEndTime);
                        // if current row and next row are of same type then merge them
                        if (index < _this._calendarRuleSet.length - 1 && _this._calendarRuleSet[index].calendarRuleType == _this._calendarRuleSet[index + 1].calendarRuleType) {
                            _this._calendarRuleSet[index].duration += _this._calendarRuleSet[index + 1].duration;
                            _this._calendarRuleSet.splice(index + 1, 1);
                        }
                        // Delete last row if last row is break after merge
                        if (index == _this._calendarRuleSet.length - 1 && _this._calendarRuleSet[index].calendarRuleType == AppCommon.CalendarRuleType.Break) {
                            _this._calendarRuleSet.splice(index, 1);
                        }
                    };
                    /**
                     * returns Start Time of work hour control
                     */
                    this.getStartTime = function () {
                        return _this.getStartTimeAtIndex(0);
                    };
                    /**
                     * returns End Time of work hour control
                     */
                    this.getEndTime = function () {
                        return _this.getEndTimeAtIndex(_this._calendarRuleSet.length - 1);
                    };
                    this._calendarRuleSet = new Array();
                    this._context = context;
                    this.init(rules);
                }
                /**
                 * This function should modify the existing data in order to add a new break.
                 * @params index: The index at which we need to insert the break.
                 */
                TimeSheetDataHandler.prototype.insertBreakAtIndex = function (index) {
                    try {
                        if (!this._context.utils.isNullOrUndefined(this._calendarRuleSet)) {
                            // Insert break only if the row is even (work hours are at even rows), and
                            // The type of calender rule at this index in _calendarRuleSet array is of type work hour.
                            if (0 == index % 2 && AppCommon.CalendarRuleType.WorkHour == this._calendarRuleSet[index].calendarRuleType) {
                                // Current duration will become the total duration of first half work hour, break and second half work hour.
                                var totalDuration = this._calendarRuleSet[index].duration;
                                // Add break only if the total Duration is more than 10 minutes.
                                if (totalDuration > SetWorkHour.SetWorkHourAddBreakHandlerConstants.ADDBREAK_MIN_WORKHOUR_DURATION) {
                                    // First half work hours need to be rounded of to nearest shorter multiple of 5.
                                    var firstHalfDuration = totalDuration / 2;
                                    firstHalfDuration = (Math.floor(firstHalfDuration / 5)) * 5;
                                    // Offset for the first half would remain same, so update duration only.
                                    this._calendarRuleSet[index].duration = firstHalfDuration;
                                    // Break time is 30 mins, if the total duration is more than 180 mins
                                    // else break time is 5 mins.
                                    var breakDuration = 0;
                                    if (totalDuration >= SetWorkHour.SetWorkHourAddBreakHandlerConstants.ADDBREAK_MIN_WORKHOUR_DURATION_LONGER_BREAK) {
                                        breakDuration = SetWorkHour.SetWorkHourAddBreakHandlerConstants.ADDBREAK_LONGER_BREAK_DURATION;
                                    }
                                    else {
                                        breakDuration = SetWorkHour.SetWorkHourAddBreakHandlerConstants.ADDBREAK_SHORTER_BREAK_DURATION;
                                    }
                                    var breakCalendarRule = void 0;
                                    breakCalendarRule = {};
                                    breakCalendarRule.calendarRuleType = AppCommon.CalendarRuleType.Break;
                                    breakCalendarRule.duration = breakDuration;
                                    breakCalendarRule.offset = this._calendarRuleSet[index].offset + firstHalfDuration;
                                    // Second half duration would be the remaining of the total duration after removing first half and break durations.
                                    var secondHalfCalendarRule = void 0;
                                    secondHalfCalendarRule = {};
                                    secondHalfCalendarRule.calendarRuleType = AppCommon.CalendarRuleType.WorkHour;
                                    secondHalfCalendarRule.duration = totalDuration - (firstHalfDuration + breakDuration);
                                    secondHalfCalendarRule.offset = this._calendarRuleSet[index].offset + firstHalfDuration + breakDuration;
                                    // Add rules to _calendarRuleSet array
                                    this._calendarRuleSet.splice(index + 1, 0, secondHalfCalendarRule);
                                    this._calendarRuleSet.splice(index + 1, 0, breakCalendarRule);
                                }
                            }
                            else {
                                var errorMessage = "The Calendar rule type is not of type CalendarRuleType.WorkHour";
                                console.error(errorMessage);
                                SetWorkHour.SetWorkHourControl.reportErrorTelemetry(this._context, errorMessage, "");
                            }
                        }
                        else {
                            var errorMessage = "Member variable _calendarRuleSet is null or undefined.";
                            console.error(errorMessage);
                            SetWorkHour.SetWorkHourControl.reportErrorTelemetry(this._context, errorMessage, "");
                        }
                    }
                    catch (error) {
                        var errorMessage = "Failed in insertBreakAtIndex function in TimeSheetDataHandler of SetWorkHoursControl.";
                        console.error(errorMessage);
                        SetWorkHour.SetWorkHourControl.reportErrorTelemetry(this._context, errorMessage, error);
                    }
                };
                /**
                 * This function should modify the existing data inorder to delete the break.
                 * @params index: The index at which we need to delete the break.
                 */
                TimeSheetDataHandler.prototype.deleteBreakAtIndex = function (index) {
                    try {
                        if (index > 0) {
                            if (!this._context.utils.isNullOrUndefined(this._calendarRuleSet)) {
                                // Delete break only if the row is odd (breaks are at odd rows), and
                                // The type of calender rule at this index in _calendarRuleSet array is of type break.
                                if (index % 2 && AppCommon.CalendarRuleType.Break == this._calendarRuleSet[index].calendarRuleType) {
                                    //index, previous index and next index duration sum up to previous index
                                    this._calendarRuleSet[index - 1].duration += this._calendarRuleSet[index].duration + this._calendarRuleSet[index + 1].duration;
                                    //delete the break and related workhour
                                    this._calendarRuleSet.splice(index, 2);
                                }
                                else {
                                    var errorMessage = "The Calendar rule type is not of type CalendarRuleType.Break";
                                    console.error(errorMessage);
                                    SetWorkHour.SetWorkHourControl.reportErrorTelemetry(this._context, errorMessage, "");
                                }
                            }
                            else {
                                var errorMessage = "Member variable _calendarRuleSet is null or undefined.";
                                console.error(errorMessage);
                                SetWorkHour.SetWorkHourControl.reportErrorTelemetry(this._context, errorMessage, "");
                            }
                        }
                        else {
                            var errorMessage = "index should be great than zero perform a delete break";
                            console.error(errorMessage);
                            SetWorkHour.SetWorkHourControl.reportErrorTelemetry(this._context, errorMessage, "");
                        }
                    }
                    catch (error) {
                        var errorMessage = "Failed in deleteBreakAtIndex function in TimeSheetDataHandler of SetWorkHoursControl.";
                        console.error(errorMessage);
                        SetWorkHour.SetWorkHourControl.reportErrorTelemetry(this._context, errorMessage, error);
                    }
                };
                TimeSheetDataHandler.prototype.getCalendarRuleAtIndex = function (indx) {
                    return this._calendarRuleSet[indx];
                };
                //Commit Merged Changes
                TimeSheetDataHandler.prototype.commitChanges = function () {
                };
                //Cancel Merged Changes
                TimeSheetDataHandler.prototype.cancelChanges = function () {
                };
                TimeSheetDataHandler.prototype.getCalendarRules = function () {
                    return this._calendarRuleSet;
                };
                TimeSheetDataHandler.prototype.getRuleXML = function () {
                    var xml = "<rules>";
                    var date = new Date().localeFormat("yyyy-MM-dd");
                    for (var count = 0; count < this._calendarRuleSet.length; count++) {
                        xml += "<rule>";
                        xml += "<type>" + ((this._calendarRuleSet[count].calendarRuleType == AppCommon.CalendarRuleType.Break) ? "break" : "effort") + "</type>";
                        xml += "<start>" + date + "T" + this.convertOffsetIntoDateTime(this._calendarRuleSet[count].offset) + "</start>";
                        xml += "<effort>1</effort>";
                        xml += "<duration>" + this._calendarRuleSet[count].duration + "</duration>";
                        xml += "</rule>";
                    }
                    xml += "</rules>";
                    return xml;
                };
                TimeSheetDataHandler.prototype.getCalendarRulesLength = function () {
                    return this._calendarRuleSet.length;
                };
                TimeSheetDataHandler.prototype.getStartTimeOfTheDay = function () {
                    if (this._calendarRuleSet == null || this._calendarRuleSet.length == 0) {
                        return "08:00:00";
                    }
                    else {
                        return this.convertOffsetIntoDateTime(this._calendarRuleSet[0].offset);
                    }
                };
                TimeSheetDataHandler.prototype.getEndTimeOfTheDay = function () {
                    if (this._calendarRuleSet == null || this._calendarRuleSet.length == 0) {
                        return "17:00:00";
                    }
                    else {
                        return this.convertOffsetIntoDateTime(this._calendarRuleSet[this._calendarRuleSet.length - 1].offset + this._calendarRuleSet[this._calendarRuleSet.length - 1].duration);
                    }
                };
                TimeSheetDataHandler.prototype.convertOffsetIntoDateTime = function (offset) {
                    var startTime = "";
                    var minutesPart = offset % 60;
                    var hoursPart = (offset - minutesPart) / 60;
                    if (hoursPart.toString().length == 1) {
                        hoursPart = "0" + hoursPart;
                    }
                    if (minutesPart.toString().length == 1) {
                        minutesPart = "0" + minutesPart;
                    }
                    startTime = hoursPart + ":" + minutesPart + ":00";
                    return startTime;
                };
                // return ths summary of work hours - total, working, breaks. eg. - "Total: 7.50 hours, Working: 6 hours, Breaks: 1.50 hours"
                TimeSheetDataHandler.prototype.getWorkHourSummary = function () {
                    return SetWorkHour.SetWorkHourLocale.SWH_Total + ": " + this.getTotalHours() + ", " + SetWorkHour.SetWorkHourLocale.SWH_Working + ": " + this.getTotalWorkingHours() + ", " + SetWorkHour.SetWorkHourLocale.SWH_Breaks + ": " + this.getTotalBreakHours();
                };
                // sets offset of calendar rule at index according to new Date
                TimeSheetDataHandler.prototype.setStartTimeAtIndex = function (index, newValue) {
                    if (index < 0 || index >= this._calendarRuleSet.length || isNaN(newValue.getTime())) {
                        return;
                    }
                    var oldOffset = this._calendarRuleSet[index].offset;
                    this._calendarRuleSet[index].offset = newValue.getHours() * 60 + newValue.getMinutes();
                    this._calendarRuleSet[index].duration += (oldOffset - this._calendarRuleSet[index].offset);
                };
                // sets duration of calendar rule at index according to new Date
                TimeSheetDataHandler.prototype.setEndTimeAtIndex = function (index, newValue) {
                    if (index < 0 || index >= this._calendarRuleSet.length || isNaN(newValue.getTime())) {
                        return;
                    }
                    // if end time is 12AM then date will be equal to 2
                    if (newValue.getDate() == 1) {
                        this._calendarRuleSet[index].duration = newValue.getHours() * 60 + newValue.getMinutes() - this._calendarRuleSet[index].offset;
                    }
                    else {
                        this._calendarRuleSet[index].duration = 24 * 60 - this._calendarRuleSet[index].offset;
                    }
                };
                // calculates the total hours/minutes including working and breaks
                TimeSheetDataHandler.prototype.getTotalHours = function () {
                    var total;
                    total = this._calendarRuleSet.reduce(function (prevDuration, rule) { return prevDuration + rule.duration; }, 0);
                    return this.returnCalculatedTotalText(total);
                };
                // calculates the total working hours/minutes
                TimeSheetDataHandler.prototype.getTotalWorkingHours = function () {
                    var total;
                    total = this._calendarRuleSet.filter(function (calendarRule) { return calendarRule.calendarRuleType == AppCommon.CalendarRuleType.WorkHour; }).reduce(function (prevDuration, rule) { return prevDuration + rule.duration; }, 0);
                    return this.returnCalculatedTotalText(total);
                };
                // calculates the total break hours/minutes
                TimeSheetDataHandler.prototype.getTotalBreakHours = function () {
                    var total;
                    total = this._calendarRuleSet.filter(function (calendarRule) { return calendarRule.calendarRuleType == AppCommon.CalendarRuleType.Break; }).reduce(function (prevDuration, rule) { return prevDuration + rule.duration; }, 0);
                    return this.returnCalculatedTotalText(total);
                };
                // return the calculated total text to be dispalyed by appending appropriated units like - hour, hours, minute, minutes
                TimeSheetDataHandler.prototype.returnCalculatedTotalText = function (total) {
                    var workingTotal = total / 60;
                    // check to return hour(s)/minute(s)
                    if (workingTotal < 1) {
                        // check to return minute or minutes
                        return total % 60 + " " + (total % 60 == 1 ? SetWorkHour.SetWorkHourLocale.SWH_Minute : SetWorkHour.SetWorkHourLocale.SWH_Minutes);
                    }
                    else {
                        // check to return hour or hours with appropriate rounding of precision
                        return ((total) % 60 == 0 ? workingTotal.toFixed(0) : workingTotal.toFixed(2)) + " " + (workingTotal == 1 ? SetWorkHour.SetWorkHourLocale.SWH_Hour : SetWorkHour.SetWorkHourLocale.SWH_Hours);
                    }
                };
                TimeSheetDataHandler.prototype.init = function (rules) {
                    var calendarRule;
                    // to hold the ticked/consumed duration by the earlier breaks and workhours
                    var tickedDuration = 0;
                    // to hold the orginal duration mentioned in the workhour rule
                    var originalDuration;
                    // To fetch the work hour record from the list of rules, break out of loop after getting the work hour record
                    for (var count = 0; count < rules.length; count++) {
                        if (rules[count].timecode == AppCommon.TimeCode.Available) {
                            // record to hold the work hour
                            calendarRule = {};
                            calendarRule.calendarRuleType = AppCommon.CalendarRuleType.WorkHour;
                            calendarRule.offset = rules[count].offset;
                            calendarRule.duration = rules[count].duration;
                            originalDuration = rules[count].duration;
                            this._calendarRuleSet.push(calendarRule);
                            break;
                        }
                    }
                    for (var count = 0; count < rules.length; count++) {
                        if (rules[count].timecode == AppCommon.TimeCode.Unavailable) {
                            // record to hold the breack
                            calendarRule = {};
                            calendarRule.calendarRuleType = AppCommon.CalendarRuleType.Break;
                            calendarRule.offset = rules[count].offset;
                            calendarRule.duration = rules[count].duration;
                            tickedDuration += rules[count].duration;
                            this._calendarRuleSet.push(calendarRule);
                            // recalculate and adjust the previous workhour record duration
                            this._calendarRuleSet[this._calendarRuleSet.length - 2].duration = calendarRule.offset - this._calendarRuleSet[this._calendarRuleSet.length - 2].offset;
                            tickedDuration += this._calendarRuleSet[this._calendarRuleSet.length - 2].duration;
                            // record to hold the work hour after the above break
                            calendarRule = {};
                            calendarRule.calendarRuleType = AppCommon.CalendarRuleType.WorkHour;
                            calendarRule.offset = rules[count].offset + rules[count].duration;
                            calendarRule.duration = originalDuration - tickedDuration;
                            this._calendarRuleSet.push(calendarRule);
                        }
                    }
                };
                return TimeSheetDataHandler;
            }());
            SetWorkHour.TimeSheetDataHandler = TimeSheetDataHandler;
        })(SetWorkHour = AppCommon.SetWorkHour || (AppCommon.SetWorkHour = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=SetWorkHourControl.js.map