/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
// tslint:disable:no-string-literal
var MscrmControls;
(function (MscrmControls) {
    var SelectEmailTemplate;
    (function (SelectEmailTemplate) {
        var ComponentBuilder = (function () {
            function ComponentBuilder(context, localizedStrings) {
                this.context = context;
                this.localizedStrings = localizedStrings;
                this.isMobile = false;
            }
            ComponentBuilder.prototype.buildButton = function (controlName, disabled, onKeyDown, onClick, onError, className) {
                var selectTemplateIconId = "microsoftIcon_searchButton";
                var selectTemplateIcon = this.context.factory.createElement("MICROSOFTICON", {
                    id: selectTemplateIconId,
                    key: selectTemplateIconId,
                    tabIndex: -1,
                    style: {},
                    type: 90
                });
                var controlId = "" + controlName + controlName + "id";
                var selectTemplateIconContainer = this.context.factory.createElement("Button", {
                    key: controlName,
                    id: controlId,
                    labelledByElementId: controlName + "label",
                    describedByElementId: controlName + "label",
                    className: className,
                    accessibilityLabel: this.localizedStrings.selectTemplateButton,
                    disabled: disabled,
                    onKeyDown: disabled ? null : onKeyDown,
                    onClick: disabled ? null : onClick,
                    onError: onError,
                    tabIndex: -1,
                    style: this.getSelectTemplateIconContainerStyle(controlId, disabled)
                }, selectTemplateIcon);
                return selectTemplateIconContainer;
            };
            ComponentBuilder.prototype.buildTextInput = function (controlName, value, onError) {
                var textInput = this.context.factory.createElement("TEXTINPUT", {
                    key: controlName,
                    id: controlName + (controlName + "id"),
                    labelledByElementId: controlName + "label",
                    describedByElementId: controlName + "label",
                    accessibilityLabel: this.localizedStrings.selectTemplateTextBox + value,
                    disabled: true,
                    autoFocus: true,
                    onError: onError,
                    style: this.getTextInputStyle(),
                    value: value
                });
                return textInput;
            };
            ComponentBuilder.prototype.buildRequiredIndicator = function (id) {
                var style = {
                    display: "inline",
                    margin: "5px 10px 0px 10px"
                };
                var textbox = this.context.theming.textbox;
                var symbol = "*";
                style.color = textbox.redcolor;
                return this.context.factory.createElement("CONTAINER", {
                    id: id,
                    key: "required",
                    style: style
                }, symbol);
            };
            ComponentBuilder.prototype.getSelectTemplateIconContainerStyle = function (controlId, disabled) {
                var style = {
                    "height": this.isMobile ? this.context.theming.measures.measure200 : this.context.theming.measures.measure250,
                    "width": this.isMobile ? this.context.theming.measures.measure200 : this.context.theming.measures.measure250,
                    "min-width": this.isMobile ? this.context.theming.measures.measure200 : this.context.theming.measures.measure250,
                    "lineHeight": this.isMobile ? this.context.theming.measures.measure200 : this.context.theming.measures.measure250,
                    "fontSize": "16px",
                    "backgroundColor": this.context.theming.colors.base.white,
                    "borderWidth": "1px",
                    "borderStyle": "solid",
                    "borderColor": this.context.theming.colors.base.white,
                    "color": this.context.theming.colors.basecolor.grey.grey5,
                    "textAlign": "center",
                    "display": "table",
                    "margin": "0",
                    "padding": "0",
                    "cursor": "pointer"
                };
                style["[data-id$='" + controlId + "']:hover, [data-id$='" + controlId + "']:hover span"] = {
                    backgroundColor: this.context.theming.colors.basecolor.grey.grey3,
                    borderColor: this.context.theming.colors.basecolor.grey.grey3
                };
                style["[data-id$='" + controlId + "']:active, [data-id$='" + controlId + "']:active span"] = {
                    backgroundColor: this.context.theming.colors.basecolor.grey.grey3,
                    borderColor: this.context.theming.colors.basecolor.grey.grey3
                };
                if (disabled) {
                    style["backgroundColor"] = this.context.theming.colors.base.white;
                    style["borderColor"] = this.context.theming.colors.base.white;
                    style["color"] = this.context.theming.colors.basecolor.grey.grey2;
                    style["[data-id$='" + controlId + "']:hover, [data-id$='" + controlId + "']:hover span"] = {
                        backgroundColor: this.context.theming.colors.base.white,
                        borderColor: this.context.theming.colors.base.white
                    };
                    style["[data-id$='" + controlId + "']:active, [data-id$='" + controlId + "']:active span"] = {
                        backgroundColor: this.context.theming.colors.base.white,
                        borderColor: this.context.theming.colors.base.white
                    };
                }
                return style;
            };
            ComponentBuilder.prototype.getTextInputStyle = function () {
                return {
                    "boxSizing": "border-box",
                    "height": this.isMobile ? this.context.theming.measures.measure200 : this.context.theming.measures.measure250,
                    "paddingLeft": "10px",
                    "border": "1px solid #FFFFFF",
                    "color": this.context.theming.colors.base.black,
                    "fontWeight": this.context.theming.fontfamilies.regular,
                    "fontSize": this.context.theming.fontsizes.bfontsize,
                    "flex-grow": 1
                };
            };
            ComponentBuilder.prototype.buildContainer = function (containerId, children, onMeasuring) {
                var properties = {
                    id: containerId,
                    key: containerId,
                    accessibilityLabel: this.localizedStrings.selectTemplateBox,
                    style: {
                        display: "flex",
                        alignItems: "flex-start",
                        width: "100%",
                        marginTop: this.isMobile ? this.context.theming.measures.measure125 : this.context.theming.measures.measure150,
                        marginBottom: this.isMobile ? this.context.theming.measures.measure125 : this.context.theming.measures.measure150,
                        height: this.isMobile ? this.context.theming.measures.measure200 : this.context.theming.measures.measure250,
                        minHeight: this.isMobile ? this.context.theming.measures.measure200 : this.context.theming.measures.measure250,
                        maxHeight: this.isMobile ? this.context.theming.measures.measure200 : this.context.theming.measures.measure250,
                        pointerEvents: "all"
                    },
                    isRequestedMeasuring: true,
                    onMeasuring: onMeasuring
                };
                return this.context.factory.createElement("CONTAINER", properties, children);
            };
            return ComponentBuilder;
        }());
        SelectEmailTemplate.ComponentBuilder = ComponentBuilder;
    })(SelectEmailTemplate = MscrmControls.SelectEmailTemplate || (MscrmControls.SelectEmailTemplate = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var SelectEmailTemplate;
    (function (SelectEmailTemplate) {
        var LocalizedStrings = (function () {
            function LocalizedStrings() {
            }
            LocalizedStrings.getLocalized = function (context) {
                return {
                    selectTemplateButton: context.resources.getString("Select_Template_Button"),
                    selectTemplateTextBox: context.resources.getString("Select_Template_TextBox"),
                    selectTemplateBox: context.resources.getString("Select_Template_Box")
                };
            };
            return LocalizedStrings;
        }());
        SelectEmailTemplate.LocalizedStrings = LocalizedStrings;
    })(SelectEmailTemplate = MscrmControls.SelectEmailTemplate || (MscrmControls.SelectEmailTemplate = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var SelectEmailTemplate;
    (function (SelectEmailTemplate) {
        var SelectEmailTemplateButton = (function () {
            function SelectEmailTemplateButton() {
                var _this = this;
                this.selectedEmailTemplate = { id: null, title: null };
                this.isMobile = false;
                this.onKeyDown = function (event) {
                    switch (event.keyCode) {
                        case 13:
                            var activityType = _this.context.parameters.activityType.formatted;
                            _this.openSelectEmailTemplateDialog(activityType);
                            break;
                    }
                };
                this.onOpenSelectEmailTemplateDialogButtonClicked = function () {
                    var activityType = _this.context.parameters.activityType.formatted;
                    _this.openSelectEmailTemplateDialog(activityType);
                };
                this.onError = function (errorDetails) {
                    throw new Error(errorDetails);
                };
                this.openSelectEmailTemplateDialog = function (activityType) {
                    var options = {
                        width: 500,
                        height: 450,
                        position: SelectEmailTemplateButton.selectTemplateDialogCenterPosition
                    };
                    var dialogArguments = {};
                    dialogArguments[SelectEmailTemplateButton.activityTypeParameterName] = activityType;
                    Xrm.Navigation
                        .openDialog(SelectEmailTemplateButton.selectEmailTemplateDialogName, options, dialogArguments)
                        .then(_this.onSelectEmailTemplateDialogClosed);
                };
                this.onSelectEmailTemplateDialogClosed = function (dialogParams) {
                    if (_this.templateWasSelected(dialogParams)) {
                        _this.refreshControlWithSelectedTemplateParamenters(dialogParams);
                    }
                };
                this.onMeasuring = function (width) {
                    var newIsMobile = width <= SelectEmailTemplateButton.mobileWidth;
                    if (_this.isMobile !== newIsMobile) {
                        _this.isMobile = newIsMobile;
                        _this.context.utils.requestRender();
                    }
                };
            }
            /**
             * Initializes the control. This function has access to the property bag context that will contain your custom control properties and utility functions.
             * Predefinitions and initializations can be done in this.
             *
             * @param notifyOutputChanged Function to call when control changed its value, to propagate changes to redux state.
             * @param context Dictionary containing custom control's context.
             * @param state The control's internal state. Has nothing to do with redux state tree.
             * @param container Wrapping div element.
             */
            SelectEmailTemplateButton.prototype.init = function (context, notifyOutputChanged, state, container) {
                this.componentBuilder = new SelectEmailTemplate.ComponentBuilder(context, SelectEmailTemplate.LocalizedStrings.getLocalized(context));
                this.context = context;
                this.container = container;
                this.notifyOutputChanged = notifyOutputChanged;
                this.renderControls(context);
            };
            /**
             * This function destroys the control and cleans up.
             */
            SelectEmailTemplateButton.prototype.destroy = function () {
                this.container.remove();
                this.container = null;
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             *
             * @param context The "Input Bag" as described above
             */
            SelectEmailTemplateButton.prototype.updateView = function (context) {
                this.renderControls(context);
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * @example i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *    value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            SelectEmailTemplateButton.prototype.getOutputs = function () {
                return {
                    selectedTemplateId: this.selectedEmailTemplate.id
                };
            };
            SelectEmailTemplateButton.prototype.renderControls = function (context) {
                var controlsToRender = [];
                if (!this.controlIsDisabled()) {
                    var requiredComponent = this.componentBuilder.buildRequiredIndicator(SelectEmailTemplateButton.requiredComponentId);
                    controlsToRender.push(requiredComponent);
                }
                var selectEmailTemplateTextInput = this.componentBuilder.buildTextInput(SelectEmailTemplateButton.selectEmailTemplateTextInputId, this.selectedEmailTemplate.title, this.onError);
                controlsToRender.push(selectEmailTemplateTextInput);
                var selectEmailTemplateButton = this.componentBuilder.buildButton(SelectEmailTemplateButton.selectEmailTemplateButtonId, this.controlIsDisabled(), this.onKeyDown, this.onOpenSelectEmailTemplateDialogButtonClicked, this.onError);
                controlsToRender.push(selectEmailTemplateButton);
                var selectEmailTemplateButtonContainer = this.componentBuilder.buildContainer(SelectEmailTemplateButton.selectEmailTemplateButtonContainerId, controlsToRender, this.onMeasuring);
                context.utils.bindDOMElement(selectEmailTemplateButtonContainer, this.container);
            };
            SelectEmailTemplateButton.prototype.templateWasSelected = function (dialogParams) {
                return dialogParams.parameters[SelectEmailTemplateButton.lastButtonClickedParameterName] ===
                    SelectEmailTemplateButton.okDialogButtonId;
            };
            SelectEmailTemplateButton.prototype.refreshControlWithSelectedTemplateParamenters = function (dialogParams) {
                this.selectedEmailTemplate = {
                    id: dialogParams.parameters[SelectEmailTemplateButton.selectedTemplateIdIdParameterName],
                    title: dialogParams.parameters[SelectEmailTemplateButton.selectedTemplateIdTitleParameterName]
                };
                this.renderControls(this.context);
                this.notifyOutputChanged();
            };
            SelectEmailTemplateButton.prototype.controlIsDisabled = function () {
                return this.context.mode.isControlDisabled || this.context.page.isPageReadOnly;
            };
            return SelectEmailTemplateButton;
        }());
        /**
         * Maximum width in pixels corresponding to mobile device window
         */
        SelectEmailTemplateButton.mobileWidth = 550;
        SelectEmailTemplateButton.selectTemplateDialogCenterPosition = 1;
        SelectEmailTemplateButton.selectEmailTemplateDialogName = "SelectEmailTemplate";
        SelectEmailTemplateButton.selectedTemplateIdIdParameterName = "selected_template_id";
        SelectEmailTemplateButton.selectedTemplateIdTitleParameterName = "selected_template_title";
        SelectEmailTemplateButton.activityTypeParameterName = "activity_type";
        SelectEmailTemplateButton.lastButtonClickedParameterName = "param_lastButtonClicked";
        SelectEmailTemplateButton.okDialogButtonId = "ok_id";
        SelectEmailTemplateButton.requiredComponentId = "requiredComponentId";
        SelectEmailTemplateButton.selectEmailTemplateButtonContainerId = "selectEmailTemplateButtonContainer";
        SelectEmailTemplateButton.selectEmailTemplateButtonId = "selectEmailTemplateButton";
        SelectEmailTemplateButton.selectEmailTemplateTextInputId = "selectEmailTemplateTextInput";
        SelectEmailTemplate.SelectEmailTemplateButton = SelectEmailTemplateButton;
    })(SelectEmailTemplate = MscrmControls.SelectEmailTemplate || (MscrmControls.SelectEmailTemplate = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=SelectEmailTemplateButton.js.map