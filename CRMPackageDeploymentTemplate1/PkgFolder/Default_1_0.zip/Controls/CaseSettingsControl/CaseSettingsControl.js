var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var CaseSettings;
    (function (CaseSettings) {
        'use strict';
        //imports
        var FREShell = MscrmControls.AppCommon.FREShell;
        var CaseSettingsControl = (function () {
            /**
             * Empty constructor.
             */
            function CaseSettingsControl(notifyOutputChanged) {
                this._caseSettingsAttributeHandler = null;
                this._notifyOutputChanged = notifyOutputChanged || (function () { });
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            CaseSettingsControl.prototype.init = function (context, notifyOutputChanged, state) {
                var _this = this;
                // custom code goes here
                this._context = context;
                CaseSettings.CaseSettingsStyles.initialize(this._context.theming, this._context.client.isRTL);
                CaseSettings.CaseSettingsLocale.initialize(function (id) { return _this._context.resources.getString(id); });
                // Initializing Clouser Preference drop down list in Case Settings page.
                this.InitializingClouserPreferenceDDL();
                var title = CaseSettings.CaseSettingsLocale.CaseSettings_Header;
                this._freShell = new FREShell(context, title);
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            CaseSettingsControl.prototype.updateView = function (context) {
                return this._freShell.getVirtualComponents(this.getChildControls(context));
            };
            CaseSettingsControl.prototype.getChildControls = function (context) {
                this._context = context;
                var params = {};
                params.normalIconImagePath = CaseSettings.CaseSettingsConstants.CASESETTINGS_HEADER_ICON_IMAGE;
                params.highContrastIconImagePath = CaseSettings.CaseSettingsConstants.CASESETTINGS_HEADER_ICON_HIGHCONTRAST_IMAGE;
                params.areaLabel = CaseSettings.CaseSettingsLocale.CaseSettings_Sub_Header;
                params.subAreaLabel = CaseSettings.CaseSettingsLocale.CaseSettings_Header;
                var innerBodyContainer = null;
                if (this._context.utils.isNullOrUndefined(this._caseSettingsAttributeHandler)) {
                    this._caseSettingsAttributeHandler = new CaseSettings.CaseSettingsAttributes(this._context);
                    innerBodyContainer = this.renderBlankContainerPage();
                }
                else if (this._caseSettingsAttributeHandler.getAvailableAttributes().length > 0) {
                    innerBodyContainer = this.renderControlPage();
                }
                else {
                    innerBodyContainer = this.renderBlankContainerPage();
                }
                params.contentContainerChild = innerBodyContainer;
                params.headerRightContainerChild = this.createHeaderRightContainer();
                this._freShell.stopPerformanceStopWatch();
                return params;
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            CaseSettingsControl.prototype.getOutputs = function () {
                return null;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            CaseSettingsControl.prototype.destroy = function () {
            };
            CaseSettingsControl.prototype.renderControlPage = function () {
                var infoLabel = this._context.factory.createElement("LABEL", {
                    key: CaseSettings.CaseSettingsConstants.CASESETTINGS_INFO_LABEL,
                    id: CaseSettings.CaseSettingsConstants.CASESETTINGS_INFO_LABEL,
                    role: "heading",
                    style: CaseSettings.CaseSettingsStyles.infoLabelContainer
                }, CaseSettings.CaseSettingsLocale.CaseSettings_Info);
                var properties = {
                    "parameters": {
                        JsonOptions: {
                            Usage: 3,
                            Static: true,
                            Type: "SingleLine.Text",
                            Value: JSON.stringify(this._caseSettingsAttributeHandler.getAvailableAttributes().map(function (c) {
                                return {
                                    Id: c.LogicalName, DisplayName: c.DisplayName
                                };
                            })),
                            Attributes: {
                                DisplayName: null,
                                LogicalName: "all_attributes",
                                Type: "string",
                                IsSecured: false,
                                RequiredLevel: 0,
                                MaxLength: 2147483647,
                                EntityLogicalName: "",
                                Format: "text",
                                ImeMode: -1,
                                Behavior: null
                            }
                        },
                        Selection: {
                            Usage: 3,
                            Static: true,
                            Type: "SingleLine.Text",
                            Value: this._caseSettingsAttributeHandler.getSelectedAttributes(),
                            Callback: this.callBackOnDualListSelectionChange.bind(this),
                            Attributes: {
                                DisplayName: null,
                                LogicalName: "cc_selectedAttributes_id",
                                Type: "string",
                                IsSecured: false,
                                RequiredLevel: 0,
                                MaxLength: 2147483647,
                                EntityLogicalName: "",
                                Format: null,
                                ImeMode: -1,
                                Behavior: null
                            }
                        },
                        SelectionOrderBy: {
                            Value: 2,
                            Usage: 3,
                            Static: true,
                            Type: "Enum",
                            Attributes: {},
                        },
                        OptionSet: {
                            Usage: 3,
                            Static: true,
                            Type: null,
                            attributes: {},
                        }
                    }
                };
                var dualListContainer = this._context.factory.createElement("CONTAINER", {
                    id: CaseSettings.CaseSettingsConstants.CASESETTINGS_DUALLIST_CONTAINER,
                    key: CaseSettings.CaseSettingsConstants.CASESETTINGS_DUALLIST_CONTAINER
                }, this._context.factory.createComponent("MscrmControls.DualListSelection.DualListSelectionControl", "DualListSelectionControl", properties));
                var clouserPreferenceDDLDiv = this.createclouserPreferenceDDLComponents();
                var mainContainer = this._context.factory.createElement("CONTAINER", {
                    id: CaseSettings.CaseSettingsConstants.CASESETTINGS_MAIN_CONTAINER,
                    key: CaseSettings.CaseSettingsConstants.CASESETTINGS_MAIN_CONTAINER,
                    style: CaseSettings.CaseSettingsStyles.csContentContainer
                }, [infoLabel, dualListContainer, clouserPreferenceDDLDiv]);
                return mainContainer;
            };
            CaseSettingsControl.prototype.renderBlankContainerPage = function () {
                var blankContainer = this._context.factory.createElement("CONTAINER", {
                    key: CaseSettings.CaseSettingsConstants.CASESETTINGS_BLANK_CONTAINER, id: CaseSettings.CaseSettingsConstants.CASESETTINGS_BLANK_CONTAINER
                }, []);
                return blankContainer;
            };
            CaseSettingsControl.prototype.callBackOnDualListSelectionChange = function (newValue) {
                this._caseSettingsAttributeHandler.setSelectedAttributes(newValue);
                this.notifyOutputChangeAndRequestRerender();
            };
            CaseSettingsControl.prototype.notifyOutputChangeAndRequestRerender = function () {
                this._notifyOutputChanged();
                this._context.utils.requestRender();
            };
            CaseSettingsControl.prototype.onSaveButtonClicked = function () {
                this._caseSettingsAttributeHandler.updateAttributeMaps();
            };
            CaseSettingsControl.prototype.onHelpButtonClicked = function () {
                Xrm.Navigation.openUrl(this.getHelpURL());
            };
            CaseSettingsControl.prototype.getHelpURL = function () {
                var baseUrl = "https://www.microsoft.com/dynamics/crm/content/helpredirect.aspx";
                var area = encodeURIComponent("/_grid/cmds/dlg_casehierarchy.aspx");
                var languageCode = this._context.userSettings.languageId;
                var version = Xrm.Page.context.getVersion();
                var url = baseUrl + "?area=" + area + "&user_lcid=" + languageCode + "&ver=" + version;
                return url;
            };
            CaseSettingsControl.prototype.createclouserPreferenceDDLComponents = function () {
                var clouserPreferenceDDLContainerComponents = [];
                // Render the select control only when the originalStatusUpdateValue is set.
                if (!this._context.utils.isNullOrUndefined(this._caseSettingsAttributeHandler.getOriginalStatusUpdateValue())) {
                    this._caseSettingsClouserPreferenceDDL.controlProps = {
                        key: CaseSettings.CaseSettingsConstants.CASESETTINGS_CLOUSER_PREFERENCE_DDL_CONTROL_PROPS,
                        id: CaseSettings.CaseSettingsConstants.CASESETTINGS_CLOUSER_PREFERENCE_DDL_CONTROL_PROPS,
                        freeTextMode: true,
                        value: { Value: this._caseSettingsAttributeHandler.getOriginalStatusUpdateValue(), Color: null },
                        onChange: this.ClouserPreferenceDDLOnChange.bind(this),
                        options: this._caseSettingsClouserPreferenceDDL.currentOptions,
                        tabIndex: 1,
                        style: CaseSettings.CaseSettingsStyles.csclouserPreferenceDDL,
                        accessibilityLabel: CaseSettings.CaseSettingsLocale.CaseSettings_Select_CascadeClouserPreference
                    };
                    this._caseSettingsClouserPreferenceDDL.component = this._context.factory.createElement("SELECT", this._caseSettingsClouserPreferenceDDL.controlProps, null);
                    var clouserPreferenceDDLLabel = this._context.factory.createElement("LABEL", {
                        key: CaseSettings.CaseSettingsConstants.CASESETTINGS_CLOUSER_PREFERENCE_DDL_LBL,
                        id: CaseSettings.CaseSettingsConstants.CASESETTINGS_CLOUSER_PREFERENCE_DDL_LBL,
                        style: CaseSettings.CaseSettingsStyles.clouserPreferenceDDLLabel,
                        role: "heading",
                        forElementId: this._context.accessibility.getUniqueId(CaseSettings.CaseSettingsConstants.CASESETTINGS_CLOUSER_PREFERENCE_DDL_CONTROL_PROPS)
                    }, CaseSettings.CaseSettingsLocale.CaseSettings_ClouserPreferenceDDL_Label_Info);
                    clouserPreferenceDDLContainerComponents = [clouserPreferenceDDLLabel, this._caseSettingsClouserPreferenceDDL.component];
                }
                var clouserPreferenceDDLContainer = this._context.factory.createElement("CONTAINER", {
                    key: CaseSettings.CaseSettingsConstants.CASESETTINGS_CLOUSER_PREFERENCE_DDL_CONTAINER,
                    id: CaseSettings.CaseSettingsConstants.CASESETTINGS_CLOUSER_PREFERENCE_DDL_CONTAINER,
                    style: CaseSettings.CaseSettingsStyles.caseSettingsClouserPreferenceContainer
                }, clouserPreferenceDDLContainerComponents);
                return clouserPreferenceDDLContainer;
            };
            CaseSettingsControl.prototype.InitializingClouserPreferenceDDL = function () {
                /*Initialzing the ClouserPreferenceDDL */
                this._caseSettingsClouserPreferenceDDL = new CaseSettings.SelectBox(CaseSettings.SelectBox.DEFAULTLISTID);
                this._caseSettingsClouserPreferenceDDL.addItems(CaseSettings.CaseSettingsLocale.CaseSettings_ClouserPreferenceDDL_None, "0");
                this._caseSettingsClouserPreferenceDDL.addItems(CaseSettings.CaseSettingsLocale.CaseSettings_ClouserPreferenceDDL_Cascade_Close, "1");
                this._caseSettingsClouserPreferenceDDL.addItems(CaseSettings.CaseSettingsLocale.CaseSettings_ClouserPreferenceDDL_Restrict_Cascade_Close, "2");
            };
            CaseSettingsControl.prototype.ClouserPreferenceDDLOnChange = function (selectedOption) {
                this._caseSettingsAttributeHandler.setCurrentStatusUpdateValue(selectedOption.Value);
            };
            /**
               * Creates RightContainer for header
           */
            CaseSettingsControl.prototype.createHeaderRightContainer = function () {
                var saveIconContainer = this._context.factory.createElement("CONTAINER", {
                    key: CaseSettings.CaseSettingsConstants.CASESETTINGS_SAVEICONCONTAINERKEY,
                    id: CaseSettings.CaseSettingsConstants.CASESETTINGS_SAVEICONCONTAINERKEY,
                    style: CaseSettings.CaseSettingsStyles.freRightButtonIconContainer
                }, []);
                var saveButton = this._context.factory.createElement("BUTTON", {
                    key: CaseSettings.CaseSettingsConstants.CASESETTINGS_SAVE_BUTTON,
                    id: CaseSettings.CaseSettingsConstants.CASESETTINGS_SAVE_BUTTON,
                    onClick: this.onSaveButtonClicked.bind(this),
                    tabIndex: 1,
                    style: CaseSettings.CaseSettingsStyles.freHeaderRightButtonStyle
                }, [saveIconContainer, CaseSettings.CaseSettingsLocale.CaseSettings_Save]);
                var helpIconImage = this._context.factory.createElement("IMG", {
                    id: CaseSettings.CaseSettingsConstants.CASESETTINGS_HELPICONCONTAINERKEY,
                    key: CaseSettings.CaseSettingsConstants.CASESETTINGS_HELPICONCONTAINERKEY,
                    source: CaseSettings.CaseSettingsConstants.CASESETTINGS_HELP_ICON_IMAGE,
                    altText: CaseSettings.CaseSettingsLocale.CaseSettings_Help,
                    style: CaseSettings.CaseSettingsStyles.freRightButtonIconContainer
                });
                var helpButton = this._context.factory.createElement("BUTTON", {
                    key: CaseSettings.CaseSettingsConstants.CASESETTINGS_HELP_BUTTON,
                    id: CaseSettings.CaseSettingsConstants.CASESETTINGS_HELP_BUTTON,
                    onClick: this.onHelpButtonClicked.bind(this),
                    tabIndex: 1,
                    style: CaseSettings.CaseSettingsStyles.freHeaderRightButtonStyle
                }, [helpIconImage, CaseSettings.CaseSettingsLocale.CaseSettings_Help]);
                var headerSeparatorContainer = this._context.factory.createElement("CONTAINER", {
                    key: CaseSettings.CaseSettingsConstants.CASESETTINGS_HEADERSEPARATORCONTAINERKEY,
                    id: CaseSettings.CaseSettingsConstants.CASESETTINGS_HEADERSEPARATORCONTAINERKEY,
                    style: CaseSettings.CaseSettingsStyles.freHeaderSeparatorContainer
                }, []);
                var headerRightContainer = this._context.factory.createElement("CONTAINER", {
                    key: CaseSettings.CaseSettingsConstants.CASESETTINGS_HEADERRIGHTCONTAINERKEY,
                    id: CaseSettings.CaseSettingsConstants.CASESETTINGS_HEADERRIGHTCONTAINERKEY,
                    style: CaseSettings.CaseSettingsStyles.freHeaderRightContainer
                }, [headerSeparatorContainer, helpButton, saveButton]);
                return headerRightContainer;
            };
            return CaseSettingsControl;
        }());
        CaseSettings.CaseSettingsControl = CaseSettingsControl;
    })(CaseSettings = MscrmControls.CaseSettings || (MscrmControls.CaseSettings = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var CaseSettings;
    (function (CaseSettings) {
        'use strict';
        var CaseSettingsStyles = (function (_super) {
            __extends(CaseSettingsStyles, _super);
            function CaseSettingsStyles() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            CaseSettingsStyles.initialize = function (theming, isRTL) {
                CaseSettingsStyles.clouserPreferenceDDLLabel = {
                    fontFamily: theming.fontfamilies.semibold,
                    fontSize: theming.fontsizes.font100,
                    lineHeight: "1.4rem",
                    color: theming.colors.basecolor.grey.grey7,
                    marginBottom: theming.measures.measure100,
                };
                CaseSettingsStyles.csclouserPreferenceDDL = {
                    width: "400px",
                    height: "25px",
                    backgroundColor: theming.colors.basecolor.white,
                    fontFamily: theming.fontfamilies.regular,
                    fontSize: theming.fontsizes.font100,
                    color: theming.colors.basecolor.grey.grey7,
                };
                CaseSettingsStyles.caseSettingsClouserPreferenceContainer = {
                    display: "flex",
                    backgroundColor: "transparent",
                    flexDirection: "column",
                    marginLeft: theming.measures.measure100,
                    marginTop: theming.measures.measure150,
                };
                CaseSettingsStyles.csContentContainer = {
                    display: "flex",
                    flex: "1 1 auto",
                    backgroundColor: "#FFFFFF",
                    flexDirection: "column"
                };
                CaseSettingsStyles.infoLabelContainer = {
                    fontFamily: theming.fontfamilies.semibold,
                    fontSize: theming.fontsizes.font100,
                    lineHeight: "1.4rem",
                    color: theming.colors.basecolor.grey.grey7,
                    marginBottom: theming.measures.measure100,
                    marginLeft: theming.measures.measure100,
                    marginTop: theming.measures.measure100
                };
                CaseSettingsStyles.saveButtonContainer = {
                    marginLeft: theming.measures.measure100,
                    width: "3rem",
                    marginTop: theming.measures.measure100
                };
                CaseSettingsStyles.freRightButtonIconContainer = {
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    backgroundColor: "transparent",
                    margin: theming.measures.measure025
                };
                CaseSettingsStyles.freHeaderSeparatorContainer = {
                    borderRight: theming.borders.border02,
                    width: "1px",
                    height: "2.1rem",
                    alignSelf: "center"
                };
                CaseSettingsStyles.freHeaderRightContainer = {
                    display: "flex",
                    alignItems: "center",
                    margin: theming.measures.measure075
                };
                CaseSettingsStyles.freHeaderRightButtonStyleHover = {
                    fontFamily: theming.fontfamilies.semibold
                };
                CaseSettingsStyles.freHeaderRightButtonStyleFocus = {
                    fontFamily: theming.fontfamilies.semibold,
                    border: "1px solid #666666",
                    outline: "none"
                };
                CaseSettingsStyles.freHeaderRightButtonStyleDisabled = {
                    color: theming.colors.basecolor.grey.grey5,
                    fontFamily: theming.fontfamilies.regular,
                };
                CaseSettingsStyles.freHeaderRightButtonStyle = {
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    alignSelf: "center",
                    border: "none",
                    backgroundColor: "transparent",
                    cursor: "pointer",
                    padding: "2px",
                    marginLeft: theming.measures.measure075,
                    marginRight: theming.measures.measure075,
                    fontFamily: theming.fontfamilies.regular,
                    fontSize: theming.fontsizes.font100,
                    color: "#0063B1",
                    lineHeight: "1.4rem",
                    whiteSpace: "nowrap",
                    hover: this.freHeaderRightButtonStyleHover,
                    focus: this.freHeaderRightButtonStyleFocus,
                    disabled: this.freHeaderRightButtonStyleDisabled,
                };
            };
            return CaseSettingsStyles;
        }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
        CaseSettingsStyles.clouserPreferenceDDLLabel = {};
        CaseSettingsStyles.csclouserPreferenceDDL = {};
        CaseSettingsStyles.caseSettingsClouserPreferenceContainer = {};
        CaseSettingsStyles.csContentContainer = {};
        CaseSettingsStyles.saveButtonContainer = {};
        CaseSettingsStyles.infoLabelContainer = {};
        CaseSettingsStyles.freRightButtonIconContainer = {};
        CaseSettingsStyles.freHeaderSeparatorContainer = {};
        CaseSettingsStyles.freHeaderRightContainer = {};
        CaseSettingsStyles.freHeaderRightButtonStyle = {};
        CaseSettingsStyles.freHeaderRightButtonStyleHover = {};
        CaseSettingsStyles.freHeaderRightButtonStyleFocus = {};
        CaseSettingsStyles.freHeaderRightButtonStyleDisabled = {};
        CaseSettings.CaseSettingsStyles = CaseSettingsStyles;
    })(CaseSettings = MscrmControls.CaseSettings || (MscrmControls.CaseSettings = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var CaseSettings;
    (function (CaseSettings) {
        'use strict';
        var CaseSettingsLocale = (function () {
            function CaseSettingsLocale() {
            }
            /*
             * Initializes the Case Settings labels.
            */
            CaseSettingsLocale.initialize = function (getString) {
                CaseSettingsLocale.CaseSettings_Info = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_Info);
                CaseSettingsLocale.CaseSettings_Save = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_Save);
                CaseSettingsLocale.CaseSettings_Help = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_Help);
                CaseSettingsLocale.CaseSettings_ValidationError = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_ValidationError);
                CaseSettingsLocale.CaseSettings_Save_Success = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_Save_Success);
                CaseSettingsLocale.CaseSettings_Save_Error = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_Save_Error);
                CaseSettingsLocale.CaseSettings_ClouserPreferenceDDL_None = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_ClouserPreferenceDDL_None);
                CaseSettingsLocale.CaseSettings_ClouserPreferenceDDL_Cascade_Close = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_ClouserPreferenceDDL_Cascade_Close);
                CaseSettingsLocale.CaseSettings_ClouserPreferenceDDL_Restrict_Cascade_Close = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_ClouserPreferenceDDL_Restrict_Cascade_Close);
                CaseSettingsLocale.CaseSettings_ClouserPreferenceDDL_Label_Info = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_ClouserPreferenceDDL_Label_Info);
                CaseSettingsLocale.CaseSettings_Available_Attributes = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_Available_Attributes);
                CaseSettingsLocale.CaseSettings_Single_Select = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_Single_Select);
                CaseSettingsLocale.CaseSettings_Multi_Select = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_Multi_Select);
                CaseSettingsLocale.CaseSettings_Multi_Deselect = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_Multi_Deselect);
                CaseSettingsLocale.CaseSettings_Single_Deselect = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_Single_Deselect);
                CaseSettingsLocale.CaseSettings_Selected_Attributes = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_Selected_Attributes);
                CaseSettingsLocale.CaseSettings_Select_CascadeClouserPreference = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_Select_CascadeClouserPreference);
                CaseSettingsLocale.CaseSettings_Header = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_Header);
                CaseSettingsLocale.CaseSettings_Sub_Header = getString(CaseSettings.CaseSettingsLabellId.ResourceKey_CaseSettings_Sub_Header);
            };
            return CaseSettingsLocale;
        }());
        CaseSettings.CaseSettingsLocale = CaseSettingsLocale;
    })(CaseSettings = MscrmControls.CaseSettings || (MscrmControls.CaseSettings = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var CaseSettings;
    (function (CaseSettings) {
        'use strict';
        var CaseSettingsLabellId = (function () {
            function CaseSettingsLabellId() {
            }
            return CaseSettingsLabellId;
        }());
        CaseSettingsLabellId.ResourceKey_CaseSettings_Info = "CaseSettings_Info";
        CaseSettingsLabellId.ResourceKey_CaseSettings_Save = "CaseSettings_Save";
        CaseSettingsLabellId.ResourceKey_CaseSettings_Help = "CaseSettings_Help";
        CaseSettingsLabellId.ResourceKey_CaseSettings_ValidationError = "CaseSettings_ValidationError";
        CaseSettingsLabellId.ResourceKey_CaseSettings_Save_Success = "CaseSettings_Save_Success";
        CaseSettingsLabellId.ResourceKey_CaseSettings_Save_Error = "CaseSettings_Save_Error";
        CaseSettingsLabellId.ResourceKey_CaseSettings_ClouserPreferenceDDL_None = "CaseSettings_ClouserPreferenceDDL_None";
        CaseSettingsLabellId.ResourceKey_CaseSettings_ClouserPreferenceDDL_Cascade_Close = "CaseSettings_ClouserPreferenceDDL_Cascade_Close";
        CaseSettingsLabellId.ResourceKey_CaseSettings_ClouserPreferenceDDL_Restrict_Cascade_Close = "CaseSettings_ClouserPreferenceDDL_Restrict_Cascade_Close";
        CaseSettingsLabellId.ResourceKey_CaseSettings_ClouserPreferenceDDL_Label_Info = "CaseSettings_ClouserPreferenceDDL_Label_Info";
        CaseSettingsLabellId.ResourceKey_CaseSettings_Available_Attributes = "CaseSettings_Available_Attributes";
        CaseSettingsLabellId.ResourceKey_CaseSettings_Single_Select = "CaseSettings_Single_Select";
        CaseSettingsLabellId.ResourceKey_CaseSettings_Multi_Select = "CaseSettings_Multi_Select";
        CaseSettingsLabellId.ResourceKey_CaseSettings_Multi_Deselect = "CaseSettings_Multi_Deselect";
        CaseSettingsLabellId.ResourceKey_CaseSettings_Single_Deselect = "CaseSettings_Single_Deselect";
        CaseSettingsLabellId.ResourceKey_CaseSettings_Selected_Attributes = "CaseSettings_Selected_Attributes";
        CaseSettingsLabellId.ResourceKey_CaseSettings_Select_CascadeClouserPreference = "CaseSettings_Select_CascadeClouserPreference";
        CaseSettingsLabellId.ResourceKey_CaseSettings_Header = "CaseSettings_Header";
        CaseSettingsLabellId.ResourceKey_CaseSettings_Sub_Header = "CaseSettings_Sub_Header";
        CaseSettings.CaseSettingsLabellId = CaseSettingsLabellId;
    })(CaseSettings = MscrmControls.CaseSettings || (MscrmControls.CaseSettings = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="CaseSettingsControl.ts" />
/// <reference path="CaseSettingsStyles.ts" />
/// <reference path="CaseSettingsLocale.ts" />
/// <reference path="CaseSettingsLabelId.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/**
* Telemetry library that takes dynamic parameter lists as event parameters in addition to fixed required parameters relavent to classify verticals association with Entities
* and pushes to crminsightsdev.cloudapp.net endpoint.  All one needs to do is Register your telemetry event with InsightsEndpoint repo (Events.xml and MdsConfig-CloudService.xml
* and start pushing event data using below APIs
*
* Sample calls for the APIs - caller : non-custom control eg: Ribbon commands
* AppsTelemetryUtility.reportData(EventList.EntitlementEvent, ModuleList.service, EntityList.entitlement, "Activation", null, { "CurrentState": "Activate", "UpdateMode": "Mouse"})
* AppsTelemetryUtility.reportData("CSHEntitlements", "Service", "Entitlement", "Deactivate", null, { "CurrentState": "Inactive", "UpdateMode": "KeyBoard"})
* Similarly ReportSuccess and Report Failure calls using either Enums (preferred) or string values.
* AppsTelemetryUtility.reportSuccess(EventList.EntitlementEvent, ModuleList.service, EntityList.entitlement, "TestAction", null, { "CurrentState": "Activate", "UpdateMode": "Mouse"})
* AppsTelemetryUtility.reportFailure(EventList.EntitlementEvent, ModuleList.service, EntityList.entitlement, "TestAction", null, { "CurrentState": "Activate", "UpdateMode": "Mouse"})
*
* Sample calls for the APIs - caller Custom Controls
* AppsTelemetryUtility.ReportSuccess(EventList.SubjectEvent, ModuleList.service, EntityList.CSSEvent, "AddBreak", this.context, {"Duration": 30, "Timezone": "PST"});
* AppsTelemetryUtility.ReportFailure("CSH_Subject", "Service", "Subject", "AddChild", this.context, {"name": "myRegarding", "parent": "myEntity"});
*
* In above samples for non-custom control calls, null is expected to be passed as part of event call for two reasons 1. Generic API for custom & non-custom control
*/
var CrmService;
(function (CrmService) {
    'use strict';
    /**
    * To format the outer payload for telemetry data according to the event schema
    */
    var TelemetryPayload = (function () {
        function TelemetryPayload() {
        }
        return TelemetryPayload;
    }());
    CrmService.TelemetryPayload = TelemetryPayload;
    /**
    * To format the inner payload for telemetry data according to the event schema
    */
    var TelemetryParameter = (function () {
        function TelemetryParameter() {
        }
        return TelemetryParameter;
    }());
    CrmService.TelemetryParameter = TelemetryParameter;
    /**
    * Declaring this key value pair to make it easy for callers
    */
    var ExtraParams = (function () {
        function ExtraParams() {
        }
        return ExtraParams;
    }());
    CrmService.ExtraParams = ExtraParams;
    /**
    * ENUMs tracking EventTypes
    */
    var EventTypes = (function () {
        function EventTypes() {
        }
        return EventTypes;
    }());
    EventTypes.Success = "Success";
    EventTypes.Failure = "Failure";
    EventTypes.EventData = "EventData";
    CrmService.EventTypes = EventTypes;
    /**
    * ENUMs tracking Vertical Events. Callers of Client Telemetry APIs can use ENUMs to pass required parameters
    * Currently listed with registered Customer Service Module List
    */
    var EventList = (function () {
        function EventList() {
        }
        return EventList;
    }());
    EventList.QueueEvent = "CSHQueues";
    EventList.RoutingRuleEvent = "CSHRoutingRules";
    EventList.ARCEvent = "CSHAutoRecordCreation";
    EventList.SubjectEvent = "CSHSubject";
    EventList.HSEvent = "CSHHolidaySchedule";
    EventList.CSSEvent = "CSHCustomerServiceSchedule";
    EventList.SettingsEvent = "CSHSettings";
    EventList.EntitlementEvent = "CSHEntitlements";
    EventList.IncidentEvent = "CSHIncident";
    EventList.EventAgnostic = "CSHMisc";
    CrmService.EventList = EventList;
    /**
    * ENUMs tracking Vertical/Module List
    */
    var ModuleList = (function () {
        function ModuleList() {
        }
        return ModuleList;
    }());
    ModuleList.service = "Service";
    ModuleList.sales = "Sales";
    ModuleList.marketing = "Marketing";
    ModuleList.verticalAgnostic = "VerticalAgnostic";
    CrmService.ModuleList = ModuleList;
    /**
    * ENUMs tracking Entity List
    * Currently listing entities list part of Customer Service Module shipping in Enterprise Release
    */
    var EntityList = (function () {
        function EntityList() {
        }
        return EntityList;
    }());
    EntityList.queue = "Queue";
    EntityList.queueItem = "QueueItem";
    EntityList.convertRule = "ConvertRule";
    EntityList.convertRuleItem = "ConvertRuleItem";
    EntityList.routingRule = "RoutingRule";
    EntityList.routingRuleItem = "RoutingRuleItem";
    EntityList.entitlement = "Entitlement";
    EntityList.entitlementTemplate = "EntitlementTemplate";
    EntityList.sla = "SLA";
    EntityList.slaItem = "SLAItem";
    EntityList.calendar = "Calendar";
    EntityList.calendarRule = "CalendarRule";
    EntityList.subject = "Subject";
    EntityList.attributemap = "AttributeMap";
    EntityList.organization = "organization";
    EntityList.incident = "Incident";
    CrmService.EntityList = EntityList;
    /**
    * ENUMs tracking Action
    */
    var Action = (function () {
        function Action() {
        }
        return Action;
    }());
    Action.create = "Create";
    Action.update = "Update";
    Action.retrieve = "Retrieve";
    Action.delete = "Delete";
    Action.clickedGridCommand = "ClickedGridCommand";
    CrmService.Action = Action;
    var AppsTelemetryUtility = (function () {
        function AppsTelemetryUtility() {
        }
        /**
        * @function reportEventData send telemetry data to the crminsightsdev.cloudapp.net endpoint.
        * @description send telemetry data to the telemetry endpoint.
        * @param appName - service / sales / any other XRM based app
        * @param context -  A reference to the context of custom entity; null for non-custom entity calls
        */
        AppsTelemetryUtility.reportData = function (eventName, appName, entityName, actionName, context, eventSpecificParams) {
            var telemetrydata = AppsTelemetryUtility.getTelemetryData(eventName, EventTypes.EventData, appName, entityName, actionName, context, eventSpecificParams);
            // Async calls be made to reportEvent call and error scenarios are expected to be handled within reportEvent infra
            if (context != null && context.reporting != null) {
                context.reporting.reportEvent(telemetrydata);
            }
            else {
                Xrm.Reporting.reportEvent(telemetrydata);
            }
        };
        ;
        AppsTelemetryUtility.reportFailure = function (eventName, appName, entityName, actionName, context, eventSpecificParams) {
            var telemetrydata = AppsTelemetryUtility.getTelemetryData(eventName, EventTypes.Failure, appName, entityName, actionName, context, eventSpecificParams);
            if (context != null && context.reporting != null) {
                context.reporting.reportEvent(telemetrydata);
            }
            else {
                Xrm.Reporting.reportEvent(telemetrydata);
            }
        };
        ;
        AppsTelemetryUtility.reportError = function (eventName, appName, entityName, actionName, context, errorMessage, errorTrace) {
            var eventSpecificParams = {};
            eventSpecificParams["errorMessage"] = errorMessage;
            eventSpecificParams["errorTrace"] = errorTrace ? JSON.stringify(errorTrace, Object.getOwnPropertyNames(errorTrace)) : "";
            AppsTelemetryUtility.reportFailure(eventName, appName, entityName, actionName, context, eventSpecificParams);
        };
        ;
        AppsTelemetryUtility.reportSuccess = function (eventName, appName, entityName, actionName, context, eventSpecificParams) {
            var telemetrydata = AppsTelemetryUtility.getTelemetryData(eventName, EventTypes.Success, appName, entityName, actionName, context, eventSpecificParams);
            if (context != null && context.reporting != null) {
                context.reporting.reportEvent(telemetrydata);
            }
            else {
                Xrm.Reporting.reportEvent(telemetrydata);
            }
        };
        ;
        AppsTelemetryUtility.getTelemetryData = function (_eventName, _telemetryDatatype, _appName, _entityName, _actionName, _context, _eventSpecificParams) {
            var payload = {
                eventName: _eventName,
                eventParameters: []
            };
            var para1 = { name: "EventType", value: _telemetryDatatype };
            var para2 = { name: "appName", value: _appName };
            var para3 = { name: "entityName", value: _entityName };
            var para4 = { name: "actionName", value: _actionName };
            var para5 = { name: "context", value: _context };
            payload.eventParameters.push(para1);
            payload.eventParameters.push(para2);
            payload.eventParameters.push(para3);
            payload.eventParameters.push(para4);
            payload.eventParameters.push(para5);
            var mKeys = Object.keys(_eventSpecificParams);
            for (var mk in mKeys) {
                var tParam = { name: mKeys[mk], value: _eventSpecificParams[mKeys[mk]] };
                payload.eventParameters.push(tParam);
            }
            return payload;
        };
        return AppsTelemetryUtility;
    }());
    CrmService.AppsTelemetryUtility = AppsTelemetryUtility;
})(CrmService || (CrmService = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../../ServiceClientCommon/AppsTelemetrylib.ts" />
/// <reference path="../../../../TypeDefinitions/AppCommon/Controls/FREShell/libs/FREShell.d.ts" /> 
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var CaseSettings;
    (function (CaseSettings) {
        var CaseSettingsAttributes = (function () {
            /**
           * constructor
           */
            function CaseSettingsAttributes(context) {
                this._allAvailableAttributes = [];
                this._attributeMapIds = [];
                this._originalSelectedAttributes = "";
                this._currentSelectedAttributes = "";
                this._systemRequiredAttributes = "";
                this._businessRequiredAttributes = "";
                this._initializeRequestsCounter = 0;
                this._expectedTotalResponseCount = 4;
                this._saveInProgress = false;
                this._context = context;
                this.initializeHandler();
            }
            /**
            * returns available attributes
            */
            CaseSettingsAttributes.prototype.getAvailableAttributes = function () {
                return this._allAvailableAttributes;
            };
            /**
           * returns selected attributes
           */
            CaseSettingsAttributes.prototype.getSelectedAttributes = function () {
                return this._currentSelectedAttributes;
            };
            // sets the selected attributes
            CaseSettingsAttributes.prototype.setSelectedAttributes = function (attributes) {
                this._currentSelectedAttributes = attributes;
            };
            /**
           * updates the attributes maps information
           */
            CaseSettingsAttributes.prototype.updateAttributeMaps = function () {
                var _this = this;
                if (this.isCaseSettingAttributesValid()) {
                    var attributesToBeDeleted = this.getDeletedAttributes();
                    var attributesToBeAdded = this.getAddedAttributes();
                    var requestsToExecute = [];
                    // Creating the requests for added attributes
                    for (var _i = 0, attributesToBeAdded_1 = attributesToBeAdded; _i < attributesToBeAdded_1.length; _i++) {
                        var attributeName = attributesToBeAdded_1[_i];
                        var updateEntity = {};
                        updateEntity["sourceattributename"] = attributeName;
                        updateEntity["targetattributename"] = attributeName;
                        updateEntity["entitymapid@odata.bind"] = "/entitymaps(" + this._entityMapIdForIncidentEntity + ")";
                        requestsToExecute.push(new CaseSettings.ODataCreateRequest("attributemap", updateEntity));
                    }
                    // Creating the requests for deleted attributes
                    for (var _a = 0, attributesToBeDeleted_1 = attributesToBeDeleted; _a < attributesToBeDeleted_1.length; _a++) {
                        var attributeName = attributesToBeDeleted_1[_a];
                        var attributeMapIdOfDeletedRecord = this._attributeMapIds
                            .filter(function (d) { return d.Id == attributeName; })
                            .map(function (a) { return a.AttributeMapId; })[0];
                        var deleteEntity = {};
                        deleteEntity["entityType"] = "attributemap";
                        deleteEntity["id"] = attributeMapIdOfDeletedRecord;
                        requestsToExecute.push(new CaseSettings.ODataDeleteRequest(deleteEntity));
                    }
                    //Status Update dropdown 
                    if (this._currentCaseSettingsStatusValue != undefined && this._origCaseSettingsStatusValue != this._currentCaseSettingsStatusValue) {
                        var statusUpdateEntity = {};
                        statusUpdateEntity["cascadestatusupdate"] = this._cascadeStatusUpdate;
                        statusUpdateEntity["restrictstatusupdate"] = this._restrictStatusUpdate;
                        var dropDownUpadte = new CaseSettings.ODataUpdateRequest("organization", this._organizationId, statusUpdateEntity);
                        requestsToExecute.push(dropDownUpadte);
                    }
                    // Executing the requests
                    if (requestsToExecute.length > 0 && !this._saveInProgress) {
                        this._saveInProgress = true;
                        this._context.webAPI.executeMultiple(requestsToExecute).then(function (success) {
                            if (success.every(function (response) { return response.ok; })) {
                                _this._context.utils.addGlobalNotification(1 /* toast */, 1 /* success */, CaseSettings.CaseSettingsLocale.CaseSettings_Save_Success, null, null);
                                _this.reportCaseSettingTelemetry();
                            }
                            else {
                            }
                            // after execution re-initialize the handler
                            _this._initializeRequestsCounter = 0;
                            _this.initializeHandler();
                            _this._saveInProgress = false;
                        }, function (error) {
                            var errorMessage;
                            if (!_this._context.utils.isNullOrUndefined(error.message)) {
                                errorMessage = error.message;
                            }
                            else {
                                errorMessage = _this._context.resources.getString(CaseSettings.CaseSettingsLocale.CaseSettings_Save_Error);
                            }
                            var alertMessage = {
                                text: errorMessage
                            };
                            _this._context.navigation.openAlertDialog(alertMessage);
                            // after execution re-initialize the handler
                            _this._initializeRequestsCounter = 0;
                            _this.initializeHandler();
                            _this._saveInProgress = false;
                        });
                    }
                }
                else {
                    var alertMessage = {
                        text: this._context.resources.getString(CaseSettings.CaseSettingsLocale.CaseSettings_ValidationError)
                    };
                    this._context.navigation.openAlertDialog(alertMessage);
                }
            };
            /**
             * returns false if any of the system and business related attributes are not part of selected attributes list
             */
            CaseSettingsAttributes.prototype.isCaseSettingAttributesValid = function () {
                var that = this;
                var selected = this._currentSelectedAttributes.split(",");
                return (this.isSuperset(selected, this._systemRequiredAttributes.split(",")) &&
                    this.isSuperset(selected, this._businessRequiredAttributes.split(",")));
            };
            /**
            * Reporting Telemtry Data when casesettings is updated
            */
            CaseSettingsAttributes.prototype.reportCaseSettingTelemetry = function () {
                try {
                    var eventSpecificAttributeMapping = {};
                    var eventSpecificDropDownUpdateParameters = {};
                    var changeinMapping = false;
                    var changeinStatusUpdate = false;
                    var allCurrentlySelectedAttributes = this._currentSelectedAttributes.split(",").sort();
                    var allOriginalSelectedAttributes = this._originalSelectedAttributes.split(",").sort();
                    if (allCurrentlySelectedAttributes.length != allOriginalSelectedAttributes.length) {
                        changeinMapping = true;
                    }
                    else {
                        allCurrentlySelectedAttributes.forEach(function (item, index) {
                            if (item != allOriginalSelectedAttributes[index]) {
                                changeinMapping = true;
                                return false;
                            }
                        });
                    }
                    //Reporting Case Settings Mapped and UnMapped Attributes 
                    if (changeinMapping == true) {
                        var allAvailableAttribute = this._allAvailableAttributes;
                        for (var _i = 0, allCurrentlySelectedAttributes_1 = allCurrentlySelectedAttributes; _i < allCurrentlySelectedAttributes_1.length; _i++) {
                            var selectedAttribute = allCurrentlySelectedAttributes_1[_i];
                            eventSpecificAttributeMapping[selectedAttribute] = "mapped";
                        }
                        for (var _a = 0, allAvailableAttribute_1 = allAvailableAttribute; _a < allAvailableAttribute_1.length; _a++) {
                            var availableAttribute = allAvailableAttribute_1[_a];
                            if (this._context.utils.isNullOrUndefined(eventSpecificAttributeMapping[availableAttribute.LogicalName])
                                || !(eventSpecificAttributeMapping[availableAttribute.LogicalName] == "mapped")) {
                                eventSpecificAttributeMapping[availableAttribute.LogicalName] = "unmapped";
                            }
                        }
                        CrmService.AppsTelemetryUtility.reportData(CrmService.EventList.IncidentEvent, CrmService.ModuleList.service, CrmService.EntityList.attributemap, CrmService.Action.update, this._context, eventSpecificAttributeMapping);
                    }
                    //Reporting Case Setting Status Value
                    if ((!this._context.utils.isNullOrUndefined(this._currentCaseSettingsStatusValue)) &&
                        (!this._context.utils.isNullOrUndefined(this._origCaseSettingsStatusValue)) &&
                        (this._origCaseSettingsStatusValue != this._currentCaseSettingsStatusValue)) {
                        changeinStatusUpdate = true;
                        eventSpecificDropDownUpdateParameters["CSStatusValue"] = CaseSettings.StatusUpdate[this._currentCaseSettingsStatusValue];
                        CrmService.AppsTelemetryUtility.reportData(CrmService.EventList.IncidentEvent, CrmService.ModuleList.service, CrmService.EntityList.organization, CrmService.Action.update, this._context, eventSpecificDropDownUpdateParameters);
                    }
                    //Reporting when any of the default Settings update
                    if (changeinMapping == true || changeinStatusUpdate == true) {
                        var eventSpecificUpdatedCasesettings = {};
                        eventSpecificUpdatedCasesettings["updatedCaseSetting"] = true;
                        CrmService.AppsTelemetryUtility.reportData(CrmService.EventList.IncidentEvent, CrmService.ModuleList.service, CrmService.EntityList.attributemap, CrmService.Action.update, this._context, eventSpecificUpdatedCasesettings);
                    }
                }
                catch (telemetryException) {
                    var errorMessage = "Error reporting Telemetry";
                    this.reportErrorTelemetry(this._context, errorMessage, telemetryException);
                }
            };
            /**
            * Logs error telemetry
            * @param context The "Input Bag" containing the parameters and other control metadata.
            * @param errorMessage error message to be reported
            * @param errorTrace stack trace information about error
            */
            CaseSettingsAttributes.prototype.reportErrorTelemetry = function (context, errorMessage, errorTrace) {
                CrmService.AppsTelemetryUtility.reportError(CrmService.EventList.IncidentEvent, CrmService.ModuleList.service, CrmService.EntityList.incident, CrmService.Action.update, context, errorMessage, errorTrace);
            };
            /**
             * This method will be called from CaseSettingsAttributes constructor to initialize the handler with selected and all available attributes details
             */
            CaseSettingsAttributes.prototype.initializeHandler = function () {
                var _this = this;
                // call to get the entitymapid of incident
                this._context.webAPI.retrieveMultipleRecords("entitymap", CaseSettings.CaseSettingsHelper.getEntityMapIdForIncidentEntityRequest()).then(function (data) {
                    try {
                        _this._initializeRequestsCounter = _this._initializeRequestsCounter + 1;
                        if (data.entities.length == 0) {
                            var emptyEntityMapIdMessage = "entitymapid not found";
                        }
                        else {
                            _this._entityMapIdForIncidentEntity = data.entities["0"].entitymapid;
                            // once entitymapid of incident is available, fetch the selected attributes list
                            var selectedAttributesUrl = _this._context.utils.createCrmUri(CaseSettings.CaseSettingsHelper.getSelectedAttributesRequest(_this._entityMapIdForIncidentEntity));
                            _this.getSelectedAttributesRequest(selectedAttributesUrl).then(function (innerCallData) {
                                try {
                                    _this.initializeSelectedAttributesData(innerCallData);
                                    _this._initializeRequestsCounter = _this._initializeRequestsCounter + 1;
                                    _this.checkRequestCounterForRerendering();
                                }
                                catch (innerCallDataExpcetion) {
                                    var errorMessage = "Error fetching the selected attributes.";
                                    _this.reportErrorTelemetry(_this._context, errorMessage, innerCallDataExpcetion);
                                }
                            }, function (innerCallError) {
                                var innerCallErrorMessage = "Retrieval of System Required Attributes Failed.";
                            });
                        }
                    }
                    catch (entityMapExpcetion) {
                        var errorMessage = "Error retreiving the EntityMap.";
                        _this.reportErrorTelemetry(_this._context, errorMessage, entityMapExpcetion);
                    }
                }, function (error) {
                    var errMessage = "Retrieval of entitymapid Failed.";
                });
                // call to get all the attributes from incident entitydefinition
                var allAttribuesUrl = CaseSettings.CaseSettingsHelper.getAllAttributesOfIncidentEntityRequest();
                this.getAllAttributesRequest(this._context.utils.createCrmUri(allAttribuesUrl)).then(function (allAttributesData) {
                    try {
                        if (allAttributesData.value.length == 0) {
                            var allAttributesDataEmptyMessage = "Attribues not found";
                        }
                        else {
                            _this.initializeAllAttributesData(allAttributesData);
                            _this._initializeRequestsCounter = _this._initializeRequestsCounter + 1;
                            _this.checkRequestCounterForRerendering();
                        }
                    }
                    catch (allAttributesExpcetion) {
                        var errorMessage = "Error Fetching all the available attributes from incident entitydefination.";
                        _this.reportErrorTelemetry(_this._context, errorMessage, allAttributesExpcetion);
                    }
                }, function (allAttributesError) {
                    var allAttributesErrorMessage = "Retrieval of all attributes call Failed.";
                });
                // call to get the StatusUpdate values
                this._context.webAPI.retrieveMultipleRecords(CaseSettings.ENTITY.ORGANIZATION, CaseSettings.CaseSettingsHelper.getStatusUpdateValueRequest()).then(function (data) {
                    try {
                        _this._organizationId = data.entities["0"].organizationid;
                        _this.setCaseSettingsStatusValue(data);
                        _this._initializeRequestsCounter = _this._initializeRequestsCounter + 1;
                        _this.checkRequestCounterForRerendering();
                    }
                    catch (statusUpdateValueexpcetion) {
                        var errorMessage = "Error Fetching StatusUpdate Value from Organization.";
                        _this.reportErrorTelemetry(_this._context, errorMessage, statusUpdateValueexpcetion);
                    }
                }, function (error) {
                    var errMessage = "Retrieval of StatusUpdateValues call Failed.";
                });
            };
            CaseSettingsAttributes.prototype.getSelectedAttributesRequest = function (selectedAttributesUrl) {
                return $.ajax({
                    url: selectedAttributesUrl,
                    type: 'GET',
                    async: true,
                    beforeSend: function (request) {
                        request.setRequestHeader("OData-MaxVersion", "4.0");
                        request.setRequestHeader("OData-Version", "4.0");
                        request.setRequestHeader("Accept", "application/json");
                        request.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                        request.setRequestHeader("Cache-Control", " no-cache, no-store, must-revalidate");
                        request.setRequestHeader("Pragma", " no-cache");
                        request.setRequestHeader("Expires", "0");
                        request.setRequestHeader("If-None-Match", "");
                    }
                });
            };
            /**
             * return the list of attributes that needs to be deleted
             */
            CaseSettingsAttributes.prototype.getDeletedAttributes = function () {
                var _this = this;
                return this._originalSelectedAttributes.split(",").filter(function (i) {
                    return _this._systemRequiredAttributes.split(",").indexOf(i) < 0 && _this._currentSelectedAttributes.indexOf(i) < 0;
                });
            };
            /**
             * return the list of attributes that needs to be added/created
             */
            CaseSettingsAttributes.prototype.getAddedAttributes = function () {
                var _this = this;
                return this._currentSelectedAttributes.split(",").filter(function (i) {
                    return _this._systemRequiredAttributes.split(",").indexOf(i) < 0 && _this._originalSelectedAttributes.indexOf(i) < 0;
                });
            };
            /**
            * checks for the request counter and if initialize Requests Counter matches with expected Response Counter then it will rerender the page
            */
            CaseSettingsAttributes.prototype.checkRequestCounterForRerendering = function () {
                var _this = this;
                if (this._initializeRequestsCounter == this._expectedTotalResponseCount) {
                    this._originalSelectedAttributes = "";
                    // before rendering the page initialize the original selected values
                    // this._selectedAttributes is used to hold the onload selected values by filtering out the entitymaps list from allattributes list
                    this._originalSelectedAttributes = this._attributeMapIds
                        .filter(function (d) { return _this._allAvailableAttributes.map(function (a) { return a.LogicalName; }).indexOf(d.Id) > -1; })
                        .map(function (a) { return a.Id; }).join(",");
                    // this._currentSelectedAttributes is used to hold the updated/refreshed values from UI
                    this._currentSelectedAttributes = this._originalSelectedAttributes;
                    this.initializeBusinessRequiredAttributes();
                    this._context.utils.requestRender();
                }
            };
            /**
            * Used to initialize the selected attributes details
            */
            CaseSettingsAttributes.prototype.initializeSelectedAttributesData = function (myDataJson) {
                var records = myDataJson.value;
                this._attributeMapIds = [];
                for (var i = 0; i < records.length; i++) {
                    var record = records[i];
                    if (record.sourceattributename == record.targetattributename) {
                        var attribute = {
                            "Id": record.sourceattributename,
                            "AttributeMapId": record.attributemapid,
                            "issystem": record.issystem
                        };
                        this._attributeMapIds.push(attribute);
                    }
                }
                // set the system required attributes
                this._systemRequiredAttributes = this._attributeMapIds
                    .filter(function (d) { return d.issystem == true; })
                    .map(function (a) { return a.Id; }).join(",");
            };
            /**
            * Ajax call request to fetch the All attributes list
            */
            CaseSettingsAttributes.prototype.getAllAttributesRequest = function (getAllUrl) {
                return $.ajax({
                    url: getAllUrl,
                    type: 'GET',
                    async: true,
                    beforeSend: function (request) {
                        request.setRequestHeader("OData-MaxVersion", "4.0");
                        request.setRequestHeader("OData-Version", "4.0");
                        request.setRequestHeader("Accept", "application/json");
                        request.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    }
                });
            };
            /**
            * Used to initialize the All available attributes details
            */
            CaseSettingsAttributes.prototype.initializeAllAttributesData = function (myDataJson) {
                var records = myDataJson.value;
                this._allAvailableAttributes = [];
                for (var i = 0; i < records.length; i++) {
                    var record = records[i];
                    if (this.validateAllAttributesRecord(record)) {
                        var that = this;
                        var attribute = {
                            LogicalName: record.LogicalName,
                            DisplayName: (record.DisplayName.LocalizedLabels.filter(function (a) { return a.LanguageCode == that._context.orgSettings.languageId; }))[0].Label,
                            isApplicationRequired: (record.RequiredLevel.Value == "ApplicationRequired") ? true : false
                        };
                        this._allAvailableAttributes.push(attribute);
                    }
                }
                this._allAvailableAttributes = this._allAvailableAttributes.sort(function (a, b) { return a.DisplayName.localeCompare(b.DisplayName); });
                this.initializeBusinessRequiredAttributes();
            };
            /**
            * performs the validation of the available attributes to ignore/display the record in available items list
            */
            CaseSettingsAttributes.prototype.validateAllAttributesRecord = function (record) {
                // if record is not having valid description then donot show the record in available items list
                if (record.Description.LocalizedLabels.length > 0) {
                    // if record is not having valid display name then donot show the record in available items list
                    if (record.DisplayName.LocalizedLabels.length > 0) {
                        // if isvalidforcreate is not equal to true then donot show the record in available items list
                        if (record.IsValidForCreate) {
                            if (this.validatateImeMode(record)) {
                                if (this.validatateYomi(record)) {
                                    return true;
                                }
                            }
                        }
                    }
                }
                return false;
            };
            /**
            * validates imemode and returns the response to the caller
            */
            CaseSettingsAttributes.prototype.validatateImeMode = function (record) {
                // Not able to get the Imemode value for actualserviceunits, billedserviceunits, timezoneruleversionnumber, utcconversiontimezonecode attributes from api call, hence hardcoded
                if (record.LogicalName == "actualserviceunits" || record.LogicalName == "billedserviceunits" || record.LogicalName == "timezoneruleversionnumber" || record.LogicalName == "utcconversiontimezonecode") {
                    return false;
                }
                else if (this._context.utils.isNullOrUndefined(record["ImeMode"])) {
                    return true;
                }
                else if (record.ImeMode == "Disabled") {
                    return false;
                }
                else {
                    return true;
                }
            };
            /**
             * returns true is group1 is superset of group2
             */
            CaseSettingsAttributes.prototype.isSuperset = function (group1, group2) {
                if (group2 == "") {
                    return true;
                }
                else {
                    return group2.every(function (item) {
                        return group1.indexOf(item) >= 0;
                    });
                }
            };
            /**
             * set the business required attributes if systemRequiredAttributes list is already available
             */
            CaseSettingsAttributes.prototype.initializeBusinessRequiredAttributes = function () {
                if (this._systemRequiredAttributes != "") {
                    var that = this;
                    this._businessRequiredAttributes = this._allAvailableAttributes
                        .filter(function (d) { return (d.isApplicationRequired == true && that._systemRequiredAttributes.split(",").indexOf(d.LogicalName) < 0); })
                        .map(function (a) { return a.LogicalName; }).join(",");
                }
            };
            /**
            * for non japanese langauge if there YomiOf attribute is having some value then return false
            */
            CaseSettingsAttributes.prototype.validatateYomi = function (record) {
                // 
                if (this._context.orgSettings.languageId != 1041 && !this._context.utils.isNullOrUndefined(record["YomiOf"]) && record.YomiOf != null) {
                    return false;
                }
                else {
                    return true;
                }
            };
            /**
            * returns Original StatusUpdateValue
            */
            CaseSettingsAttributes.prototype.getOriginalStatusUpdateValue = function () {
                return this._origCaseSettingsStatusValue;
            };
            /**
            * sets Current StatusUpdateValue
            */
            CaseSettingsAttributes.prototype.setCurrentStatusUpdateValue = function (value) {
                this._currentCaseSettingsStatusValue = value;
                if (value == CaseSettings.StatusUpdate.None) {
                    this._cascadeStatusUpdate = false;
                    this._restrictStatusUpdate = false;
                }
                if (value == CaseSettings.StatusUpdate.Restrict) {
                    this._cascadeStatusUpdate = false;
                    this._restrictStatusUpdate = true;
                }
                if (value == CaseSettings.StatusUpdate.Cascade) {
                    this._cascadeStatusUpdate = true;
                    this._restrictStatusUpdate = false;
                }
                if (value == CaseSettings.StatusUpdate.Restrict) {
                    this._cascadeStatusUpdate = false;
                    this._restrictStatusUpdate = true;
                }
            };
            /**
            * Set StatusUpdateValue based on cascadestatusupdate and Restrict
            */
            CaseSettingsAttributes.prototype.setCaseSettingsStatusValue = function (data) {
                if (data.entities["0"].cascadestatusupdate == true) {
                    this._origCaseSettingsStatusValue = CaseSettings.StatusUpdate.Cascade;
                }
                else if (data.entities["0"].restrictstatusupdate == true) {
                    this._origCaseSettingsStatusValue = CaseSettings.StatusUpdate.Restrict;
                }
                else {
                    this._origCaseSettingsStatusValue = CaseSettings.StatusUpdate.None;
                }
            };
            return CaseSettingsAttributes;
        }());
        CaseSettings.CaseSettingsAttributes = CaseSettingsAttributes;
        var ValidationState;
        (function (ValidationState) {
            ValidationState[ValidationState["Success"] = 0] = "Success";
            ValidationState[ValidationState["MandatoryAttributeMissing"] = 1] = "MandatoryAttributeMissing";
        })(ValidationState = CaseSettings.ValidationState || (CaseSettings.ValidationState = {}));
    })(CaseSettings = MscrmControls.CaseSettings || (MscrmControls.CaseSettings = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var CaseSettings;
    (function (CaseSettings) {
        'use strict';
        var CaseSettingsConstants;
        (function (CaseSettingsConstants) {
            //keys and ids
            CaseSettingsConstants.CASESETTINGS_INFO_LABEL = "caseSettingsInfoLabel";
            CaseSettingsConstants.CASESETTINGS_DUALLIST_CONTAINER = "caseSettingsDualListContainer";
            CaseSettingsConstants.CASESETTINGS_SAVE_BUTTON = "caseSettingsSaveButton";
            CaseSettingsConstants.CASESETTINGS_HELP_BUTTON = "caseSettingsHelpButton";
            CaseSettingsConstants.CASESETTINGS_MAIN_CONTAINER = "caseSettingsMainContainer";
            CaseSettingsConstants.CASESETTINGS_BLANK_CONTAINER = "caseSettingsBlankContainer";
            CaseSettingsConstants.CASESETTINGS_CLOUSER_PREFERENCE_DDL_CONTROL_PROPS = "caseSettingsClouserPreferenceDDLControlProps";
            CaseSettingsConstants.CASESETTINGS_CLOUSER_PREFERENCE_DDL_LBL = "caseSettingsClouserPreferenceDDLLabel";
            CaseSettingsConstants.CASESETTINGS_CLOUSER_PREFERENCE_DDL_CONTAINER = "caseSettingsClouserPreferenceDDLContainer";
            CaseSettingsConstants.CASESETTINGS_SAVEICONCONTAINERKEY = "caseSettingsSaveIconContainerKey";
            CaseSettingsConstants.CASESETTINGS_HELPICONCONTAINERKEY = "caseSettingsHelpIconContainerKey";
            CaseSettingsConstants.CASESETTINGS_HEADERSEPARATORCONTAINERKEY = "caseSettingsHeaderSeparatorContainerKey";
            CaseSettingsConstants.CASESETTINGS_HEADERRIGHTCONTAINERKEY = "caseSettingsHeaderRightContainerKey";
            // Image paths
            CaseSettingsConstants.CASESETTINGS_HEADER_ICON_IMAGE = "../../WebResources/Service/_imgs/Controls/CaseSettings/CaseSettings.svg";
            CaseSettingsConstants.CASESETTINGS_HELP_ICON_IMAGE = "../../WebResources/CustomerServiceHub/_imgs/Sitemap/Help.svg";
            CaseSettingsConstants.CASESETTINGS_HEADER_ICON_HIGHCONTRAST_IMAGE = "../../WebResources/Service/_imgs/Controls/CaseSettings/CaseSettings_HC.svg";
        })(CaseSettingsConstants = CaseSettings.CaseSettingsConstants || (CaseSettings.CaseSettingsConstants = {}));
        var ENTITY = (function () {
            function ENTITY() {
            }
            Object.defineProperty(ENTITY, "ORGANIZATION", {
                get: function () {
                    return "organization";
                },
                enumerable: true,
                configurable: true
            });
            return ENTITY;
        }());
        CaseSettings.ENTITY = ENTITY;
        var StatusUpdate;
        (function (StatusUpdate) {
            StatusUpdate[StatusUpdate["None"] = 0] = "None";
            StatusUpdate[StatusUpdate["Cascade"] = 1] = "Cascade";
            StatusUpdate[StatusUpdate["Restrict"] = 2] = "Restrict";
        })(StatusUpdate = CaseSettings.StatusUpdate || (CaseSettings.StatusUpdate = {}));
    })(CaseSettings = MscrmControls.CaseSettings || (MscrmControls.CaseSettings = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var CaseSettings;
    (function (CaseSettings) {
        'use strict';
        var CaseSettingsHelper = (function () {
            function CaseSettingsHelper() {
            }
            CaseSettingsHelper.getEntityMapIdForIncidentEntityRequest = function () {
                return "?$filter=sourceentityname eq 'incident' and targetentityname eq 'incident'";
            };
            CaseSettingsHelper.getSelectedAttributesRequest = function (entityMapId) {
                return "/api/data/v9.0/entitymaps(" + entityMapId + ")/entity_map_attribute_maps?$select=sourceattributename,targetattributename,attributemapid,issystem";
            };
            CaseSettingsHelper.getAllAttributesOfIncidentEntityRequest = function () {
                return "/api/data/v9.0/EntityDefinitions(LogicalName='incident')/Attributes?$filter=IsValidForUpdate ne false and IsLogical ne true  and LogicalName ne 'parentcaseid' and LogicalName ne 'masterid'";
            };
            CaseSettingsHelper.getStatusUpdateValueRequest = function () {
                return "?$select=cascadestatusupdate,restrictstatusupdate";
            };
            return CaseSettingsHelper;
        }());
        CaseSettings.CaseSettingsHelper = CaseSettingsHelper;
        var ODataCreateRequest = (function () {
            function ODataCreateRequest(etn, payload) {
                this.etn = etn;
                this.payload = payload;
            }
            ODataCreateRequest.prototype.getMetadata = function () {
                return {
                    boundParameter: undefined,
                    parameterTypes: {},
                    operationName: "Create",
                    operationType: 2,
                };
            };
            return ODataCreateRequest;
        }());
        CaseSettings.ODataCreateRequest = ODataCreateRequest;
        var ODataDeleteRequest = (function () {
            function ODataDeleteRequest(entityReference) {
                this.entityReference = entityReference;
            }
            ODataDeleteRequest.prototype.getMetadata = function () {
                return {
                    boundParameter: undefined,
                    parameterTypes: {
                        "entityReference": {
                            "typeName": "mscrm.crmbaseentity",
                            "structuralProperty": 5 /* EntityType */,
                        },
                    },
                    operationName: "Delete",
                    operationType: 2,
                };
            };
            return ODataDeleteRequest;
        }());
        CaseSettings.ODataDeleteRequest = ODataDeleteRequest;
        var ODataUpdateRequest = (function () {
            function ODataUpdateRequest(etn, id, payload) {
                this.etn = etn;
                this.id = id;
                this.payload = payload;
            }
            ODataUpdateRequest.prototype.getMetadata = function () {
                return {
                    boundParameter: undefined,
                    parameterTypes: {},
                    operationName: "Update",
                    operationType: 2,
                };
            };
            return ODataUpdateRequest;
        }());
        CaseSettings.ODataUpdateRequest = ODataUpdateRequest;
    })(CaseSettings = MscrmControls.CaseSettings || (MscrmControls.CaseSettings = {}));
})(MscrmControls || (MscrmControls = {}));
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var CaseSettings;
    (function (CaseSettings) {
        'use strict';
    })(CaseSettings = MscrmControls.CaseSettings || (MscrmControls.CaseSettings = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var CaseSettings;
    (function (CaseSettings) {
        /**
        * A select box can contain multiple list. At a time, only one list can be rendered by the select box.
        * On an event, we can change list pointer to the list which need to be rendered by select box.
        */
        var SelectBox = (function () {
            /**
            *
            * @param currentListId:creates a list and make it as current list.
            */
            function SelectBox(currentListId) {
                //It contains set of list to be rendered in select box.
                this._optionsList = {};
                this._currentListId = currentListId;
                this._optionsList[currentListId] = new Array();
                this.currentOptions = new Array();
                this.currentOptions = this._optionsList[currentListId];
            }
            Object.defineProperty(SelectBox, "DEFAULTLISTID", {
                get: function () {
                    return "defaultId";
                },
                enumerable: true,
                configurable: true
            });
            /**
            * This function changes the listPointer of select box to the new list @currentListId
            * @param currentListId: The new listId which is to be rendered in the select box
            */
            SelectBox.prototype.changeCurrentListId = function (currentListId) {
                this._currentListId = currentListId;
                this.currentOptions = this._optionsList[currentListId];
            };
            /**
            * It creates element displayed in select box.
            * Each element in select box is composed of text and value
            * @param _text:The text rendered in the select box on the screen
            * @param _value:The value corresponding to the text
            */
            SelectBox.prototype.createOption = function (_text, _value) {
                // Converting _value to Number datatype.
                var x = +_value;
                return { Label: _text, Value: x };
            };
            /**
            *If list doesnot exist, then it creates new list, adds the element in list and returns true
            *else simply adds the value and text in the list and return false.
            *If listId not specified, it takes currentListId.
            * @param id use to identify the list from collection of list
            * @param key by which resource will be fetched from resource file
            * @param value value used by select box
            */
            SelectBox.prototype.addItems = function (text, value, listId) {
                var b = false;
                if (listId === undefined)
                    listId = this._currentListId;
                if (this._optionsList[listId] === undefined) {
                    this._optionsList[listId] = new Array();
                    b = true;
                }
                this._optionsList[listId].push(this.createOption(text, value));
                return b;
            };
            return SelectBox;
        }());
        CaseSettings.SelectBox = SelectBox;
    })(CaseSettings = MscrmControls.CaseSettings || (MscrmControls.CaseSettings = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=CaseSettingsControl.js.map