/**
 * This code was generated from a script.
 * Manual changes to this file will be overwritten if the code is regenerated.
 *
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="Typings/mscrm.d.ts" />
/// <reference path="Typings/CommonControl.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var WebResource;
    (function (WebResource) {
        'use strict';
        var WebResourceWrapperControl = (function () {
            /**
             * Empty constructor.
             */
            function WebResourceWrapperControl() {
                this._controlId = MscrmCommon.ControlUtils.ControlGuidGenerator.newGuid("WebResourceWrapperControl");
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            WebResourceWrapperControl.prototype.init = function (context, notifyOutputChanged) {
                this._context = context;
                this._notifyOutputChanged = notifyOutputChanged;
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            WebResourceWrapperControl.prototype.updateView = function (context) {
                this._context = context;
                return this._context.factory.createElement("CONTAINER", {
                    key: this._getId("Container")
                }, this._createIframeControl());
            };
            WebResourceWrapperControl.prototype._createIframeControl = function () {
                var properties = {
                    id: this._getId("IFrame"),
                    title: "Power BI Configuration",
                    src: this._context.parameters.PbiUrl.raw,
                    scrolling: false,
                    onLoad: this._onLoad.bind(this),
                    security: undefined,
                    style: {
                        border: "0px",
                        height: "500px",
                        width: "456px"
                    }
                };
                return this._context.factory.createElement("IFRAME", properties);
            };
            WebResourceWrapperControl.prototype._onLoad = function (event) {
                //TODO: Error handling for onload
            };
            WebResourceWrapperControl.prototype._getId = function (suffix) {
                return MscrmCommon.ControlUtils.String.Format("{0}_{1}", this._controlId, suffix);
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            WebResourceWrapperControl.prototype.getOutputs = function () {
                return;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            WebResourceWrapperControl.prototype.destroy = function () {
            };
            return WebResourceWrapperControl;
        }());
        WebResource.WebResourceWrapperControl = WebResourceWrapperControl;
    })(WebResource = MscrmControls.WebResource || (MscrmControls.WebResource = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="WebResourceWrapperControl.ts" /> 
//# sourceMappingURL=WebResourceWrapperControl.js.map