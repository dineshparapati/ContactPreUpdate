var ServiceCommon;
(function (ServiceCommon) {
    'use strict';
    //Output related interfaces
    var WeeklyScheduleControlOutput = (function () {
        function WeeklyScheduleControlOutput() {
        }
        return WeeklyScheduleControlOutput;
    }());
    ServiceCommon.WeeklyScheduleControlOutput = WeeklyScheduleControlOutput;
    var WeeklyScheduleControlOutputStatus;
    (function (WeeklyScheduleControlOutputStatus) {
        WeeklyScheduleControlOutputStatus[WeeklyScheduleControlOutputStatus["Error"] = 0] = "Error";
        WeeklyScheduleControlOutputStatus[WeeklyScheduleControlOutputStatus["Success"] = 1] = "Success";
    })(WeeklyScheduleControlOutputStatus = ServiceCommon.WeeklyScheduleControlOutputStatus || (ServiceCommon.WeeklyScheduleControlOutputStatus = {}));
    var WeeklyScheduleControlOutputData = (function () {
        function WeeklyScheduleControlOutputData() {
        }
        return WeeklyScheduleControlOutputData;
    }());
    ServiceCommon.WeeklyScheduleControlOutputData = WeeklyScheduleControlOutputData;
    var WorkRuleMode;
    (function (WorkRuleMode) {
        WorkRuleMode[WorkRuleMode["AllTheSameRules"] = 0] = "AllTheSameRules";
        WorkRuleMode[WorkRuleMode["VaryByDayRules"] = 1] = "VaryByDayRules";
        WorkRuleMode[WorkRuleMode["TwentyX7Support"] = 2] = "TwentyX7Support";
        WorkRuleMode[WorkRuleMode["NotWorking"] = 3] = "NotWorking";
    })(WorkRuleMode = ServiceCommon.WorkRuleMode || (ServiceCommon.WorkRuleMode = {}));
})(ServiceCommon || (ServiceCommon = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CalendarRuleType;
        (function (CalendarRuleType) {
            CalendarRuleType[CalendarRuleType["Break"] = 0] = "Break";
            CalendarRuleType[CalendarRuleType["WorkHour"] = 1] = "WorkHour";
        })(CalendarRuleType = AppCommon.CalendarRuleType || (AppCommon.CalendarRuleType = {}));
        var Day;
        (function (Day) {
            Day[Day["NONE"] = -1] = "NONE";
            Day[Day["SUN"] = 0] = "SUN";
            Day[Day["MON"] = 1] = "MON";
            Day[Day["TUE"] = 2] = "TUE";
            Day[Day["WED"] = 3] = "WED";
            Day[Day["THU"] = 4] = "THU";
            Day[Day["FRI"] = 5] = "FRI";
            Day[Day["SAT"] = 6] = "SAT";
        })(Day = AppCommon.Day || (AppCommon.Day = {}));
        var TimeCode;
        (function (TimeCode) {
            TimeCode[TimeCode["Available"] = 0] = "Available";
            TimeCode[TimeCode["Busy"] = 1] = "Busy";
            TimeCode[TimeCode["Unavailable"] = 2] = "Unavailable";
            TimeCode[TimeCode["Filter"] = 3] = "Filter";
        })(TimeCode = AppCommon.TimeCode || (AppCommon.TimeCode = {}));
        var SubCode;
        (function (SubCode) {
            SubCode[SubCode["Unspecified"] = 0] = "Unspecified";
            SubCode[SubCode["Schedulable"] = 1] = "Schedulable";
            SubCode[SubCode["Committed"] = 2] = "Committed";
            SubCode[SubCode["Uncommitted"] = 3] = "Uncommitted";
            SubCode[SubCode["Break"] = 4] = "Break";
            SubCode[SubCode["Holiday"] = 5] = "Holiday";
            SubCode[SubCode["Vacation"] = 6] = "Vacation";
            SubCode[SubCode["Appointment"] = 7] = "Appointment";
            SubCode[SubCode["ResourceStartTime"] = 8] = "ResourceStartTime";
            SubCode[SubCode["ResourceServiceRestriction"] = 9] = "ResourceServiceRestriction";
            SubCode[SubCode["ResourceCapacity"] = 10] = "ResourceCapacity";
            SubCode[SubCode["ServiceRestriction"] = 11] = "ServiceRestriction";
            SubCode[SubCode["ServiceCost"] = 12] = "ServiceCost";
        })(SubCode = AppCommon.SubCode || (AppCommon.SubCode = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * IMPORTANT!
 * DO NOT MAKE CHANGES TO THIS FILE - THIS FILE IS AUTO-GENERATED FROM ODATA CSDL METADATA DOCUMENT
 * SEE https://msdn.microsoft.com/en-us/library/mt607990.aspx FOR MORE INFORMATION
 */
var ODataContract;
(function (ODataContract) {
    /* tslint:disable:crm-force-fields-private */
    var DeleteWeeklyScheduleRequest = (function () {
        function DeleteWeeklyScheduleRequest() {
        }
        DeleteWeeklyScheduleRequest.prototype.getMetadata = function () {
            var metadata = {
                boundParameter: null,
                operationName: "DeleteWeeklySchedule",
                operationType: 0,
                parameterTypes: {
                    "CalendarId": {
                        "typeName": "Edm.Guid",
                        "structuralProperty": 1,
                    },
                },
            };
            return metadata;
        };
        return DeleteWeeklyScheduleRequest;
    }());
    ODataContract.DeleteWeeklyScheduleRequest = DeleteWeeklyScheduleRequest;
})(ODataContract || (ODataContract = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../../ServiceCommon/CalendarDataInterfaces.ts" />
/// <reference path="../SetWorkHourControl/SetWorkHourInterfaces.ts" />
/// <reference path="../../ClientCommon/DataContracts/Action/DeleteWeeklyScheduleRequest.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CustomerServiceSchedule;
        (function (CustomerServiceSchedule) {
            'use strict';
            var WeeklyScheduleControl = (function () {
                /*
                 * Empty constructor.
                 */
                function WeeklyScheduleControl() {
                    this._inputCustomerServiceScheduleData = null;
                    this._dataHandler = null;
                    this._uiHandler = null;
                    this._isDeleteSuccessful = false;
                    this._isLoadingForFirstTime = true;
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                WeeklyScheduleControl.prototype.init = function (context, notifyOutputChanged, state) {
                    var _this = this;
                    this._context = context;
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                    CustomerServiceSchedule.WeeklyScheduleStyles.initialize(this._context.theming, this._context.client.isRTL);
                    CustomerServiceSchedule.WeeklyScheduleLocale.initialize(function (id) { return _this._context.resources.getString(id); });
                    this.initializeDateTimeFormatingInformation();
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                WeeklyScheduleControl.prototype.updateView = function (context) {
                    this._context = context;
                    if (!this._context.utils.isNullOrUndefined(this._context.parameters.weeklyScheduleControlInput)
                        && !this._context.utils.isNullOrUndefined(this._context.parameters.weeklyScheduleControlInput.raw)) {
                        var newCSSData = this._context.parameters.weeklyScheduleControlInput.raw;
                        if (this._isLoadingForFirstTime || !this.jsonEqual(newCSSData, this._inputCustomerServiceScheduleData)
                            || this._uiHandler.getCurrentDeleteSuccessfulStatus() === true) {
                            this._isLoadingForFirstTime = false;
                            this.processInputDataAndGenerateUIHandler();
                            this._isDeleteSuccessful = false;
                        }
                    }
                    if (!this._context.utils.isNullOrUndefined(this._uiHandler)) {
                        return this._uiHandler.getUIComponents();
                    }
                    return this._context.factory.createElement("CONTAINER", {
                        id: CustomerServiceSchedule.WeeklyScheduleConstants.TOPMOST_CONTAINERID,
                        key: CustomerServiceSchedule.WeeklyScheduleConstants.TOPMOST_CONTAINERID,
                        style: CustomerServiceSchedule.WeeklyScheduleStyles.topMostContainer,
                    }, []);
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *    value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                */
                WeeklyScheduleControl.prototype.getOutputs = function () {
                    // returns outputbag based on current data handler object state.
                    var dataHandlerObject = this._uiHandler.getDataHandlerObject();
                    var controlOutputData = CustomerServiceSchedule.OuputDataGenerator.getOuputDataFromDataHandler(dataHandlerObject, this._context);
                    var outputBag = {
                        weeklyScheduleControlOutput: controlOutputData,
                        deleteWeeklyScheduleSuccessful: this._uiHandler.getCurrentDeleteSuccessfulStatus()
                    };
                    return outputBag;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                */
                WeeklyScheduleControl.prototype.destroy = function () {
                };
                /**
                 * Compares to objects
                 * @param a object1
                 * @param b object2
                 */
                WeeklyScheduleControl.prototype.jsonEqual = function (a, b) {
                    return JSON.stringify(a) === JSON.stringify(b);
                };
                /**
                 * Shows generic error message to user
                 * @param context The "Input Bag" containing the parameters and other control metadata.
                 */
                WeeklyScheduleControl.showErrorMessage = function (context, errorMessage, buttonText) {
                    var alertMessage = {
                        text: errorMessage != null ? errorMessage : CustomerServiceSchedule.WeeklyScheduleLocale.Error_GenericErrorOccurred,
                        confirmButtonLabel: buttonText != null ? buttonText : CustomerServiceSchedule.WeeklyScheduleLocale.ConfirmButtonText
                    };
                    context.navigation.openAlertDialog(alertMessage);
                };
                /**
                 * Initializes timeformating information
                 */
                WeeklyScheduleControl.prototype.initializeDateTimeFormatingInformation = function () {
                    this._dateFormattingInfo = this._context.client.dateFormattingInfo;
                    this._isTwoDigitFormat = (this._dateFormattingInfo.ShortTimePattern.match(new RegExp("h", "gi")) || []).length === 2; // has HH or hh in the format string
                    this._is24HourFormat = this._dateFormattingInfo.ShortTimePattern.indexOf("H") >= 0; // has H means 24Hour format
                };
                /**
                 * Funtion does the following tasks:
                 * 1. Get input data from context params.
                 * 2. Get DataHandler object - stores and handles data.
                 * 3. Get UIHandler object - needed to render UI based on data handler.
                 */
                WeeklyScheduleControl.prototype.processInputDataAndGenerateUIHandler = function () {
                    //1. Get input data from context params.
                    if (!this._context.utils.isNullOrUndefined(this._context.parameters.weeklyScheduleControlInput)
                        && !this._context.utils.isNullOrUndefined(this._context.parameters.weeklyScheduleControlInput.raw)) {
                        this._inputCustomerServiceScheduleData = this._context.parameters.weeklyScheduleControlInput.raw;
                    }
                    //2. Get DataHandler object.
                    if (!this._context.utils.isNullOrUndefined(this._inputCustomerServiceScheduleData)) {
                        var inputDataProcessor = new CustomerServiceSchedule.InputDataProcessor(this._context, this._inputCustomerServiceScheduleData);
                        this._dataHandler = new CustomerServiceSchedule.DataHandler(this._context, inputDataProcessor);
                        if (!this._context.utils.isNullOrUndefined(this._dataHandler)) {
                            //3. Get UIHandler object - needed to render UI.
                            this._uiHandler = new CustomerServiceSchedule.UIHandler(this._context, this._notifyOutputChanged, this._dataHandler, this._isDeleteSuccessful);
                            this._notifyOutputChanged();
                        }
                        else {
                            WeeklyScheduleControl.showErrorMessage(this._context);
                        }
                    }
                    else {
                        WeeklyScheduleControl.showErrorMessage(this._context);
                    }
                };
                /**
                 * Checks whether an object is an undefined, null or empty string.
                 * @param context The "Input Bag" containing the parameters and other control metadata.
                 * @param object The object to check.
                 * @returns A flag indicating whether the object is undefined, null or an empty string.
                 */
                WeeklyScheduleControl.isNullOrEmptyString = function (context, object) {
                    return context.utils.isNullOrUndefined(object) || object === "";
                };
                /**
                 * Returns refreshCounterAfterSetWorkHoursOperation
                 */
                WeeklyScheduleControl.getRefreshCounterAfterSetWorkHoursOperation = function () {
                    return this._refreshCounterAfterSetWorkHoursOperation;
                };
                /**
                 * Increments refreshCounterAfterSetWorkHoursOperation
                 */
                WeeklyScheduleControl.incrementRefreshCounterAfterSetWorkHoursOperation = function () {
                    this._refreshCounterAfterSetWorkHoursOperation++;
                };
                return WeeklyScheduleControl;
            }());
            WeeklyScheduleControl._refreshCounterAfterSetWorkHoursOperation = 0;
            CustomerServiceSchedule.WeeklyScheduleControl = WeeklyScheduleControl;
        })(CustomerServiceSchedule = AppCommon.CustomerServiceSchedule || (AppCommon.CustomerServiceSchedule = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CustomerServiceSchedule;
        (function (CustomerServiceSchedule) {
            'use strict';
            var WeeklyScheduleStyles = (function () {
                function WeeklyScheduleStyles() {
                }
                WeeklyScheduleStyles.initialize = function (theming, isRTL) {
                    WeeklyScheduleStyles.optionSetContainer = {
                        width: "100%",
                        marginBottom: theming.measures.measure050,
                    };
                    WeeklyScheduleStyles.oneLineControlContainerStyle = {
                        width: "100%",
                    };
                    WeeklyScheduleStyles.topMostContainer = {
                        display: "flex",
                        flexDirection: "column",
                        width: "100%"
                    };
                    WeeklyScheduleStyles.optionTabContainer = {
                        display: "flex",
                        flexDirection: "column",
                        width: "100%"
                    };
                    WeeklyScheduleStyles.fieldLabelStyle = {
                        fontFamily: theming.fontfamilies.regular,
                        fontSize: theming.fontsizes.font100,
                        lineHeight: "1.4rem",
                        color: theming.colors.basecolor.grey.grey7,
                        marginBottom: theming.measures.measure050,
                        display: "inline-block",
                        width: "50%"
                    };
                    WeeklyScheduleStyles.CheckboxControlContainer = {
                        display: "flex",
                        flexDirection: "column"
                    };
                    WeeklyScheduleStyles.setWorkHoursLabelStyle = {
                        display: "inline-block",
                        width: "50%",
                        color: "#315fa2",
                        textDecoration: "none"
                    };
                    WeeklyScheduleStyles.CheckboxControlContainer = {
                        display: "flex",
                        flexDirection: "column"
                    };
                    WeeklyScheduleStyles.checkBoxFocusStyle = {
                        ":focus": {
                            outlineOffset: "0px !important"
                        }
                    };
                    WeeklyScheduleStyles.deleteButtonContainer = {
                        display: "flex",
                        justifyContent: "flex-start",
                        width: "100%",
                        paddingBottom: theming.measures.measure050,
                        marginTop: theming.measures.measure050,
                        borderBottom: "0.1rem solid #CCCCCC"
                    };
                    WeeklyScheduleStyles.deleteButton = {
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        alignSelf: "center",
                        border: "none",
                        backgroundColor: "transparent",
                        cursor: "pointer",
                        margin: "0rem"
                    };
                    WeeklyScheduleStyles.deleteButtonlabel = {
                        alignSelf: "center",
                        fontSize: theming.fontsizes.font100,
                        fontFamily: theming.fontfamilies.regular,
                        fontColor: "#3B79B7",
                        justifyContent: "center",
                        cursor: "pointer"
                    };
                    WeeklyScheduleStyles.deleteButtonIconContainer = {
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        backgroundColor: "transparent",
                        flexDirection: "column",
                        margin: theming.measures.measure025
                    };
                };
                return WeeklyScheduleStyles;
            }());
            CustomerServiceSchedule.WeeklyScheduleStyles = WeeklyScheduleStyles;
        })(CustomerServiceSchedule = AppCommon.CustomerServiceSchedule || (AppCommon.CustomerServiceSchedule = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CustomerServiceSchedule;
        (function (CustomerServiceSchedule) {
            'use strict';
            var WeeklyScheduleConstants;
            (function (WeeklyScheduleConstants) {
                //keys and ids
                WeeklyScheduleConstants.TOPMOST_CONTAINERID = "WSC_TopMostContainer";
                WeeklyScheduleConstants.SETWORKHOURS_OPTIONSET_ID = "WSC_SetWorkHoursOptionSet";
                WeeklyScheduleConstants.SETWORKHOURS_OPTIONSET_CONTAINERID = "WSC_SetWorkHoursOptionSetContainer";
                WeeklyScheduleConstants.SAMEALLDAY_CHECKBOX_ID = "WSC_SameAllDayCheckbox";
                WeeklyScheduleConstants.SAMEALLDAY_LABEL_ID = "WSC_SameAllDayLabel";
                WeeklyScheduleConstants.SAMEALLDAY_ONELINECONTROL_CONTAINER_ID = "WSC_SameAllDayOneLineControlContainer";
                WeeklyScheduleConstants.OPTIONTAB_CONTAINER_ID = "WSC_OptionTabContainer";
                WeeklyScheduleConstants.SAMEALLDAY_ONELINECONTROL_ID = "WSC_SameEachDayOneLineControl";
                WeeklyScheduleConstants.DISABLED_SETWORKHOURSLINK_CONTROL_ID = "WSC_DisabledSetWorkHoursLink";
                WeeklyScheduleConstants.DELETEWEEKLYSCHEDULEBUTTON = "WSC_DeleteWeeklyScheduleButton";
                WeeklyScheduleConstants.DELETEWEEKLYSCHEDULEBUTTONCONTAINER = "WSC_DeleteWeeklyScheduleButtonContainer";
                WeeklyScheduleConstants.DELETEWEEKLYSCHEDULEBUTTONLABEL = "WSC_DeleteWeeklyScheduleButtonLabel";
                WeeklyScheduleConstants.DELETEWEEKLYSCHEDULEICONCONTAINER = "WSC_DeleteWeeklyScheduleIconContainer";
                WeeklyScheduleConstants.HOLIDAY_SCHEDULE_CONTROL_ID = "CalendarRule_HolidaySchedule";
                WeeklyScheduleConstants.OPTION_SET_CONTROL_OPTION_CLASS_NAME = "crm-jqm-optionSet2ButtonWidth";
                //other
                WeeklyScheduleConstants.DAYS_ID_PREFIX = "DayUniquePrefix";
                WeeklyScheduleConstants.LINKCONTROL_SUFFIX = "_WSC_LinkControl";
                WeeklyScheduleConstants.DAY_CHECKBOXCONTAINER_PREFIX = "DayCheckboxContainer_";
                WeeklyScheduleConstants.DAY_CHECKBOX_PREFIX = "DayCheckbox_";
                WeeklyScheduleConstants.DAY_LABEL_PREFIX = "DayLabel_";
                WeeklyScheduleConstants.DAY_ONELINECONTROL_PREFIX = "DayOneLineControl_";
                WeeklyScheduleConstants.CONST_SETWORKHOURS_OTYPE = "8";
                WeeklyScheduleConstants.MDD_SETWORKHOUR_UNIQUENAME = "CreateOrUpdateTimeSheetDetails";
                WeeklyScheduleConstants.MDD_SETWORKHOUR_Input = "setWorkHourControl_Input";
                WeeklyScheduleConstants.DELETECALANDARACTIVATEDIMAGEPATH = "../../WebResources/AppCommon/ControlWS/CalendarRule/DeleteCalendarActivated.svg";
                WeeklyScheduleConstants.CALENDARRULE_GROUPDESIGNATOR = "FC5769FC-4DE9-445d-8F4E-6E9869E60857";
                //key codes
                WeeklyScheduleConstants.LEFT_KEY = 37;
                WeeklyScheduleConstants.UP_KEY = 38;
                WeeklyScheduleConstants.RIGHT_KEY = 39;
                WeeklyScheduleConstants.DOWN_KEY = 40;
                WeeklyScheduleConstants.TAB_KEY = 9;
            })(WeeklyScheduleConstants = CustomerServiceSchedule.WeeklyScheduleConstants || (CustomerServiceSchedule.WeeklyScheduleConstants = {}));
        })(CustomerServiceSchedule = AppCommon.CustomerServiceSchedule || (AppCommon.CustomerServiceSchedule = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CustomerServiceSchedule;
        (function (CustomerServiceSchedule) {
            'use strict';
            var WeeklyScheduleLocale = (function () {
                function WeeklyScheduleLocale() {
                }
                /*
                 * Initializes the Weekly Schedule labels.
                */
                WeeklyScheduleLocale.initialize = function (getString) {
                    WeeklyScheduleLocale.WSS_24_7 = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_WSS_24_7);
                    WeeklyScheduleLocale.WSS_SetWorkHours = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_WSS_SetWorkHours);
                    WeeklyScheduleLocale.WSS_Sunday = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_WSS_Sunday);
                    WeeklyScheduleLocale.WSS_Monday = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_WSS_Monday);
                    WeeklyScheduleLocale.WSS_Tuesday = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_WSS_Tuesday);
                    WeeklyScheduleLocale.WSS_Wednesday = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_WSS_Wednesday);
                    WeeklyScheduleLocale.WSS_Thursday = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_WSS_Thursday);
                    WeeklyScheduleLocale.WSS_Friday = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_WSS_Friday);
                    WeeklyScheduleLocale.WSS_Saturday = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_WSS_Saturday);
                    WeeklyScheduleLocale.WSS_AreSameEachDay = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_WSS_AreSameEachDay);
                    WeeklyScheduleLocale.Error_GenericErrorOccurred = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_Error_GenericErrorOccurred);
                    WeeklyScheduleLocale.ConfirmButtonText = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_ConfirmButtonText);
                    WeeklyScheduleLocale.NotWorkingText = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_NotWorkingText);
                    WeeklyScheduleLocale.HoursText = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_HoursText);
                    WeeklyScheduleLocale.AtleastOneWorkingDayErrorMessage = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_AtleastOneWorkingDayErrorMessage);
                    WeeklyScheduleLocale.SpecifyWorkHoursErrorMessage = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_SpecifyWorkHoursErrorMessage);
                    WeeklyScheduleLocale.WSS_ConfirmDelete = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_WSS_ConfirmDelete);
                    WeeklyScheduleLocale.WSS_ConfirmDeleteText = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_WSS_ConfirmDeleteText);
                    WeeklyScheduleLocale.WSS_ConfirmDeleteButtonLabel = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_WSS_ConfirmDeleteButtonLabel);
                    WeeklyScheduleLocale.WSS_AlertDeleteText = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_WSS_AlertDeleteText);
                    WeeklyScheduleLocale.WSS_AlertDeleteButtonLabel = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_WSS_AlertDeleteButtonLabel);
                    WeeklyScheduleLocale.WSS_DeleteCalendarButtonLabel = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_WSS_DeleteCalendarButtonLabel);
                    WeeklyScheduleLocale.Global_Notification_After_DeleteCalendar = getString(CustomerServiceSchedule.WeeklyScheduleLabelId.ResourceKey_Global_Notification_After_DeleteCalendar);
                };
                return WeeklyScheduleLocale;
            }());
            CustomerServiceSchedule.WeeklyScheduleLocale = WeeklyScheduleLocale;
        })(CustomerServiceSchedule = AppCommon.CustomerServiceSchedule || (AppCommon.CustomerServiceSchedule = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CustomerServiceSchedule;
        (function (CustomerServiceSchedule) {
            'use strict';
            var WeeklyScheduleLabelId = (function () {
                function WeeklyScheduleLabelId() {
                }
                return WeeklyScheduleLabelId;
            }());
            WeeklyScheduleLabelId.ResourceKey_WSS_24_7 = "CC_WSS_24_7_Option";
            WeeklyScheduleLabelId.ResourceKey_WSS_SetWorkHours = "CC_WSS_SetWorkHours";
            WeeklyScheduleLabelId.ResourceKey_WSS_Sunday = "CC_WSS_Sunday";
            WeeklyScheduleLabelId.ResourceKey_WSS_Monday = "CC_WSS_Monday";
            WeeklyScheduleLabelId.ResourceKey_WSS_Tuesday = "CC_WSS_Tuesday";
            WeeklyScheduleLabelId.ResourceKey_WSS_Wednesday = "CC_WSS_Wednesday";
            WeeklyScheduleLabelId.ResourceKey_WSS_Thursday = "CC_WSS_Thursday";
            WeeklyScheduleLabelId.ResourceKey_WSS_Friday = "CC_WSS_Friday";
            WeeklyScheduleLabelId.ResourceKey_WSS_Saturday = "CC_WSS_Saturday";
            WeeklyScheduleLabelId.ResourceKey_WSS_AreSameEachDay = "CC_WSS_AreSameEachDay";
            WeeklyScheduleLabelId.ResourceKey_Error_GenericErrorOccurred = "CC_Error_GenericErrorOccurred";
            WeeklyScheduleLabelId.ResourceKey_ConfirmButtonText = "CC_ConfirmButtonText";
            WeeklyScheduleLabelId.ResourceKey_AtleastOneWorkingDayErrorMessage = "CC_Error_AtleastOneWorkingDay";
            WeeklyScheduleLabelId.ResourceKey_SpecifyWorkHoursErrorMessage = "CC_Error_SpecifyWorkHours";
            WeeklyScheduleLabelId.ResourceKey_NotWorkingText = "CC_NotWorkingText";
            WeeklyScheduleLabelId.ResourceKey_HoursText = "CC_HoursText";
            WeeklyScheduleLabelId.ResourceKey_WSS_ConfirmDelete = "CC_WSS_ConfirmDelete";
            WeeklyScheduleLabelId.ResourceKey_WSS_ConfirmDeleteText = "CC_WSS_ConfirmDeleteText";
            WeeklyScheduleLabelId.ResourceKey_WSS_ConfirmDeleteButtonLabel = "CC_WSS_ConfirmDeleteButtonLabel";
            WeeklyScheduleLabelId.ResourceKey_WSS_AlertDeleteText = "CC_WSS_AlertDeleteText";
            WeeklyScheduleLabelId.ResourceKey_WSS_AlertDeleteButtonLabel = "CC_WSS_AlertDeleteButtonLabel";
            WeeklyScheduleLabelId.ResourceKey_WSS_DeleteCalendarButtonLabel = "CC_WSS_DeleteCalendarButtonLabel";
            WeeklyScheduleLabelId.ResourceKey_Global_Notification_After_DeleteCalendar = "CC_Global_Notification_After_DeleteCalendar";
            WeeklyScheduleLabelId.ResourceKey_Global_Notification_After_SetWorkHours = "CC_Global_Notification_After_SetWorkHours";
            CustomerServiceSchedule.WeeklyScheduleLabelId = WeeklyScheduleLabelId;
        })(CustomerServiceSchedule = AppCommon.CustomerServiceSchedule || (AppCommon.CustomerServiceSchedule = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="WeeklyScheduleControl.ts" />
/// <reference path="WeeklyScheduleStyles.ts" />
/// <reference path="WeeklyScheduleConstants.ts" />
/// <reference path="WeeklyScheduleLocale.ts" />
/// <reference path="WeeklyScheduleLabelId.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CustomerServiceSchedule;
        (function (CustomerServiceSchedule) {
            'use strict';
            var InputDataProcessorHelper = (function () {
                function InputDataProcessorHelper() {
                }
                /**
                 * Checks whether an object is null or undefined.
                 * @param object The object to check.
                 * @returns A flag indicating whether the object is null or undefined.
                 */
                InputDataProcessorHelper.isNullOrUndefined = function (object) {
                    return object === null || object === undefined;
                };
                /**
                 * Checks whether break is associated with given innerCalendar.
                 * @param innerCalendarData data corresponding to innerCalendar
                 * @returns A flag indicating whether break is associated with given innerCalendar or not.
                 */
                InputDataProcessorHelper.isBreaksAvailable = function (innerCalendarData) {
                    var isBreaks = false;
                    var relatedCalendarRules = innerCalendarData.calendar_calendar_rules;
                    if (!InputDataProcessorHelper.isNullOrUndefined(relatedCalendarRules) && relatedCalendarRules.length > 0) {
                        for (var _i = 0, relatedCalendarRules_1 = relatedCalendarRules; _i < relatedCalendarRules_1.length; _i++) {
                            var calendarRule = relatedCalendarRules_1[_i];
                            if (!InputDataProcessorHelper.isNullOrUndefined(calendarRule)) {
                                if (calendarRule.subcode == AppCommon.SubCode.Break && calendarRule.duration > 0) {
                                    isBreaks = true;
                                    break;
                                }
                            }
                        }
                    }
                    return isBreaks;
                };
                /**
                 * Finds the rule in the calendar rules collection given innerCalendarId.
                 * @param innerCalendarId the guid for the inner calendar.
                 */
                InputDataProcessorHelper.findCalendarRuleByInnerCalendarId = function (innerCalendarId, calendarRules) {
                    if (InputDataProcessorHelper.isNullOrUndefined(innerCalendarId)) {
                        return null;
                    }
                    for (var _i = 0, calendarRules_1 = calendarRules; _i < calendarRules_1.length; _i++) {
                        var tmpRule = calendarRules_1[_i];
                        if (tmpRule._innercalendarid_value == innerCalendarId) {
                            return tmpRule;
                        }
                    }
                    return null;
                };
                /**
                 * Retrieve the recurring calendar rule that holds workplan.
                 * @param innerCalendarId Id of inner calendar for which we need to retrieve RecurrenceRule
                 */
                InputDataProcessorHelper.retrieveRecurrenceRule = function (innerCalendarId, calendarRules) {
                    if (InputDataProcessorHelper.isNullOrUndefined(innerCalendarId)) {
                        return null;
                    }
                    var ownerRule = InputDataProcessorHelper.findCalendarRuleByInnerCalendarId(innerCalendarId, calendarRules);
                    if (InputDataProcessorHelper.isNullOrUndefined(ownerRule)) {
                        return null;
                    }
                    if (!InputDataProcessorHelper.isNullOrUndefined(ownerRule.isvaried) && !ownerRule.isvaried) {
                        return ownerRule;
                    }
                    var firstRuleInRecurrence = null;
                    var rule = null;
                    for (var _i = 0, calendarRules_2 = calendarRules; _i < calendarRules_2.length; _i++) {
                        var tmpRule = calendarRules_2[_i];
                        rule = tmpRule;
                        if (rule.starttime == ownerRule.starttime) {
                            if (InputDataProcessorHelper.isNullOrUndefined(firstRuleInRecurrence))
                                firstRuleInRecurrence = rule;
                            if (InputDataProcessorHelper.isRecurrenceDefined(rule)) {
                                break;
                            }
                        }
                        // Rules are sorted by start time so we can break now
                        if (rule.starttime > ownerRule.starttime) {
                            break;
                        }
                    }
                    if (rule != firstRuleInRecurrence) {
                        throw new Error("Didn't find recurrence rule -- shouldn't get here");
                    }
                    if (!InputDataProcessorHelper.isNullOrUndefined(rule)) {
                        return rule;
                    }
                    return firstRuleInRecurrence;
                };
                /**
                 * Is a single recurrence defined for this rule or a full recurrence.
                 * @param rule calendarRule under investigation.
                 * @returns true - recurring, false - not.
                 */
                InputDataProcessorHelper.isRecurrenceDefined = function (rule) {
                    if (!InputDataProcessorHelper.isWorkRule(rule)) {
                        // Find out if InputDataProcessorHelper rule has associated recurrence or is it just
                        // a single occurrence.
                        var freq = InputDataProcessorHelper.recurrenceRuleFieldToString(rule.pattern, "FREQ");
                        var count = InputDataProcessorHelper.recurrenceRuleFieldToString(rule.pattern, "COUNT");
                        var nativeRecurrence = InputDataProcessorHelper.isGroupDesignatorForCalendarRule(rule);
                        return ((freq == "WEEKLY") && (count.length == 0) && nativeRecurrence);
                    }
                    return false;
                };
                /**
                 * Checks if rule is work related rule.
                 * @param rule calendarRule under investigation.
                 * @returns true - if rule is work related rule, false - not.
                 */
                InputDataProcessorHelper.isWorkRule = function (rule) {
                    if (!InputDataProcessorHelper.isNullOrUndefined(rule)
                        && !InputDataProcessorHelper.isNullOrUndefined(rule.issimple) && rule.issimple) {
                        return true;
                    }
                    return false;
                };
                /**
                 * Extract and convert fields (FREQ=.../UNTIL=...;) from an ical rrule.
                 * This method will know to expect semi colon in inner fields and no semi colon in last field.
                 * @param rule rule to extract and convert substring from.
                 * @param field to be extracted.
                 * @returns Sub string extracted.
                 */
                InputDataProcessorHelper.recurrenceRuleFieldToString = function (rule, field) {
                    if (InputDataProcessorHelper.isNullOrUndefined(rule) || InputDataProcessorHelper.isNullOrUndefined(field)) {
                        return "";
                    }
                    var indexOfField = rule.indexOf(field);
                    if (indexOfField == -1) {
                        // No such field in RRule ...
                        return "";
                    }
                    else {
                        if (rule[indexOfField + field.length] != '=') {
                            // No equal after rule, format incorrect.
                            return "";
                        }
                        var indexOfFieldContent = indexOfField + field.length + 1; // Add one to accomodate for the "=".
                        rule = rule.substring(indexOfFieldContent);
                        var indexOfFieldContentEnd = rule.indexOf(";");
                        if (indexOfFieldContentEnd == -1) {
                            // if last field then there's no semi colon...
                            indexOfFieldContentEnd = rule.length;
                        }
                        return rule.substring(0, indexOfFieldContentEnd);
                    }
                };
                /**
                 * Checks if group designator field of rule corresponds to CalendarRule Group designator.
                 * @param rule rule under investigation.
                 * @returns true - if rule has group designator field for CalendarRule, false - not.
                 */
                InputDataProcessorHelper.isGroupDesignatorForCalendarRule = function (rule) {
                    if (!InputDataProcessorHelper.isNullOrUndefined(rule) &&
                        !InputDataProcessorHelper.isNullOrUndefined(rule.groupdesignator)) {
                        if (rule.groupdesignator.toLowerCase() == CustomerServiceSchedule.WeeklyScheduleConstants.CALENDARRULE_GROUPDESIGNATOR.toLowerCase()) {
                            return true;
                        }
                    }
                    return false;
                };
                /**
                 * Retrieve the working hours calendar rule from the calendar rules.
                 * @param calendarRules calendarRules from which working hour rule need to be retrieved.
                 * @returns Working hours rule.
                 */
                InputDataProcessorHelper.retrieveWorkingHoursRule = function (calendarRules) {
                    if (InputDataProcessorHelper.isNullOrUndefined(calendarRules)) {
                        return null;
                    }
                    // Look for the calendar rule containing working hours
                    for (var _i = 0, calendarRules_3 = calendarRules; _i < calendarRules_3.length; _i++) {
                        var rule = calendarRules_3[_i];
                        if (InputDataProcessorHelper.compareCalendarRuleTimeType("WorkingHoursTimeType", rule) ||
                            InputDataProcessorHelper.compareCalendarRuleTimeType("NotWorkingTimeType", rule)) {
                            return rule;
                        }
                    }
                    return null;
                };
                /**
                 * Get WeeklyScheduleControlOptionsData from input params.
                 * @param innerCalendarId  the guid for the inner calendar.
                 * @param startTime start time.
                 * @param endTime end time.
                 */
                InputDataProcessorHelper.getWeeklyScheduleControlOptionsData = function (innerCalendarId, startTime, endTime) {
                    var optionsData = {
                        innerCalendarId: innerCalendarId,
                        startTime: startTime,
                        endTime: endTime
                    };
                    return optionsData;
                };
                /**
                 * Is the recurring rule a varied by day rule.
                 * @param recurringRule Rule in question.
                 * @returns true - if rule is varied rule, false - not.
                 */
                InputDataProcessorHelper.isRecurringRuleVaried = function (recurringRule) {
                    if (InputDataProcessorHelper.isNullOrUndefined(recurringRule)) {
                        return false;
                    }
                    if (!InputDataProcessorHelper.isNullOrUndefined(recurringRule.isvaried)) {
                        return recurringRule.isvaried;
                    }
                    return false;
                };
                /**
                 * Based on rule pattern determine if all days are present in rule pattern.
                 * @param pattern recurrence pattern of the rule.
                 * @returns true - if all days are present in pattern, false - not.
                 */
                InputDataProcessorHelper.isAllDaysInRule = function (pattern) {
                    var returnValue = true;
                    for (var dayIndex = 0; dayIndex < InputDataProcessorHelper._allDays.length; dayIndex++) {
                        returnValue = returnValue && InputDataProcessorHelper.isDayInRule(pattern, dayIndex);
                    }
                    return returnValue;
                };
                /**
                 * Based on rule pattern determine which day of the week is on and which day is off.
                 * @param pattern recurrence pattern of the rule.
                 * @param dayIndex 0 based day check mark index.
                 * @returns true - if given day is present in pattern, false - not.
                 */
                InputDataProcessorHelper.isDayInRule = function (pattern, dayIndex) {
                    var day = InputDataProcessorHelper._allDays[dayIndex];
                    if (!InputDataProcessorHelper.isNullOrUndefined(day)) {
                        var patternIndex = pattern.indexOf("BYDAY");
                        if (pattern.substring(patternIndex).indexOf(day) > 0) {
                            return true;
                        }
                    }
                    return false;
                };
                /**
                 * Compare a time type to rule time codes.
                 * @param timeType Time type.
                 * @param calendarRule Rule containing codes.
                 * @returns true - conditions matched, false - not.
                 */
                InputDataProcessorHelper.compareCalendarRuleTimeType = function (timeType, calendarRule) {
                    if (calendarRule.timecode == InputDataProcessorHelper.timeTypeToTimeCode(timeType)
                        && calendarRule.subcode == InputDataProcessorHelper.timeTypeToSubCode(timeType)) {
                        return true;
                    }
                    return false;
                };
                /**
                 * Converts timetype string to TimeCode enum.
                 * @param timeType string indicating timetype.
                 * @returns value ot TimeCode enum.
                 */
                InputDataProcessorHelper.timeTypeToTimeCode = function (timeType) {
                    var retVal = AppCommon.TimeCode.Unavailable;
                    switch (timeType) {
                        case "WorkingHoursTimeType":
                            retVal = AppCommon.TimeCode.Available;
                            break;
                        case "NotWorkingTimeType":
                        case "BreakTimeType":
                        case "VacationTimeType":
                        case "HolidayTimeType":
                            retVal = AppCommon.TimeCode.Unavailable;
                            break;
                        case "ResourceServiceRestrictionTimeType":
                        case "ResourceCapacityTimeType":
                            retVal = AppCommon.TimeCode.Filter;
                            break;
                    }
                    return retVal;
                };
                /**
                 * Converts timetype string to SubCode enum.
                 * @param timeType string indicating timetype.
                 * @returns value ot SubCode enum.
                 */
                InputDataProcessorHelper.timeTypeToSubCode = function (timeType) {
                    var retVal = AppCommon.SubCode.Unspecified;
                    switch (timeType) {
                        case "WorkingHoursTimeType":
                            retVal = AppCommon.SubCode.Schedulable;
                            break;
                        case "NotWorkingTimeType":
                            retVal = AppCommon.SubCode.Unspecified;
                            break;
                        case "BreakTimeType":
                            retVal = AppCommon.SubCode.Break;
                            break;
                        case "VacationTimeType":
                            retVal = AppCommon.SubCode.Vacation;
                            break;
                        case "HolidayTimeType":
                            retVal = AppCommon.SubCode.Holiday;
                            break;
                        case "ResourceServiceRestrictionTimeType":
                            retVal = AppCommon.SubCode.ResourceServiceRestriction;
                            break;
                        case "ResourceCapacityTimeType":
                            retVal = AppCommon.SubCode.ResourceCapacity;
                            break;
                    }
                    return retVal;
                };
                return InputDataProcessorHelper;
            }());
            InputDataProcessorHelper._allDays = ["SU", "MO", "TU", "WE", "TH", "FR", "SA"];
            CustomerServiceSchedule.InputDataProcessorHelper = InputDataProcessorHelper;
        })(CustomerServiceSchedule = AppCommon.CustomerServiceSchedule || (AppCommon.CustomerServiceSchedule = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CustomerServiceSchedule;
        (function (CustomerServiceSchedule) {
            'use strict';
            var DataHandler = (function () {
                function DataHandler(context, inputDataProcessor) {
                    this._context = context;
                    this._calendarId = inputDataProcessor.getCalendarId();
                    this._writeCalendarPrv = inputDataProcessor.getWriteCalendarPrv();
                    this._deleteCalendarPrv = inputDataProcessor.getDeleteCalendarPrv();
                    this._recurringRuleInnerCalendarId = inputDataProcessor.getRecurringRuleInnerCalendarId();
                    this._workRuleMode = inputDataProcessor.detectWorkRuleMode();
                    this._days = inputDataProcessor.getDaysSelectionFromInputData();
                    this._timeZoneCode = inputDataProcessor.getTimeZoneCodeFromInputData();
                    this._sameAllDayData = inputDataProcessor.getSameAllDayOptionsData();
                    this._varyEachDayData = inputDataProcessor.getVaryEachDayOptionsData();
                }
                /**
                 * checks if obejct is null or undefined
                 * @param object object which needs to be checked
                 */
                DataHandler.prototype.isNullOrUndefined = function (object) {
                    return this._context.utils.isNullOrUndefined(object);
                };
                /**
                 * Get calendarid corresponding to current data.
                 * @returns calendar id guid value.
                 */
                DataHandler.prototype.getCalendarId = function () {
                    return this._calendarId;
                };
                /**
                 * Get WriteCalendarPrivilege of user.
                 * @returns true - if user has Write permission on calendar entity, false - if not.
                 */
                DataHandler.prototype.getWriteCalendarPrv = function () {
                    return this._writeCalendarPrv;
                };
                /**
                 * Get DeleteCalendarPrivilege of user.
                 * @returns true - if user has Delete permission on calendar entity, false - if not.
                 */
                DataHandler.prototype.getDeleteCalendarPrv = function () {
                    return this._deleteCalendarPrv;
                };
                /**
                 * Get timeZoneCode corresponding to current data.
                 * @returns number indicating timezonecode.
                 */
                DataHandler.prototype.getTimeZoneCode = function () {
                    return this._timeZoneCode;
                };
                /**
                 * Get workRuleMode corresponding to current data.
                 * @returns WorkRuleMode enum value.
                 */
                DataHandler.prototype.getWorkRuleMode = function () {
                    return this._workRuleMode;
                };
                /**
                 * Set workRuleMode
                 * @param newWorkRuleMode new workrulemode value to be set
                 */
                DataHandler.prototype.setWorkRuleMode = function (newWorkRuleMode) {
                    this._workRuleMode = newWorkRuleMode;
                };
                /**
                 * Checks if day is selected in current data.
                 * @param day day under investigation.
                 * @returns true - if day is selected in current data, false - if not.
                 */
                DataHandler.prototype.isDaySelected = function (day) {
                    return this._days[day];
                };
                /**
                 * Set day selection value in current data.
                 * @param day day selected.
                 * @param newValue new value to be set.
                 */
                DataHandler.prototype.setDaySelectedValue = function (day, newValue) {
                    this._days[day] = newValue;
                };
                /**
                 * Get InnerCalendarId of RecurringRule.
                 * @returns innerCalendarId corresponding to recurring rule.
                 */
                DataHandler.prototype.getRecurringRuleInnerCalendarId = function () {
                    return this._recurringRuleInnerCalendarId;
                };
                /**
                 * Get InnerCalendarId of RecurringRule.
                 * @param innerCalendarId corresponding to recurring rule.
                 */
                DataHandler.prototype.setRecurringRuleInnerCalendarId = function (innerCalendarId) {
                    this._recurringRuleInnerCalendarId = innerCalendarId;
                };
                /**
                 * Get OptionsData corresponding to SameAllDay option.
                 * @returns An object of WeeklyScheduleControlOptionsData interface, which contains data related to SameAllDay option.
                 */
                DataHandler.prototype.getSameAllDayData = function () {
                    return this._sameAllDayData;
                };
                /**
                 * Private function to retrieve OptionsData corresponding to perticular day.
                 * @param day index of day
                 * @returns An object of WeeklyScheduleControlOptionsData interface, which contains data related to VaryEachDay option.
                 */
                DataHandler.prototype.getVaryEachDayData = function (day) {
                    return this._varyEachDayData[day];
                };
                return DataHandler;
            }());
            CustomerServiceSchedule.DataHandler = DataHandler;
        })(CustomerServiceSchedule = AppCommon.CustomerServiceSchedule || (AppCommon.CustomerServiceSchedule = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CustomerServiceSchedule;
        (function (CustomerServiceSchedule) {
            'use strict';
            var OuputDataGenerator = (function () {
                function OuputDataGenerator() {
                }
                OuputDataGenerator.getOuputDataFromDataHandler = function (dataHandler, context) {
                    var weeklyScheduleControlOutput = new CustomerServiceSchedule.WeeklyScheduleControlOutput();
                    try {
                        weeklyScheduleControlOutput.status = CustomerServiceSchedule.OutputStatus.Success;
                        //Use data handler object and generate outputdata
                        var outputData = new CustomerServiceSchedule.OutputData();
                        outputData.refreshCounterAfterSetWorkHoursOperation = CustomerServiceSchedule.WeeklyScheduleControl.getRefreshCounterAfterSetWorkHoursOperation();
                        outputData.innerCalendarId = dataHandler.getRecurringRuleInnerCalendarId();
                        outputData.workRuleMode = dataHandler.getWorkRuleMode();
                        if (outputData.workRuleMode == CustomerServiceSchedule.WorkRuleMode.TwentyX7Support) {
                            //populate output data for 24x7 support
                            outputData.weekDaysCheckmarks = OuputDataGenerator.getDaysSelectionArray(CustomerServiceSchedule.WorkRuleMode.TwentyX7Support, dataHandler);
                        }
                        else if (outputData.workRuleMode == CustomerServiceSchedule.WorkRuleMode.AllTheSameRules) {
                            //populate output data for SameAllDay
                            if (context.utils.isNullOrUndefined(outputData.innerCalendarId)) {
                                weeklyScheduleControlOutput.errorMessage = CustomerServiceSchedule.WeeklyScheduleLocale.SpecifyWorkHoursErrorMessage;
                                weeklyScheduleControlOutput.status = CustomerServiceSchedule.OutputStatus.Error;
                            }
                            else {
                                outputData.weekDaysCheckmarks = OuputDataGenerator.getDaysSelectionArray(CustomerServiceSchedule.WorkRuleMode.AllTheSameRules, dataHandler);
                            }
                        }
                        else if (outputData.workRuleMode == CustomerServiceSchedule.WorkRuleMode.VaryByDayRules) {
                            //populate output data for VaryEachDay
                            if (context.utils.isNullOrUndefined(outputData.innerCalendarId)) {
                                weeklyScheduleControlOutput.errorMessage = CustomerServiceSchedule.WeeklyScheduleLocale.SpecifyWorkHoursErrorMessage;
                                weeklyScheduleControlOutput.status = CustomerServiceSchedule.OutputStatus.Error;
                            }
                            else {
                                outputData.weekDaysCheckmarks = OuputDataGenerator.getDaysSelectionArray(CustomerServiceSchedule.WorkRuleMode.VaryByDayRules, dataHandler);
                            }
                        }
                        //populate outputdata
                        weeklyScheduleControlOutput.data = outputData;
                    }
                    catch (e) {
                        weeklyScheduleControlOutput.status = CustomerServiceSchedule.OutputStatus.Error;
                        weeklyScheduleControlOutput.errorMessage = CustomerServiceSchedule.WeeklyScheduleLocale.Error_GenericErrorOccurred;
                    }
                    return weeklyScheduleControlOutput;
                };
                OuputDataGenerator.getDaysSelectionArray = function (workRuleMode, dataHandler) {
                    var daysSelectionArray = [true, true, true, true, true, true, true]; //initalize with all 7 days selected
                    if (workRuleMode != CustomerServiceSchedule.WorkRuleMode.TwentyX7Support) {
                        for (var i = 0; i < daysSelectionArray.length; i++) {
                            daysSelectionArray[i] = dataHandler.isDaySelected(i);
                        }
                    }
                    return daysSelectionArray;
                };
                return OuputDataGenerator;
            }());
            CustomerServiceSchedule.OuputDataGenerator = OuputDataGenerator;
        })(CustomerServiceSchedule = AppCommon.CustomerServiceSchedule || (AppCommon.CustomerServiceSchedule = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CustomerServiceSchedule;
        (function (CustomerServiceSchedule) {
            'use strict';
            var UIHandler = (function () {
                function UIHandler(context, notifyOutputChanged, dataHandler, _isDeleteSuccessful) {
                    this._mapDaysToIndex = [CustomerServiceSchedule.WeeklyScheduleLocale.WSS_Sunday, CustomerServiceSchedule.WeeklyScheduleLocale.WSS_Monday, CustomerServiceSchedule.WeeklyScheduleLocale.WSS_Tuesday, CustomerServiceSchedule.WeeklyScheduleLocale.WSS_Wednesday, CustomerServiceSchedule.WeeklyScheduleLocale.WSS_Thursday, CustomerServiceSchedule.WeeklyScheduleLocale.WSS_Friday, CustomerServiceSchedule.WeeklyScheduleLocale.WSS_Saturday];
                    this._context = context;
                    this._dataHandler = dataHandler;
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                    this._isDeleteSuccessful = _isDeleteSuccessful;
                    this._lastFocusedElemId = "";
                    var workRuleMode = this._dataHandler.getWorkRuleMode();
                    if (workRuleMode == CustomerServiceSchedule.WorkRuleMode.AllTheSameRules || workRuleMode == CustomerServiceSchedule.WorkRuleMode.TwentyX7Support) {
                        this._isSameAllDayCheckboxSelected = true;
                    }
                    if (workRuleMode == CustomerServiceSchedule.WorkRuleMode.VaryByDayRules) {
                        this._isOriginalWorkRuleModeVaried = true;
                    }
                    else {
                        this._isOriginalWorkRuleModeVaried = false;
                    }
                }
                /**
                 * checks if obejct is null or undefined
                 * @param object object which needs to be checked
                 */
                UIHandler.prototype.isNullOrUndefined = function (object) {
                    return this._context.utils.isNullOrUndefined(object);
                };
                /**
                 * Get status of delete operation.
                 */
                UIHandler.prototype.getCurrentDeleteSuccessfulStatus = function () {
                    return this._isDeleteSuccessful;
                };
                /**
                 * Get DataHandler object related to UIHandler.
                 */
                UIHandler.prototype.getDataHandlerObject = function () {
                    return this._dataHandler;
                };
                /**
                 * Get UI Components related to WeeklyScheduleControl.
                 */
                UIHandler.prototype.getUIComponents = function () {
                    return this.getWorkHourMainControl();
                };
                /**
                 * Checks if all days are unselected.
                 */
                UIHandler.prototype.isAllDaysUnselected = function () {
                    for (var i = 0; i < 7; i++) {
                        if (this._dataHandler.isDaySelected(i))
                            return false;
                    }
                    //If control reaches here that means none of the days are selected.
                    return true;
                };
                /**
                 * Get TopMost container of WeeklyScheduleControl.
                 */
                UIHandler.prototype.getWorkHourMainControl = function () {
                    var topMostContainer;
                    try {
                        // Don't display delete button if user is not having delete or write privilege
                        if (!this._dataHandler.getDeleteCalendarPrv() || !this._dataHandler.getWriteCalendarPrv()) {
                            topMostContainer = this._context.factory.createElement("CONTAINER", {
                                id: CustomerServiceSchedule.WeeklyScheduleConstants.TOPMOST_CONTAINERID,
                                key: CustomerServiceSchedule.WeeklyScheduleConstants.TOPMOST_CONTAINERID,
                                style: CustomerServiceSchedule.WeeklyScheduleStyles.topMostContainer,
                            }, [this.createWorkHoursOptionSet(), this.getWorkHourMainControlContentPaneBasedOnChoice()]);
                        }
                        else {
                            topMostContainer = this._context.factory.createElement("CONTAINER", {
                                id: CustomerServiceSchedule.WeeklyScheduleConstants.TOPMOST_CONTAINERID,
                                key: CustomerServiceSchedule.WeeklyScheduleConstants.TOPMOST_CONTAINERID,
                                style: CustomerServiceSchedule.WeeklyScheduleStyles.topMostContainer,
                            }, [this.createDeleteButton(), this.createWorkHoursOptionSet(), this.getWorkHourMainControlContentPaneBasedOnChoice()]);
                        }
                    }
                    catch (e) {
                        console.error(e);
                        CustomerServiceSchedule.WeeklyScheduleControl.showErrorMessage(this._context);
                    }
                    return topMostContainer;
                };
                /**
                * Rendering the Delete Button
                */
                UIHandler.prototype.createDeleteButton = function () {
                    var deleteButtonLabel = this._context.factory.createElement("LABEL", {
                        key: CustomerServiceSchedule.WeeklyScheduleConstants.DELETEWEEKLYSCHEDULEBUTTONLABEL,
                        id: CustomerServiceSchedule.WeeklyScheduleConstants.DELETEWEEKLYSCHEDULEBUTTONLABEL,
                        style: CustomerServiceSchedule.WeeklyScheduleStyles.deleteButtonlabel
                    }, CustomerServiceSchedule.WeeklyScheduleLocale.WSS_DeleteCalendarButtonLabel);
                    var deleteIconContainer = this._context.factory.createElement("IMG", {
                        key: CustomerServiceSchedule.WeeklyScheduleConstants.DELETEWEEKLYSCHEDULEICONCONTAINER,
                        id: CustomerServiceSchedule.WeeklyScheduleConstants.DELETEWEEKLYSCHEDULEICONCONTAINER,
                        source: CustomerServiceSchedule.WeeklyScheduleConstants.DELETECALANDARACTIVATEDIMAGEPATH,
                        style: CustomerServiceSchedule.WeeklyScheduleStyles.deleteButtonIconContainer
                    }, []);
                    var deleteWeeklyScheduleButton = this._context.factory.createElement("BUTTON", {
                        key: CustomerServiceSchedule.WeeklyScheduleConstants.DELETEWEEKLYSCHEDULEBUTTON,
                        id: CustomerServiceSchedule.WeeklyScheduleConstants.DELETEWEEKLYSCHEDULEBUTTON,
                        style: CustomerServiceSchedule.WeeklyScheduleStyles.deleteButton,
                        disabled: this._context.utils.isNullOrUndefined(this._dataHandler.getRecurringRuleInnerCalendarId())
                            ? true : false,
                        onClick: this.onDeleteWeeklyScheduleButtonClicked.bind(this),
                        tabIndex: 0
                    }, [deleteIconContainer, deleteButtonLabel]);
                    return this._context.factory.createElement("CONTAINER", {
                        id: CustomerServiceSchedule.WeeklyScheduleConstants.DELETEWEEKLYSCHEDULEBUTTONCONTAINER,
                        key: CustomerServiceSchedule.WeeklyScheduleConstants.DELETEWEEKLYSCHEDULEBUTTONCONTAINER,
                        style: CustomerServiceSchedule.WeeklyScheduleStyles.deleteButtonContainer
                    }, deleteWeeklyScheduleButton);
                };
                /**
                 * CallBack function for Delete Button
                 */
                UIHandler.prototype.onDeleteWeeklyScheduleButtonClicked = function () {
                    if (!this._context.utils.isNullOrUndefined(this._dataHandler.getRecurringRuleInnerCalendarId())) {
                        var that_1 = this;
                        var deleteWeeklyScheduleRequest_1 = new ODataContract.DeleteWeeklyScheduleRequest();
                        var str = this._dataHandler.getCalendarId();
                        var calendarId = {
                            guid: str
                        };
                        deleteWeeklyScheduleRequest_1.CalendarId = calendarId;
                        //Open a confirm dialog
                        var dialogOptions = {
                            height: 205,
                            width: 450
                        };
                        var confirmDialogStrings = {
                            title: CustomerServiceSchedule.WeeklyScheduleLocale.WSS_ConfirmDelete,
                            text: CustomerServiceSchedule.WeeklyScheduleLocale.WSS_ConfirmDeleteText,
                            confirmButtonLabel: CustomerServiceSchedule.WeeklyScheduleLocale.WSS_ConfirmDeleteButtonLabel
                        };
                        this._context.navigation.openConfirmDialog(confirmDialogStrings, dialogOptions)
                            .then(function (result) {
                            if (result.confirmed) {
                                that_1._context.webAPI.execute(deleteWeeklyScheduleRequest_1).then(function (success) {
                                    that_1._isDeleteSuccessful = true;
                                    var successNoticationMessage = CustomerServiceSchedule.WeeklyScheduleLocale.Global_Notification_After_DeleteCalendar;
                                    that_1._context.utils.addGlobalNotification(1 /* toast */, 1 /* success */, successNoticationMessage, "", null).then(function (response) {
                                        //Notification displayed successfully
                                    }, function (error) {
                                        console.error("Error displaying notification : " + error);
                                    });
                                    that_1._context.accessibility.focusElementById(CustomerServiceSchedule.WeeklyScheduleConstants.SETWORKHOURS_OPTIONSET_CONTAINERID);
                                    that_1._notifyOutputChanged();
                                }, function (failure) {
                                    CustomerServiceSchedule.WeeklyScheduleControl.showErrorMessage(that_1._context);
                                    that_1._isDeleteSuccessful = false;
                                });
                            }
                        });
                    }
                    else {
                        //Open Alert Dialog
                        var alertMessage = {
                            text: CustomerServiceSchedule.WeeklyScheduleLocale.WSS_AlertDeleteText,
                            confirmButtonLabel: CustomerServiceSchedule.WeeklyScheduleLocale.WSS_AlertDeleteButtonLabel
                        };
                        this._context.navigation.openAlertDialog(alertMessage);
                    }
                };
                /**
                 * Get UI WorkHours choice from WorkRuleMode data.
                 */
                UIHandler.prototype.getSelectedChoiceForWorkHoursFromWorkRuleMode = function () {
                    var selectedWorkHoursChoice;
                    var workRuleMode = this._dataHandler.getWorkRuleMode();
                    if (workRuleMode == CustomerServiceSchedule.WorkRuleMode.TwentyX7Support) {
                        selectedWorkHoursChoice = CustomerServiceSchedule.SELECTED_WORKHOURS_CHOICE.TWENTYFOUR_SEVEN_SUPPORT;
                    }
                    else if (workRuleMode == CustomerServiceSchedule.WorkRuleMode.AllTheSameRules
                        || workRuleMode == CustomerServiceSchedule.WorkRuleMode.VaryByDayRules) {
                        selectedWorkHoursChoice = CustomerServiceSchedule.SELECTED_WORKHOURS_CHOICE.SET_WORK_HOURS;
                    }
                    return selectedWorkHoursChoice;
                };
                /**
                 * Get WorkRuleMode data from WorkHours choice.
                 * @param newValue selected WorkHours choice.
                 */
                UIHandler.prototype.getWorkRuleModeFromSelectedChoiceForWorkHours = function (newValue) {
                    var workRuleMode;
                    if (newValue == CustomerServiceSchedule.SELECTED_WORKHOURS_CHOICE.TWENTYFOUR_SEVEN_SUPPORT) {
                        workRuleMode = CustomerServiceSchedule.WorkRuleMode.TwentyX7Support;
                    }
                    else if (newValue == CustomerServiceSchedule.SELECTED_WORKHOURS_CHOICE.SET_WORK_HOURS) {
                        if (this._isSameAllDayCheckboxSelected) {
                            workRuleMode = CustomerServiceSchedule.WorkRuleMode.AllTheSameRules;
                        }
                        else {
                            workRuleMode = CustomerServiceSchedule.WorkRuleMode.VaryByDayRules;
                        }
                    }
                    return workRuleMode;
                };
                /**
                 * Create option set for WorkHours choice.
                 */
                UIHandler.prototype.createWorkHoursOptionSet = function () {
                    var properties = {
                        "parameters": {
                            value: {
                                Usage: 3,
                                Static: false,
                                Type: "OptionSet",
                                Value: this.getSelectedChoiceForWorkHoursFromWorkRuleMode(),
                                Attributes: {
                                    DefaultValue: 0,
                                    Options: [{ Value: 0, Label: CustomerServiceSchedule.WeeklyScheduleLocale.WSS_SetWorkHours }, { Value: 1, Label: CustomerServiceSchedule.WeeklyScheduleLocale.WSS_24_7 }]
                                },
                                Callback: this.callBackOnWorkHourModeChange.bind(this)
                            },
                        }
                    };
                    var createWorkHoursOptionSetContainer = this._context.factory.createElement("CONTAINER", {
                        id: CustomerServiceSchedule.WeeklyScheduleConstants.SETWORKHOURS_OPTIONSET_CONTAINERID,
                        key: CustomerServiceSchedule.WeeklyScheduleConstants.SETWORKHOURS_OPTIONSET_CONTAINERID,
                        style: CustomerServiceSchedule.WeeklyScheduleStyles.optionSetContainer,
                    }, [this._context.factory.createComponent("MscrmControls.OptionSet.OptionSetControl", CustomerServiceSchedule.WeeklyScheduleConstants.SETWORKHOURS_OPTIONSET_ID, properties)]);
                    return createWorkHoursOptionSetContainer;
                };
                /**
                 * Callback function for WorkHour optionset value change.
                 * @param newValue value of selected option.
                 */
                UIHandler.prototype.callBackOnWorkHourModeChange = function (newValue) {
                    try {
                        if (!this._context.utils.isNullOrUndefined(newValue)) {
                            var newWorkRuleMode = this.getWorkRuleModeFromSelectedChoiceForWorkHours(newValue);
                            this._dataHandler.setWorkRuleMode(newWorkRuleMode);
                        }
                    }
                    catch (e) {
                        console.error(e);
                        CustomerServiceSchedule.WeeklyScheduleControl.showErrorMessage(this._context);
                    }
                    finally {
                        this.notifyOutputChangeAndRequestRerender();
                    }
                };
                /**
                 * Create SameAllDay UI which includes checkbox+label+link.
                 */
                UIHandler.prototype.createSameEachDayOneLineControl = function () {
                    var dayIndex = CustomerServiceSchedule.Day.NONE;
                    var uniqueId = CustomerServiceSchedule.WeeklyScheduleConstants.DAYS_ID_PREFIX + dayIndex;
                    var that = this;
                    var sameEachDayCheckboxProperties = {
                        type: "checkbox",
                        id: CustomerServiceSchedule.WeeklyScheduleConstants.DAY_CHECKBOX_PREFIX + uniqueId,
                        key: CustomerServiceSchedule.WeeklyScheduleConstants.DAY_CHECKBOX_PREFIX + uniqueId,
                        tagname: "INPUT",
                        value: this._isSameAllDayCheckboxSelected,
                        tabIndex: 0,
                        onValueChange: this.onChangeForSameAllDayCheckbox.bind(this),
                        style: CustomerServiceSchedule.WeeklyScheduleStyles.checkBoxFocusStyle
                    };
                    var sameEachDayCheckboxControl = this._context.factory.createElement("BOOLEAN", sameEachDayCheckboxProperties);
                    //Adding a container for checkbox to attach onKeyDown event
                    var checkBoxContainer = this._context.factory.createElement("CONTAINER", {
                        id: CustomerServiceSchedule.WeeklyScheduleConstants.DAY_CHECKBOXCONTAINER_PREFIX + uniqueId,
                        key: CustomerServiceSchedule.WeeklyScheduleConstants.DAY_CHECKBOXCONTAINER_PREFIX + uniqueId,
                        onKeyDown: function (event) {
                            that.onCheckBoxKeyDown(event, dayIndex);
                        }
                    }, sameEachDayCheckboxControl);
                    var sameAllDayLabel = this._context.factory.createElement("LABEL", {
                        id: CustomerServiceSchedule.WeeklyScheduleConstants.SAMEALLDAY_LABEL_ID,
                        key: CustomerServiceSchedule.WeeklyScheduleConstants.SAMEALLDAY_LABEL_ID,
                        style: CustomerServiceSchedule.WeeklyScheduleStyles.fieldLabelStyle,
                        forElementId: this._context.accessibility.getUniqueId(CustomerServiceSchedule.WeeklyScheduleConstants.DAY_CHECKBOX_PREFIX + uniqueId),
                    }, CustomerServiceSchedule.WeeklyScheduleLocale.WSS_AreSameEachDay);
                    var sameAllDayLinkControl;
                    if (this._isSameAllDayCheckboxSelected) {
                        sameAllDayLinkControl = this.getSetWorkHoursHyperLinkControl(CustomerServiceSchedule.WeeklyScheduleConstants.DAY_CHECKBOX_PREFIX + uniqueId, CustomerServiceSchedule.Day.NONE);
                    }
                    return this._context.factory.createElement("CONTAINER", {
                        id: CustomerServiceSchedule.WeeklyScheduleConstants.SAMEALLDAY_ONELINECONTROL_CONTAINER_ID,
                        key: CustomerServiceSchedule.WeeklyScheduleConstants.SAMEALLDAY_ONELINECONTROL_CONTAINER_ID,
                        style: CustomerServiceSchedule.WeeklyScheduleStyles.oneLineControlContainerStyle
                    }, [checkBoxContainer, sameAllDayLabel, sameAllDayLinkControl]);
                };
                /**
                 * Callback function for SameAllDay checkbox value change.
                 * @param newValue value indicating checkbox is selected or not.
                 */
                UIHandler.prototype.onChangeForSameAllDayCheckbox = function (newValue) {
                    this._isSameAllDayCheckboxSelected = newValue;
                    if (this._isSameAllDayCheckboxSelected) {
                        this._dataHandler.setWorkRuleMode(CustomerServiceSchedule.WorkRuleMode.AllTheSameRules);
                    }
                    else {
                        this._dataHandler.setWorkRuleMode(CustomerServiceSchedule.WorkRuleMode.VaryByDayRules);
                    }
                    this.notifyOutputChangeAndRequestRerender();
                };
                /**
                 * Get WorkHour related information container.
                 */
                UIHandler.prototype.getWorkHourMainControlContentPaneBasedOnChoice = function () {
                    var sameAllDayOneLineControl;
                    var rowItems = [];
                    if (this.getSelectedChoiceForWorkHoursFromWorkRuleMode() == CustomerServiceSchedule.SELECTED_WORKHOURS_CHOICE.SET_WORK_HOURS) {
                        //SameAllDay and VaryEachDay scenario
                        sameAllDayOneLineControl = this.createSameEachDayOneLineControl();
                        //get days onelinecontrols
                        for (var dayIndex = 0; dayIndex < this._mapDaysToIndex.length; dayIndex++) {
                            var uniqueId = CustomerServiceSchedule.WeeklyScheduleConstants.DAYS_ID_PREFIX + dayIndex;
                            rowItems[dayIndex] = this.getWorkHourRowItemBasedOnChoice(uniqueId);
                        }
                        rowItems.unshift(sameAllDayOneLineControl);
                    }
                    else {
                    }
                    var that = this;
                    var optionTabContainer = this._context.factory.createElement("CONTAINER", {
                        id: CustomerServiceSchedule.WeeklyScheduleConstants.OPTIONTAB_CONTAINER_ID,
                        key: CustomerServiceSchedule.WeeklyScheduleConstants.OPTIONTAB_CONTAINER_ID,
                        style: CustomerServiceSchedule.WeeklyScheduleStyles.optionTabContainer,
                        onFocus: function () {
                            that.onFocusRowsContainer();
                        },
                    }, rowItems);
                    return optionTabContainer;
                };
                /**
                 * Returns a boolean value indicating whether the time has to be displayed in 24 hour format or not
                 */
                UIHandler.prototype.is24HourFormat = function () {
                    //context.client.dateFormattingInfo.ShortTimePattern will contain 'H' if time has to be shown in 24 hour format
                    //ShortTimePattern would contain HH:mm or H:mm to display time in 24 hours format
                    return this._context.client.dateFormattingInfo.ShortTimePattern.indexOf("H") >= 0;
                };
                /**
                 * Returns a boolean value indicating whether the time has to be displayed in 2 digit format or not
                 */
                UIHandler.prototype.isTwoDigitFormat = function () {
                    //context.client.dateFormattingInfo.ShortTimePattern will contain 'hh:mm tt' or 'h:mm tt' if time has to be shown in two digits
                    return (this._context.client.dateFormattingInfo.ShortTimePattern.match(new RegExp("h", "gi")) || []).length === 2;
                };
                /**
                 * Generates Display text  of time which will be displayed in UI
                 * @param minutes : The minutes offset value.
                 */
                UIHandler.prototype.getDisplayTime = function (minutes) {
                    var text = "";
                    var date = new Date();
                    date.setHours(0);
                    date.setMinutes(0);
                    date.setMinutes(minutes);
                    date.localeFormat(this._context.client.dateFormattingInfo.ShortTimePattern);
                    var is24HourFormat = this.is24HourFormat();
                    var isTwoDigitFormat = this.isTwoDigitFormat();
                    if (is24HourFormat) {
                        text = isTwoDigitFormat ? date.localeFormat("HH:mm") : date.localeFormat("H:mm");
                    }
                    else {
                        text = isTwoDigitFormat ? date.localeFormat("hh:mm") : date.localeFormat("h:mm");
                        text = parseInt(date.localeFormat("HH")) < 12 ? text + " " + this._context.userSettings.dateFormattingInfo.AMDesignator : text + " " + this._context.userSettings.dateFormattingInfo.PMDesignator;
                    }
                    return text;
                };
                /**
                 * Returns total work hours by substracting end time from start time.
                 */
                UIHandler.prototype.getTotalWorkHours = function (optionsData) {
                    var startTime = optionsData.startTime / 60;
                    var endTime = optionsData.endTime / 60;
                    return (endTime - startTime) % 1 == 0 ? (endTime - startTime).toFixed(0) : (endTime - startTime).toFixed(2);
                };
                /**
                 * Reutrns label to be displayed on link for particular day.
                 * @param day day for which label to be displayed.
                 */
                UIHandler.prototype.getWorkHoursDisplayTextLabelForDay = function (day) {
                    var linkLabel = "";
                    var optionsData;
                    if (day == CustomerServiceSchedule.Day.NONE) {
                        optionsData = this._dataHandler.getSameAllDayData();
                    }
                    else {
                        optionsData = this._dataHandler.getVaryEachDayData(day);
                    }
                    if (!this.isNullOrUndefined(optionsData.startTime) && !this.isNullOrUndefined(optionsData.endTime)) {
                        //that means start and end time is already set - generate link label.
                        linkLabel = this.getDisplayTime(optionsData.startTime) + " - " + this.getDisplayTime(optionsData.endTime) + " (" + this.getTotalWorkHours(optionsData) + " " + CustomerServiceSchedule.WeeklyScheduleLocale.HoursText + ")";
                    }
                    else {
                        //"New" scenario
                        linkLabel = CustomerServiceSchedule.WeeklyScheduleLocale.WSS_SetWorkHours; //default text
                    }
                    return linkLabel;
                };
                /**
                 * Get innerCalendarId related to particular day.
                 * @param day day for which innerCalendarId is needed.
                 */
                UIHandler.prototype.getInnerCalendarIdForDay = function (day) {
                    if (day == CustomerServiceSchedule.Day.NONE) {
                        return this._dataHandler.getRecurringRuleInnerCalendarId();
                    }
                    else {
                        return this._dataHandler.getVaryEachDayData(day).innerCalendarId;
                    }
                };
                /**
                 * Get SetWorkHoursInfo interface object to pass on to SetWorkHours MDD.
                 * @param day day for which SetWorkHoursInfo object needs to be populated.
                 */
                UIHandler.prototype.getWorkHoursData = function (day) {
                    var innerCalendarIdForDay = this._dataHandler.getRecurringRuleInnerCalendarId();
                    if (day != CustomerServiceSchedule.Day.NONE) {
                        //This means some day link is clicked for VaryEachDay option.
                        if (!this._isOriginalWorkRuleModeVaried) {
                            //If original mode is not VaryEachDay then it's the first time we are clicking on any VaryEachDay link
                            //We have to pass "-1" to SetWorkHours MDD.
                            day = CustomerServiceSchedule.Day.NONE;
                        }
                        else {
                            //This means original mode is VaryEachDay. So, we just want to change workHours for one particular day.
                            innerCalendarIdForDay = this.getInnerCalendarIdForDay(day);
                        }
                    }
                    var setWorkHoursLinkInfo;
                    setWorkHoursLinkInfo = {
                        calendarId: this._dataHandler.getCalendarId(),
                        innerCalendarId: this.isNullOrUndefined(innerCalendarIdForDay) ? "" : innerCalendarIdForDay,
                        resourceId: this._context.userSettings.userId,
                        timeZoneCode: this._dataHandler.getTimeZoneCode(),
                        day: day,
                        oType: CustomerServiceSchedule.WeeklyScheduleConstants.CONST_SETWORKHOURS_OTYPE,
                        leafCalRules: null,
                        writeCalendarPrv: this._dataHandler.getWriteCalendarPrv()
                    };
                    return setWorkHoursLinkInfo;
                };
                /**
                 * Get SetWorkHoursInfo interface data for selected link.
                 * @param id id of the link clicked.
                 */
                UIHandler.prototype.getSetWorkHoursDataForSelectedLink = function (dayIndex) {
                    //populate SetWorkHoursInfo based on which link is clicked.
                    var setWorkHoursLinkInfo = this.getWorkHoursData(dayIndex);
                    return setWorkHoursLinkInfo;
                };
                /**
                 * Get HyperLinkControl.
                 * @param parentId id of related parent control.
                 * @param linkLabel label to be displayed on link.
                 */
                UIHandler.prototype.getSetWorkHoursHyperLinkControl = function (parentId, dayIndex) {
                    var that = this;
                    var linkLabel = "";
                    if (dayIndex == CustomerServiceSchedule.Day.NONE) {
                        linkLabel = this.getWorkHoursDisplayTextLabelForDay(dayIndex);
                    }
                    else {
                        linkLabel = this.getLinkLabelForDay(dayIndex);
                    }
                    var setWorkHoursLink = this._context.factory.createElement("HYPERLINK", {
                        id: parentId + CustomerServiceSchedule.WeeklyScheduleConstants.LINKCONTROL_SUFFIX,
                        key: parentId + CustomerServiceSchedule.WeeklyScheduleConstants.LINKCONTROL_SUFFIX,
                        onClick: function (event) {
                            that.onClickSetWorkHoursHyperLink(dayIndex, event);
                        },
                        onKeyDown: function (event) {
                            that.onHyperLinkKeyDown(event, dayIndex);
                        },
                        forElementId: this._context.accessibility.getUniqueId(parentId),
                        style: CustomerServiceSchedule.WeeklyScheduleStyles.setWorkHoursLabelStyle
                    }, linkLabel);
                    return setWorkHoursLink;
                };
                /**
                 * Callback for click event on hyperlink.
                 * @param parentId id of related parent control.
                 */
                UIHandler.prototype.onClickSetWorkHoursHyperLink = function (dayIndex, event) {
                    event.preventDefault();
                    //get data for link which is clicked
                    var setWorkHoursLinkInfo = this.getSetWorkHoursDataForSelectedLink(dayIndex);
                    if (this._context.utils.isNullOrUndefined(setWorkHoursLinkInfo)) {
                        console.error("SetWorkHours link data is null.");
                        CustomerServiceSchedule.WeeklyScheduleControl.showErrorMessage(this._context);
                        return;
                    }
                    //Open SetWorkHours dialog
                    var dialogParameters = {};
                    dialogParameters[CustomerServiceSchedule.WeeklyScheduleConstants.MDD_SETWORKHOUR_Input] = JSON.stringify(setWorkHoursLinkInfo);
                    var dialogOptions = {};
                    dialogOptions.position = 2 /* side */;
                    dialogOptions.width = "50%";
                    var that = this;
                    this._context.navigation.openDialog(CustomerServiceSchedule.WeeklyScheduleConstants.MDD_SETWORKHOUR_UNIQUENAME, dialogOptions, dialogParameters).then(function (response) {
                        if (that._context.utils.isNullOrUndefined(response.parameters)
                            || that._context.utils.isNullOrUndefined(response.parameters.setWorkHourControl_Output)) {
                            //In case of SetWorkHours MDD is cancelled.
                            return;
                        }
                        var setWorkHourControlOutput = response.parameters.setWorkHourControl_Output;
                        that.handleSetWorkHoursDialogOutputResponse(setWorkHourControlOutput);
                    }, function (error) {
                        console.error(error);
                        CustomerServiceSchedule.WeeklyScheduleControl.showErrorMessage(that._context);
                    });
                };
                /**
                 * Private function to handle response from SetWorkHours MDD.
                 * @param setWorkHourControlOutput output object received from SetWorkHours MDD.
                 */
                UIHandler.prototype.handleSetWorkHoursDialogOutputResponse = function (setWorkHourControlOutput) {
                    if (this._context.utils.isNullOrUndefined(setWorkHourControlOutput)) {
                        console.error("SetWorkHours dialog response is null.");
                        CustomerServiceSchedule.WeeklyScheduleControl.showErrorMessage(this._context);
                        return;
                    }
                    var recurringRuleInnerCalendarId = this._dataHandler.getRecurringRuleInnerCalendarId();
                    if (this.isNullOrUndefined(recurringRuleInnerCalendarId)) {
                        //We are only setting recurringRuleInnerCalendarId in case there was no innerCalendar - i.e. New scenario.
                        //For Edit scenario we are not doing any bookkeeping. This will be taken care when MDD will fetch data again from server and re-render WeeklyScheduleControl.
                        this._dataHandler.setRecurringRuleInnerCalendarId(setWorkHourControlOutput.innerCalendarId);
                    }
                    //Save is successful, increment idForSave -- This is to notify CSSRule MDD to call SaveWeeklySchedule SDK
                    CustomerServiceSchedule.WeeklyScheduleControl.incrementRefreshCounterAfterSetWorkHoursOperation();
                    this.notifyOutputChangeAndRequestRerender();
                };
                /**
                 * Private function to retrieve dayIndex from id.
                 * @param strId id under investigation.
                 */
                UIHandler.prototype.getDayIndexFromDayId = function (strId) {
                    //format expected : id = "xyzday<index>"
                    var dayIndex = -1;
                    var matchedIndex = strId.indexOf(CustomerServiceSchedule.WeeklyScheduleConstants.DAYS_ID_PREFIX);
                    if (matchedIndex >= 0) {
                        dayIndex = Number(strId.substr(matchedIndex + CustomerServiceSchedule.WeeklyScheduleConstants.DAYS_ID_PREFIX.length));
                    }
                    return dayIndex;
                };
                /**
                 * Get link label for given day.
                 * @param dayIndex day for which label to be found.
                 */
                UIHandler.prototype.getLinkLabelForDay = function (dayIndex) {
                    var linkLabel;
                    if (!this._dataHandler.isDaySelected(dayIndex)) {
                        linkLabel = CustomerServiceSchedule.WeeklyScheduleLocale.NotWorkingText;
                    }
                    else {
                        linkLabel = this.getWorkHoursDisplayTextLabelForDay(dayIndex);
                    }
                    return linkLabel;
                };
                UIHandler.prototype.getWorkHourRowItemBasedOnChoice = function (uniqueId) {
                    var dayIndex = this.getDayIndexFromDayId(uniqueId);
                    var LineItemControls = [];
                    var that = this;
                    var checkboxProp = {
                        type: "checkbox",
                        id: CustomerServiceSchedule.WeeklyScheduleConstants.DAY_CHECKBOX_PREFIX + uniqueId,
                        key: CustomerServiceSchedule.WeeklyScheduleConstants.DAY_CHECKBOX_PREFIX + uniqueId,
                        tagname: "INPUT",
                        value: this._dataHandler.isDaySelected(dayIndex),
                        tabIndex: 0,
                        onValueChange: this.onChangeDayCheckbox.bind(this, dayIndex),
                        style: CustomerServiceSchedule.WeeklyScheduleStyles.checkBoxFocusStyle
                    };
                    var dayCheckBox = this._context.factory.createElement("BOOLEAN", checkboxProp);
                    //Adding a container for checkbox to attach keydown event
                    var dayCheckBoxContainer = this._context.factory.createElement("CONTAINER", {
                        id: CustomerServiceSchedule.WeeklyScheduleConstants.DAY_CHECKBOXCONTAINER_PREFIX + uniqueId,
                        key: CustomerServiceSchedule.WeeklyScheduleConstants.DAY_CHECKBOXCONTAINER_PREFIX + uniqueId,
                        onKeyDown: function (event) {
                            that.onCheckBoxKeyDown(event, dayIndex);
                        }
                    }, dayCheckBox);
                    LineItemControls[0] = dayCheckBoxContainer;
                    var dayCheckboxLabel = this._context.factory.createElement("LABEL", {
                        id: CustomerServiceSchedule.WeeklyScheduleConstants.DAY_LABEL_PREFIX + uniqueId,
                        key: CustomerServiceSchedule.WeeklyScheduleConstants.DAY_LABEL_PREFIX + uniqueId,
                        style: CustomerServiceSchedule.WeeklyScheduleStyles.fieldLabelStyle,
                        forElementId: this._context.accessibility.getUniqueId(CustomerServiceSchedule.WeeklyScheduleConstants.DAY_CHECKBOX_PREFIX + uniqueId),
                    }, this._mapDaysToIndex[dayIndex]);
                    LineItemControls[1] = dayCheckboxLabel;
                    if (!this._isSameAllDayCheckboxSelected) {
                        if (this._dataHandler.isDaySelected(dayIndex)) {
                            LineItemControls[2] = this.getSetWorkHoursHyperLinkControl(CustomerServiceSchedule.WeeklyScheduleConstants.DAY_CHECKBOX_PREFIX + uniqueId, dayIndex);
                        }
                        else {
                            LineItemControls[2] = this.getNotWorkingLabelControl();
                        }
                    }
                    return this._context.factory.createElement("CONTAINER", {
                        id: CustomerServiceSchedule.WeeklyScheduleConstants.DAY_ONELINECONTROL_PREFIX + uniqueId,
                        key: CustomerServiceSchedule.WeeklyScheduleConstants.DAY_ONELINECONTROL_PREFIX + uniqueId,
                        style: CustomerServiceSchedule.WeeklyScheduleStyles.oneLineControlContainerStyle
                    }, LineItemControls);
                };
                /**
                 * Callback for on change of any day checkbox value change.
                 * @param index index of day
                 * @param newValue value indicating whether checkbox is selected or not.
                 */
                UIHandler.prototype.onChangeDayCheckbox = function (index, newValue) {
                    this._dataHandler.setDaySelectedValue(index, newValue);
                    if (this.isAllDaysUnselected()) {
                        this._dataHandler.setDaySelectedValue(index, true);
                        CustomerServiceSchedule.WeeklyScheduleControl.showErrorMessage(this._context, CustomerServiceSchedule.WeeklyScheduleLocale.AtleastOneWorkingDayErrorMessage, CustomerServiceSchedule.WeeklyScheduleLocale.ConfirmButtonText);
                        this.notifyOutputChangeAndRequestRerender();
                        return;
                    }
                    this.notifyOutputChangeAndRequestRerender();
                };
                /**
                 * Private function to generate label with NotWorking text.
                 */
                UIHandler.prototype.getNotWorkingLabelControl = function () {
                    return this._context.factory.createElement("LABEL", {
                        id: CustomerServiceSchedule.WeeklyScheduleConstants.DISABLED_SETWORKHOURSLINK_CONTROL_ID,
                        key: CustomerServiceSchedule.WeeklyScheduleConstants.DISABLED_SETWORKHOURSLINK_CONTROL_ID,
                        style: CustomerServiceSchedule.WeeklyScheduleStyles.fieldLabelStyle
                    }, CustomerServiceSchedule.WeeklyScheduleLocale.NotWorkingText);
                };
                /**
                 * Notify that output bag has changed and re-render UI.
                 */
                UIHandler.prototype.notifyOutputChangeAndRequestRerender = function () {
                    this._notifyOutputChanged();
                    this._context.utils.requestRender();
                };
                UIHandler.prototype.getTargetCheckBoxId = function (dayIndex) {
                    var checkBoxId = CustomerServiceSchedule.WeeklyScheduleConstants.DAY_CHECKBOX_PREFIX + CustomerServiceSchedule.WeeklyScheduleConstants.DAYS_ID_PREFIX + dayIndex;
                    var generatedCheckBoxId = this._context.accessibility.getUniqueId(checkBoxId);
                    return generatedCheckBoxId;
                };
                UIHandler.prototype.getTargetHyperLinkId = function (dayIndex) {
                    var linkId = CustomerServiceSchedule.WeeklyScheduleConstants.DAY_CHECKBOX_PREFIX + CustomerServiceSchedule.WeeklyScheduleConstants.DAYS_ID_PREFIX + dayIndex + CustomerServiceSchedule.WeeklyScheduleConstants.LINKCONTROL_SUFFIX;
                    var generatedLinkId = this._context.accessibility.getUniqueId(linkId);
                    return generatedLinkId;
                };
                /**
                 * Handles onKeyDown events on checkboxes in the control
                 * @param event
                 * @param originID
                 * @param index
                 */
                UIHandler.prototype.onCheckBoxKeyDown = function (event, dayIndex) {
                    var targetElemId = "";
                    var targetIndex = dayIndex;
                    var keyCode = event.keyCode;
                    switch (keyCode) {
                        case CustomerServiceSchedule.WeeklyScheduleConstants.RIGHT_KEY:
                            targetIndex = dayIndex;
                            targetElemId = this.getTargetHyperLinkId(targetIndex);
                            break;
                        case CustomerServiceSchedule.WeeklyScheduleConstants.UP_KEY:
                            if (dayIndex != -1) {
                                targetIndex = dayIndex - 1;
                            }
                            targetElemId = this.getTargetCheckBoxId(targetIndex);
                            break;
                        case CustomerServiceSchedule.WeeklyScheduleConstants.DOWN_KEY:
                            if (dayIndex != 6) {
                                targetIndex = dayIndex + 1;
                            }
                            targetElemId = this.getTargetCheckBoxId(targetIndex);
                            break;
                        case CustomerServiceSchedule.WeeklyScheduleConstants.TAB_KEY:
                            if (event.shiftKey) {
                                this._lastFocusedElemId = this.getTargetCheckBoxId(dayIndex);
                                this.setFocusOnOptionSetContainer();
                            }
                            else {
                                this._lastFocusedElemId = this.getTargetCheckBoxId(dayIndex);
                                targetElemId = "id-" + this._context.page.entityTypeName + "-7-" + CustomerServiceSchedule.WeeklyScheduleConstants.HOLIDAY_SCHEDULE_CONTROL_ID + "-" + CustomerServiceSchedule.WeeklyScheduleConstants.HOLIDAY_SCHEDULE_CONTROL_ID + ".fieldControl-option-set-select";
                            }
                            break;
                    }
                    if (this.isArrowOrTabKeyPressed(keyCode)) {
                        event.stopPropagation();
                        event.preventDefault();
                    }
                    if (targetElemId != "") {
                        if (document.getElementById(targetElemId) != null) {
                            this._context.accessibility.focusElementById(targetElemId, true);
                        }
                    }
                };
                /**
                 * Set the Focus on first option element in Option set container
                 */
                UIHandler.prototype.setFocusOnOptionSetContainer = function () {
                    var optionSetId = this._context.accessibility.getUniqueId(CustomerServiceSchedule.WeeklyScheduleConstants.SETWORKHOURS_OPTIONSET_CONTAINERID);
                    var optionSetContainer = document.getElementById(optionSetId);
                    if (optionSetContainer) {
                        var optionSetElements = optionSetContainer.getElementsByClassName(CustomerServiceSchedule.WeeklyScheduleConstants.OPTION_SET_CONTROL_OPTION_CLASS_NAME);
                        if (optionSetElements.length > 0) {
                            optionSetElements[0].focus();
                        }
                    }
                };
                /**
                 * Handles onKeyDown event on hyperlink controls
                 * @param event
                 * @param originID
                 * @param index
                 */
                UIHandler.prototype.onHyperLinkKeyDown = function (event, dayIndex) {
                    var targetElemId = "";
                    var targetIndex = dayIndex;
                    var keyCode = event.keyCode;
                    switch (keyCode) {
                        case CustomerServiceSchedule.WeeklyScheduleConstants.LEFT_KEY:
                            targetIndex = dayIndex;
                            targetElemId = this.getTargetCheckBoxId(targetIndex);
                            break;
                        case CustomerServiceSchedule.WeeklyScheduleConstants.UP_KEY:
                            if (dayIndex != 0) {
                                targetIndex = dayIndex - 1;
                            }
                            targetElemId = this.getTargetHyperLinkId(targetIndex);
                            break;
                        case CustomerServiceSchedule.WeeklyScheduleConstants.DOWN_KEY:
                            if (dayIndex != 6) {
                                targetIndex = dayIndex + 1;
                            }
                            targetElemId = this.getTargetHyperLinkId(targetIndex);
                            break;
                        case CustomerServiceSchedule.WeeklyScheduleConstants.TAB_KEY:
                            if (event.shiftKey) {
                                this._lastFocusedElemId = this.getTargetHyperLinkId(dayIndex);
                                this.setFocusOnOptionSetContainer();
                            }
                            else {
                                this._lastFocusedElemId = this.getTargetHyperLinkId(dayIndex);
                                targetElemId = "id-" + this._context.page.entityTypeName + "-7-" + CustomerServiceSchedule.WeeklyScheduleConstants.HOLIDAY_SCHEDULE_CONTROL_ID + "-" + CustomerServiceSchedule.WeeklyScheduleConstants.HOLIDAY_SCHEDULE_CONTROL_ID + ".fieldControl-option-set-select";
                            }
                            break;
                    }
                    if (this.isArrowOrTabKeyPressed(keyCode)) {
                        event.stopPropagation();
                        event.preventDefault();
                    }
                    if (targetElemId != "") {
                        if (document.getElementById(targetElemId) != null) {
                            this._context.accessibility.focusElementById(targetElemId, true);
                        }
                    }
                };
                /**
                 * this function returns true for keyCode = arrow/tab else returns false
                 * @param keyCode
                 */
                UIHandler.prototype.isArrowOrTabKeyPressed = function (keyCode) {
                    if (this.isArrowKeyPressed(keyCode) || keyCode == CustomerServiceSchedule.WeeklyScheduleConstants.TAB_KEY) {
                        return true;
                    }
                    return false;
                };
                /**
                 * This function return true if keyCode is one of the left,up,right or down keys else returns false
                 * @param keyCode
                 */
                UIHandler.prototype.isArrowKeyPressed = function (keyCode) {
                    if (keyCode >= CustomerServiceSchedule.WeeklyScheduleConstants.LEFT_KEY && keyCode <= CustomerServiceSchedule.WeeklyScheduleConstants.DOWN_KEY) {
                        return true;
                    }
                    return false;
                };
                /**
                 * This function handles focus entry from top and bottom in the rows for different days
                 */
                UIHandler.prototype.onFocusRowsContainer = function () {
                    if (document.getElementById(this._lastFocusedElemId) != null) {
                        this._context.accessibility.focusElementById(this._lastFocusedElemId, true);
                        this._lastFocusedElemId = "";
                    }
                };
                return UIHandler;
            }());
            CustomerServiceSchedule.UIHandler = UIHandler;
        })(CustomerServiceSchedule = AppCommon.CustomerServiceSchedule || (AppCommon.CustomerServiceSchedule = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CustomerServiceSchedule;
        (function (CustomerServiceSchedule) {
            'use strict';
            var InputDataProcessor = (function () {
                function InputDataProcessor(context, inputData) {
                    this._allDays = ["SU", "MO", "TU", "WE", "TH", "FR", "SA"];
                    try {
                        this._context = context;
                        this._calendarId = inputData.calendarId;
                        if (!this.isNullOrUndefined(inputData.mainCalendarAndRelatedCalendarRulesResponse)) {
                            this._mainCalendarAndRelatedCalendarRulesResponse = inputData.mainCalendarAndRelatedCalendarRulesResponse;
                            this._calendarRules = inputData.mainCalendarAndRelatedCalendarRulesResponse.calendar_calendar_rules;
                            this._innerCalendarAndRelatedCalendarRulesResponses = inputData.innerCalendarAndRelatedCalendarRulesResponses;
                            this._writeCalendarPrv = inputData.calendarPrivilege.writePrv;
                            this._deleteCalendarPrv = inputData.calendarPrivilege.deletePrv;
                        }
                        this._timeZoneCode = this.getTimeZoneCodeFromInputData();
                        this._inputScenario = this.detectScenarioFromInputData();
                        if (this._inputScenario == CustomerServiceSchedule.InputScenario.EditScenario) {
                            //"Edit" scenario - we already have calendarRules associated with calendar
                            var innerCalendarId = this._mainCalendarAndRelatedCalendarRulesResponse.calendar_calendar_rules[0]._innercalendarid_value;
                            this._recurringRule = CustomerServiceSchedule.InputDataProcessorHelper.retrieveRecurrenceRule(innerCalendarId, this._calendarRules);
                            this._recurringRuleInnerCalendarId = this.isNullOrUndefined(this._recurringRule) ? null : this._recurringRule._innercalendarid_value;
                            this._workingHourRule = this.getWorkingHourRuleFromInputData();
                        }
                        //once all values are initalized find out workrulemode
                        this._workRuleMode = this.detectWorkRuleMode();
                    }
                    catch (e) {
                        console.error("Error parsing inputdata in WeeklyScheduleControl : " + e);
                        CustomerServiceSchedule.WeeklyScheduleControl.showErrorMessage(this._context);
                    }
                }
                /**
                 * Checks whether an object is null or undefined.
                 * @param object The object to check.
                 * @returns A flag indicating whether the object is null or undefined.
                 */
                InputDataProcessor.prototype.isNullOrUndefined = function (object) {
                    return this._context.utils.isNullOrUndefined(object);
                };
                /**
                 * Get calendarid corresponding to current data.
                 * @returns calendar id guid value.
                 */
                InputDataProcessor.prototype.getCalendarId = function () {
                    return this._calendarId;
                };
                /**
                 * Get WriteCalendarPrivilege of user.
                 * @returns true - if user has Write permission on calendar entity, false - if not.
                 */
                InputDataProcessor.prototype.getWriteCalendarPrv = function () {
                    return this._writeCalendarPrv;
                };
                /**
                 * Get DeleteCalendarPrivilege of user.
                 * @returns true - if user has Delete permission on calendar entity, false - if not.
                 */
                InputDataProcessor.prototype.getDeleteCalendarPrv = function () {
                    return this._deleteCalendarPrv;
                };
                /**
                 * Get innerCalendarId corresponding to recurring rule.
                 * @returns innerCalendarId corresponding to recurring rule.
                 */
                InputDataProcessor.prototype.getRecurringRuleInnerCalendarId = function () {
                    return this._recurringRuleInnerCalendarId;
                };
                /**
                 * Get timeZoneCode from InputData.
                 * @returns number indicating timezonecode related to inputdata.
                 */
                InputDataProcessor.prototype.getTimeZoneCodeFromInputData = function () {
                    var timeZoneCode = -1; //please verify and check in new scenario
                    if (!this.isNullOrUndefined(this._calendarRules) && this._calendarRules.length > 0) {
                        timeZoneCode = this._calendarRules[0].timezonecode;
                    }
                    return timeZoneCode;
                };
                /**
                 * Detects whether inputdata is for "New" or "Edit" scenario.
                 * @returns value of InputScenario enum.
                 */
                InputDataProcessor.prototype.detectScenarioFromInputData = function () {
                    var inputScenario;
                    if (this.isNullOrUndefined(this._calendarRules) || this._calendarRules.length == 0) {
                        inputScenario = CustomerServiceSchedule.InputScenario.NewScenario;
                    }
                    else {
                        inputScenario = CustomerServiceSchedule.InputScenario.EditScenario;
                    }
                    return inputScenario;
                };
                /**
                 * Detects workRuleMode of inputdata.
                 * @returns value of WorkRuleMode enum.
                 */
                InputDataProcessor.prototype.detectWorkRuleMode = function () {
                    var workRuleMode;
                    if (this._inputScenario == CustomerServiceSchedule.InputScenario.NewScenario) {
                        workRuleMode = CustomerServiceSchedule.WorkRuleMode.AllTheSameRules;
                    }
                    else {
                        //Edit scenario
                        if (this.isAllTheSameRules()) {
                            workRuleMode = CustomerServiceSchedule.WorkRuleMode.AllTheSameRules;
                        }
                        else if (this.isVaryByDayRules()) {
                            workRuleMode = CustomerServiceSchedule.WorkRuleMode.VaryByDayRules;
                        }
                        else if (this.is247OrNotWorkingRules()) {
                            workRuleMode = CustomerServiceSchedule.WorkRuleMode.TwentyX7Support;
                        }
                        else {
                            workRuleMode = CustomerServiceSchedule.WorkRuleMode.NotWorking;
                        }
                    }
                    return workRuleMode;
                };
                /**
                 * Finds out which days are selected as working days in inputdata.
                 * @returns An array of boolean values indicating whether day is working day or not.
                 */
                InputDataProcessor.prototype.getDaysSelectionFromInputData = function () {
                    var daysSelection = []; //initalize with all 7 days selected
                    if (this._inputScenario == CustomerServiceSchedule.InputScenario.NewScenario) {
                        daysSelection = [true, true, true, true, true, true, true];
                    }
                    else {
                        //Edit scenario
                        for (var dayIndex = 0; dayIndex < this._allDays.length; dayIndex++) {
                            daysSelection[dayIndex] = false;
                            var day = this._allDays[dayIndex];
                            if (!this.isNullOrUndefined(day) && !this.isNullOrUndefined(this._calendarRules)) {
                                for (var _i = 0, _a = this._calendarRules; _i < _a.length; _i++) {
                                    var calendarRule = _a[_i];
                                    var patternIndex = calendarRule.pattern.indexOf("BYDAY");
                                    if (calendarRule.pattern.substring(patternIndex).indexOf(day) > 0) {
                                        daysSelection[dayIndex] = true;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    return daysSelection;
                };
                /**
                 * Get OptionsData corresponding to SameAllDay option.
                 * @returns An object of WeeklyScheduleControlOptionsData interface, which contains data related to SameAllDay option.
                 */
                InputDataProcessor.prototype.getSameAllDayOptionsData = function () {
                    var weeklyScheduleControlOptionsData = null;
                    if (this._inputScenario == CustomerServiceSchedule.InputScenario.NewScenario) {
                        weeklyScheduleControlOptionsData = CustomerServiceSchedule.InputDataProcessorHelper.getWeeklyScheduleControlOptionsData(null, null, null);
                    }
                    else {
                        var recurringRuleInnerCalendarId = this._recurringRuleInnerCalendarId;
                        var startTime = this._workingHourRule.offset;
                        var endTime = this._workingHourRule.offset + this._workingHourRule.duration;
                        weeklyScheduleControlOptionsData = CustomerServiceSchedule.InputDataProcessorHelper.getWeeklyScheduleControlOptionsData(recurringRuleInnerCalendarId, startTime, endTime);
                    }
                    return weeklyScheduleControlOptionsData;
                };
                /**
                 * Get OptionsData corresponding to VaryEachDay option.
                 * @returns An array of objects of WeeklyScheduleControlOptionsData interface, which contains data related to VaryEachDay option.
                 */
                InputDataProcessor.prototype.getVaryEachDayOptionsData = function () {
                    var varyEachDayData = [];
                    if (this._inputScenario == CustomerServiceSchedule.InputScenario.NewScenario) {
                        for (var i = 0; i < this._allDays.length; i++) {
                            varyEachDayData[i] = CustomerServiceSchedule.InputDataProcessorHelper.getWeeklyScheduleControlOptionsData(null, null, null);
                        }
                    }
                    else {
                        for (var i = 0; i < this._allDays.length; i++) {
                            varyEachDayData[i] = this.getVaryEachDayOptionsDataForDay(i);
                        }
                    }
                    return varyEachDayData;
                };
                /**
                 * Private function to retrieve OptionsData corresponding to perticular day.
                 * @param dayIndex index of day
                 * @returns An object of WeeklyScheduleControlOptionsData interface, which contains data related to VaryEachDay option.
                 */
                InputDataProcessor.prototype.getVaryEachDayOptionsDataForDay = function (dayIndex) {
                    var innerCalendarIdForDay = this.getInnerCalendarIdForDay(dayIndex);
                    var workingHourCalendarRule;
                    var startTime;
                    var endTime;
                    if (!this.isNullOrUndefined(this._innerCalendarAndRelatedCalendarRulesResponses)) {
                        var innerCalendarForDay = this._innerCalendarAndRelatedCalendarRulesResponses[innerCalendarIdForDay];
                        if (!this.isNullOrUndefined(innerCalendarForDay.calendar_calendar_rules) && innerCalendarForDay.calendar_calendar_rules.length > 0) {
                            workingHourCalendarRule = CustomerServiceSchedule.InputDataProcessorHelper.retrieveWorkingHoursRule(innerCalendarForDay.calendar_calendar_rules);
                            startTime = workingHourCalendarRule.offset;
                            endTime = workingHourCalendarRule.offset + workingHourCalendarRule.duration;
                        }
                    }
                    return CustomerServiceSchedule.InputDataProcessorHelper.getWeeklyScheduleControlOptionsData(innerCalendarIdForDay, startTime, endTime);
                };
                /**
                 * Get innerCalendarId corresponding to give day.
                 * @param dayIndex index of day
                 * @returns innerCalendarId corresponding to given day.
                 */
                InputDataProcessor.prototype.getInnerCalendarIdForDay = function (dayIndex) {
                    var innerCalendarId = null;
                    var day = this._allDays[dayIndex];
                    if (!this.isNullOrUndefined(day) && !this.isNullOrUndefined(this._calendarRules)) {
                        for (var _i = 0, _a = this._calendarRules; _i < _a.length; _i++) {
                            var calendarRule = _a[_i];
                            var patternIndex = calendarRule.pattern.indexOf("BYDAY");
                            if (calendarRule.pattern.substring(patternIndex).indexOf(day) > 0) {
                                innerCalendarId = calendarRule._innercalendarid_value;
                                break;
                            }
                        }
                    }
                    //If there is no innerCalendarId for day then default innerCalendarId is recurringRuleInnerCalendarId.
                    if (this.isNullOrUndefined(innerCalendarId)) {
                        innerCalendarId = this._recurringRuleInnerCalendarId;
                    }
                    return innerCalendarId;
                };
                /**
                 * Get working hour rule corresponding to recurring rule.
                 * @returns object of CalendarCalendarRuleData, which contains data related to workingHourRule.
                 */
                InputDataProcessor.prototype.getWorkingHourRuleFromInputData = function () {
                    var workingHourRule = null;
                    if (!this.isNullOrUndefined(this._recurringRule) && !this.isNullOrUndefined(this._innerCalendarAndRelatedCalendarRulesResponses)) {
                        var innerCalendar = this._innerCalendarAndRelatedCalendarRulesResponses[this._recurringRule._innercalendarid_value];
                        var innerCalendarCalendarRules = innerCalendar.calendar_calendar_rules;
                        workingHourRule = CustomerServiceSchedule.InputDataProcessorHelper.retrieveWorkingHoursRule(innerCalendarCalendarRules);
                    }
                    return workingHourRule;
                };
                /**
                 * Checks whether inputdata corresponds to SameAllDay WorkRuleMode.
                 * @returns A flag indicating whether WorkRuleMode is SameAllDay or not.
                 */
                InputDataProcessor.prototype.isAllTheSameRules = function () {
                    if (this.isNullOrUndefined(this._recurringRule)) {
                        return true;
                    }
                    else {
                        return (!CustomerServiceSchedule.InputDataProcessorHelper.isRecurringRuleVaried(this._recurringRule))
                            && (CustomerServiceSchedule.InputDataProcessorHelper.compareCalendarRuleTimeType("WorkingHoursTimeType", this._workingHourRule)
                                && ((this._workingHourRule.duration == 1440
                                    && (CustomerServiceSchedule.InputDataProcessorHelper.isBreaksAvailable(this._innerCalendarAndRelatedCalendarRulesResponses[this._recurringRule._innercalendarid_value])
                                        || !CustomerServiceSchedule.InputDataProcessorHelper.isAllDaysInRule(this._recurringRule.pattern)))
                                    ||
                                        (this._workingHourRule.duration != 1440)));
                    }
                };
                /**
                 * Checks whether inputdata corresponds to 24by7 WorkRuleMode.
                 * @returns A flag indicating whether WorkRuleMode is 24by7 or not.
                 */
                InputDataProcessor.prototype.is247OrNotWorkingRules = function () {
                    return (!this.isNullOrUndefined(this._recurringRule) && !CustomerServiceSchedule.InputDataProcessorHelper.isRecurringRuleVaried(this._recurringRule))
                        && (CustomerServiceSchedule.InputDataProcessorHelper.compareCalendarRuleTimeType("WorkingHoursTimeType", this._workingHourRule)
                            && (this._workingHourRule.duration == 1440
                                && !CustomerServiceSchedule.InputDataProcessorHelper.isBreaksAvailable(this._innerCalendarAndRelatedCalendarRulesResponses[this._recurringRule._innercalendarid_value])
                                && CustomerServiceSchedule.InputDataProcessorHelper.isAllDaysInRule(this._recurringRule.pattern)));
                };
                /**
                 * Checks whether inputdata corresponds to VaryByDay WorkRuleMode.
                 * @returns A flag indicating whether WorkRuleMode is VaryByDay or not.
                 */
                InputDataProcessor.prototype.isVaryByDayRules = function () {
                    if (this.isNullOrUndefined(this._recurringRule))
                        return false;
                    return CustomerServiceSchedule.InputDataProcessorHelper.isRecurringRuleVaried(this._recurringRule);
                };
                return InputDataProcessor;
            }());
            CustomerServiceSchedule.InputDataProcessor = InputDataProcessor;
        })(CustomerServiceSchedule = AppCommon.CustomerServiceSchedule || (AppCommon.CustomerServiceSchedule = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CustomerServiceSchedule;
        (function (CustomerServiceSchedule) {
            'use strict';
            CustomerServiceSchedule.WeeklyScheduleControlOutput = ServiceCommon.WeeklyScheduleControlOutput;
            CustomerServiceSchedule.OutputStatus = ServiceCommon.WeeklyScheduleControlOutputStatus;
            CustomerServiceSchedule.OutputData = ServiceCommon.WeeklyScheduleControlOutputData;
            CustomerServiceSchedule.WorkRuleMode = ServiceCommon.WorkRuleMode;
            CustomerServiceSchedule.Day = MscrmControls.AppCommon.Day;
            var SELECTED_WORKHOURS_CHOICE;
            (function (SELECTED_WORKHOURS_CHOICE) {
                SELECTED_WORKHOURS_CHOICE[SELECTED_WORKHOURS_CHOICE["SET_WORK_HOURS"] = 0] = "SET_WORK_HOURS";
                SELECTED_WORKHOURS_CHOICE[SELECTED_WORKHOURS_CHOICE["TWENTYFOUR_SEVEN_SUPPORT"] = 1] = "TWENTYFOUR_SEVEN_SUPPORT";
            })(SELECTED_WORKHOURS_CHOICE = CustomerServiceSchedule.SELECTED_WORKHOURS_CHOICE || (CustomerServiceSchedule.SELECTED_WORKHOURS_CHOICE = {}));
            var InputScenario;
            (function (InputScenario) {
                InputScenario[InputScenario["NewScenario"] = 0] = "NewScenario";
                InputScenario[InputScenario["EditScenario"] = 1] = "EditScenario";
            })(InputScenario = CustomerServiceSchedule.InputScenario || (CustomerServiceSchedule.InputScenario = {}));
        })(CustomerServiceSchedule = AppCommon.CustomerServiceSchedule || (AppCommon.CustomerServiceSchedule = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=WeeklyScheduleControl.js.map