/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var LinkedInExtensionControls;
(function (LinkedInExtensionControls) {
    var LinkedInLeadDialog;
    (function (LinkedInLeadDialog) {
        'use strict';
        var LinkedInLeadDialogControl = (function () {
            /**
             * Empty constructor.
             */
            function LinkedInLeadDialogControl() {
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            LinkedInLeadDialogControl.prototype.init = function (context, notifyOutputChanged, state) {
                // custom code goes here
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            LinkedInLeadDialogControl.prototype.updateView = function (context) {
                return this.buildLinkedInLeadControl(context);
            };
            LinkedInLeadDialogControl.prototype.buildLinkedInLeadControl = function (context) {
                var ctrlInputs = new LinkedInLeadDialog.ControlInputs(context);
                var properties = {
                    "parameters": {
                        TopCard2: { Static: true, Type: "Enum", Value: true, Primary: false },
                        Icebreakers: { Static: true, Type: "Enum", Value: true, Primary: false },
                        GetIntroduced: { Static: true, Type: "Enum", Value: true, Primary: false },
                        RelatedLeads: { Static: true, Type: "Enum", Value: true, Primary: false },
                        ShowChrome: { Static: true, Type: "Enum", Value: true, Primary: false },
                        CrmRecordId: { Static: true, Type: "SingleLine.Text", Value: ctrlInputs.CrmRecordId, Primary: false },
                        LastName: { Static: true, Type: "SingleLine.Text", Value: ctrlInputs.LastName, Primary: true },
                        FirstName: { Static: true, Type: "SingleLine.Text", Value: ctrlInputs.FirstName, Primary: false },
                        Email: { Static: true, Type: "SingleLine.Text", Value: ctrlInputs.Email, Primary: false },
                        JobTitle: { Static: true, Type: "SingleLine.Text", Value: ctrlInputs.JobTitle, Primary: false },
                        CompanyName: { Static: true, Type: "SingleLine.Text", Value: ctrlInputs.CompanyName, Primary: false }
                    }
                };
                return context.factory.createComponent("MscrmControls.LinkedInIntegration.LinkedInLeadControl", "LinkedInLeadDialogControl", properties);
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            LinkedInLeadDialogControl.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                return null;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            LinkedInLeadDialogControl.prototype.destroy = function () {
            };
            return LinkedInLeadDialogControl;
        }());
        LinkedInLeadDialog.LinkedInLeadDialogControl = LinkedInLeadDialogControl;
    })(LinkedInLeadDialog = LinkedInExtensionControls.LinkedInLeadDialog || (LinkedInExtensionControls.LinkedInLeadDialog = {}));
})(LinkedInExtensionControls || (LinkedInExtensionControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="LinkedInLeadDialogControl.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
var LinkedInExtensionControls;
(function (LinkedInExtensionControls) {
    var LinkedInLeadDialog;
    (function (LinkedInLeadDialog) {
        'use strict';
        var ControlInputs = (function () {
            function ControlInputs(context) {
                if (context.parameters == null || context.parameters.Inputs == null || context.parameters.Inputs.raw == null
                    || context.parameters.Inputs.raw.LastName == null || context.parameters.Inputs.raw.CrmRecordId == null) {
                    throw new Error("One or more mandatory inputs were was not specified");
                }
                this.LastName = context.parameters.Inputs.raw.LastName;
                this.CrmRecordId = context.parameters.Inputs.raw.CrmRecordId;
                this.FirstName = context.parameters.Inputs.raw.FirstName ? context.parameters.Inputs.raw.FirstName : "";
                this.Email = context.parameters.Inputs.raw.Email ? context.parameters.Inputs.raw.Email : "";
                this.JobTitle = context.parameters.Inputs.raw.JobTitle ? context.parameters.Inputs.raw.JobTitle : "";
                this.CompanyName = context.parameters.Inputs.raw.CompanyName ? context.parameters.Inputs.raw.CompanyName : "";
            }
            return ControlInputs;
        }());
        LinkedInLeadDialog.ControlInputs = ControlInputs;
    })(LinkedInLeadDialog = LinkedInExtensionControls.LinkedInLeadDialog || (LinkedInExtensionControls.LinkedInLeadDialog = {}));
})(LinkedInExtensionControls || (LinkedInExtensionControls = {}));
//# sourceMappingURL=LinkedInLeadDialogControl.js.map