var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t;
    return { next: verb(0), "throw": verb(1), "return": verb(2) };
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var DynamicListSubgrid;
    (function (DynamicListSubgrid) {
        var ODataServiceClient = (function () {
            function ODataServiceClient() {
            }
            ODataServiceClient.prototype.get = function (url, successCallback, failureCallback) {
                var request = new XMLHttpRequest();
                request.open("get", url);
                request.setRequestHeader("Accept", "application/json");
                request.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                request.setRequestHeader("OData-MaxVersion", "4.0");
                request.setRequestHeader("OData-Version", "4.0");
                request.setRequestHeader("prefer", "odata.include-annotations=\"*\"");
                request.onreadystatechange = function () {
                    if (request.readyState === 4) {
                        request.onreadystatechange = null;
                        var status = request.status;
                        if (status >= 200 && status < 300) {
                            successCallback(request.response);
                        }
                        else {
                            failureCallback(request.response);
                        }
                    }
                };
                request.send();
            };
            return ODataServiceClient;
        }());
        DynamicListSubgrid.ODataServiceClient = ODataServiceClient;
    })(DynamicListSubgrid = MscrmControls.DynamicListSubgrid || (MscrmControls.DynamicListSubgrid = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/// <reference path="../privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var DynamicListSubgrid;
    (function (DynamicListSubgrid) {
        var ListMemberRecordSetQueryService = (function () {
            function ListMemberRecordSetQueryService(context, serviceClient) {
                this.context = context;
                this.serviceClient = serviceClient;
            }
            ListMemberRecordSetQueryService.prototype.retrieveRecords = function (recordSetName, fetchXml) {
                return __awaiter(this, void 0, void 0, function () {
                    var _this = this;
                    var entitiesResponse;
                    return __generator(this, function (_a) {
                        entitiesResponse = new Promise(function (resolve, reject) {
                            var requestUrl = _this.context.page.getClientUrl() + ("/api/data/v9.0/" + encodeURI(recordSetName) + "?fetchXml=" + encodeURI(fetchXml));
                            _this.serviceClient.get(requestUrl, function (response) {
                                var responseRaw = JSON.parse(response);
                                var result = {
                                    records: responseRaw["value"],
                                    totalRecordsCount: responseRaw["@Microsoft.Dynamics.CRM.totalrecordcount"],
                                    totalRecordsCountExceeded: responseRaw["@Microsoft.Dynamics.CRM.totalrecordcountlimitexceeded"]
                                };
                                resolve(result);
                            }, function (response) {
                                _this.context.reporting.reportFailure("marketing", new Error("ListMemberRecordSetQueryService-retrieveRecords"), "", [
                                    { name: "RequestUrl", value: requestUrl },
                                    { name: "ResponseError", value: JSON.stringify(response) }
                                ]);
                            });
                        });
                        return [2 /*return*/, entitiesResponse];
                    });
                });
            };
            return ListMemberRecordSetQueryService;
        }());
        DynamicListSubgrid.ListMemberRecordSetQueryService = ListMemberRecordSetQueryService;
    })(DynamicListSubgrid = MscrmControls.DynamicListSubgrid || (MscrmControls.DynamicListSubgrid = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var DataSetRecordsModel = (function () {
            function DataSetRecordsModel() {
            }
            return DataSetRecordsModel;
        }());
        ListMemberDataSet.DataSetRecordsModel = DataSetRecordsModel;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var EntityDescriptorBase = (function () {
            function EntityDescriptorBase(context, savedQueryId) {
                this.context = context;
                this.savedQueryId = savedQueryId;
            }
            EntityDescriptorBase.prototype.getColumns = function () {
                return __awaiter(this, void 0, void 0, function () {
                    var savedQuery, fetchXml, attributes, entityName, columns, requiredAttributes, _i, _a, attribute, requiredAttribute, metadata;
                    return __generator(this, function (_b) {
                        switch (_b.label) {
                            case 0: return [4 /*yield*/, this.context.webAPI.retrieveRecord(ListMemberDataSet.EntityDescriptorsConstants.SavedQuery, this.savedQueryId)];
                            case 1:
                                savedQuery = _b.sent();
                                fetchXml = (new DOMParser()).parseFromString(savedQuery[ListMemberDataSet.EntityDescriptorsConstants.FetchXml], "text/xml");
                                attributes = fetchXml.querySelectorAll(ListMemberDataSet.EntityDescriptorsConstants.Attribute);
                                entityName = fetchXml.querySelector("entity").getAttribute(ListMemberDataSet.EntityDescriptorsConstants.Name);
                                columns = new Array();
                                requiredAttributes = new Array();
                                for (_i = 0, _a = Array.from(attributes); _i < _a.length; _i++) {
                                    attribute = _a[_i];
                                    requiredAttribute = attribute.getAttribute(ListMemberDataSet.EntityDescriptorsConstants.Name);
                                    if (requiredAttribute !== this.getIdFieldName()) {
                                        requiredAttributes.push(attribute.getAttribute(ListMemberDataSet.EntityDescriptorsConstants.Name));
                                    }
                                }
                                return [4 /*yield*/, this.context.utils.getEntityMetadata(entityName, requiredAttributes)];
                            case 2:
                                metadata = _b.sent();
                                metadata.Attributes.forEach(function (attr) {
                                    columns.push(new ListMemberDataSet.ListMemberColumn(attr.LogicalName, attr.DisplayName));
                                });
                                return [2 /*return*/, columns];
                        }
                    });
                });
            };
            EntityDescriptorBase.prototype.getSavedQueryId = function () {
                return this.savedQueryId;
            };
            return EntityDescriptorBase;
        }());
        ListMemberDataSet.EntityDescriptorBase = EntityDescriptorBase;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var AccountSavedQueriesId = (function () {
            function AccountSavedQueriesId() {
            }
            return AccountSavedQueriesId;
        }());
        AccountSavedQueriesId.AccountAdvancedFindView = "00000000-0000-0000-00AA-000000666000";
        ListMemberDataSet.AccountSavedQueriesId = AccountSavedQueriesId;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var ContactSavedQueriesId = (function () {
            function ContactSavedQueriesId() {
            }
            return ContactSavedQueriesId;
        }());
        ContactSavedQueriesId.ContactAdvancedFindView = "00000000-0000-0000-00AA-000000666400";
        ListMemberDataSet.ContactSavedQueriesId = ContactSavedQueriesId;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var EntityDescriptorsConstants = (function () {
            function EntityDescriptorsConstants() {
            }
            return EntityDescriptorsConstants;
        }());
        EntityDescriptorsConstants.FetchXml = "fetchxml";
        EntityDescriptorsConstants.Name = "name";
        EntityDescriptorsConstants.SavedQuery = "savedquery";
        EntityDescriptorsConstants.Attribute = "attribute";
        ListMemberDataSet.EntityDescriptorsConstants = EntityDescriptorsConstants;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var LeadSavedQueriesId = (function () {
            function LeadSavedQueriesId() {
            }
            return LeadSavedQueriesId;
        }());
        LeadSavedQueriesId.LeadAdvancedFindView = "00000000-0000-0000-00AA-000000666700";
        ListMemberDataSet.LeadSavedQueriesId = LeadSavedQueriesId;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var EntityNames = (function () {
            function EntityNames() {
            }
            return EntityNames;
        }());
        EntityNames.Account = "account";
        EntityNames.Contact = "contact";
        EntityNames.Lead = "lead";
        EntityNames.List = "list";
        ListMemberDataSet.EntityNames = EntityNames;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var RecordSetNames = (function () {
            function RecordSetNames() {
            }
            return RecordSetNames;
        }());
        RecordSetNames.Accounts = "accounts";
        RecordSetNames.Contacts = "contacts";
        RecordSetNames.Leads = "leads";
        ListMemberDataSet.RecordSetNames = RecordSetNames;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var AccountEntityDescriptor = (function (_super) {
            __extends(AccountEntityDescriptor, _super);
            function AccountEntityDescriptor(context, savedQueryId) {
                return _super.call(this, context, savedQueryId) || this;
            }
            AccountEntityDescriptor.prototype.getIdFieldName = function () {
                return "accountid";
            };
            AccountEntityDescriptor.prototype.getEntityName = function () {
                return ListMemberDataSet.EntityNames.Account;
            };
            AccountEntityDescriptor.prototype.getRecordSetName = function () {
                return ListMemberDataSet.RecordSetNames.Accounts;
            };
            return AccountEntityDescriptor;
        }(ListMemberDataSet.EntityDescriptorBase));
        ListMemberDataSet.AccountEntityDescriptor = AccountEntityDescriptor;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var ContactEntityDescriptor = (function (_super) {
            __extends(ContactEntityDescriptor, _super);
            function ContactEntityDescriptor(context, savedQueryId) {
                return _super.call(this, context, savedQueryId) || this;
            }
            ContactEntityDescriptor.prototype.getIdFieldName = function () {
                return "contactid";
            };
            ContactEntityDescriptor.prototype.getEntityName = function () {
                return ListMemberDataSet.EntityNames.Contact;
            };
            ContactEntityDescriptor.prototype.getRecordSetName = function () {
                return ListMemberDataSet.RecordSetNames.Contacts;
            };
            return ContactEntityDescriptor;
        }(ListMemberDataSet.EntityDescriptorBase));
        ListMemberDataSet.ContactEntityDescriptor = ContactEntityDescriptor;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var EntityDescriptorFactory = (function () {
            function EntityDescriptorFactory() {
            }
            /**
             * Returns an entity descriptor associated with given entity name.
             * @param {string} entityName on which to perform the search.
             * @returns {IEntityDescriptor} associated with entity name.
             * @throws {Error} if unknown entity name was used for resolving descriptor.
             */
            EntityDescriptorFactory.prototype.getEntityDescriptor = function (entityName, webAPI, savedQueryId) {
                switch (entityName) {
                    case ListMemberDataSet.EntityNames.Account: return new ListMemberDataSet.AccountEntityDescriptor(webAPI, savedQueryId ? savedQueryId : ListMemberDataSet.AccountSavedQueriesId.AccountAdvancedFindView);
                    case ListMemberDataSet.EntityNames.Contact: return new ListMemberDataSet.ContactEntityDescriptor(webAPI, savedQueryId ? savedQueryId : ListMemberDataSet.ContactSavedQueriesId.ContactAdvancedFindView);
                    case ListMemberDataSet.EntityNames.Lead: return new ListMemberDataSet.LeadEntityDescriptor(webAPI, savedQueryId ? savedQueryId : ListMemberDataSet.LeadSavedQueriesId.LeadAdvancedFindView);
                    default: throw new Error("Entity descriptor for " + entityName + " is not implemented");
                }
            };
            return EntityDescriptorFactory;
        }());
        ListMemberDataSet.EntityDescriptorFactory = EntityDescriptorFactory;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var LeadEntityDescriptor = (function (_super) {
            __extends(LeadEntityDescriptor, _super);
            function LeadEntityDescriptor(context, savedQueryId) {
                return _super.call(this, context, savedQueryId) || this;
            }
            LeadEntityDescriptor.prototype.getIdFieldName = function () {
                return "leadid";
            };
            LeadEntityDescriptor.prototype.getEntityName = function () {
                return ListMemberDataSet.EntityNames.Lead;
            };
            LeadEntityDescriptor.prototype.getRecordSetName = function () {
                return ListMemberDataSet.RecordSetNames.Leads;
            };
            return LeadEntityDescriptor;
        }(ListMemberDataSet.EntityDescriptorBase));
        ListMemberDataSet.LeadEntityDescriptor = LeadEntityDescriptor;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var FetchXmlEnhancer = (function () {
            function FetchXmlEnhancer(fetchXml) {
                this.fetchXml = fetchXml;
                this.xmlDoc = FetchXmlEnhancer.parseFromString(this.fetchXml);
            }
            FetchXmlEnhancer.prototype.addColumns = function (columns) {
                var entity = this.xmlDoc.querySelector("fetch entity");
                FetchXmlEnhancer.specifyColumnsSet(entity, columns);
                return this;
            };
            FetchXmlEnhancer.prototype.setPage = function (count, currentPage) {
                var fetch = this.xmlDoc.querySelector("fetch");
                fetch.setAttribute("count", String(count));
                fetch.setAttribute("page", String(currentPage));
                fetch.setAttribute("returntotalrecordcount", "true");
                return this;
            };
            FetchXmlEnhancer.prototype.resetOrder = function () {
                var entity = this.xmlDoc.querySelector("fetch entity");
                var orderElements = entity.querySelectorAll("order");
                for (var i = 0; i < orderElements.length; i++) {
                    entity.removeChild(orderElements[i]);
                }
                return this;
            };
            FetchXmlEnhancer.prototype.setOrder = function (attribute, descending) {
                var entity = this.xmlDoc.querySelector("fetch entity");
                var orderElement = this.xmlDoc.createElement("order");
                orderElement.setAttribute("attribute", attribute);
                orderElement.setAttribute("descending", String(descending));
                entity.appendChild(orderElement);
                return this;
            };
            FetchXmlEnhancer.prototype.toFetchXml = function () {
                return new XMLSerializer().serializeToString(this.xmlDoc);
            };
            FetchXmlEnhancer.specifyColumnsSet = function (entity, columns) {
                for (var _i = 0, columns_1 = columns; _i < columns_1.length; _i++) {
                    var column = columns_1[_i];
                    var attributeNode = FetchXmlEnhancer.getElementFromXmlString("<attribute name=\"" + column.name + "\"/>", "attribute");
                    entity.appendChild(attributeNode);
                }
            };
            FetchXmlEnhancer.parseFromString = function (xml) {
                return new DOMParser().parseFromString(xml, "text/xml");
            };
            FetchXmlEnhancer.getElementFromXmlString = function (xml, selector) {
                return FetchXmlEnhancer.parseFromString(xml).querySelector(selector);
            };
            return FetchXmlEnhancer;
        }());
        ListMemberDataSet.FetchXmlEnhancer = FetchXmlEnhancer;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var ListMemberColumn = (function () {
            function ListMemberColumn(name, displayName) {
                this.dataType = "SingleLine.Text";
                this.alias = "name";
                this.visualSizeFactor = 25;
                this.isHidden = false;
                this.order = 1;
                this.attributes = {
                    maxLength: 200,
                    type: "SingleLine.Text",
                    format: "Text"
                };
                this.disableSorting = false;
                this.name = name;
                this.displayName = displayName;
            }
            return ListMemberColumn;
        }());
        ListMemberDataSet.ListMemberColumn = ListMemberColumn;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var ListMemberDataSetPaging = (function () {
            function ListMemberDataSetPaging(dataSetRecordsProvider) {
                this.dataSetRecordsProvider = dataSetRecordsProvider;
                this.currentPage = 1;
                /**
                * Total number of results on the server for the currently applied query.
                */
                this.totalResultCount = 0;
                /**
                 * The number of results per page.
                 */
                this.pageSize = 14;
                /**
                 * Whether the result set can be paged forwards.
                 */
                this.hasNextPage = true;
                /**
                 * Whether the result set can be paged backwards.
                 */
                this.hasPreviousPage = true;
            }
            /**
             * Sets the number of results to return per page on the next data refresh.
             */
            ListMemberDataSetPaging.prototype.setPageSize = function (pageSize) {
                this.pageSize = pageSize;
            };
            /**
             * Request the next page of results to be loaded.
             */
            ListMemberDataSetPaging.prototype.loadNextPage = function () {
            };
            /**
             * Request the previous page of results to be loaded.
             */
            ListMemberDataSetPaging.prototype.loadPreviousPage = function () {
            };
            /**
             * Reload the results from the server, and reset to page 1.
             */
            ListMemberDataSetPaging.prototype.reset = function () {
                this.currentPage = 1;
            };
            ListMemberDataSetPaging.prototype.loadExactPage = function (page) {
                this.currentPage = page;
                return this.dataSetRecordsProvider.getListMemberRecords();
            };
            ListMemberDataSetPaging.prototype.getCurrentPage = function () {
                return this.currentPage;
            };
            return ListMemberDataSetPaging;
        }());
        ListMemberDataSet.ListMemberDataSetPaging = ListMemberDataSetPaging;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var ListMemberDataSetColumnValidator = (function () {
            function ListMemberDataSetColumnValidator() {
            }
            ListMemberDataSetColumnValidator.prototype.validate = function (value, isValueChanging, isDisabled) {
                return new ListMemberDataSet.ListMemberValidationResult("", true);
            };
            return ListMemberDataSetColumnValidator;
        }());
        ListMemberDataSet.ListMemberDataSetColumnValidator = ListMemberDataSetColumnValidator;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var ListMemberDataSetProvider = (function () {
            function ListMemberDataSetProvider(listMembersFetchXml, recordQueryService, entityDescriptor, columns) {
                this.listMembersFetchXml = listMembersFetchXml;
                this.recordQueryService = recordQueryService;
                this.entityDescriptor = entityDescriptor;
                this.columns = columns;
                this.sorting = null;
                this.currentRecords = [];
                this.dataSetPaging = new ListMemberDataSet.ListMemberDataSetPaging(this);
            }
            ListMemberDataSetProvider.prototype.setFetchXml = function (fetchXml) {
                this.listMembersFetchXml = fetchXml;
            };
            ListMemberDataSetProvider.prototype.isLoading = function () {
                return false;
            };
            ListMemberDataSetProvider.prototype.isError = function () {
                return false;
            };
            ListMemberDataSetProvider.prototype.getErrorMessage = function () {
                return null;
            };
            ListMemberDataSetProvider.prototype.setSorting = function (sorting) {
                this.sorting = sorting;
            };
            ListMemberDataSetProvider.prototype.setFiltering = function (filtering) {
                this.filtering = filtering;
            };
            ListMemberDataSetProvider.prototype.refresh = function () {
                return this.dataSetPaging.loadExactPage(1);
            };
            ListMemberDataSetProvider.prototype.getRecords = function () {
                return null;
            };
            ListMemberDataSetProvider.prototype.getPaging = function () {
                return this.dataSetPaging;
            };
            ListMemberDataSetProvider.prototype.getColumns = function () {
                return this.columns;
            };
            ListMemberDataSetProvider.prototype.save = function (record) {
                throw new Error("Not implemented");
            };
            ListMemberDataSetProvider.prototype.getListMemberRecords = function () {
                return __awaiter(this, void 0, void 0, function () {
                    var fetchXmlEnhancer, _i, _a, sortStatus, response, records, _b, _c, entity;
                    return __generator(this, function (_d) {
                        switch (_d.label) {
                            case 0:
                                if (!this.listMembersFetchXml) {
                                    return [2 /*return*/, []];
                                }
                                fetchXmlEnhancer = new ListMemberDataSet.FetchXmlEnhancer(this.listMembersFetchXml)
                                    .addColumns(this.columns)
                                    .setPage(this.dataSetPaging.pageSize, this.dataSetPaging.getCurrentPage())
                                    .resetOrder();
                                if (this.sorting) {
                                    for (_i = 0, _a = this.sorting; _i < _a.length; _i++) {
                                        sortStatus = _a[_i];
                                        fetchXmlEnhancer.setOrder(sortStatus.name, sortStatus.sortDirection === 1 /* Descending */);
                                    }
                                }
                                return [4 /*yield*/, this.recordQueryService.retrieveRecords(this.entityDescriptor.getRecordSetName(), fetchXmlEnhancer.toFetchXml())];
                            case 1:
                                response = _d.sent();
                                this.dataSetPaging.totalResultCount = response.totalRecordsCount;
                                records = [];
                                for (_b = 0, _c = response.records; _b < _c.length; _b++) {
                                    entity = _c[_b];
                                    records.push(new ListMemberDataSet.ListMemberRecord(entity[this.entityDescriptor.getIdFieldName()], entity, this.entityDescriptor.getEntityName(), this.entityDescriptor.getIdFieldName()));
                                }
                                return [2 /*return*/, records];
                        }
                    });
                });
            };
            return ListMemberDataSetProvider;
        }());
        ListMemberDataSet.ListMemberDataSetProvider = ListMemberDataSetProvider;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var ListMemberRecord = (function () {
            function ListMemberRecord(id, record, logicalName, primaryFieldName) {
                this.record = {};
                this.id = id;
                this.record = record;
                this.logicalName = logicalName;
                this.primaryFieldName = primaryFieldName;
            }
            ListMemberRecord.prototype.getRecordId = function () {
                return this.id;
            };
            ListMemberRecord.prototype.getValue = function (columnName) {
                return this.record[columnName];
            };
            ListMemberRecord.prototype.setValue = function (columnName, newValue) {
                return this.record[columnName] = newValue;
            };
            ListMemberRecord.prototype.getFormattedValue = function (columnName) {
                return this.record[columnName];
            };
            ListMemberRecord.prototype.getPrimaryEntityLogicalName = function () {
                return this.logicalName;
            };
            ListMemberRecord.prototype.isEditable = function (columnName) {
                return window.Promise.resolve(false);
            };
            ListMemberRecord.prototype.isSecured = function (columnName) {
                return window.Promise.resolve(true);
            };
            ListMemberRecord.prototype.isReadable = function (columnName) {
                return window.Promise.resolve(true);
            };
            ListMemberRecord.prototype.getFieldRequiredLevel = function (columnName) {
                return window.Promise.resolve(0 /* None */);
            };
            ListMemberRecord.prototype.getAttributes = function (column) {
                return null;
            };
            ListMemberRecord.prototype.getValidator = function (column) {
                return null;
            };
            ListMemberRecord.prototype.getNamedReference = function () {
                var _this = this;
                return {
                    Id: {
                        guid: this.id,
                        toString: function () { return _this.id; }
                    },
                    Name: null,
                    LogicalName: this.logicalName
                };
            };
            ListMemberRecord.prototype.getActivityPartyRecord = function () {
                return null;
            };
            ListMemberRecord.prototype.getErrorMessage = function () {
                return null;
            };
            ListMemberRecord.prototype.isDirty = function () {
                return false;
            };
            ListMemberRecord.prototype.isRecordValid = function () {
                return true;
            };
            ListMemberRecord.prototype.getNotification = function (columnName) {
                return null;
            };
            ListMemberRecord.prototype.isValid = function (columnName) {
                return true;
            };
            ListMemberRecord.prototype.validateAllColumns = function () {
                return null;
            };
            ListMemberRecord.prototype.save = function () {
                return null;
            };
            return ListMemberRecord;
        }());
        ListMemberDataSet.ListMemberRecord = ListMemberRecord;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ListMemberDataSet;
    (function (ListMemberDataSet) {
        var ListMemberValidationResult = (function () {
            function ListMemberValidationResult(errorMessage, isValid) {
                this.errorMessage = errorMessage;
                this.isValid = isValid;
            }
            return ListMemberValidationResult;
        }());
        ListMemberDataSet.ListMemberValidationResult = ListMemberValidationResult;
    })(ListMemberDataSet = MscrmControls.ListMemberDataSet || (MscrmControls.ListMemberDataSet = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/// <reference path="Dataset/DataSetRecordsModel.ts" />
/// <reference path="Dataset/IRecordSetQueryService.ts" />
/// <reference path="Dataset/IDataSetRecordsProvider.ts" />
/// <reference path="Dataset/IFetchXmlDataSetDataProvider.ts" />
/// <reference path="Dataset/Descriptors/EntityDescriptorBase.ts" />
/// <reference path="Constants/AccountSavedQueriesID.ts" />
/// <reference path="Constants/ContactSavedQueriesID.ts" />
/// <reference path="Constants/EntityDescriptorsConstants.ts" />
/// <reference path="Constants/LeadSavedQueriesID.ts" />
/// <reference path="Constants/EntityNames.ts" />
/// <reference path="Constants/RecordSetNames.ts" />
/// <reference path="Dataset/Descriptors/AccountEntityDescriptor.ts" />
/// <reference path="Dataset/Descriptors/ContactEntityDescriptor.ts" />
/// <reference path="Dataset/Descriptors/EntityDescriptorFactory.ts" />
/// <reference path="Dataset/Descriptors/IEntityDescriptor.ts" />
/// <reference path="Dataset/Descriptors/LeadEntityDescriptor.ts" />
/// <reference path="Dataset/FetchXmlEnhancer.ts" />
/// <reference path="Dataset/ListMemberColumn.ts" />
/// <reference path="Dataset/ListMemberDataSetPaging.ts" />
/// <reference path="Dataset/ListMemberDataSetColumnValidator.ts" />
/// <reference path="Dataset/ListMemberDataSetProvider.ts" />
/// <reference path="Dataset/ListMemberRecord.ts" />
/// <reference path="Dataset/ListMemberValidationResult.ts" />
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var DynamicListSubgrid;
    (function (DynamicListSubgrid) {
        var EntityMap = (function () {
            function EntityMap() {
            }
            EntityMap.getEntityName = function (entityTypeCode) {
                switch (entityTypeCode) {
                    case DynamicListSubgrid.EntityTypeCodes.Account: return MscrmControls.ListMemberDataSet.EntityNames.Account;
                    case DynamicListSubgrid.EntityTypeCodes.Contact: return MscrmControls.ListMemberDataSet.EntityNames.Contact;
                    case DynamicListSubgrid.EntityTypeCodes.Lead: return MscrmControls.ListMemberDataSet.EntityNames.Lead;
                    default: throw new Error("Unknown entityTypeCode [" + entityTypeCode + "] used for resolving entity name.");
                }
            };
            return EntityMap;
        }());
        DynamicListSubgrid.EntityMap = EntityMap;
    })(DynamicListSubgrid = MscrmControls.DynamicListSubgrid || (MscrmControls.DynamicListSubgrid = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var DynamicListSubgrid;
    (function (DynamicListSubgrid) {
        var EntityTypeCodes;
        (function (EntityTypeCodes) {
            EntityTypeCodes[EntityTypeCodes["Account"] = 1] = "Account";
            EntityTypeCodes[EntityTypeCodes["Contact"] = 2] = "Contact";
            EntityTypeCodes[EntityTypeCodes["Lead"] = 4] = "Lead";
        })(EntityTypeCodes = DynamicListSubgrid.EntityTypeCodes || (DynamicListSubgrid.EntityTypeCodes = {}));
    })(DynamicListSubgrid = MscrmControls.DynamicListSubgrid || (MscrmControls.DynamicListSubgrid = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/// <reference path="Service/IServiceClient.ts" />
/// <reference path="Service/ODataServiceClient.ts" />
/// <reference path="Service/ListMemberRecordSetQueryService.ts" />
/// <reference path="../ListMemberDataSet/commonreferences.ts" />
/// <reference path="Constants/EntityMap.ts" />
/// <reference path="Constants/EntityTypeCodes.ts" />
/// <reference path="inputsOutputs.g.ts" />
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var DynamicListSubgrid;
    (function (DynamicListSubgrid) {
        var ControlBuilder = (function () {
            function ControlBuilder() {
            }
            ControlBuilder.prototype.buildReadOnlyGridControl = function (context, memberType, controlName, provider) {
                var parameters = {
                    parameters: {
                        Grid: {
                            Primary: false,
                            DataProvider: provider,
                            DataSetUIOptions: {
                                displayPaging: true,
                                displayIndex: false,
                                displayQuickFind: false,
                                displayCommandBar: false
                            },
                            Type: "Grid",
                            TargetEntityType: memberType,
                            IsUserView: false,
                            EnableViewPicker: false,
                            RefreshInput: {
                                Static: true,
                                Value: 0
                            }
                        },
                        EnableEditing: {
                            Usage: 1,
                            Static: true,
                            Type: "Enum",
                            Value: "No",
                            Primary: false,
                        },
                        EnableGroupBy: {
                            Usage: 1,
                            Static: true,
                            Type: "Enum",
                            Value: "No",
                            Primary: true,
                        },
                        EnableFiltering: {
                            Usage: 1,
                            Static: true,
                            Type: "Enum",
                            Value: "No",
                            Primary: true,
                        },
                        ReflowBehavior: {
                            Usage: 1,
                            Static: true,
                            Type: "Enum",
                            Value: "GridOnly",
                            Primary: true,
                        }
                    },
                    key: "DynamicListSubgrid",
                    id: "DynamicListSubgrid"
                };
                return context.factory.createComponent(ControlBuilder.GridControlId, controlName, parameters);
            };
            return ControlBuilder;
        }());
        ControlBuilder.GridControlId = "MscrmControls.Grid.GridControl";
        DynamicListSubgrid.ControlBuilder = ControlBuilder;
    })(DynamicListSubgrid = MscrmControls.DynamicListSubgrid || (MscrmControls.DynamicListSubgrid = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var DynamicListSubgrid;
    (function (DynamicListSubgrid) {
        var DynamicListSubgridControl = (function () {
            function DynamicListSubgridControl() {
                var _this = this;
                this.entityDescriptorFactory = new MscrmControls.ListMemberDataSet.EntityDescriptorFactory();
                this.memberType = -1;
                this.init = function (context, notifyOutputChanged, state, container) {
                    _this.container = container;
                    _this.controlBuilder = new DynamicListSubgrid.ControlBuilder();
                    if (_this.updateParmeters(context.parameters)) {
                        _this.renderFirstTime(context);
                    }
                };
                this.updateView = function (context) {
                    // Note: Dynamic list subgrid does not support change of member type (field is immutable on the form, grid is only rendered in edit)
                    if (_this.updateParmeters(context.parameters) && !_this.renderFirstTime(context)) {
                        // Parameters are available, and it is not the first time render, so refresh the sub grid with current parameters
                        // Refreshing grid upon query change
                        if (_this.dataSetDataProvider) {
                            _this.dataSetDataProvider.setFetchXml(_this.fetchXml);
                        }
                        else {
                            // The control is not ready to refresh sub grid yet, wait for data set provider and request to refresh the control
                            // Note: This condition will only be met when trying to refresh the sub grid which didnt finish its intital rendering yet
                            _this.dataSetDataProviderPromise.then(function (dataSetDataProvider) {
                                dataSetDataProvider.setFetchXml(_this.fetchXml);
                                context.utils.requestRender();
                            });
                        }
                    }
                };
                this.getOutputs = function () {
                    return { fetchXml: _this.fetchXml, memberType: _this.memberType };
                };
                this.destroy = function () {
                    if (_this.container) {
                        _this.container.remove();
                    }
                    _this.container = null;
                };
            }
            DynamicListSubgridControl.prototype.renderFirstTime = function (context) {
                var _this = this;
                if (!this.dataSetDataProviderPromise) {
                    this.dataSetDataProviderPromise = this.createDataSetProviderPromise(context);
                    this.dataSetDataProviderPromise.then(function (value) {
                        _this.dataSetDataProvider = value;
                    });
                    this.dataSetDataProviderPromise.then(function (dataSetProvider) {
                        var readOnlyGrid = _this.controlBuilder.buildReadOnlyGridControl(context, DynamicListSubgrid.EntityMap.getEntityName(_this.memberType), DynamicListSubgridControl.controlName, dataSetProvider);
                        context.utils.bindDOMElement(readOnlyGrid, _this.container);
                    });
                    return true;
                }
                return false;
            };
            DynamicListSubgridControl.prototype.createDataSetProviderPromise = function (context) {
                var _this = this;
                var dataSetDataProviderPromise = new Promise(function (resolve, reject) {
                    try {
                        var memberEntityName = DynamicListSubgrid.EntityMap.getEntityName(_this.memberType);
                        var entityDescriptor_1 = _this.entityDescriptorFactory.getEntityDescriptor(memberEntityName, context);
                        entityDescriptor_1.getColumns().then(function (columns) {
                            var dsp = new MscrmControls.ListMemberDataSet.ListMemberDataSetProvider(_this.fetchXml, new DynamicListSubgrid.ListMemberRecordSetQueryService(context, new DynamicListSubgrid.ODataServiceClient()), entityDescriptor_1, columns);
                            resolve(dsp);
                        }).catch(function (reson) {
                            reject();
                            context.reporting.reportFailure("marketing", new Error("createDataSetProviderPromise.getColumns"));
                        });
                    }
                    catch (error) {
                        reject();
                        context.reporting.reportFailure("marketing", new Error("createDataSetProviderPromise"));
                    }
                });
                return dataSetDataProviderPromise;
            };
            DynamicListSubgridControl.prototype.updateParmeters = function (input) {
                var paramChanged = false;
                if (input.fetchXml && input.fetchXml.raw != this.fetchXml) {
                    this.fetchXml = input.fetchXml.raw;
                    paramChanged = true;
                }
                if (input.memberType && input.memberType.raw != this.memberType) {
                    this.memberType = input.memberType.raw;
                    paramChanged = true;
                }
                return paramChanged;
            };
            return DynamicListSubgridControl;
        }());
        DynamicListSubgridControl.controlName = "cc_dynamicListMemebersGrid";
        DynamicListSubgrid.DynamicListSubgridControl = DynamicListSubgridControl;
    })(DynamicListSubgrid = MscrmControls.DynamicListSubgrid || (MscrmControls.DynamicListSubgrid = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=DynamicListSubgrid.js.map