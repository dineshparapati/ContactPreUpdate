/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../../references/internal/TypeDefinitions/CommonControl/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var OfficeProductivity;
    (function (OfficeProductivity) {
        'use strict';
        var NestedLinkControl = (function () {
            /**
             * Empty constructor.
             */
            function NestedLinkControl() {
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             */
            NestedLinkControl.prototype.init = function (context, notifyOutputChanged, state) {
                this._context = context;
                this.controlUtil = new OfficeProductivity.LinkControlUtil(context, notifyOutputChanged);
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            NestedLinkControl.prototype.updateView = function (context) {
                this._context = context;
                return this.controlUtil.render(context);
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            NestedLinkControl.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                return null;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            NestedLinkControl.prototype.destroy = function () {
            };
            return NestedLinkControl;
        }());
        OfficeProductivity.NestedLinkControl = NestedLinkControl;
    })(OfficeProductivity = MscrmControls.OfficeProductivity || (MscrmControls.OfficeProductivity = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="NestedLinkControl.ts" />
var MscrmControls;
(function (MscrmControls) {
    var OfficeProductivity;
    (function (OfficeProductivity) {
        'use strict';
        var ControlConstants;
        (function (ControlConstants) {
            ControlConstants.DIALOG_SUBHEADING_ID = "MultiChannelDialogSubheading";
            ControlConstants.LINK_TEXT_ID = "MultiChannelDialogLink";
            ControlConstants.LINK_VALUE = "https://teams.microsoft.com/l/app/cd2d8695-bdc9-4d8e-9620-cc963ed81f41";
            /* RESX string constants */
            ControlConstants.DIALOG_SUBHEADING_KEY = "DIALOG_SUBHEADING";
            ControlConstants.LINK_TEXT_KEY = "LINK_TEXT";
            ControlConstants.EventGetStartedClicked = "MsTeamsIntegration.GetStartedButtonClicked";
            ControlConstants.ComponentName = "ComponentName";
            ControlConstants.MDD_NAME = "MultiChannelMDD";
        })(ControlConstants = OfficeProductivity.ControlConstants || (OfficeProductivity.ControlConstants = {}));
    })(OfficeProductivity = MscrmControls.OfficeProductivity || (MscrmControls.OfficeProductivity = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var OfficeProductivity;
    (function (OfficeProductivity) {
        'use strict';
        var LinkControlUtil = (function () {
            function LinkControlUtil(context, notifyOutputChanged) {
                this._context = context;
                this._notifyOutputChanged = notifyOutputChanged || (function () { });
            }
            LinkControlUtil.prototype.render = function (context) {
                this._context = context;
                return this.CreateLinkElement(this._context);
            };
            /**
             * Creates the visualization for Label
             */
            LinkControlUtil.prototype.CreateLinkElement = function (context) {
                var _this = this;
                var linkText = context.resources.getString(OfficeProductivity.ControlConstants.LINK_TEXT_KEY);
                var link = context.factory.createElement("HYPERLINK", {
                    id: OfficeProductivity.ControlConstants.LINK_TEXT_ID,
                    key: OfficeProductivity.ControlConstants.LINK_TEXT_ID,
                    role: "link",
                    target: "_blank",
                    tabIndex: 0,
                    onclick: function (event) { return _this.logTelemetry(event); },
                    href: OfficeProductivity.ControlConstants.LINK_VALUE,
                    title: linkText,
                    accessibilityLabel: linkText,
                    style: {
                        textDecoration: "none",
                        color: "#4275b2"
                    },
                }, linkText);
                var dialogSubheading = context.factory.createElement("LABEL", {
                    id: OfficeProductivity.ControlConstants.DIALOG_SUBHEADING_ID,
                    key: OfficeProductivity.ControlConstants.DIALOG_SUBHEADING_ID
                }, [context.resources.getString(OfficeProductivity.ControlConstants.DIALOG_SUBHEADING_KEY).replace("{0}", ""), link]);
                return context.factory.createElement("CONTAINER", {
                    id: OfficeProductivity.ControlConstants.DIALOG_SUBHEADING_ID + "_container",
                    key: OfficeProductivity.ControlConstants.DIALOG_SUBHEADING_ID + "_container",
                    style: {
                        marginTop: '10px',
                        marginBottom: '10px',
                        width: "100%",
                        "white-space": 'normal'
                    }
                }, [dialogSubheading]);
            };
            /* utility to log telemetry for link click */
            LinkControlUtil.prototype.logTelemetry = function (event) {
                // log telemetry for this activity
                var parameters = [
                    { name: OfficeProductivity.ControlConstants.ComponentName, value: OfficeProductivity.ControlConstants.MDD_NAME }
                ];
                this._context.reporting.reportSuccess(OfficeProductivity.ControlConstants.EventGetStartedClicked, parameters);
            };
            return LinkControlUtil;
        }());
        OfficeProductivity.LinkControlUtil = LinkControlUtil;
    })(OfficeProductivity = MscrmControls.OfficeProductivity || (MscrmControls.OfficeProductivity = {}));
})(MscrmControls || (MscrmControls = {}));
;
//# sourceMappingURL=NestedLinkControl.js.map