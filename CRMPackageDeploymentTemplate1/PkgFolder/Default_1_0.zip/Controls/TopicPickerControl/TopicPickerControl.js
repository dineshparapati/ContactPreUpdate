/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TopicPickerControl;
    (function (TopicPickerControl_1) {
        "use strict";
        var TopicPickerControl = (function () {
            function TopicPickerControl() {
            }
            TopicPickerControl.prototype.init = function (context, notifyOutputChanged, state, container) {
            };
            TopicPickerControl.prototype.updateView = function (context) {
            };
            TopicPickerControl.prototype.getOutputs = function () {
            };
            TopicPickerControl.prototype.destroy = function () {
            };
            return TopicPickerControl;
        }());
        TopicPickerControl_1.TopicPickerControl = TopicPickerControl;
    })(TopicPickerControl = MscrmControls.TopicPickerControl || (MscrmControls.TopicPickerControl = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=TopicPickerControl.js.map