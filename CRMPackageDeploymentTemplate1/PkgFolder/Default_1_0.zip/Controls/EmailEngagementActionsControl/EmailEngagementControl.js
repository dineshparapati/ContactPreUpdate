/// <reference path="../../../../jsreferences/internal/TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../jsreferences/internal/TypeDefinitions/mscrmcomponents.d.ts" />
/// <reference path="../../../../jsreferences/external/TypeDefinitions/jquery.d.ts" />
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * IMPORTANT!
 * DO NOT MAKE CHANGES TO THIS FILE - THIS FILE IS AUTO-GENERATED FROM ODATA CSDL METADATA DOCUMENT
 * SEE https://msdn.microsoft.com/en-us/library/mt607990.aspx FOR MORE INFORMATION
 */
//import { ODataContract, ODataContractMetadata } from "Storage/DataSource/WebAPISerialization/ODataRequest";
/* tslint:disable:crm-force-fields-private */
var Sdk;
(function (Sdk) {
    var GetBestTimeToEmailRequest = (function () {
        function GetBestTimeToEmailRequest(entityReferenceCollection) {
            this.EntityReferenceCollection = entityReferenceCollection;
        }
        GetBestTimeToEmailRequest.prototype.getMetadata = function () {
            var metadata = {
                boundParameter: null,
                parameterTypes: {
                    "EntityReferenceCollection": {
                        "typeName": "mscrm.crmbaseentity",
                        "structuralProperty": 4
                    }
                },
                operationName: "BestTimeToEmail",
                operationType: 0
            };
            return metadata;
        };
        return GetBestTimeToEmailRequest;
    }());
    Sdk.GetBestTimeToEmailRequest = GetBestTimeToEmailRequest;
})(Sdk || (Sdk = {}));
/**
 * This code was generated from a script.
 * Manual changes to this file will be overwritten if the code is regenerated.
 *
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../jsreferences/internal/TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../jsreferences/internal/TypeDefinitions/XrmClientApi.d.ts" />
/// <reference path="../../../../jsreferences/internal/TypeDefinitions/lib.es6.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var EmailEngagement;
    (function (EmailEngagement) {
        'use strict';
        var EmailEngagementActionsControl = (function () {
            /**
             * Empty constructor.
             */
            function EmailEngagementActionsControl() {
                this.isContentLoaded = false;
                this.recipientPreferences = [];
                this._reminderInvalidated = false;
                this.delaySetActive = false;
                this.delayNotSetActive = false;
                this.schedulerControlsList = [];
                this._delayTimeLoaded = false;
                this._isEmailSent = false;
                this._isAnyNonFollowableRecipient = false;
                this.removeDelayFunctionHandler = this.setDelayFocus.bind(this);
                this.removeReminderFunctionHandler = this.setReminderFocus.bind(this);
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            EmailEngagementActionsControl.prototype.init = function (context, notifyOutputChanged, state) {
                // custom code goes here
                this._context = context;
                if (this._context.mode.isOffline) {
                    return;
                }
                else {
                    //For a new Email
                    this.isContentLoaded = false;
                    this._directionCode = this._context.parameters.directioncode.raw;
                    this._statusCode = this._context.parameters.statuscode.raw;
                    this._emailReminderText = this._context.parameters.emailremindertext ? this._context.parameters.emailremindertext.raw : null;
                    this._emailReminderType = this._context.parameters.emailremindertype.raw ? this._context.parameters.emailremindertype.raw : this._context.parameters.emailremindertype.attributes.DefaultValue;
                    this._emailReminderStatus = this._context.parameters.emailreminderstatus.raw;
                    this._delayedEmailSendtime = this._context.parameters.delayedemailsendtime ? this._context.parameters.delayedemailsendtime.raw : null;
                    this._emailReminderExpiryTime = this._context.parameters.emailreminderexpirytime ? this._context.parameters.emailreminderexpirytime.raw : null;
                    this._isEmailFollowed = this._context.parameters.isemailfollowed.raw ? this._context.parameters.isemailfollowed.raw : this._context.parameters.isemailfollowed.attributes.DefaultValue;
                    this._followEmailUserPreference = this._context.parameters.followemailuserpreference.raw;
                    this._ccParams = this._context.parameters.ccparams.raw;
                    this._toParams = this._context.parameters.toparams.raw;
                    this.checkEntityPreferenceForRecipients();
                    if (this._directionCode) {
                        if (MscrmCommon.ControlUtils.String.isNullOrEmpty(this._context.page.entityId)) {
                            this._isEmailFollowed = true;
                            this._followEmailUserPreference = true;
                        }
                    }
                    if (this._statusCode && this._statusCode !== 1)
                        this._isEmailSent = true;
                    var date_now = this.getTimeInUserPrefTimeZone(new Date());
                    this.suggestedDelaySendTime = date_now;
                    this.infoIconUrl = this._context.resources.getString("CustomControl_EmailEngagement_Email_recipient_Info_Link");
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                    if (MscrmCommon.ControlUtils.String.isNullOrEmpty(this._context.page.entityId))
                        this._notifyOutputChanged();
                }
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            EmailEngagementActionsControl.prototype.updateView = function (context) {
                this._context = context;
                if (this._context.mode.isOffline) {
                    var controls = [];
                    return this.createContainerWithControls(controls, "dummyView");
                }
                else {
                    if (!this._initialize(context)) {
                        var controls_1 = [];
                        controls_1.push(this.tempVDomContainer());
                        return this.createContainerWithControls(controls_1, "tempPage");
                    }
                    var controls = [];
                    controls.push(this.sectionHeader());
                    controls.push(this.createEmailRecepientSection(this._isEmailFollowed));
                    controls.push(this.createEmailSchedulerSection());
                    controls.push(this.createReminderSection());
                    return this.createContainerWithControls(controls, "completePage");
                }
            };
            /**
             * This function will create a temporary DOM
             */
            EmailEngagementActionsControl.prototype.tempVDomContainer = function () {
                var imginfoControl;
                var imginfoControlContainer = this._context.factory.createElement("CONTAINER", {
                    id: "tempControlContainer_id",
                    key: "tempControlContainer_key",
                    style: {
                        fontSize: "24px",
                        color: "#003399"
                    }
                }, imginfoControl);
                return imginfoControlContainer;
            };
            /**
              * Generates container element for passed array with controls
              * @param controls - array with elements which are need to be wrapped
              * @param containerSuffix - suffix for the container id and key
              * @returns container element with passed controls
              */
            EmailEngagementActionsControl.prototype.createContainerWithControls = function (controls, containerSuffix) {
                var orgId = this.getCrmOrganizationId(this._context);
                var emailActionLoaded = new EmailEngagementActionEntryPoint("Email Engagement Actions Loaded", orgId);
                this._context.reporting.reportEvent(emailActionLoaded);
                return this._context.factory.createElement("CONTAINER", {
                    key: "containerWithControls" + containerSuffix,
                    id: "containerWithControls" + containerSuffix,
                    style: {
                        flexDirection: "column",
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%"
                    }
                }, controls);
            };
            // On Update view, reinitialized the components of Page that have changed due to change in passed parameters. return true if updateView is needed
            EmailEngagementActionsControl.prototype._initialize = function (context) {
                if ((MscrmCommon.ControlUtils.Object.isNullOrUndefined(context.parameters.ccparams) ? true : MscrmCommon.ControlUtils.Object.isNullOrUndefined(context.parameters.ccparams.raw))
                    || (MscrmCommon.ControlUtils.Object.isNullOrUndefined(context.parameters.toparams) ? true : MscrmCommon.ControlUtils.Object.isNullOrUndefined(context.parameters.toparams.raw))) {
                    return false;
                }
                if ((this._toParams.length !== context.parameters.toparams.raw.length) || (this._ccParams.length !== context.parameters.ccparams.raw.length)) {
                    this._ccParams = context.parameters.ccparams.raw;
                    this._toParams = context.parameters.toparams.raw;
                    this._delayTimeLoaded = false;
                    this.ManageFollowRelatedStates();
                }
                return true;
            };
            /**
             * This function will create the section header
             */
            EmailEngagementActionsControl.prototype.sectionHeader = function () {
                var headerLabel = this._context.factory.createElement("LABEL", {
                    id: "header_label",
                    key: "header_label",
                    style: {
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        borderBottom: this._context.theming.borders.border02,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontWeight: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.basecolor.black,
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        display: "block",
                        width: "100%"
                    }
                }, this._context.resources.getString("CustomControl_EmailEngagement_Section_Header_Label"));
                return this._context.factory.createElement("CONTAINER", {
                    key: "header_Container",
                    id: "header_Container"
                }, headerLabel);
            };
            /**
             * This function will receive email preference
             * It will set the control for email recepient section based on the preference
             * @param preference
             */
            EmailEngagementActionsControl.prototype.createEmailRecepientSection = function (preference) {
                var controlsList = [];
                if (this._followEmailUserPreference) {
                    this.SetEmailFollowed(this._followEmailUserPreference && preference);
                }
                if (this.emailFollowPrefrence && this._followEmailUserPreference) {
                    controlsList = controlsList.concat(this.emailFollowSection());
                }
                else if (!this.emailFollowPrefrence && this._followEmailUserPreference) {
                    if (this._isAnyNonFollowableRecipient) {
                        controlsList = controlsList.concat(this.emailOtherEntityPreferenceSection());
                    }
                    else {
                        controlsList = controlsList.concat(this.emailPreferenceSection());
                    }
                }
                else {
                    controlsList = controlsList.concat(this.emailUnFollowSection());
                }
                return this._context.factory.createElement("CONTAINER", {
                    key: "create_email_Container",
                    id: "create_email_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        paddingBottom: this._context.theming.measures.measure100,
                        paddingTop: this._context.theming.measures.measure100,
                        borderBottom: this._context.theming.borders.border02
                    }
                }, controlsList);
            };
            /**
             * This function will set email follow status and handles the linked behaviour
             */
            EmailEngagementActionsControl.prototype.SetEmailFollowed = function (follow) {
                this.emailFollowPrefrence = follow;
            };
            /**
             * This function will create a Email follow section for Email Recepient
             */
            EmailEngagementActionsControl.prototype.emailFollowSection = function () {
                var recepientIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "e_follow_img_recepient",
                    key: "e_follow_img_recepient",
                    type: 64,
                    altText: "Email_UnFollow_Image",
                    style: {
                        padding: this._context.theming.measures.measure075,
                        color: this._context.theming.colors.whitebackground,
                        fontSize: "16px"
                    }
                });
                var recepientIconWrapper = this._context.factory.createElement("CONTAINER", {
                    id: "e_follow_img_Wrapper",
                    key: "e_follow_img_Wrapper",
                    style: {
                        backgroundColor: this._context.theming.colors.statuscolor.alert2.fill,
                        borderRadius: "50%",
                        height: "37px"
                    }
                }, recepientIcon);
                var recepientInfo = this._context.factory.createElement("CONTAINER", {
                    key: "e_follow_content",
                    id: "e_follow_content",
                    style: {
                        flexGrow: "1",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        paddingLeft: this._context.theming.measures.measure075,
                        paddingRight: this._context.theming.measures.measure075
                    }
                }, this.followRecepientSection());
                return this._context.factory.createElement("CONTAINER", {
                    key: "e_follow_Container",
                    id: "e_follow_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        justifyContent: "space-between",
                        display: "flex",
                        width: "100%"
                    }
                }, [recepientIconWrapper, recepientInfo]);
            };
            /**
             * This function will create UI container for Email follow section
             */
            EmailEngagementActionsControl.prototype.followRecepientSection = function () {
                var recepientInfoLabel = this._context.resources.getString("CustomControl_EmailEngagement_Recepient_Activity_Follow");
                var followStatusLabel = this._context.resources.getString("CustomControl_EmailEngagement_Dont_Follow_Btn");
                var infoIconToolTip = this._context.resources.getString("CustomControl_EmailEngagement_Recipient_Tooltip");
                var infoIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "email_follow_info_icon",
                    key: "email_follow_info_icon",
                    type: 181,
                    altText: "Email_follow_Info_Icon",
                    style: {
                        margin: "auto",
                        color: "#0059B2",
                        paddingLeft: "5px"
                    }
                });
                var infoIconLink = this._context.factory.createElement("HYPERLINK", {
                    id: "email_follow_info_icon_link",
                    key: "email_follow_info_icon_link",
                    target: "_new",
                    tabIndex: 0,
                    href: this.infoIconUrl,
                    role: "link",
                    accessibilityLabel: infoIconToolTip,
                    style: {
                        textDecoration: "none"
                    }
                }, [infoIcon]);
                var recepientInfoWrapper = this._context.factory.createElement("LABEL", {
                    id: "recepient_label_follow",
                    key: "recepient_label_follow",
                    accessibilityLabel: recepientInfoLabel,
                    accessibilityLive: "assertive",
                    accessibilityRelevant: "all",
                    accessibilityAtomic: true,
                    style: {
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontWeight: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.basecolor.black,
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        display: "block",
                        width: "100%"
                    }
                }, [recepientInfoLabel, infoIconLink]);
                var followSection = this._context.factory.createElement("BUTTON", {
                    id: "follow_label",
                    key: "follow_label",
                    role: "link",
                    disabled: this._isEmailSent ? true : false,
                    tabIndex: 0,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.basecolor.blue["blue4"],
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        display: "block",
                        width: "50%",
                        cursor: this._isEmailSent ? "not-allowed" : "pointer",
                        background: "none",
                        border: "none",
                        padding: "0",
                        textAlign: "left",
                        ":focus": {
                            border: "1px solid #e2e2e2"
                        }
                    },
                    onClick: this.unfollowClickHandler.bind(this)
                }, followStatusLabel);
                return this._context.factory.createElement("CONTAINER", {
                    key: "recepient_follow_InfoContainer",
                    id: "recepient_follow_InfoContainer",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        flexDirection: "column"
                    }
                }, [recepientInfoWrapper, followSection]);
            };
            /**
             * This function will retry follow click handler
             */
            EmailEngagementActionsControl.prototype.retryFollowClickHandler = function () {
                this.ManageFollowRelatedStates();
            };
            /**
             * This function will handle unfollow button click functionality
             */
            EmailEngagementActionsControl.prototype.unfollowClickHandler = function () {
                var _this = this;
                var confirmFollowLabels = { title: this._context.resources.getString("CustomControl_EmailEngagement_Recipient_Unfollow_MDD"), text: this._context.resources.getString("CustomControl_EmailEngagement_Recipient_Unfollow_MDD_Description"), cancelButtonLabel: this._context.resources.getString("CustomControl_EmailEngagement_Cancel_Btn"), confirmButtonLabel: this._context.resources.getString("CustomControl_EmailEngagement_Ok_Btn") };
                var promise = this._context.navigation.openConfirmDialog(confirmFollowLabels, null);
                promise.then(function (result) {
                    if (result && result.confirmed) {
                        _this._followEmailUserPreference = false;
                        _this.ManageFollowRelatedStates();
                    }
                }, function (error) {
                    console.log(error);
                });
            };
            /**
             * This function renders the control based on the follow preferences
             */
            EmailEngagementActionsControl.prototype.ManageFollowRelatedStates = function () {
                var responseData;
                this.recipientPreferences = [];
                var promise = this.getPreferences();
                var that = this;
                promise.then(function () {
                    var preference = true;
                    var viewPrefs = that.getRecipientPreferences();
                    if (viewPrefs.length == 0) {
                        that._isEmailFollowed = true;
                    }
                    else {
                        for (var i = 0; i < viewPrefs.length; i++) {
                            preference = preference && (viewPrefs[i].emailPreference);
                        }
                        that._isEmailFollowed = preference;
                    }
                    that._notifyOutputChanged();
                    that.renderControl(true);
                    if (that._followEmailUserPreference) {
                        that._context.accessibility.focusElementById("follow_label");
                    }
                    else {
                        that._context.accessibility.focusElementById("unfollow_pref_label");
                    }
                }, function (rejectReason) {
                    console.log(rejectReason);
                });
            };
            /*
            * Function to check Entity preference for recipients
            */
            EmailEngagementActionsControl.prototype.checkEntityPreferenceForRecipients = function () {
                var toRecipient = [];
                var ccRecipient = [];
                var isAnyNonFollowableToRecipient = false;
                var isAnyNonFollowableCcRecipient = false;
                this._isAnyNonFollowableRecipient = false;
                if (this._toParams) {
                    if (typeof this._toParams.get_entities === "undefined") {
                        toRecipient = this._toParams;
                    }
                    else {
                        toRecipient = this._toParams.get_entities();
                    }
                }
                if (this._ccParams) {
                    if (typeof this._ccParams.get_entities === "undefined") {
                        ccRecipient = this._ccParams;
                    }
                    else {
                        ccRecipient = this._ccParams.get_entities();
                    }
                }
                isAnyNonFollowableToRecipient = this.OtherEntityCheckForRecipients(toRecipient);
                isAnyNonFollowableCcRecipient = this.OtherEntityCheckForRecipients(ccRecipient);
                if (isAnyNonFollowableToRecipient || isAnyNonFollowableCcRecipient) {
                    var recipientResponse = {};
                    recipientResponse.emailPreference = false;
                    this.setRecipientPreferences(recipientResponse);
                    this._isAnyNonFollowableRecipient = true;
                }
            };
            /*
            * Function handles the to and cc field and segregates entities based on their values and return a promise to viewPreferencesClickHandler
            */
            EmailEngagementActionsControl.prototype.getPreferences = function () {
                var accountIdsConditionalValues = "";
                var contactIdsConditionalValues = "";
                var leadIdsConditionalValues = "";
                var participatingEntitiesCount = 0;
                var completedCount = 0;
                var toRecipient = [];
                var ccRecipient = [];
                var isAnyNonFollowableToRecipient = false;
                var isAnyNonFollowableCcRecipient = false;
                this._isAnyNonFollowableRecipient = false;
                if (this._toParams) {
                    if (typeof this._toParams.get_entities === "undefined") {
                        toRecipient = this._toParams;
                    }
                    else {
                        toRecipient = this._toParams.get_entities();
                    }
                }
                if (this._ccParams) {
                    if (typeof this._ccParams.get_entities === "undefined") {
                        ccRecipient = this._ccParams;
                    }
                    else {
                        ccRecipient = this._ccParams.get_entities();
                    }
                }
                isAnyNonFollowableToRecipient = this.OtherEntityCheckForRecipients(toRecipient);
                isAnyNonFollowableCcRecipient = this.OtherEntityCheckForRecipients(ccRecipient);
                if (isAnyNonFollowableToRecipient || isAnyNonFollowableCcRecipient) {
                    var recipientResponse = {};
                    recipientResponse.emailPreference = false;
                    this.setRecipientPreferences(recipientResponse);
                    this._isAnyNonFollowableRecipient = true;
                    return window.Promise.resolve();
                }
                if (toRecipient != null) {
                    var recipientToList = this.SegregateRecipients(toRecipient, accountIdsConditionalValues, contactIdsConditionalValues, leadIdsConditionalValues, participatingEntitiesCount);
                    accountIdsConditionalValues = accountIdsConditionalValues + recipientToList["account"];
                    contactIdsConditionalValues = contactIdsConditionalValues + recipientToList["contact"];
                    leadIdsConditionalValues = leadIdsConditionalValues + recipientToList["lead"];
                }
                if (ccRecipient != null) {
                    var recipientCcList = this.SegregateRecipients(ccRecipient, accountIdsConditionalValues, contactIdsConditionalValues, leadIdsConditionalValues, participatingEntitiesCount);
                    accountIdsConditionalValues = accountIdsConditionalValues + recipientCcList["account"];
                    contactIdsConditionalValues = contactIdsConditionalValues + recipientCcList["contact"];
                    leadIdsConditionalValues = leadIdsConditionalValues + recipientCcList["lead"];
                }
                var accountFetchXml = this.fetchXMLForEntities("account", "followemail", "name", "accountid", accountIdsConditionalValues);
                var contactFetchXml = this.fetchXMLForEntities("contact", "followemail", "fullname", "contactid", contactIdsConditionalValues);
                var leadFetchXml = this.fetchXMLForEntities("lead", "followemail", "subject", "leadid", leadIdsConditionalValues);
                var promises = [];
                if (accountIdsConditionalValues != "") {
                    promises.push(this.getAccountPromise(accountFetchXml));
                }
                if (contactIdsConditionalValues != "") {
                    promises.push(this.getContactPromise(contactFetchXml));
                }
                if (leadIdsConditionalValues != "") {
                    promises.push(this.getLeadPromise(leadFetchXml));
                }
                this._returnPreferencesPromise = Promise.all(promises);
                return this._returnPreferencesPromise;
            };
            /*
            * Method to check if the recipient is not related to account, contact, lead entities
            * @reciepient : to/cc field value.
            */
            EmailEngagementActionsControl.prototype.OtherEntityCheckForRecipients = function (recipient) {
                if (recipient != null) {
                    for (var i = 0; i < recipient.length; i++) {
                        if (recipient[i].fields) {
                            if (recipient[i].fields.partyid.TypeName !== "account" && recipient[i].fields.partyid.TypeName !== "contact" && recipient[i].fields.partyid.TypeName !== "lead") {
                                return true;
                            }
                        }
                        else {
                            if (recipient[i]._etn !== "account" && recipient[i]._etn !== "contact" && recipient[i]._etn !== "lead") {
                                return true;
                            }
                        }
                    }
                }
                return false;
            };
            /*
            * SegregateRecipients differntiates the entities (account,contact, lead) based on the to and cc field
            * @reciepient : to/cc field value.
            * @accountIdsConditionalValues: used to build the account entity fetch xml
            * @contactIdsConditionalValues: used to build the contact entity fetch xml
            * @leadIdsConditionalValues: used to build the lead entity fetch xml
            * @participatingEntitiesCount: gives the no.of entities present in the to and cc field.
            */
            EmailEngagementActionsControl.prototype.SegregateRecipients = function (recipient, accountIdsConditionalValues, contactIdsConditionalValues, leadIdsConditionalValues, participatingEntitiesCount) {
                var recipientList = {};
                if (recipient != null) {
                    for (var i = 0; i < recipient.length; i++) {
                        if (recipient[i].fields) {
                            if (recipient[i].fields.partyid.TypeName == "account") {
                                participatingEntitiesCount = accountIdsConditionalValues == "" ? participatingEntitiesCount + 1 : participatingEntitiesCount;
                                // fill accIds
                                accountIdsConditionalValues = accountIdsConditionalValues + "<value>" + recipient[i].fields.partyid.Id.toString() + "</value>";
                            }
                            else if (recipient[i].fields.partyid.TypeName == "contact") {
                                participatingEntitiesCount = contactIdsConditionalValues == "" ? participatingEntitiesCount + 1 : participatingEntitiesCount;
                                // fill contactIds
                                contactIdsConditionalValues = contactIdsConditionalValues + "<value>" + recipient[i].fields.partyid.Id.toString() + "</value>";
                            }
                            else if (recipient[i].fields.partyid.TypeName == "lead") {
                                participatingEntitiesCount = leadIdsConditionalValues == "" ? participatingEntitiesCount + 1 : participatingEntitiesCount;
                                // fill leadIds
                                leadIdsConditionalValues = leadIdsConditionalValues + "<value>" + recipient[i].fields.partyid.Id.toString() + "</value>";
                            }
                        }
                        else {
                            if (recipient[i]._etn == "account") {
                                participatingEntitiesCount = accountIdsConditionalValues == "" ? participatingEntitiesCount + 1 : participatingEntitiesCount;
                                // fill accIds
                                accountIdsConditionalValues = accountIdsConditionalValues + "<value>" + recipient[i]._id.toString() + "</value>";
                            }
                            else if (recipient[i]._etn == "contact") {
                                participatingEntitiesCount = contactIdsConditionalValues == "" ? participatingEntitiesCount + 1 : participatingEntitiesCount;
                                // fill contactIds
                                contactIdsConditionalValues = contactIdsConditionalValues + "<value>" + recipient[i]._id + "</value>";
                            }
                            else if (recipient[i]._etn == "lead") {
                                participatingEntitiesCount = leadIdsConditionalValues == "" ? participatingEntitiesCount + 1 : participatingEntitiesCount;
                                // fill leadIds
                                leadIdsConditionalValues = leadIdsConditionalValues + "<value>" + recipient[i]._id.toString() + "</value>";
                            }
                        }
                    }
                    recipientList["account"] = accountIdsConditionalValues;
                    recipientList["contact"] = contactIdsConditionalValues;
                    recipientList["lead"] = leadIdsConditionalValues;
                    recipientList["participatingEntitiesCount"] = participatingEntitiesCount;
                }
                return recipientList;
            };
            /*
            * fetchXMLForEntities generates the fetch xml string based on the input values
            * @entity: describes the entity i.e either account/contact/lead
            * @followemail: boolean value either true/false
            * @nameId : name differs for each entity, for contact nameId: fullname, for account nameId: name and for Lead nameId: subject
            * @entityId: entityid describes the id of the entity accountid/contactid/leadid
            * @entityValue: which we generates from the SegregateRecipients
            */
            EmailEngagementActionsControl.prototype.fetchXMLForEntities = function (entity, followemail, nameId, entityId, entityValue) {
                return "<fetch version='1.0' mapping='logical' distinct='true'><entity name='" + entity + "'><attribute name='" + followemail + "' /><attribute name='" + nameId + "' /><attribute name='" + entityId + "' /><filter type='and'><condition attribute='" + entityId + "' operator='in'>" + entityValue + "</condition></filter></entity></fetch>";
            };
            EmailEngagementActionsControl.prototype.setRecipientPreferences = function (recipient) {
                this.recipientPreferences.push(recipient);
            };
            EmailEngagementActionsControl.prototype.getContactPromise = function (contactFetchXml) {
                var that = this;
                return this._context.webAPI.retrieveMultipleRecords("contact", "?fetchXml=" + contactFetchXml).then(function (data) {
                    var orgId = that.getCrmOrganizationId(that._context);
                    var retrieveRecordsAction = new ActionOnEmailEngagementActions("Retrieving leads data", "success", orgId);
                    that._context.reporting.reportEvent(retrieveRecordsAction);
                    var entities = data.entities;
                    if (entities.length > 0) {
                        for (var i = 0; i < entities.length; i++) {
                            if (entities[i].hasOwnProperty("followemail")) {
                                var recipientResponse = {};
                                recipientResponse.entityName = "contact";
                                recipientResponse.entityDisplayName = entities[i].fullname.toString();
                                recipientResponse.entityId = entities[i].contactid.toString();
                                recipientResponse.emailPreference = (entities[i].followemail);
                                that.setRecipientPreferences(recipientResponse);
                            }
                        }
                    }
                }, function (rejectReason) {
                    var orgId = that.getCrmOrganizationId(that._context);
                    var retrieveRecordsAction = new ActionOnEmailEngagementActions("Retrieving contacts data", "failed", orgId);
                    that._context.reporting.reportEvent(retrieveRecordsAction);
                    console.log("rejected promise contactIdsConditionalValues multiple records ", rejectReason);
                });
            };
            EmailEngagementActionsControl.prototype.getAccountPromise = function (accountFetchXml) {
                var that = this;
                return this._context.webAPI.retrieveMultipleRecords("account", "?fetchXml=" + accountFetchXml).then(function (data) {
                    var orgId = that.getCrmOrganizationId(that._context);
                    var retrieveRecordsAction = new ActionOnEmailEngagementActions("Retrieving accounts data", "success", orgId);
                    that._context.reporting.reportEvent(retrieveRecordsAction);
                    var entities = data.entities;
                    if (entities.length > 0) {
                        for (var i = 0; i < entities.length; i++) {
                            if (entities[i].hasOwnProperty("followemail")) {
                                var recipientResponse = {};
                                recipientResponse.entityName = "account";
                                recipientResponse.entityDisplayName = entities[i].name.toString();
                                recipientResponse.entityId = entities[i].accountid.toString();
                                recipientResponse.emailPreference = (entities[i].followemail);
                                that.setRecipientPreferences(recipientResponse);
                            }
                        }
                    }
                }, function (rejectReason) {
                    var orgId = that.getCrmOrganizationId(that._context);
                    var retrieveRecordsAction = new ActionOnEmailEngagementActions("Retrieving accounts data", "failed", orgId);
                    that._context.reporting.reportEvent(retrieveRecordsAction);
                    console.log("rejected promise accountIdsConditionalValues multiple records ", rejectReason);
                });
            };
            EmailEngagementActionsControl.prototype.getLeadPromise = function (leadFetchXml) {
                var that = this;
                return this._context.webAPI.retrieveMultipleRecords("lead", "?fetchXml=" + leadFetchXml).then(function (data) {
                    var orgId = that.getCrmOrganizationId(that._context);
                    var retrieveRecordsAction = new ActionOnEmailEngagementActions("Retrieving leads data", "success", orgId);
                    that._context.reporting.reportEvent(retrieveRecordsAction);
                    var entities = data.entities;
                    if (entities.length > 0) {
                        for (var i = 0; i < entities.length; i++) {
                            if (entities[i].hasOwnProperty("followemail")) {
                                var recipientResponse = {};
                                recipientResponse.entityName = "lead";
                                recipientResponse.entityDisplayName = entities[i].subject.toString();
                                recipientResponse.entityId = entities[i].leadid.toString();
                                recipientResponse.emailPreference = (entities[i].followemail);
                                that.setRecipientPreferences(recipientResponse);
                            }
                        }
                    }
                }, function (rejectReason) {
                    var orgId = that.getCrmOrganizationId(that._context);
                    var retrieveRecordsAction = new ActionOnEmailEngagementActions("Retrieving leads data", "failed", orgId);
                    that._context.reporting.reportEvent(retrieveRecordsAction);
                    console.log("rejected promise LeadIdsConditionalValues multiple records ", rejectReason);
                });
            };
            EmailEngagementActionsControl.prototype.getRecipientPreferences = function () {
                return this.recipientPreferences || [];
            };
            /**
             * This function will create a Email other entity preferences section for Email Recepient
             */
            EmailEngagementActionsControl.prototype.emailOtherEntityPreferenceSection = function () {
                var recepientIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "e_other_pref_img_recepient",
                    key: "e_other_pref_img_recepient",
                    type: 64,
                    altText: "Email_UnFollow_Image",
                    style: {
                        padding: this._context.theming.measures.measure075,
                        color: this._context.theming.colors.whitebackground,
                        fontSize: "16px"
                    }
                });
                var recepientIconWrapper = this._context.factory.createElement("CONTAINER", {
                    id: "e_other_pref_img_Wrapper",
                    key: "e_other_pref_img_Wrapper",
                    style: {
                        //alert2 changed
                        backgroundColor: this._context.theming.colors.statuscolor.alert2.fill,
                        borderRadius: "50%",
                        height: "37px"
                    }
                }, recepientIcon);
                var recepientInfo = this._context.factory.createElement("CONTAINER", {
                    key: "e_other_pref_content",
                    id: "e_other_pref_content",
                    style: {
                        flexGrow: "1",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        paddingLeft: this._context.theming.measures.measure075,
                        paddingRight: this._context.theming.measures.measure075
                    }
                }, this.otherEntityPreferenceRecepientSection());
                return this._context.factory.createElement("CONTAINER", {
                    key: "e_other_pref_Container",
                    id: "e_other_pref_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        justifyContent: "space-between",
                        display: "flex"
                    }
                }, [recepientIconWrapper, recepientInfo]);
            };
            /**
             * This function will create a Email preferences section for Email Recepient
             */
            EmailEngagementActionsControl.prototype.emailPreferenceSection = function () {
                var recepientIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "e_pref_img_recepient",
                    key: "e_pref_img_recepient",
                    type: 64,
                    altText: "Email_UnFollow_Image",
                    style: {
                        padding: this._context.theming.measures.measure075,
                        color: this._context.theming.colors.whitebackground,
                        fontSize: "16px"
                    }
                });
                var recepientIconWrapper = this._context.factory.createElement("CONTAINER", {
                    id: "e_pref_img_Wrapper",
                    key: "e_pref_img_Wrapper",
                    style: {
                        //alert2 changed
                        backgroundColor: this._context.theming.colors.statuscolor.alert2.fill,
                        borderRadius: "50%",
                        height: "37px"
                    }
                }, recepientIcon);
                var recepientInfo = this._context.factory.createElement("CONTAINER", {
                    key: "e_pref_content",
                    id: "e_pref_content",
                    style: {
                        flexGrow: "1",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        paddingLeft: this._context.theming.measures.measure075,
                        paddingRight: this._context.theming.measures.measure075
                    }
                }, this.followPreferenceRecepientSection());
                return this._context.factory.createElement("CONTAINER", {
                    key: "e_pref_Container",
                    id: "e_pref_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        justifyContent: "space-between",
                        display: "flex"
                    }
                }, [recepientIconWrapper, recepientInfo]);
            };
            /**
             * This function will create UI container for Email other entity Preference section
             */
            EmailEngagementActionsControl.prototype.otherEntityPreferenceRecepientSection = function () {
                var recepientInfoLabel = this._context.resources.getString("CustomControl_EmailEngagement_Recipient_Other_preferences_label");
                var infoIconToolTip = this._context.resources.getString("CustomControl_EmailEngagement_Recipient_Tooltip");
                var infoIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "email_info_icon",
                    key: "email_info_icon",
                    type: 181,
                    altText: "Email_Info_Icon",
                    style: {
                        margin: "auto",
                        color: "#0059B2",
                        paddingLeft: "5px"
                    }
                });
                var infoIconLink = this._context.factory.createElement("HYPERLINK", {
                    id: "email_info_icon_link",
                    key: "eemail_info_icon_link",
                    target: "_new",
                    href: this.infoIconUrl,
                    tabIndex: 0,
                    role: "link",
                    accessibilityLabel: infoIconToolTip,
                    style: {
                        textDecoration: "none"
                    }
                }, [infoIcon]);
                var recepientInfoWrapper = this._context.factory.createElement("LABEL", {
                    id: "recepient_other_label_unfollow",
                    key: "recepient_other_label_unfollow",
                    accessibilityLabel: recepientInfoLabel,
                    accessibilityLive: "assertive",
                    accessibilityRelevant: "all",
                    accessibilityAtomic: true,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        fontWeight: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.basecolor.black,
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis"
                    }
                }, [recepientInfoLabel, infoIconLink]);
                return this._context.factory.createElement("CONTAINER", {
                    key: "recepient_other_pref_InfoContainer",
                    id: "recepient_other_pref_InfoContainer",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        flexDirection: "column"
                    }
                }, [recepientInfoWrapper]);
            };
            /**
             * This function will create UI container for Email Preference section
             */
            EmailEngagementActionsControl.prototype.followPreferenceRecepientSection = function () {
                var recepientInfoLabel = this._context.resources.getString("CustomControl_EmailEngagement_Recipient_preferences_label");
                var preferenceLabel = this._context.resources.getString("CustomControl_EmailEngagement_View_preferences_Btn");
                var retryLabel = this._context.resources.getString("CustomControl_EmailEngagement_Retry_Follow_Btn");
                var unfollowStatusLabel = this._context.resources.getString("CustomControl_EmailEngagement_Dont_Follow_Btn");
                var infoIconToolTip = this._context.resources.getString("CustomControl_EmailEngagement_Recipient_Tooltip");
                var infoIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "email_info_icon",
                    key: "email_info_icon",
                    type: 181,
                    altText: "Email_Info_Icon",
                    style: {
                        margin: "auto",
                        color: "#0059B2",
                        paddingLeft: "5px"
                    }
                });
                var infoIconLink = this._context.factory.createElement("HYPERLINK", {
                    id: "email_info_icon_link",
                    key: "eemail_info_icon_link",
                    target: "_new",
                    href: this.infoIconUrl,
                    tabIndex: 0,
                    role: "link",
                    accessibilityLabel: infoIconToolTip,
                    style: {
                        textDecoration: "none"
                    }
                }, [infoIcon]);
                var recepientInfoWrapper = this._context.factory.createElement("LABEL", {
                    id: "recepient_label_unfollow",
                    key: "recepient_label_unfollow",
                    accessibilityLabel: recepientInfoLabel,
                    accessibilityLive: "assertive",
                    accessibilityRelevant: "all",
                    accessibilityAtomic: true,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        fontWeight: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.basecolor.black,
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis"
                    }
                }, [recepientInfoLabel, infoIconLink]);
                var preferenceSection = this._context.factory.createElement("BUTTON", {
                    id: "preference_label",
                    key: "preference_label",
                    role: "link",
                    tabIndex: 0,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.basecolor.blue["blue4"],
                        paddingRight: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        display: "block",
                        whiteSpace: "nowrap",
                        width: "33%",
                        background: "none",
                        border: "none",
                        padding: "0",
                        textAlign: "left",
                        ":focus": {
                            border: "1px solid #e2e2e2"
                        }
                    },
                    onClick: this.viewPreferencesClickHandler.bind(this)
                }, preferenceLabel);
                var retrySection = this._context.factory.createElement("BUTTON", {
                    id: "retry_label",
                    key: "retry_label",
                    role: "link",
                    disabled: this._isEmailSent ? true : false,
                    tabIndex: 0,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.basecolor.blue["blue4"],
                        paddingRight: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        display: "block",
                        cursor: this._isEmailSent ? "not-allowed" : "pointer",
                        width: "33%",
                        background: "none",
                        border: "none",
                        padding: "0",
                        textAlign: "left",
                        ":focus": {
                            border: "1px solid #e2e2e2"
                        }
                    },
                    onClick: this.retryFollowClickHandler.bind(this)
                }, retryLabel);
                var unfollowSection = this._context.factory.createElement("BUTTON", {
                    id: "follow_label",
                    key: "follow_label",
                    role: "link",
                    disabled: this._isEmailSent ? true : false,
                    tabIndex: 0,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.basecolor.blue["blue4"],
                        paddingRight: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        display: "block",
                        width: "33%",
                        cursor: this._isEmailSent ? "not-allowed" : "pointer",
                        background: "none",
                        border: "none",
                        padding: "0",
                        textAlign: "left",
                        ":focus": {
                            border: "1px solid #e2e2e2"
                        }
                    },
                    onClick: this.unfollowClickHandler.bind(this)
                }, unfollowStatusLabel);
                var recSubContainer = this._context.factory.createElement("CONTAINER", {
                    key: "recepientSubContainer",
                    id: "recepientSubContainer",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground
                    }
                }, [preferenceSection, retrySection, unfollowSection]);
                return this._context.factory.createElement("CONTAINER", {
                    key: "recepient_pref_InfoContainer",
                    id: "recepient_pref_InfoContainer",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        flexDirection: "column"
                    }
                }, [recepientInfoWrapper, recSubContainer]);
            };
            /*
            *This Function handles the click of view preferences link, It will read values from to and cc fields and fetch their preferences using fetch xml
            */
            EmailEngagementActionsControl.prototype.viewPreferencesClickHandler = function () {
                this.recipientPreferences = [];
                var promise = this.getPreferences();
                var that = this;
                promise.then(function () {
                    var dialogOptions = {
                        height: 400,
                        width: 500
                    };
                    var dialogParams = {};
                    var viewPrefs = that.getRecipientPreferences();
                    dialogParams["id_preferences"] = viewPrefs;
                    dialogParams["id_tableHeaderLeft"] = "Recipient Name";
                    dialogParams["id_tableHeaderRight"] = "Email Activity Preference";
                    dialogParams["id_followText"] = "Allow";
                    dialogParams["id_donotFollowText"] = "Do not allow";
                    that._context.navigation.openDialog("ContactPreferencesControl", dialogOptions, dialogParams).then(function (response) {
                        that._context.accessibility.focusElementById("preference_label");
                    }, function (error) {
                        console.log(error);
                    });
                }, function (rejectReason) {
                    console.log(rejectReason);
                });
            };
            /**
             * This function will create a Email unfollow section for Email Recepient
             */
            EmailEngagementActionsControl.prototype.emailUnFollowSection = function () {
                var recepientIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "e_unfollow_img_recepient",
                    key: "e_unfollow_img_recepient",
                    type: 64,
                    altText: "Email_UnFollow_Image",
                    style: {
                        padding: this._context.theming.measures.measure075,
                        color: this._context.theming.colors.whitebackground,
                        fontSize: "16px"
                    }
                });
                var recepientIconWrapper = this._context.factory.createElement("CONTAINER", {
                    id: "e_unfollow_img_Wrapper",
                    key: "e_unfollow_img_Wrapper",
                    style: {
                        backgroundColor: this._context.theming.colors.statuscolor.alert2.fill,
                        borderRadius: "50%",
                        height: "37px"
                    }
                }, recepientIcon);
                var recepientInfo = this._context.factory.createElement("CONTAINER", {
                    key: "e_unfollow_content",
                    id: "e_unfollow_content",
                    style: {
                        flexGrow: "1",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        paddingLeft: this._context.theming.measures.measure075,
                        paddingRight: this._context.theming.measures.measure075
                    }
                }, this.unFollowRecepientSection());
                return this._context.factory.createElement("CONTAINER", {
                    key: "e_unfollow_Container",
                    id: "e_unfollow_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        justifyContent: "space-between",
                        display: "flex",
                        width: "100%"
                    }
                }, [recepientIconWrapper, recepientInfo]);
            };
            /**
             * This function will create UI container for Email unfollow section
             */
            EmailEngagementActionsControl.prototype.unFollowRecepientSection = function () {
                var recepientInfoLabel = this._context.resources.getString("CustomControl_EmailEngagement_Recipient_Not_Followed_Description");
                var followStatusLabel = this._context.resources.getString("CustomControl_EmailEngagement_Follow_Btn");
                var infoIconToolTip = this._context.resources.getString("CustomControl_EmailEngagement_Recipient_Tooltip");
                var infoIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "email_unfollow_info_icon",
                    key: "email_unfollow_info_icon",
                    type: 181,
                    altText: "Email_Info_Icon",
                    style: {
                        margin: "auto",
                        color: "#0059B2",
                        paddingLeft: "5px"
                    }
                });
                var infoIconLink = this._context.factory.createElement("HYPERLINK", {
                    id: "email_info_icon_link",
                    key: "eemail_info_icon_link",
                    target: "_new",
                    tabIndex: 0,
                    role: "link",
                    href: this.infoIconUrl,
                    accessibilityLabel: infoIconToolTip,
                    style: {
                        textDecoration: "none"
                    }
                }, [infoIcon]);
                var recepientInfoWrapper = this._context.factory.createElement("LABEL", {
                    id: "recepient_label",
                    key: "recepient_label",
                    accessibilityLabel: recepientInfoLabel,
                    accessibilityLive: "assertive",
                    accessibilityRelevant: "all",
                    accessibilityAtomic: true,
                    style: {
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontWeight: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.basecolor.black,
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        display: "block",
                        width: "100%"
                    }
                }, [recepientInfoLabel, infoIconLink]);
                var followSection = this._context.factory.createElement("BUTTON", {
                    id: "unfollow_pref_label",
                    key: "unfollow_pref_label",
                    role: "link",
                    disabled: this._isEmailSent ? true : false,
                    tabIndex: 0,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.basecolor.blue["blue4"],
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        display: "block",
                        width: "50%",
                        cursor: this._isEmailSent ? "not-allowed" : "pointer",
                        background: "none",
                        border: "none",
                        padding: "0",
                        textAlign: "left",
                        ":focus": {
                            border: "1px solid #e2e2e2"
                        }
                    },
                    onClick: this.followClickHandler.bind(this)
                }, followStatusLabel);
                return this._context.factory.createElement("CONTAINER", {
                    key: "recepient_unfollow_InfoContainer",
                    id: "recepient_unfollow_InfoContainer",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        flexDirection: "column"
                    }
                }, [recepientInfoWrapper, followSection]);
            };
            /**
             * This function will handle follow button click functionality
             */
            EmailEngagementActionsControl.prototype.followClickHandler = function () {
                var _this = this;
                var confirmFollowLabels = { title: this._context.resources.getString("CustomControl_EmailEngagement_Recipient_follow_MDD"), text: this._context.resources.getString("CustomControl_EmailEngagement_Recipient_follow_MDD_Description"), cancelButtonLabel: this._context.resources.getString("CustomControl_EmailEngagement_Cancel_Btn"), confirmButtonLabel: this._context.resources.getString("CustomControl_EmailEngagement_Ok_Btn") };
                var promise = this._context.navigation.openConfirmDialog(confirmFollowLabels, null);
                promise.then(function (result) {
                    if (result && result.confirmed) {
                        _this._followEmailUserPreference = true;
                        _this.ManageFollowRelatedStates();
                    }
                }, function (error) {
                    console.log(error);
                });
            };
            /**
             * This function will set the control for email scheduler section
             */
            EmailEngagementActionsControl.prototype.createEmailSchedulerSection = function () {
                if (this._statusCode && (this._statusCode === 3 || this._statusCode === 2)) {
                    this.schedulerControlsList = [];
                    return this._context.factory.createElement("CONTAINER", {
                        key: "create_schedule_sent_Container",
                        id: "create_schedule_sent_Container"
                    });
                }
                else {
                    if (this._delayedEmailSendtime) {
                        var delay_Time = this._delayedEmailSendtime.localeFormat(this._context.client.dateFormattingInfo.ShortTimePattern.toString());
                        var delay_Date = this._delayedEmailSendtime.localeFormat(this._context.client.dateFormattingInfo.ShortDatePattern.toString());
                        this.delay_Set_innerText = MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("CustomControl_EmailEngagement_Delay_Set_Delivery_Info"), delay_Date, delay_Time);
                        this.schedulerControlsList = [this.schedulerSetSection()];
                    }
                    else {
                        if (!this._delayTimeLoaded)
                            this.enableSuggestionTimeText();
                    }
                    return this._context.factory.createElement("CONTAINER", {
                        key: "create_schedule_Container",
                        id: "create_schedule_Container",
                        style: {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            paddingTop: this._context.theming.measures.measure100,
                            paddingBottom: this._context.theming.measures.measure100,
                            borderBottom: this._context.theming.borders.border02
                        }
                    }, this.schedulerControlsList);
                }
            };
            /**
             * This function will create a delay Set for Scheduler Section
             */
            EmailEngagementActionsControl.prototype.schedulerSetSection = function () {
                var schedulerIcon = this._context.factory.createElement("CRMICON", {
                    id: "img_scheduler_S_recepient",
                    key: "img_scheduler_S_recepient",
                    type: 34,
                    altText: "Email_Scheduler_Image",
                    style: {
                        padding: this._context.theming.measures.measure075,
                        color: this._context.theming.colors.whitebackground,
                        fontSize: "16px"
                    }
                });
                var schedulerIconWrapper = this._context.factory.createElement("CONTAINER", {
                    id: "img_scheduler_S_Wrapper",
                    key: "img_scheduler_S_Wrapper",
                    style: {
                        fontSize: "16px",
                        backgroundColor: this._context.theming.colors.statuscolor.positive2.fill,
                        borderRadius: "50%",
                        height: "37px"
                    }
                }, schedulerIcon);
                var schedulerInfo = this._context.factory.createElement("CONTAINER", {
                    key: "scheduler_S_content",
                    id: "scheduler_S_content",
                    style: {
                        flexGrow: "1",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        paddingLeft: this._context.theming.measures.measure075,
                        paddingRight: this._context.theming.measures.measure075
                    }
                }, this.delaySend_Set());
                return this._context.factory.createElement("CONTAINER", {
                    key: "scheduler_S_Container",
                    id: "scheduler_S_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        justifyContent: "space-between",
                        display: "flex",
                        width: "100%"
                    }
                }, [schedulerIconWrapper, schedulerInfo]);
            };
            /**
             * This function will create UI container for delay Set Element
             */
            EmailEngagementActionsControl.prototype.delaySend_Set = function () {
                var ds_s_innerText = this.delay_Set_innerText;
                var ds_s_changeSchedule_Link = this._context.resources.getString("CustomControl_EmailEngagement_Change_Schedule_Btn");
                var ds_s_reset_delay_Link = this._context.resources.getString("CustomControl_EmailEngagement_Remove_Delay_Btn");
                var ds_s_InfoWrapper = this._context.factory.createElement("LABEL", {
                    id: "ds_s_label",
                    key: "ds_s_label",
                    accessibilityLabel: ds_s_innerText,
                    accessibilityLive: "assertive",
                    accessibilityRelevant: "all",
                    accessibilityAtomic: true,
                    style: {
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontWeight: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.basecolor.black,
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        display: "block",
                        width: "100%"
                    }
                }, ds_s_innerText);
                var ds_s_change_linkSection = this._context.factory.createElement("BUTTON", {
                    id: "ds_s_change_link_label",
                    key: "ds_s_change_link_label",
                    role: "link",
                    tabIndex: 0,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.basecolor.blue["blue4"],
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        width: "50%",
                        display: "block",
                        background: "none",
                        border: "none",
                        padding: "0",
                        textAlign: "left",
                        ":focus": {
                            border: "1px solid #e2e2e2"
                        }
                    },
                    onClick: this.delaySend_ClickHandler.bind(this)
                }, ds_s_changeSchedule_Link);
                var ds_s_reset_linkSection = this._context.factory.createElement("BUTTON", {
                    id: "ds_s_reset_link_label",
                    key: "ds_s_reset_link_label",
                    role: "link",
                    tabIndex: 0,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.basecolor.blue["blue4"],
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        display: "block",
                        width: "50%",
                        background: "none",
                        border: "none",
                        padding: "0",
                        textAlign: "left",
                        ":focus": {
                            border: "1px solid #e2e2e2"
                        }
                    },
                    onClick: this.removeDelay_ClickHandler.bind(this)
                }, ds_s_reset_delay_Link);
                var ds_s_sub_Container = this._context.factory.createElement("CONTAINER", {
                    key: "ds_s_sub_Container",
                    id: "ds_s_sub_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground
                    }
                }, [ds_s_change_linkSection, ds_s_reset_linkSection]);
                return this._context.factory.createElement("CONTAINER", {
                    key: "delaySend_S_Container",
                    id: "delaySend_S_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        flexDirection: "column",
                        width: "100%"
                    }
                }, [ds_s_InfoWrapper, ds_s_sub_Container]);
            };
            /**
            * This function will receive control element which needs to be updated conditionally
            * It will render the email scheduler control based on the recepient properties
            */
            EmailEngagementActionsControl.prototype.enableSuggestionTimeText = function () {
                var toRecipient;
                var ccRecipient;
                var entityReference;
                var recipientName;
                if (this._toParams) {
                    if (typeof this._toParams.get_entities === "undefined") {
                        toRecipient = this._toParams;
                    }
                    else {
                        toRecipient = this._toParams.get_entities();
                    }
                }
                if (this._ccParams) {
                    if (typeof this._ccParams.get_entities === "undefined") {
                        ccRecipient = this._ccParams;
                    }
                    else {
                        ccRecipient = this._ccParams.get_entities();
                    }
                }
                if (toRecipient && toRecipient.length == 1) {
                    if (toRecipient[0].fields) {
                        if (toRecipient[0].fields.partyid && toRecipient[0].fields.partyid.TypeName != null) {
                            entityReference = toRecipient[0].fields.partyid;
                            recipientName = entityReference.Name;
                        }
                    }
                    else {
                        if (toRecipient[0]._etn != null) {
                            entityReference = { TypeName: toRecipient[0]._etn, Name: toRecipient[0]._name, Id: toRecipient[0]._id };
                            recipientName = entityReference.Name;
                        }
                    }
                }
                if (ccRecipient && ccRecipient.length == 1) {
                    if (entityReference == null && toRecipient && toRecipient.length == 0) {
                        if (ccRecipient[0].fields) {
                            if (ccRecipient[0].fields.partyid && ccRecipient[0].fields.partyid.TypeName != null) {
                                entityReference = ccRecipient[0].fields.partyid;
                                recipientName = entityReference.Name;
                            }
                        }
                        else {
                            if (ccRecipient[0]._etn != null) {
                                entityReference = { TypeName: ccRecipient[0]._etn, Name: ccRecipient[0]._name, Id: ccRecipient[0]._id };
                                recipientName = entityReference.Name;
                            }
                        }
                    }
                    else {
                        entityReference = null;
                    }
                }
                if (entityReference) {
                    var entRefReq = {};
                    entRefReq.id = entityReference.Id.toString();
                    entRefReq.entityType = entityReference.TypeName;
                    var EntityReferenceCollection = [];
                    EntityReferenceCollection[0] = entRefReq;
                    var that = this;
                    var requestRegardingBestEmail = new Sdk.GetBestTimeToEmailRequest(EntityReferenceCollection);
                    var deferred = this._context.webAPI.execute(requestRegardingBestEmail);
                    deferred.then(function (odataResponse) {
                        odataResponse.json().then(function (response) {
                            var orgId = that.getCrmOrganizationId(that._context);
                            var emailAction = new ActionOnEmailEngagementActions("Best Time to Mail API", "success", orgId);
                            that._context.reporting.reportEvent(emailAction);
                            if (response.ShouldDisplay) {
                                var utcSuggestedDateTime = that.getTimeInUserPrefTimeZone(new Date(response.PreferredTime));
                                that.suggestedDelaySendTime = utcSuggestedDateTime;
                                var delay_Time = that.suggestedDelaySendTime.localeFormat(that._context.client.dateFormattingInfo.ShortTimePattern.toString());
                                var delay_Date = that.suggestedDelaySendTime.localeFormat(that._context.client.dateFormattingInfo.ShortDatePattern.toString());
                                that.delay_Has_Suggestion_innerText = MscrmCommon.ControlUtils.String.Format(that._context.resources.getString("CustomControl_EmailEngagement_Delay_Has_Suggestion_Info"), recipientName, delay_Date + " " + delay_Time);
                                that.schedulerControlsList = [that.schedulerHasSuggestionSection()];
                            }
                            else {
                                that.schedulerControlsList = [that.schedulerNotSetSection()];
                            }
                            that._delayTimeLoaded = true;
                            that.renderControl(true);
                        });
                    }, function (err) {
                        var orgId = that.getCrmOrganizationId(that._context);
                        var emailAction = new ActionOnEmailEngagementActions("Best Time to Mail API", "failed to get response", orgId);
                        that._context.reporting.reportEvent(emailAction);
                        that.schedulerControlsList = [that.schedulerNotSetSection()];
                        that._delayTimeLoaded = true;
                        that.renderControl(true);
                    });
                }
                else {
                    this.schedulerControlsList = [this.schedulerNotSetSection()];
                    this._delayTimeLoaded = true;
                }
            };
            /**
             * This function will create a delay Not Set for Scheduler Section
             */
            EmailEngagementActionsControl.prototype.schedulerNotSetSection = function () {
                var schedulerIcon = this._context.factory.createElement("CRMICON", {
                    id: "img_scheduler_NS_recepient",
                    key: "img_scheduler_NS_recepient",
                    type: 34,
                    altText: "Email_Scheduler_Image",
                    style: {
                        padding: this._context.theming.measures.measure075,
                        color: this._context.theming.colors.whitebackground,
                        fontSize: "16px"
                    }
                });
                var schedulerIconWrapper = this._context.factory.createElement("CONTAINER", {
                    id: "img_scheduler_NS_Wrapper",
                    key: "img_scheduler_NS_Wrapper",
                    style: {
                        fontSize: "16px",
                        backgroundColor: this._context.theming.colors.statuscolor.positive2.fill,
                        borderRadius: "50%",
                        height: "37px"
                    }
                }, schedulerIcon);
                var schedulerInfo = this._context.factory.createElement("CONTAINER", {
                    key: "scheduler_NS_content",
                    id: "scheduler_NS_content",
                    style: {
                        flexGrow: "1",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        paddingLeft: this._context.theming.measures.measure075,
                        paddingRight: this._context.theming.measures.measure075
                    }
                }, this.delaySend_NotSet());
                return this._context.factory.createElement("CONTAINER", {
                    key: "scheduler_NS_Container",
                    id: "scheduler_NS_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        justifyContent: "space-between",
                        display: "flex",
                        width: "100%"
                    }
                }, [schedulerIconWrapper, schedulerInfo]);
            };
            /**
             * This function will create UI container for delay Send not Set Element
             */
            EmailEngagementActionsControl.prototype.delaySend_NotSet = function () {
                var dsn_innerText = this._context.resources.getString("CustomControl_EmailEngagement_Schedule_Not_Set_Desc");
                var dsn_Link = this._context.resources.getString("CustomControl_EmailEngagement_Send_Later_Btn");
                var dsn_InfoWrapper = this._context.factory.createElement("LABEL", {
                    id: "dsn_label",
                    key: "dsn_label",
                    accessibilityLabel: dsn_innerText,
                    accessibilityLive: "assertive",
                    accessibilityRelevant: "all",
                    accessibilityAtomic: true,
                    title: dsn_innerText,
                    style: {
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontWeight: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.basecolor.black,
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        display: "block",
                        width: "100%"
                    }
                }, dsn_innerText);
                var dsn_linkSection = this._context.factory.createElement("BUTTON", {
                    id: "dsn_link_label",
                    key: "dsn_link_label",
                    role: "link",
                    tabIndex: 0,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.basecolor.blue["blue4"],
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        display: "block",
                        width: "50%",
                        background: "none",
                        border: "none",
                        padding: "0",
                        textAlign: "left",
                        ":focus": {
                            border: "1px solid #e2e2e2"
                        }
                    },
                    onClick: this.delaySend_ClickHandler.bind(this)
                }, dsn_Link);
                return this._context.factory.createElement("CONTAINER", {
                    key: "delaySend_N_Container",
                    id: "delaySend_N_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        flexDirection: "column"
                    }
                }, [dsn_InfoWrapper, dsn_linkSection]);
            };
            /**
             * This function will create 'has suggestion' content for Scheduler Section
             */
            EmailEngagementActionsControl.prototype.schedulerHasSuggestionSection = function () {
                var schedulerIcon = this._context.factory.createElement("CRMICON", {
                    id: "img_scheduler_HS_recepient",
                    key: "img_scheduler_HS_recepient",
                    type: 34,
                    altText: "Email_Scheduler_Image",
                    style: {
                        padding: this._context.theming.measures.measure075,
                        color: this._context.theming.colors.whitebackground,
                        fontSize: "16px"
                    }
                });
                var schedulerIconWrapper = this._context.factory.createElement("CONTAINER", {
                    id: "img_scheduler_HS_Wrapper",
                    key: "img_scheduler_HS_Wrapper",
                    style: {
                        fontSize: "16px",
                        backgroundColor: this._context.theming.colors.statuscolor.positive2.fill,
                        borderRadius: "50%",
                        height: "37px"
                    }
                }, schedulerIcon);
                var schedulerInfo = this._context.factory.createElement("CONTAINER", {
                    key: "scheduler_HS_content",
                    id: "scheduler_HS_content",
                    style: {
                        flexGrow: "1",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        paddingLeft: this._context.theming.measures.measure075,
                        paddingRight: this._context.theming.measures.measure075
                    }
                }, this.delaySend_HasSuggestion());
                return this._context.factory.createElement("CONTAINER", {
                    key: "scheduler_HS_Container",
                    id: "scheduler_HS_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        justifyContent: "space-between",
                        display: "flex",
                        width: "100%"
                    }
                }, [schedulerIconWrapper, schedulerInfo]);
            };
            /**
             * This function will create UI container for delay Send has Suggestion Element
             */
            EmailEngagementActionsControl.prototype.delaySend_HasSuggestion = function () {
                //let ds_hs_innerText: string = "It is outside business hours for {0}. We suggest you send this email on {1} your time.";
                var ds_hs_innerText = this.delay_Has_Suggestion_innerText;
                var ds_hs_Link = this._context.resources.getString("CustomControl_EmailEngagement_Delay_Send_Btn");
                var ds_hs_InfoWrapper = this._context.factory.createElement("LABEL", {
                    id: "ds_hs_label",
                    key: "ds_hs_label",
                    accessibilityLabel: ds_hs_innerText,
                    accessibilityLive: "assertive",
                    accessibilityRelevant: "all",
                    accessibilityAtomic: true,
                    style: {
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontWeight: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.basecolor.black,
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        display: "block",
                        width: "100%"
                    }
                }, ds_hs_innerText);
                var ds_hs_linkSection = this._context.factory.createElement("BUTTON", {
                    id: "ds_hs_link_label",
                    key: "ds_hs_link_label",
                    role: "link",
                    tabIndex: 0,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.basecolor.blue["blue4"],
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        display: "block",
                        width: "50%",
                        background: "none",
                        border: "none",
                        padding: "0",
                        textAlign: "left",
                        ":focus": {
                            border: "1px solid #e2e2e2"
                        }
                    },
                    onClick: this.delaySend_ClickHandler.bind(this)
                }, ds_hs_Link);
                return this._context.factory.createElement("CONTAINER", {
                    key: "delaySend_HS_Container",
                    id: "delaySend_HS_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        flexDirection: "column"
                    }
                }, [ds_hs_InfoWrapper, ds_hs_linkSection]);
            };
            EmailEngagementActionsControl.prototype.openSendDialog = function () {
                var dialogOptions = {
                    height: 300,
                    width: 450
                };
                var localizedDate = this.getTimeInUserPrefTimeZone(new Date());
                var dialogParams = {};
                dialogParams["isSetFromBestTimeToEmail"] = "false";
                if (this._delayedEmailSendtime) {
                    dialogParams["id_delayedSendTime"] = this._delayedEmailSendtime;
                }
                else if (this.suggestedDelaySendTime > localizedDate) {
                    dialogParams["id_delayedSendTime"] = this.suggestedDelaySendTime;
                    dialogParams["isSetFromBestTimeToEmail"] = "true";
                    var delayArguments = {};
                    delayArguments["bestTimeToEmailSuggestion"] = dialogParams["id_delayedSendTime"];
                    delayArguments["bestTimeToEmailSuggestionUsed"] = "BTDisplay";
                    delayArguments["data"] = "BTDisplay";
                }
                else {
                    var setDelayDate = this.getDateTimeNow();
                    setDelayDate.setDate(setDelayDate.getDate() + 2);
                    dialogParams["id_delayedSendTime"] = setDelayDate;
                }
                dialogParams["id_footerText"] = this._context.resources.getString("CustomControl_EmailEngagement_Send_MDD_Footer");
                dialogParams["id_dateErrorText"] = this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Invalid_Date_Error");
                dialogParams["id_lastButtonClicked"] = '';
                dialogParams["id_now"] = this.getDateTimeNow().getTime();
                dialogParams["id_UserSpecificShortDatePattern"] = this._context.client.dateFormattingInfo.ShortDatePattern.toString();
                dialogParams["id_UserSpecificShortTimePattern"] = this._context.client.dateFormattingInfo.ShortTimePattern.toString();
                dialogParams["MDDResponse"] = "";
                var that = this;
                this._context.navigation.openDialog("DelaySendControl", dialogOptions, dialogParams).then(function (response) {
                    if (response.parameters.id_lastButtonClicked === "ok_id") {
                        that.sendDialogCallBackHandler(response.parameters, dialogParams);
                    }
                    else {
                        if (dialogParams["isSetFromBestTimeToEmail"] && dialogParams["isSetFromBestTimeToEmail"] === "true") {
                            var delayArguments = {};
                            delayArguments["bestTimeToEmailSuggestion"] = dialogParams["id_delayedSendTime"];
                            delayArguments["bestTimeToEmailSuggestionUsed"] = "BTFalse";
                            delayArguments["data"] = "BTCancel";
                        }
                        that._context.accessibility.focusElementById("dsn_link_label");
                    }
                });
            };
            EmailEngagementActionsControl.prototype.sendDialogCallBackHandler = function (params, dialogParams) {
                var delaySendTime = params.id_delayedSendTime;
                if (delaySendTime) {
                    if (dialogParams["isSetFromBestTimeToEmail"] && dialogParams["isSetFromBestTimeToEmail"] === "true") {
                        var delayArguments = {};
                        if (dialogParams["id_delayedSendTime"]) {
                            if (params.id_delayedSendTime === dialogParams["id_delayedSendTime"]) {
                                delayArguments["bestTimeToEmailSuggestionUsed"] = "BTTrue";
                                delayArguments["data"] = "BTAccept";
                            }
                        }
                        else {
                            delayArguments["bestTimeToEmailSuggestionUsed"] = "BTFalse";
                            delayArguments["data"] = "BTChange";
                        }
                        delayArguments["bestTimeToEmailSuggestion"] = delaySendTime.toDateString();
                    }
                    this._delayedEmailSendtime = delaySendTime;
                    this._notifyOutputChanged();
                    this.renderControl(true);
                    this._context.accessibility.focusElementById("ds_s_change_link_label");
                }
                else {
                    this._context.accessibility.focusElementById("dsn_link_label");
                }
            };
            EmailEngagementActionsControl.prototype.delaySend_ClickHandler = function () {
                this.openSendDialog();
            };
            EmailEngagementActionsControl.prototype.removeDelay_ClickHandler = function () {
                this._delayedEmailSendtime = null;
                this._delayTimeLoaded = false;
                this._notifyOutputChanged();
                this.renderControl(true, this.removeDelayFunctionHandler);
            };
            EmailEngagementActionsControl.prototype.setDelayFocus = function () {
                this._context.accessibility.focusElementById("dsn_link_label");
            };
            EmailEngagementActionsControl.prototype.createReminderSection = function () {
                var reminderControls = [];
                var IsReminderSet;
                var today = this.getTimeInUserPrefTimeZone(new Date());
                this._reminderInvalidated = false;
                if (this._emailReminderExpiryTime) {
                    IsReminderSet = true;
                }
                if (IsReminderSet) {
                    if (this._emailReminderStatus === 2) {
                        this._reminderInvalidated = true;
                        reminderControls.push(this.reminderMetSection());
                    }
                    else if (this._emailReminderExpiryTime < today) {
                        this._reminderInvalidated = true;
                        reminderControls.push(this.reminderNotSetSection());
                    }
                    else {
                        if (this.emailFollowPrefrence || (this._emailReminderType === 2)) {
                            reminderControls.push(this.reminderSetSection());
                        }
                        else {
                            reminderControls.push(this.reminderSetWithWarningSection());
                        }
                    }
                }
                else {
                    reminderControls.push(this.reminderNotSetSection());
                }
                //Changing the label of the Email Remainder section based on the option selected
                if (this._emailReminderExpiryTime) {
                    var optionSelected = this._emailReminderType;
                    var reminderTimeValue = this._emailReminderExpiryTime; //this.getTimeInUserPrefTimeZone(this._emailReminderExpiryTime)
                    var shortDatePattern = this._context.client.dateFormattingInfo.ShortDatePattern.toString();
                    var shortTimePattern = this._context.client.dateFormattingInfo.ShortTimePattern.toString();
                    var reminderText = "";
                    var timePart = reminderTimeValue.localeFormat(this._context.client.dateFormattingInfo.ShortTimePattern.toString());
                    var datePart = reminderTimeValue.localeFormat(this._context.client.dateFormattingInfo.ShortDatePattern.toString());
                    var reminderTime = datePart + " " + timePart;
                    var recipientName = this.getSingleRecipientName();
                    if (optionSelected == 0) {
                        if (recipientName == "") {
                            reminderText = MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Footer_Option1_single_recipient"), reminderTime);
                        }
                        else {
                            reminderText = MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Footer_Option1_ignore_recipient"), recipientName, reminderTime);
                        }
                    }
                    if (optionSelected == 1) {
                        if (recipientName == "") {
                            reminderText = MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Footer_Option2_single_recipient"), reminderTime);
                        }
                        else {
                            reminderText = MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Footer_Option2_ignore_recipient"), recipientName, reminderTime);
                        }
                    }
                    if (optionSelected == 2) {
                        reminderText = MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Footer_footerTextOption3"), reminderTime);
                    }
                    reminderControls = [this.reminderSetSection(reminderText)];
                }
                return this._context.factory.createElement("CONTAINER", {
                    key: "create_reminder_Container",
                    id: "create_reminder_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        paddingBottom: this._context.theming.measures.measure100,
                        paddingTop: this._context.theming.measures.measure100
                    }
                }, reminderControls);
            };
            EmailEngagementActionsControl.prototype.getTimeInUserPrefTimeZone = function (date) {
                date.setMinutes(date.getMinutes() + date.getTimezoneOffset() + this._context.client.getUserTimeZoneUtcOffset(date));
                return date;
            };
            EmailEngagementActionsControl.prototype.getSingleRecipientName = function () {
                var recipientName = "";
                var toRecipient = [];
                var ccRecipient = [];
                if (this._toParams) {
                    if (typeof this._toParams.get_entities === "undefined") {
                        toRecipient = this._toParams;
                    }
                    else {
                        toRecipient = this._toParams.get_entities();
                    }
                }
                if (this._ccParams) {
                    if (typeof this._ccParams.get_entities === "undefined") {
                        ccRecipient = this._ccParams;
                    }
                    else {
                        ccRecipient = this._ccParams.get_entities();
                    }
                }
                if (toRecipient && toRecipient.length === 1) {
                    if (toRecipient[0].fields && toRecipient[0].fields.partyid) {
                        recipientName = toRecipient[0].fields.partyid.Name;
                    }
                    else {
                        recipientName = toRecipient[0]._name;
                    }
                }
                if (ccRecipient && ccRecipient.length == 1) {
                    if (recipientName == "") {
                        if (ccRecipient[0].fields && ccRecipient[0].fields.partyid) {
                            recipientName = ccRecipient[0].fields.partyid.Name;
                        }
                        else {
                            recipientName = ccRecipient[0]._name;
                        }
                    }
                }
                return recipientName;
            };
            EmailEngagementActionsControl.prototype.reminder_NotSet = function () {
                var r_ns_innerText = this._context.resources.getString("CustomControl_EmailEngagement_Reminder_NotSet_Info");
                var r_ns_Link = this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Set_Btn");
                var r_ns_InfoWrapper = this._context.factory.createElement("LABEL", {
                    id: "r_ns_label",
                    key: "r_ns_label",
                    accessibilityLabel: r_ns_innerText,
                    accessibilityLive: "assertive",
                    accessibilityRelevant: "all",
                    accessibilityAtomic: true,
                    style: {
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontWeight: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.basecolor.black,
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        display: "block",
                        width: "100%"
                    }
                }, r_ns_innerText);
                var r_ns_linkSection = this._context.factory.createElement("BUTTON", {
                    id: "r_ns_link_label",
                    key: "r_ns_link_label",
                    role: "link",
                    tabIndex: 0,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.basecolor.blue["blue4"],
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        display: "block",
                        width: "50%",
                        background: "none",
                        border: "none",
                        padding: "0",
                        textAlign: "left",
                        ":focus": {
                            border: "1px solid #e2e2e2"
                        }
                    },
                    onClick: this.reminderNotSetClickHandler.bind(this)
                }, r_ns_Link);
                return this._context.factory.createElement("CONTAINER", {
                    key: "reminder_N_Container",
                    id: "reminder_N_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        flexDirection: "column",
                        width: "100%"
                    }
                }, [r_ns_InfoWrapper, r_ns_linkSection]);
            };
            EmailEngagementActionsControl.prototype.reminder_Set = function (reminderText) {
                var r_s_innerText = reminderText ? reminderText : this._emailReminderText;
                var r_set_Link = this._context.resources.getString("CustomControl_EmailEngagement_Change_reminder_Btn");
                var r_remove_Link = this._context.resources.getString("CustomControl_EmailEngagement_Remove_reminder_Btn");
                var r_s_InfoWrapper = this._context.factory.createElement("LABEL", {
                    id: "r_s_label",
                    key: "r_s_label",
                    accessibilityLabel: r_s_innerText,
                    accessibilityLive: "assertive",
                    accessibilityRelevant: "all",
                    accessibilityAtomic: true,
                    style: {
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontWeight: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.basecolor.black,
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        display: "block",
                        width: "100%"
                    }
                }, r_s_innerText);
                var r_remove_linkSection = this._context.factory.createElement("BUTTON", {
                    id: "r_s_remove_link_label",
                    key: "r_s_remove_link_label",
                    role: "link",
                    tabIndex: 0,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.basecolor.blue["blue4"],
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        display: "block",
                        width: "50%",
                        background: "none",
                        border: "none",
                        padding: "0",
                        textAlign: "left",
                        ":focus": {
                            border: "1px solid #e2e2e2"
                        }
                    },
                    onClick: this.removeReminderClickHandler.bind(this)
                }, r_remove_Link);
                var r_set_linkSection = this._context.factory.createElement("BUTTON", {
                    id: "r_sn_link_label",
                    key: "r_sn_link_label",
                    role: "link",
                    tabIndex: 0,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.basecolor.blue["blue4"],
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        display: "block",
                        width: "50%",
                        background: "none",
                        border: "none",
                        padding: "0",
                        textAlign: "left",
                        ":focus": {
                            border: "1px solid #e2e2e2"
                        }
                    },
                    onClick: this.setReminderClickHandler.bind(this)
                }, r_set_Link);
                var r_s_sub_Container = this._context.factory.createElement("CONTAINER", {
                    key: "r_s_sub_Container",
                    id: "r_s_sub_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground
                    }
                }, [r_set_linkSection, r_remove_linkSection]);
                return this._context.factory.createElement("CONTAINER", {
                    key: "reminder_s_Container",
                    id: "reminder_s_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        flexDirection: "column",
                        width: "100%"
                    }
                }, [r_s_InfoWrapper, r_s_sub_Container]);
            };
            EmailEngagementActionsControl.prototype.reminder_Set_With_Warning = function () {
                var r_sw_innerText = this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Warning_Info");
                var r_sw_changeReminder_Link = this._context.resources.getString("CustomControl_EmailEngagement_Change_reminder_Btn");
                var r_sw_remove_reminder_Link = this._context.resources.getString("CustomControl_EmailEngagement_Remove_reminder_Btn");
                var r_sw_InfoWrapper = this._context.factory.createElement("LABEL", {
                    id: "r_sw_label",
                    key: "r_sw_label",
                    accessibilityLabel: r_sw_innerText,
                    accessibilityLive: "assertive",
                    accessibilityRelevant: "all",
                    accessibilityAtomic: true,
                    style: {
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontWeight: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.basecolor.black,
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        display: "block",
                        width: "100%"
                    }
                }, r_sw_innerText);
                var r_sw_change_linkSection = this._context.factory.createElement("BUTTON", {
                    id: "r_sw__change_link_label",
                    key: "r_sw__change_link_label",
                    role: "link",
                    tabIndex: 0,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.basecolor.blue["blue4"],
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        display: "block",
                        width: "50%",
                        background: "none",
                        border: "none",
                        padding: "0",
                        textAlign: "left",
                        ":focus": {
                            border: "1px solid #e2e2e2"
                        }
                    },
                    onClick: this.setReminderClickHandler.bind(this)
                }, r_sw_changeReminder_Link);
                var r_sw_remove_linkSection = this._context.factory.createElement("BUTTON", {
                    id: "r_sw__remove_link_label",
                    key: "r_sw__remove_link_label",
                    role: "link",
                    tabIndex: 0,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.basecolor.blue["blue4"],
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        display: "block",
                        width: "50%",
                        background: "none",
                        border: "none",
                        padding: "0",
                        textAlign: "left",
                        ":focus": {
                            border: "1px solid #e2e2e2"
                        }
                    },
                    onClick: this.removeReminderClickHandler.bind(this)
                }, r_sw_remove_reminder_Link);
                var r_sw_sub_Container = this._context.factory.createElement("CONTAINER", {
                    key: "r_sw_sub_Container",
                    id: "r_sw_sub_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground
                    }
                }, [r_sw_change_linkSection, r_sw_remove_linkSection]);
                return this._context.factory.createElement("CONTAINER", {
                    key: "reminder_Sw_Container",
                    id: "reminder_Sw_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        flexDirection: "column",
                        width: "100%"
                    }
                }, [r_sw_InfoWrapper, r_sw_sub_Container]);
            };
            EmailEngagementActionsControl.prototype.reminder_Met = function () {
                var r_m_innerText = this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Met_Info");
                var r_m_Link = this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Set_Btn");
                var r_m_InfoWrapper = this._context.factory.createElement("LABEL", {
                    id: "r_m_label",
                    key: "r_m_label",
                    accessibilityLabel: r_m_innerText,
                    accessibilityLive: "assertive",
                    accessibilityRelevant: "all",
                    accessibilityAtomic: true,
                    style: {
                        fontFamily: this._context.theming.fontfamilies.semibold,
                        fontSize: this._context.theming.fontsizes.font100,
                        fontWeight: this._context.theming.fontfamilies.regular,
                        color: this._context.theming.colors.basecolor.black,
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        display: "block",
                        width: "100%"
                    }
                }, r_m_innerText);
                var r_m_linkSection = this._context.factory.createElement("BUTTON", {
                    id: "r_m_link_label",
                    key: "r_m_link_label",
                    role: "link",
                    tabIndex: 0,
                    style: {
                        fontSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.basecolor.blue["blue4"],
                        paddingBottom: this._context.theming.measures.measure075,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        display: "block",
                        width: "50%",
                        background: "none",
                        border: "none",
                        padding: "0",
                        textAlign: "left",
                        ":focus": {
                            border: "1px solid #e2e2e2"
                        }
                    },
                    onClick: this.setReminderClickHandler.bind(this)
                }, r_m_Link);
                return this._context.factory.createElement("CONTAINER", {
                    key: "reminder_M_Container",
                    id: "reminder_M_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        flexDirection: "column"
                    }
                }, [r_m_InfoWrapper, r_m_linkSection]);
            };
            EmailEngagementActionsControl.prototype.reminderNotSetSection = function () {
                var reminderIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "img_reminder_NS_recepient",
                    key: "img_reminder_NS_recepient",
                    type: 357,
                    altText: "Email_Scheduler_Image",
                    style: {
                        padding: this._context.theming.measures.measure075,
                        color: this._context.theming.colors.grays.gray05,
                        fontSize: "16px"
                    }
                });
                var reminderIconWrapper = this._context.factory.createElement("CONTAINER", {
                    id: "img_reminder_NS_wrapper",
                    key: "img_reminder_NS_wrapper",
                    style: {
                        backgroundColor: this._context.theming.colors.grays.gray02,
                        borderRadius: "50%",
                        height: "37px"
                    }
                }, reminderIcon);
                var reminderInfo = this._context.factory.createElement("CONTAINER", {
                    key: "reminder_NS_content",
                    id: "reminder_NS_content",
                    style: {
                        flexGrow: "1",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        paddingLeft: this._context.theming.measures.measure075,
                        paddingRight: this._context.theming.measures.measure075
                    }
                }, this.reminder_NotSet());
                return this._context.factory.createElement("CONTAINER", {
                    key: "reminder_NS_Container",
                    id: "reminder_NS_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        justifyContent: "space-between",
                        display: "flex",
                        width: "100%"
                    }
                }, [reminderIconWrapper, reminderInfo]);
            };
            EmailEngagementActionsControl.prototype.reminderSetSection = function (reminderText) {
                var remindersetText = reminderText ? reminderText : '';
                var reminderIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "img_reminder_S_recepient",
                    key: "img_reminder_S_recepient",
                    type: 357,
                    altText: "Email_Scheduler_Image",
                    style: {
                        padding: this._context.theming.measures.measure075,
                        color: this._context.theming.colors.grays.gray05,
                        fontSize: "16px"
                    }
                });
                var reminderIconWrapper = this._context.factory.createElement("CONTAINER", {
                    id: "img_reminder_S_Wrapper",
                    key: "img_reminder_S_Wrapper",
                    style: {
                        fontSize: "16px",
                        backgroundColor: this._context.theming.colors.grays.gray02,
                        borderRadius: "50%",
                        height: "37px"
                    }
                }, reminderIcon);
                var reminderInfo = this._context.factory.createElement("CONTAINER", {
                    key: "reminder_S_content",
                    id: "reminder_S_content",
                    style: {
                        flexGrow: "1",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        paddingLeft: this._context.theming.measures.measure075,
                        paddingRight: this._context.theming.measures.measure075
                    }
                }, this.reminder_Set(remindersetText));
                return this._context.factory.createElement("CONTAINER", {
                    key: "reminder_S_Container",
                    id: "reminder_S_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        justifyContent: "space-between",
                        display: "flex",
                        width: "100%"
                    }
                }, [reminderIconWrapper, reminderInfo]);
            };
            EmailEngagementActionsControl.prototype.reminderSetWithWarningSection = function () {
                var reminderIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "img_reminder_SW_recepient",
                    key: "img_reminder_SW_recepient",
                    type: 357,
                    altText: "Email_Scheduler_Image",
                    style: {
                        padding: this._context.theming.measures.measure075,
                        color: this._context.theming.colors.grays.gray05,
                        fontSize: "16px"
                    }
                });
                var reminderIconWrapper = this._context.factory.createElement("CONTAINER", {
                    id: "img_reminder_SW_Wrapper",
                    key: "img_reminder_SW_Wrapper",
                    style: {
                        backgroundColor: this._context.theming.colors.grays.gray02,
                        borderRadius: "50%",
                        height: "37px"
                    }
                }, reminderIcon);
                var reminderInfo = this._context.factory.createElement("CONTAINER", {
                    key: "reminder_SW_content",
                    id: "reminder_SW_content",
                    style: {
                        flexGrow: "1",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        paddingLeft: this._context.theming.measures.measure075,
                        paddingRight: this._context.theming.measures.measure075
                    }
                }, this.reminder_Set_With_Warning());
                return this._context.factory.createElement("CONTAINER", {
                    key: "reminder_SW_Container",
                    id: "reminder_SW_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        justifyContent: "space-between",
                        display: "flex",
                        width: "100%"
                    }
                }, [reminderIconWrapper, reminderInfo]);
            };
            EmailEngagementActionsControl.prototype.reminderMetSection = function () {
                var reminderIcon = this._context.factory.createElement("MICROSOFTICON", {
                    id: "img_reminder_M_recepient",
                    key: "img_reminder_M_recepient",
                    type: 357,
                    altText: "Email_Scheduler_Image",
                    style: {
                        padding: this._context.theming.measures.measure075,
                        color: this._context.theming.colors.grays.gray05,
                        fontSize: "16px"
                    }
                });
                var reminderIconWrapper = this._context.factory.createElement("CONTAINER", {
                    id: "img_reminder_M_Wrapper",
                    key: "img_reminder_M_Wrapper",
                    style: {
                        backgroundColor: this._context.theming.colors.grays.gray02,
                        borderRadius: "50%",
                        height: "37px"
                    }
                }, reminderIcon);
                var reminderInfo = this._context.factory.createElement("CONTAINER", {
                    key: "reminder_M_content",
                    id: "reminder_M_content",
                    style: {
                        flexGrow: "1",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        paddingLeft: this._context.theming.measures.measure075,
                        paddingRight: this._context.theming.measures.measure075
                    }
                }, this.reminder_Met());
                return this._context.factory.createElement("CONTAINER", {
                    key: "reminder_M_Container",
                    id: "reminder_M_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        justifyContent: "space-between",
                        display: "flex",
                        width: "100%"
                    }
                }, [reminderIconWrapper, reminderInfo]);
            };
            EmailEngagementActionsControl.prototype.openReminderDialog = function () {
                var dialogOptions = {
                    height: 400,
                    width: 500
                };
                var that = this;
                var dialogParams = {};
                var setReminderDate = this.getTimeInUserPrefTimeZone(new Date());
                var today = this.getTimeInUserPrefTimeZone(new Date());
                setReminderDate.setDate(setReminderDate.getDate() + 2);
                dialogParams["id_reminderOptionSelected"] = this._emailReminderType;
                dialogParams["id_reminderTextSelected"] = this._emailReminderText;
                if (this._emailReminderExpiryTime) {
                    if (!this._reminderInvalidated) {
                        dialogParams["id_reminderDateSelected"] = this._emailReminderExpiryTime;
                    }
                    else {
                        dialogParams["id_reminderDateSelected"] = "";
                    }
                }
                else {
                    dialogParams["id_reminderDateSelected"] = setReminderDate;
                }
                dialogParams["id_footerTextOption1_single_recipient"] = this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Footer_Option1_ignore_recipient");
                dialogParams["id_footerTextOption1_ignore_recipient"] = this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Footer_Option1_single_recipient");
                dialogParams["id_footerTextOption2_single_recipient"] = this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Footer_Option2_ignore_recipient");
                dialogParams["id_footerTextOption2_ignore_recipient"] = this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Footer_Option2_single_recipient");
                dialogParams["id_footerTextOption3"] = this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Footer_footerTextOption3");
                dialogParams["id_dateErrorText"] = this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Invalid_Date_Error");
                if (!this.emailFollowPrefrence && this._followEmailUserPreference) {
                    dialogParams["id_invalidChoice"] = this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Condition_Info_Email_Not_Followed");
                }
                else {
                    dialogParams["id_invalidChoice"] = this._context.resources.getString("CustomControl_EmailEngagement_Reminder_Condition_Info_Email_Activity_Not_Allowed");
                }
                dialogParams["id_isEmailFollowedValue"] = this.emailFollowPrefrence && this._followEmailUserPreference;
                dialogParams["id_now"] = today.getTime();
                var recipientName = this.getSingleRecipientName();
                if (recipientName != "") {
                    dialogParams["id_recipientName"] = recipientName;
                }
                else {
                    dialogParams["id_recipientName"] = "";
                }
                dialogParams["id_lastButtonClicked"] = "";
                dialogParams["id_UserSpecificShortDatePattern"] = this._context.client.dateFormattingInfo.ShortDatePattern.toString(); //Mscrm.DateTimeUtility.GetShortDateFormat();
                dialogParams["id_UserSpecificShortTimePattern"] = this._context.client.dateFormattingInfo.ShortTimePattern.toString(); //"h:mm tt";
                this._context.navigation.openDialog("EmailReminderControl", dialogOptions, dialogParams).then(function (response) {
                    if (response.parameters["id_lastButtonClicked"] == "ok_id") {
                        that._emailReminderType = response.parameters["id_reminderOptionSelected"];
                        that._emailReminderText = response.parameters["id_reminderTextSelected"];
                        that._emailReminderExpiryTime = response.parameters["id_reminderDateSelected"];
                        that._notifyOutputChanged();
                        that.renderControl(true);
                        that._context.accessibility.focusElementById("r_sn_link_label");
                    }
                }, function (error) {
                    console.log("Error is " + error);
                });
            };
            /**
             * This function will open reminder dialog
             */
            EmailEngagementActionsControl.prototype.setReminderClickHandler = function () {
                this.openReminderDialog();
            };
            /**
             * This function will remove email reminder
             */
            EmailEngagementActionsControl.prototype.removeReminderClickHandler = function () {
                this._emailReminderType = 0;
                this._emailReminderText = "";
                this._emailReminderExpiryTime = null;
                this._notifyOutputChanged();
                this.renderControl(true, this.removeReminderFunctionHandler);
            };
            /**
             * This function will set reminder focus
             */
            EmailEngagementActionsControl.prototype.setReminderFocus = function () {
                this._context.accessibility.focusElementById("r_ns_link_label");
            };
            /**
             * This function will open reminder dialog
             */
            EmailEngagementActionsControl.prototype.reminderNotSetClickHandler = function () {
                this.openReminderDialog();
            };
            /**
            * Initiate the request render available in the utils
            */
            EmailEngagementActionsControl.prototype.renderControl = function (render, callback) {
                if (render === void 0) { render = false; }
                if (render) {
                    this._context.utils.requestRender(callback);
                }
            };
            EmailEngagementActionsControl.prototype.getDateTimeNow = function () {
                var now = new Date();
                now.setMinutes(now.getMinutes() + now.getTimezoneOffset() + this._context.userSettings.getTimeZoneOffsetMinutes(now));
                return now;
            };
            EmailEngagementActionsControl.prototype.getCrmOrganizationId = function (context) {
                try {
                    var orgSettings = context.client.orgSettings;
                    var orgId = "";
                    if (orgSettings.organizationId != null && orgSettings.organizationId != undefined) {
                        orgId = orgSettings.organizationId.replace("{", "").replace("}", "");
                    }
                    else {
                        orgId = (context.orgSettings.attributes["organizationId"] != undefined && context.orgSettings.attributes["organizationId"] != null) ? context.orgSettings.attributes["organizationId"] : "";
                    }
                    return orgId;
                }
                catch (e) {
                    return "";
                }
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            EmailEngagementActionsControl.prototype.getOutputs = function () {
                var result = {
                    emailreminderexpirytime: this._emailReminderExpiryTime,
                    followemailuserpreference: this._followEmailUserPreference,
                    delayedemailsendtime: this._delayedEmailSendtime,
                    toparams: this._toParams,
                    ccparams: this._ccParams,
                    isemailfollowed: this._isEmailFollowed,
                    directioncode: this._directionCode,
                    statuscode: this._statusCode,
                    emailremindertext: this._emailReminderText,
                    emailremindertype: this._emailReminderType,
                    emailreminderstatus: this._emailReminderStatus
                };
                return result;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            EmailEngagementActionsControl.prototype.destroy = function () {
            };
            return EmailEngagementActionsControl;
        }());
        EmailEngagement.EmailEngagementActionsControl = EmailEngagementActionsControl;
    })(EmailEngagement = MscrmControls.EmailEngagement || (MscrmControls.EmailEngagement = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="EmailEngagementControl.ts" />
/// <reference path="libs/Sdk/GetBestTimeToMailRequest.ts" />
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../PrivateReferences.ts"/>
var ActionOnEmailActions = "ActionOnEmailEngagementActions";
var EmailEngagementActionsEntryPoint = "EmailEngagementActionEntryPoint";
var EmailEventParameter = (function () {
    function EmailEventParameter(name, value) {
        this.name = name;
        this.value = value;
    }
    return EmailEventParameter;
}());
var ActionOnEmailEngagementActions = (function () {
    function ActionOnEmailEngagementActions(action, description, orgId) {
        this.eventParameters = [];
        this.eventName = ActionOnEmailActions;
        this.addEventParameter("actionName", action);
        this.addEventParameter("description", description);
        this.addEventParameter("orgId", orgId);
    }
    ActionOnEmailEngagementActions.prototype.addEventParameter = function (parameterName, value) {
        var event = new EmailEventParameter(parameterName, value);
        this.eventParameters.push(event);
    };
    return ActionOnEmailEngagementActions;
}());
var EmailEngagementActionEntryPoint = (function () {
    function EmailEngagementActionEntryPoint(entryPoint, orgId) {
        this.eventParameters = [];
        this.eventName = EmailEngagementActionsEntryPoint;
        this.addEventParameter("entryPoint", entryPoint);
        this.addEventParameter("orgId", orgId);
    }
    EmailEngagementActionEntryPoint.prototype.addEventParameter = function (parameterName, value) {
        var event = new EmailEventParameter(parameterName, value);
        this.eventParameters.push(event);
    };
    return EmailEngagementActionEntryPoint;
}());
