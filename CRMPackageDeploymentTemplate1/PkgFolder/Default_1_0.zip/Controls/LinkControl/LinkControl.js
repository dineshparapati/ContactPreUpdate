/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../../references/internal/TypeDefinitions/CommonControl/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var OfficeProductivity;
    (function (OfficeProductivity) {
        'use strict';
        var LinkControl = (function () {
            /**
             * Empty constructor.
             */
            function LinkControl() {
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            LinkControl.prototype.init = function (context, notifyOutputChanged, state) {
                this._context = context;
                this.linkElement = new OfficeProductivity.LinkElement(context, notifyOutputChanged);
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            LinkControl.prototype.updateView = function (context) {
                return this.linkElement.render();
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            LinkControl.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                return null;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            LinkControl.prototype.destroy = function () {
            };
            return LinkControl;
        }());
        OfficeProductivity.LinkControl = LinkControl;
    })(OfficeProductivity = MscrmControls.OfficeProductivity || (MscrmControls.OfficeProductivity = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="LinkControl.ts" />
var MscrmControls;
(function (MscrmControls) {
    var OfficeProductivity;
    (function (OfficeProductivity) {
        'use strict';
        var LinkElement = (function () {
            function LinkElement(context, notifyOutputChanged) {
                this._context = context;
                this._notifyOutputChanged = notifyOutputChanged || (function () { });
                // reading the control's src value
                this.linkValue = this._context.parameters.linkValue.raw;
                this.linkText = this._context.parameters.linkText.raw;
                this.linkAltText = this._context.parameters.linkAltText.raw;
            }
            LinkElement.prototype.render = function () {
                // reading the control's value
                this.linkValue = this._context.parameters.linkValue.raw;
                this.linkText = this._context.parameters.linkText.raw;
                this.linkAltText = this._context.parameters.linkAltText.raw;
                return this.createLinkElement(this.linkValue, this.linkText);
            };
            /**
             * Creates the visualization for Link
             */
            LinkElement.prototype.createLinkElement = function (linkValue, linkText) {
                var properties = {
                    id: "link_offcieproductivity",
                    key: "link_offcieproductivity",
                    role: "link",
                    target: "_blank",
                    href: this.linkValue,
                    tabIndex: 0,
                    title: this.linkText,
                    accessibilityLabel: this.linkText,
                    style: {
                        width: "100%",
                        textDecoration: "none",
                        color: "#4275b2"
                    },
                    altText: this.linkAltText
                };
                var linkControl = this._context.factory.createElement("HYPERLINK", properties, this.linkText);
                return this._context.factory.createElement("CONTAINER", {
                    style: {
                        width: "100%",
                        height: "inherit",
                        justifyContent: "center",
                        alignItems: "center"
                    },
                    key: "linkContainer"
                }, linkControl);
            };
            return LinkElement;
        }());
        OfficeProductivity.LinkElement = LinkElement;
    })(OfficeProductivity = MscrmControls.OfficeProductivity || (MscrmControls.OfficeProductivity = {}));
})(MscrmControls || (MscrmControls = {}));
;
//# sourceMappingURL=LinkControl.js.map