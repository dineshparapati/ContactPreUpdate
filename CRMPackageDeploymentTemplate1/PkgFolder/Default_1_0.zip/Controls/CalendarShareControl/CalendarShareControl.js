/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/**
* Telemetry library that takes dynamic parameter lists as event parameters in addition to fixed required parameters relavent to classify verticals association with Entities
* and pushes to crminsightsdev.cloudapp.net endpoint.  All one needs to do is Register your telemetry event with InsightsEndpoint repo (Events.xml and MdsConfig-CloudService.xml
* and start pushing event data using below APIs
*
* Sample calls for the APIs - caller : non-custom control eg: Ribbon commands
* AppsTelemetryUtility.reportData(EventList.EntitlementEvent, ModuleList.service, EntityList.entitlement, "Activation", null, { "CurrentState": "Activate", "UpdateMode": "Mouse"})
* AppsTelemetryUtility.reportData("CSHEntitlements", "Service", "Entitlement", "Deactivate", null, { "CurrentState": "Inactive", "UpdateMode": "KeyBoard"})
* Similarly ReportSuccess and Report Failure calls using either Enums (preferred) or string values.
* AppsTelemetryUtility.reportSuccess(EventList.EntitlementEvent, ModuleList.service, EntityList.entitlement, "TestAction", null, { "CurrentState": "Activate", "UpdateMode": "Mouse"})
* AppsTelemetryUtility.reportFailure(EventList.EntitlementEvent, ModuleList.service, EntityList.entitlement, "TestAction", null, { "CurrentState": "Activate", "UpdateMode": "Mouse"})
*
* Sample calls for the APIs - caller Custom Controls
* AppsTelemetryUtility.ReportSuccess(EventList.SubjectEvent, ModuleList.service, EntityList.CSSEvent, "AddBreak", this.context, {"Duration": 30, "Timezone": "PST"});
* AppsTelemetryUtility.ReportFailure("CSH_Subject", "Service", "Subject", "AddChild", this.context, {"name": "myRegarding", "parent": "myEntity"});
*
* In above samples for non-custom control calls, null is expected to be passed as part of event call for two reasons 1. Generic API for custom & non-custom control
*/
var AppsTelemetryLib;
(function (AppsTelemetryLib) {
    'use strict';
    /**
    * To format the outer payload for telemetry data according to the event schema
    */
    var TelemetryPayload = (function () {
        function TelemetryPayload() {
        }
        return TelemetryPayload;
    }());
    AppsTelemetryLib.TelemetryPayload = TelemetryPayload;
    /**
    * To format the inner payload for telemetry data according to the event schema
    */
    var TelemetryParameter = (function () {
        function TelemetryParameter() {
        }
        return TelemetryParameter;
    }());
    AppsTelemetryLib.TelemetryParameter = TelemetryParameter;
    /**
    * Declaring this key value pair to make it easy for callers
    */
    var ExtraParams = (function () {
        function ExtraParams() {
        }
        return ExtraParams;
    }());
    AppsTelemetryLib.ExtraParams = ExtraParams;
    /**
    * ENUMs tracking EventTypes
    */
    var EventTypes = (function () {
        function EventTypes() {
        }
        return EventTypes;
    }());
    EventTypes.Success = "Success";
    EventTypes.Failure = "Failure";
    EventTypes.EventData = "EventData";
    AppsTelemetryLib.EventTypes = EventTypes;
    /**
    * ENUMs tracking Vertical Events. Callers of Client Telemetry APIs can use ENUMs to pass required parameters
    * Currently listed with registered Customer Service Module List
    */
    var EventList = (function () {
        function EventList() {
        }
        return EventList;
    }());
    EventList.QueueEvent = "CSHQueues";
    EventList.RoutingRuleEvent = "CSHRoutingRules";
    EventList.ARCEvent = "CSHAutoRecordCreation";
    EventList.SubjectEvent = "CSHSubject";
    EventList.HSEvent = "CSHHolidaySchedule";
    EventList.CSSEvent = "CSHCustomerServiceSchedule";
    EventList.SettingsEvent = "CSHSettings";
    EventList.EntitlementEvent = "CSHEntitlements";
    EventList.IncidentEvent = "CSHIncident";
    EventList.EventAgnostic = "CSHMisc";
    AppsTelemetryLib.EventList = EventList;
    /**
    * ENUMs tracking Vertical/Module List
    */
    var ModuleList = (function () {
        function ModuleList() {
        }
        return ModuleList;
    }());
    ModuleList.service = "Service";
    ModuleList.sales = "Sales";
    ModuleList.marketing = "Marketing";
    ModuleList.verticalAgnostic = "VerticalAgnostic";
    AppsTelemetryLib.ModuleList = ModuleList;
    /**
    * ENUMs tracking Entity List
    * Currently listing entities list part of Customer Service Module shipping in Enterprise Release
    */
    var EntityList = (function () {
        function EntityList() {
        }
        return EntityList;
    }());
    EntityList.queue = "Queue";
    EntityList.queueItem = "QueueItem";
    EntityList.convertRule = "ConvertRule";
    EntityList.convertRuleItem = "ConvertRuleItem";
    EntityList.routingRule = "RoutingRule";
    EntityList.routingRuleItem = "RoutingRuleItem";
    EntityList.entitlement = "Entitlement";
    EntityList.entitlementTemplate = "EntitlementTemplate";
    EntityList.sla = "SLA";
    EntityList.slaItem = "SLAItem";
    EntityList.calendar = "Calendar";
    EntityList.calendarRule = "CalendarRule";
    EntityList.subject = "Subject";
    EntityList.incident = "Incident";
    EntityList.organization = "organization";
    AppsTelemetryLib.EntityList = EntityList;
    /**
    * ENUMs tracking Action
    */
    var Action = (function () {
        function Action() {
        }
        return Action;
    }());
    Action.create = "Create";
    Action.update = "Update";
    Action.retrieve = "Retrieve";
    Action.delete = "Delete";
    Action.clickedGridCommand = "ClickedGridCommand";
    AppsTelemetryLib.Action = Action;
    var AppsTelemetryUtility = (function () {
        function AppsTelemetryUtility() {
        }
        /**
        * @function reportEventData send telemetry data to the crminsightsdev.cloudapp.net endpoint.
        * @description send telemetry data to the telemetry endpoint.
        * @param appName - service / sales / any other XRM based app
        * @param context -  A reference to the context of custom entity; null for non-custom entity calls
        */
        AppsTelemetryUtility.reportData = function (eventName, appName, entityName, actionName, context, eventSpecificParams) {
            var telemetrydata = AppsTelemetryUtility.getTelemetryData(eventName, EventTypes.EventData, appName, entityName, actionName, context, eventSpecificParams);
            // Async calls be made to reportEvent call and error scenarios are expected to be handled within reportEvent infra
            if (context != null && context.reporting != null) {
                context.reporting.reportEvent(telemetrydata);
            }
            else {
                Xrm.Reporting.reportEvent(telemetrydata);
            }
        };
        ;
        AppsTelemetryUtility.reportFailure = function (eventName, appName, entityName, actionName, context, eventSpecificParams) {
            var telemetrydata = AppsTelemetryUtility.getTelemetryData(eventName, EventTypes.Failure, appName, entityName, actionName, context, eventSpecificParams);
            if (context != null && context.reporting != null) {
                context.reporting.reportEvent(telemetrydata);
            }
            else {
                Xrm.Reporting.reportEvent(telemetrydata);
            }
        };
        ;
        AppsTelemetryUtility.reportError = function (eventName, appName, entityName, actionName, context, errorMessage, errorTrace) {
            var eventSpecificParams = {};
            eventSpecificParams["errorMessage"] = errorMessage;
            eventSpecificParams["errorTrace"] = errorTrace ? JSON.stringify(errorTrace, Object.getOwnPropertyNames(errorTrace)) : "";
            AppsTelemetryUtility.reportFailure(eventName, appName, entityName, actionName, context, eventSpecificParams);
        };
        ;
        AppsTelemetryUtility.reportSuccess = function (eventName, appName, entityName, actionName, context, eventSpecificParams) {
            var telemetrydata = AppsTelemetryUtility.getTelemetryData(eventName, EventTypes.Success, appName, entityName, actionName, context, eventSpecificParams);
            if (context != null && context.reporting != null) {
                context.reporting.reportEvent(telemetrydata);
            }
            else {
                Xrm.Reporting.reportEvent(telemetrydata);
            }
        };
        ;
        AppsTelemetryUtility.getTelemetryData = function (_eventName, _telemetryDatatype, _appName, _entityName, _actionName, _context, _eventSpecificParams) {
            var payload = {
                eventName: _eventName,
                eventParameters: []
            };
            var para1 = { name: "EventType", value: _telemetryDatatype };
            var para2 = { name: "appName", value: _appName };
            var para3 = { name: "entityName", value: _entityName };
            var para4 = { name: "actionName", value: _actionName };
            var para5 = { name: "context", value: _context };
            payload.eventParameters.push(para1);
            payload.eventParameters.push(para2);
            payload.eventParameters.push(para3);
            payload.eventParameters.push(para4);
            payload.eventParameters.push(para5);
            var __eventSpecificParams = JSON.stringify(_eventSpecificParams);
            var para6 = { name: "eventSpecificParams", value: __eventSpecificParams };
            payload.eventParameters.push(para6);
            return payload;
        };
        return AppsTelemetryUtility;
    }());
    AppsTelemetryLib.AppsTelemetryUtility = AppsTelemetryUtility;
})(AppsTelemetryLib || (AppsTelemetryLib = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
var AppCommon;
(function (AppCommon) {
    var DialogConstants = (function () {
        function DialogConstants() {
        }
        return DialogConstants;
    }());
    DialogConstants.AssignTomeOption = "rdoMe_id";
    DialogConstants.BusinessQueuesLookupId = "businessqueues_id";
    DialogConstants.DialogCancelId = "cancel_id";
    DialogConstants.DialogOkId = "ok_id";
    DialogConstants.OwnerId = "owner_id";
    DialogConstants.OwnerType = "owner_type";
    DialogConstants.QueueItemAssignedToUserText = "lbl_assignedtouser";
    DialogConstants.QueueItemAssignedToQueueText = "lbl_addtoqueue";
    DialogConstants.QueueItemRouteHeaderText = "lbl_headerdescription";
    DialogConstants.QueueItemQueueLookupId = "crmQueueLookupControl_id";
    DialogConstants.QueueItemRemoveId = "chkBoxRemoveItem_id";
    DialogConstants.QueueItemRouteToId = "routeto_id";
    DialogConstants.QueueItemUserLookupId = "crmUserLookupControl_id";
    DialogConstants.SelectedRecordsCount = "selected_records_count";
    DialogConstants.ShowAssignToMeOption = "show_assign_to_me_option";
    DialogConstants.SystemUserViewId = "systemuserview_id";
    DialogConstants.LastButtonClicked = "last_button_clicked";
    DialogConstants.LastButtonClickedParam = "param_lastButtonClicked";
    DialogConstants.RecordsParam = "param_records";
    DialogConstants.CalendarName = "Schedule_Name";
    DialogConstants.CalendarDescription = "Schedule_Description";
    DialogConstants.CalendarHeader = "Schedule_header";
    DialogConstants.CalendarGrid = "Calendar_Grid";
    DialogConstants.CalendarType = "Calendar_Type";
    DialogConstants.CalendarRecord = "Calendar_Record";
    DialogConstants.CalendarFormName = "name";
    DialogConstants.CalendarFormDescription = "description";
    DialogConstants.Customer_Service_Schedule_View_Id = "F4D446E0-3749-4BA4-9C85-EAB861EAFDFC";
    DialogConstants.Holiday_Schedule_View_Id = "06453A1D-9288-4F0E-9351-819D619ECB5F";
    DialogConstants.CustomerServiceScheduleType = "1";
    DialogConstants.HolidayScheduleType = "2";
    DialogConstants.MDD_CSS_PARAM_WeeklyScheduleControl_Input = "weeklyScheduleControl_Input";
    DialogConstants.MDD_PARAM_Calendar_Id_Input = "calendar_Id";
    DialogConstants.MDD_CSS_PARAM_Calendar_ShareControl_Input = "calendarShareControl_Input";
    DialogConstants.MDD_CSS_PARAM_WeeklyScheduleControl_Output = "weeklyScheduleControl_Output";
    DialogConstants.MDD_CSS_PARAM_CustomerServiceSchedule_Status = "customerServiceSchedule_Status";
    DialogConstants.MDD_CSS_PARAM_SetWorkHourControl_Input = "setWorkHourControl_Input";
    DialogConstants.MDD_CSS_PARAM_SetWorkHourControl_Output = "setWorkHourControl_Output";
    DialogConstants.MDD_CSS_PARAM_DeleteWeeklyScheduleStatus_Output = "deleteWeeklyScheduleStatus_Output";
    DialogConstants.MDD_CSS_Dialog_CalendarRule_Warning = "CalendarRule_Warning";
    DialogConstants.MDD_CSS_SaveButton_Id = "savecalendarrule_id";
    DialogConstants.MDD_CSS_SaveAndCloseButton_Id = "saveandclosecalendarrule_id";
    DialogConstants.MDD_SetWorkHours_OKButton_Id = "oktimesheetdetails_id";
    DialogConstants.MDD_CSS_PARAM_HolidayListControl_Input = "holidayListControl_Input";
    DialogConstants.MDD_HS_DoneButtonId = "save_id";
    DialogConstants.MDD_HolidayItem_Param_State = "holidayItem_state";
    DialogConstants.MDD_HolidayItem_Param_Calendar_Id = "calendar_id";
    DialogConstants.MDD_HolidayItem_Param_CalendarRule_Id = "calendarRule_id";
    DialogConstants.ErrorMsg_Dialog_Load_Failed = "Error_DialogLoadFailed";
    DialogConstants.ErrorMsg_Dialog_Save_Failed = "Error_DialogSaveFailed";
    // QueueItem constants for Dialog
    DialogConstants.EntitySystemUser = "systemuser";
    DialogConstants.QueueItem_FetchXml = "<fetch version='1.0' mapping='logical'>" +
        "<entity name='systemuser'>'+'<order attribute='fullname' descending='false' />" +
        "<attribute name='systemuserid' /><attribute name='fullname' />" +
        "<link-entity name='queuemembership' from='systemuserid' to='systemuserid' alias='QueueMembers'>" +
        "<filter type='and'>" +
        "<condition attribute='queueid' operator='eq' value='{0}' />" +
        "</filter>" +
        "</link-entity>" +
        "</entity>" +
        "</fetch>";
    DialogConstants.QueueItem_LayoutXml = "<grid name='systemuser' object='8' jump='name' select='1' icon='1' preview='0'>" +
        "<row name='systemuser' id='systemuserid'>" +
        "<cell name='fullname' width='300' />" +
        "<cell name='systemuserid' width='0' ishidden='1'/>" +
        "</row>" +
        "</grid>";
    AppCommon.DialogConstants = DialogConstants;
    var DialogName = (function () {
        function DialogName() {
        }
        return DialogName;
    }());
    DialogName.AddToQueueDialog = "AddToQueue";
    DialogName.CreateOrUpdateCustomerServiceScheduleRule = "CreateOrUpdateCustomerServiceScheduleRule";
    DialogName.CreateOrUpdateHolidayItem = "CreateOrUpdateHolidayItem";
    AppCommon.DialogName = DialogName;
})(AppCommon || (AppCommon = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="../ClientCommon/DialogConstants.ts" />
var ServiceCommon;
(function (ServiceCommon) {
    var DialogConstants = AppCommon.DialogConstants;
    var DialogName = AppCommon.DialogName;
    var CalendarEmailCopyLinkLibrary = (function () {
        /**
         * Constructor for CalendarEmailCopyLibrary
         * @param invokedFromCustomControl Whether is called from CustomControl or not
         */
        function CalendarEmailCopyLinkLibrary(invokedFromCustomControl) {
            var _this = this;
            /**
             * Email / copy a Link from the records on the specified grid.
             * @param usingEmail True to email, False to copy
             * @param records The selected records
             * @param entityName The entity name for this grid
             * @param gridControl gridcontrol from which function is called
             * @param writeUrlOnly
             */
            this.emailCopyLinkRecords = function (usingEmail, records, entityName, gridControl, writeUrlOnly) {
                var CalendarType = "";
                CalendarType = CalendarEmailCopyLinkLibrary.GetCalendarType(gridControl);
                _this.emailCopyLinks(usingEmail, records, CalendarType, null, writeUrlOnly);
            };
            /**
             * Email / copy a Link from a list of entity references.
             * @param usingEmail True to email, False to copy
             * @param records The selected records
             * @param CalendarType Type of calendar CSS or HS
             * @param context Current Context
             * @param writeUrlOnly True if to write the URL only with out the title (optional) (default: false)
             * @param ccFieldValue Email CC address (optional)
             */
            this.emailCopyLinks = function (usingEmail, records, CalendarType, context, writeUrlOnly, ccFieldValue) {
                try {
                    if (!records || !records.length) {
                        CalendarEmailCopyLinkLibrary.openAlertDialog(context, "Error_Message_Action_NoItemSelected");
                        return;
                    }
                    if (records.length > 10) {
                        CalendarEmailCopyLinkLibrary.openAlertDialog(context, "Error_Max_Shortcut_Record_Reached");
                        return;
                    }
                    if (!usingEmail && !CalendarEmailCopyLinkLibrary.isInternetExplorer()) {
                        CalendarEmailCopyLinkLibrary.openAlertDialog(context, "Shortcut_To_Clipboard_Unsupported");
                        return;
                    }
                    if (!writeUrlOnly) {
                        writeUrlOnly = !usingEmail && records.length === 1;
                    }
                    var subject = "";
                    var body = "";
                    for (var i = 0; i < records.length; i++) {
                        var record = records[i];
                        var pageUrl = CalendarEmailCopyLinkLibrary.getCalendarRecordPageUrl(record.Id, CalendarType);
                        var entityTitle = record.Name;
                        body += (i > 0 ? "\r\n" : "") + (writeUrlOnly ? "" : entityTitle) + (" " + pageUrl + " ");
                        if (i === 0 && records.length === 1) {
                            subject = entityTitle;
                        }
                    }
                    if (usingEmail) {
                        CalendarEmailCopyLinkLibrary.openEmailForm("", subject, body, context, ccFieldValue);
                        CalendarEmailCopyLinkLibrary.reportData(context, CalendarEmailCopyLinkLibrary._emailLinkActionName);
                    }
                    else {
                        CalendarEmailCopyLinkLibrary.copyToClipBoard(body, context);
                        CalendarEmailCopyLinkLibrary.reportData(context, CalendarEmailCopyLinkLibrary._copyLinkActionName);
                    }
                }
                catch (error) {
                    var errorMessage = "Failed in emailCopyLinks function of CalendarEmailCopyLinkLibrary.";
                    CalendarEmailCopyLinkLibrary.reportErrorTelemetry(context, AppsTelemetryLib.Action.clickedGridCommand, errorMessage, error);
                    CalendarEmailCopyLinkLibrary.openAlertDialog(context, "UnexpectedErrorMessage");
                }
            };
            CalendarEmailCopyLinkLibrary._invokedFromCustomControl = invokedFromCustomControl;
        }
        /**
         * Logs error telemetry
         * @param context The "Input Bag" containing the parameters and other control metadata.
         * @param errorMessage error message to be reported
         * @param errorTrace stack trace information about error
         */
        CalendarEmailCopyLinkLibrary.reportErrorTelemetry = function (context, action, errorMessage, errorTrace) {
            if (!CalendarEmailCopyLinkLibrary._invokedFromCustomControl) {
                context = null;
            }
            AppsTelemetryLib.AppsTelemetryUtility.reportError(AppsTelemetryLib.EventList.CSSEvent, AppsTelemetryLib.ModuleList.service, AppsTelemetryLib.EntityList.calendar, action, context, errorMessage, errorTrace);
        };
        return CalendarEmailCopyLinkLibrary;
    }());
    CalendarEmailCopyLinkLibrary._appCommonResourceName = "AppCommon/Localization/Languages/AppCommon";
    CalendarEmailCopyLinkLibrary._invokedFromCustomControl = false;
    CalendarEmailCopyLinkLibrary._emailLinkActionName = "emailLinkCommand";
    CalendarEmailCopyLinkLibrary._copyLinkActionName = "copyLinkCommand";
    /**
    * Returns Localized string in based on if we are in MDD or Grid
    */
    CalendarEmailCopyLinkLibrary.getResourceString = function (key, context) {
        if (CalendarEmailCopyLinkLibrary._invokedFromCustomControl) {
            return context.resources.getString(key);
        }
        else {
            return Xrm.Utility.getResourceString(CalendarEmailCopyLinkLibrary._appCommonResourceName, key);
        }
    };
    /**
    * Opens Alert Dialog
    */
    CalendarEmailCopyLinkLibrary.openAlertDialog = function (context, key) {
        var alertMessage = CalendarEmailCopyLinkLibrary.getResourceString(key, context);
        if (CalendarEmailCopyLinkLibrary._invokedFromCustomControl) {
            context.navigation.openAlertDialog({ text: alertMessage });
        }
        else {
            Xrm.Navigation.openAlertDialog({ text: alertMessage });
        }
    };
    /**
    * Opens Alert Dialog
    */
    CalendarEmailCopyLinkLibrary.openErrorDialog = function (context, dialogOptions) {
        if (CalendarEmailCopyLinkLibrary._invokedFromCustomControl) {
            context.navigation.openErrorDialog(dialogOptions);
        }
        else {
            Xrm.Navigation.openErrorDialog(dialogOptions);
        }
    };
    /**
     * Copy data to clipboard
     * This works only in Internet Explorer
     * @param data text that needs to be copied to clipboard
     * @param context Current Context
     */
    CalendarEmailCopyLinkLibrary.copyToClipBoard = function (data, context) {
        var clipboardData = null;
        if (window && window.clipboardData && window.clipboardData.setData) {
            var retries = 2;
            // Try at least twice, sometimes IE acts wierd and does not copy the first time.
            while (retries > 0 && !clipboardData) {
                window.clipboardData.setData("text", data);
                // make sure that the data is copied over to the clipboard.
                clipboardData = window.clipboardData.getData("text");
                retries--;
            }
        }
        if (clipboardData && clipboardData.length <= 0) {
            CalendarEmailCopyLinkLibrary.openAlertDialog(context, "Shortcut_To_Clipboard_Error");
        }
    };
    /**
     * returns if current browser is internet Explorer
     */
    CalendarEmailCopyLinkLibrary.isInternetExplorer = function () {
        if (window && window.clipboardData && window.clipboardData.setData && Sys.Browser.agent) {
            return Sys.Browser.InternetExplorer === Sys.Browser.agent;
        }
        // Refer to Core/Application/WebPlatform/Utility/Util.cs : IsInternetExplorer() for more details
        if (Sys.Browser.agent == null && navigator.userAgent) {
            var agent = navigator.userAgent;
            if (agent.indexOf("IE") >= 0 || agent.indexOf("rv:11.0") > -1 || agent.indexOf("MSIE") > -1 || agent.indexOf("Trident/7.0") > -1) {
                return true;
            }
        }
        return false;
    };
    /**
     * open Email Form  (mailto)
     * @param to To Email address
     * @param subject Subject of email
     * @param body Body of email
     * @param context Current Context
     * @param cc CC email address
     */
    CalendarEmailCopyLinkLibrary.openEmailForm = function (to, subject, body, context, cc) {
        var mailtoLink = "mailto:";
        if (to) {
            var index = to.lastIndexOf("@");
            if (index >= 0 && index < to.length)
                mailtoLink += encodeURIComponent(to.substr(0, index)) + "@" + encodeURIComponent(to.substr(index + 1));
            else
                mailtoLink += encodeURIComponent(to);
        }
        var seporator = "?";
        if (cc) {
            mailtoLink += seporator + "cc=" + encodeURIComponent(cc);
            seporator = "&";
        }
        if (subject) {
            mailtoLink += seporator + "subject=" + encodeURIComponent(subject);
            seporator = "&";
        }
        if (body) {
            mailtoLink += seporator + "body=" + encodeURIComponent(body);
        }
        var maxAllowableLength = 2020;
        if (mailtoLink.length > maxAllowableLength) {
            var errorDialogOptions = {
                message: "",
                errorCode: -2147204303
            };
            CalendarEmailCopyLinkLibrary.openErrorDialog(context, errorDialogOptions);
        }
        else {
            window.location.href = mailtoLink;
        }
    };
    /**
     * returns Calendar records MDD URL
     * @param recordId of selected record
     * @param CalendarType Subject of email
     * @param PassedContext context
     */
    CalendarEmailCopyLinkLibrary.getCalendarRecordPageUrl = function (recordId, CalendarType, PassedContext) {
        var pageUrl = null;
        var dialogName = "";
        var context = null;
        if (CalendarEmailCopyLinkLibrary._invokedFromCustomControl) {
            context = getGlobalContextObject();
        }
        else if (PassedContext) {
            context = PassedContext;
        }
        else {
            context = Xrm.Utility.getGlobalContext();
        }
        if (context) {
            if (CalendarType == DialogConstants.CustomerServiceScheduleType) {
                dialogName = DialogName.CreateOrUpdateCustomerServiceScheduleRule;
                var data = "{id:" + recordId + "}";
                pageUrl = context.getCurrentAppUrl();
                pageUrl += "&pagetype=dialog";
                pageUrl += "&name=" + dialogName;
                pageUrl += "&data=" + data;
            }
            else if (CalendarType == DialogConstants.HolidayScheduleType) {
                var id = recordId;
                pageUrl = context.getCurrentAppUrl();
                pageUrl += "&pagetype=entityrecord";
                pageUrl += "&etn=calendar";
                pageUrl += "&id=" + recordId;
            }
            else {
                throw new Error("Unknown Calendar Type: " + CalendarType);
            }
        }
        else {
            throw new Error("context is undefined");
        }
        return pageUrl;
    };
    /**
     * Returns whether this is Customer Service Schedule Grid or Holiday Schedule Grid
     * @param grid
     */
    CalendarEmailCopyLinkLibrary.GetCalendarType = function (gridControl) {
        if (gridControl) {
            var gridViewId = gridControl.getViewSelector().getCurrentView().id;
            var viewId = gridViewId.replace("{", "").replace("}", "").toUpperCase();
            if (viewId == DialogConstants.Customer_Service_Schedule_View_Id) {
                return DialogConstants.CustomerServiceScheduleType;
            }
            else if (viewId == DialogConstants.Holiday_Schedule_View_Id) {
                return DialogConstants.HolidayScheduleType;
            }
        }
        return "";
    };
    /**
     * Logs event telemetry
     * @param action actionname of event to be logged
     */
    CalendarEmailCopyLinkLibrary.reportData = function (context, action) {
        if (!CalendarEmailCopyLinkLibrary._invokedFromCustomControl) {
            context = null;
        }
        var eventSpecificParams = {};
        eventSpecificParams["source"] = CalendarEmailCopyLinkLibrary._invokedFromCustomControl ? "customcontrol" : "ribbon";
        AppsTelemetryLib.AppsTelemetryUtility.reportData(AppsTelemetryLib.EventList.CSSEvent, AppsTelemetryLib.ModuleList.service, AppsTelemetryLib.EntityList.calendar, action, context, eventSpecificParams);
    };
    ServiceCommon.CalendarEmailCopyLinkLibrary = CalendarEmailCopyLinkLibrary;
})(ServiceCommon || (ServiceCommon = {}));
var ServiceCommon;
(function (ServiceCommon) {
    'use strict';
    //Output related interfaces
    var WeeklyScheduleControlOutput = (function () {
        function WeeklyScheduleControlOutput() {
        }
        return WeeklyScheduleControlOutput;
    }());
    ServiceCommon.WeeklyScheduleControlOutput = WeeklyScheduleControlOutput;
    var WeeklyScheduleControlOutputStatus;
    (function (WeeklyScheduleControlOutputStatus) {
        WeeklyScheduleControlOutputStatus[WeeklyScheduleControlOutputStatus["Error"] = 0] = "Error";
        WeeklyScheduleControlOutputStatus[WeeklyScheduleControlOutputStatus["Success"] = 1] = "Success";
    })(WeeklyScheduleControlOutputStatus = ServiceCommon.WeeklyScheduleControlOutputStatus || (ServiceCommon.WeeklyScheduleControlOutputStatus = {}));
    var WeeklyScheduleControlOutputData = (function () {
        function WeeklyScheduleControlOutputData() {
        }
        return WeeklyScheduleControlOutputData;
    }());
    ServiceCommon.WeeklyScheduleControlOutputData = WeeklyScheduleControlOutputData;
    var WorkRuleMode;
    (function (WorkRuleMode) {
        WorkRuleMode[WorkRuleMode["AllTheSameRules"] = 0] = "AllTheSameRules";
        WorkRuleMode[WorkRuleMode["VaryByDayRules"] = 1] = "VaryByDayRules";
        WorkRuleMode[WorkRuleMode["TwentyX7Support"] = 2] = "TwentyX7Support";
        WorkRuleMode[WorkRuleMode["NotWorking"] = 3] = "NotWorking";
    })(WorkRuleMode = ServiceCommon.WorkRuleMode || (ServiceCommon.WorkRuleMode = {}));
})(ServiceCommon || (ServiceCommon = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../../../../ClientUtility/Client/Common/AppsTelemetrylib.ts" />
/// <reference path="../../ServiceCommon/CalendarEmailCopyLinkLibrary.ts" />
/// <reference path="../../ServiceCommon/CalendarDataInterfaces.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="PrivateReferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CustomerServiceSchedule;
        (function (CustomerServiceSchedule) {
            'use strict';
            var CalendarEmailCopyLinkLibrary = ServiceCommon.CalendarEmailCopyLinkLibrary;
            var CalendarShareControl = (function () {
                /**
                * Empty constructor.
                */
                function CalendarShareControl() {
                    /**
                     * returns if current browser is internet Explorer
                     */
                    this.isInternetExplorer = function () {
                        if (Sys.Browser.agent) {
                            return Sys.Browser.InternetExplorer === Sys.Browser.agent;
                        }
                        // Refer to Core/Application/WebPlatform/Utility/Util.cs : IsInternetExplorer() for more details
                        if (Sys.Browser.agent == null && navigator.userAgent) {
                            var agent = navigator.userAgent;
                            if (agent.indexOf("IE") >= 0 || agent.indexOf("rv:11.0") > -1 || agent.indexOf("MSIE") > -1 || agent.indexOf("Trident/7.0") > -1) {
                                return true;
                            }
                        }
                        return false;
                    };
                }
                /**
                * This function should be used for any initial setup necessary for your control.
                * @params context The "Input Bag" containing the parameters and other control metadata.
                * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                * @params state The user state for this control set from setState in the last session
                * @params container The div element to draw this control in
                */
                CalendarShareControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    this._isInternetExplorer = this.isInternetExplorer();
                    this._emailCopyLink = new CalendarEmailCopyLinkLibrary(true);
                    CustomerServiceSchedule.CalendarShareStyles.initialize(this._context.theming, this._context.client.isRTL);
                };
                /**
                    * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                    * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                    * as well as resource, client, and theming info (see mscrm.d.ts)
                    * @params context The "Input Bag" as described above
                    */
                CalendarShareControl.prototype.updateView = function (context) {
                    this._context = context;
                    return this.createCalendarShareControl();
                };
                /**
                * This function returns the Calendar Share control.
                */
                CalendarShareControl.prototype.createCalendarShareControl = function () {
                    var topMostContainer = null;
                    try {
                        topMostContainer = this._context.factory.createElement("CONTAINER", {
                            id: CustomerServiceSchedule.CalendarShareConstants.TOPMOST_CONTAINERID,
                            key: CustomerServiceSchedule.CalendarShareConstants.TOPMOST_CONTAINERID,
                            style: CustomerServiceSchedule.CalendarShareStyles.topMostContainer,
                        }, [this.createEmailLinkAndCopyLinkButtons()]);
                    }
                    catch (e) {
                        this.showErrorMessage(e);
                    }
                    return topMostContainer;
                };
                /**
                * This function creates Email Link and Copy Link buttons & returs them.
                */
                CalendarShareControl.prototype.createEmailLinkAndCopyLinkButtons = function () {
                    var container = null;
                    var controlInput;
                    var id;
                    var name;
                    if (this._context.parameters.calendarShareControlInput) {
                        controlInput = this._context.parameters.calendarShareControlInput.raw;
                        if (!this._context.utils.isNullOrUndefined(controlInput)) {
                            id = controlInput.id;
                            name = controlInput.name;
                        }
                    }
                    var record = { Id: id, Name: name };
                    var records = [record];
                    var emailLinkIConContainer = this._context.factory.createElement("IMG", {
                        key: CustomerServiceSchedule.CalendarShareConstants.EMAILLINKICONID, id: CustomerServiceSchedule.CalendarShareConstants.EMAILLINKICONID,
                        source: CustomerServiceSchedule.ResourcePath.EmailLinkIcon,
                        style: CustomerServiceSchedule.CalendarShareStyles.copyAndEmailIconsStyle
                    }, []);
                    var emailLinkHighContrastIConContainer = this._context.factory.createElement("IMG", {
                        key: CustomerServiceSchedule.CalendarShareConstants.EMAILLINKHCICONID, id: CustomerServiceSchedule.CalendarShareConstants.EMAILLINKHCICONID,
                        source: CustomerServiceSchedule.ResourcePath.EmailLinkHighContrastIcon,
                        style: CustomerServiceSchedule.CalendarShareStyles.copyAndEmailHighContrastIconsStyle
                    }, []);
                    var copyLinkIConContainer = this._context.factory.createElement("IMG", {
                        key: CustomerServiceSchedule.CalendarShareConstants.COPYLINKICONID, id: CustomerServiceSchedule.CalendarShareConstants.COPYLINKICONID,
                        source: CustomerServiceSchedule.ResourcePath.CopyLinkIcon,
                        style: CustomerServiceSchedule.CalendarShareStyles.copyAndEmailIconsStyle
                    }, []);
                    var copyLinkHighContrastIConContainer = this._context.factory.createElement("IMG", {
                        key: CustomerServiceSchedule.CalendarShareConstants.COPYLINKHCICONID, id: CustomerServiceSchedule.CalendarShareConstants.COPYLINKHCICONID,
                        source: CustomerServiceSchedule.ResourcePath.CopyLinkHighContrastIcon,
                        style: CustomerServiceSchedule.CalendarShareStyles.copyAndEmailHighContrastIconsStyle
                    }, []);
                    var emailLinkButton = this._context.factory.createElement("BUTTON", {
                        key: CustomerServiceSchedule.CalendarShareConstants.EMAIL_LINKBUTTONID, id: CustomerServiceSchedule.CalendarShareConstants.EMAIL_LINKBUTTONID,
                        title: this._context.resources.getString(CustomerServiceSchedule.CalendarShareLocaleConstans.ResourceKey_EmailLink_Key),
                        tabindex: "0",
                        style: CustomerServiceSchedule.CalendarShareStyles.emailLinkButtonStyle,
                        onClick: this._emailCopyLink.emailCopyLinks.bind(this, true, records, "1", this._context, false, null),
                    }, [emailLinkIConContainer, emailLinkHighContrastIConContainer, this._context.resources.getString(CustomerServiceSchedule.CalendarShareLocaleConstans.ResourceKey_EmailLink_Key)]);
                    var copyLinkButton = this._context.factory.createElement("BUTTON", {
                        key: CustomerServiceSchedule.CalendarShareConstants.COPY_LINKBUTTONID, id: CustomerServiceSchedule.CalendarShareConstants.COPY_LINKBUTTONID,
                        title: this._context.resources.getString(CustomerServiceSchedule.CalendarShareLocaleConstans.ResourceKey_CopyLink_Key),
                        tabindex: "0",
                        style: CustomerServiceSchedule.CalendarShareStyles.copyLinkButtonStyle,
                        onClick: this._emailCopyLink.emailCopyLinks.bind(this, false, records, "1", this._context, true, null),
                    }, [copyLinkIConContainer, copyLinkHighContrastIConContainer, this._context.resources.getString(CustomerServiceSchedule.CalendarShareLocaleConstans.ResourceKey_CopyLink_Key)]);
                    if (this._isInternetExplorer) {
                        container = this._context.factory.createElement("CONTAINER", {
                            key: CustomerServiceSchedule.CalendarShareConstants.BUTTONSCONTAINERID, id: CustomerServiceSchedule.CalendarShareConstants.BUTTONSCONTAINERID,
                            style: CustomerServiceSchedule.CalendarShareStyles.fieldLabelStyle
                        }, [emailLinkButton, copyLinkButton]);
                    }
                    else {
                        container = this._context.factory.createElement("CONTAINER", {
                            key: CustomerServiceSchedule.CalendarShareConstants.BUTTONSCONTAINERID, id: CustomerServiceSchedule.CalendarShareConstants.BUTTONSCONTAINERID,
                            style: CustomerServiceSchedule.CalendarShareStyles.fieldLabelStyle
                        }, [emailLinkButton]);
                    }
                    return container;
                };
                /**
                * Shows generic error message to user
                * @param context The "Input Bag" containing the parameters and other control metadata.
                */
                CalendarShareControl.prototype.showErrorMessage = function (context, errorMessage, buttonText) {
                    var alertMessage = {
                        text: errorMessage != null ? errorMessage : this._context.resources.getString(CustomerServiceSchedule.CalendarShareLocaleConstans.ResourceKey_Error_GenericErrorOccurred),
                        confirmButtonLabel: buttonText != null ? buttonText : this._context.resources.getString(CustomerServiceSchedule.CalendarShareLocaleConstans.ResourceKey_ConfirmButtonText)
                    };
                    context.navigation.openAlertDialog(alertMessage);
                };
                /**
                    * This function will return an "Output Bag" to the Crm Infrastructure
                    * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                    * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                    * {
                    *		value: myvalue
                    * };
                    * @returns The "Output Bag" containing values to pass to the infrastructure
                    */
                CalendarShareControl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                    * This function will be called when the control is destroyed
                    * It should be used for cleanup and releasing any memory the control is using
                    */
                CalendarShareControl.prototype.destroy = function () {
                };
                return CalendarShareControl;
            }());
            CustomerServiceSchedule.CalendarShareControl = CalendarShareControl;
        })(CustomerServiceSchedule = AppCommon.CustomerServiceSchedule || (AppCommon.CustomerServiceSchedule = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CustomerServiceSchedule;
        (function (CustomerServiceSchedule) {
            'use strict';
            var CalendarShareStyles = (function () {
                function CalendarShareStyles() {
                }
                CalendarShareStyles.initialize = function (theming, isRTL) {
                    CalendarShareStyles.topMostContainer = {
                        display: "flex",
                        flexDirection: "column",
                        width: "100%"
                    };
                    CalendarShareStyles.fieldLabelStyle = {
                        fontFamily: theming.fontfamilies.regular,
                        fontSize: theming.fontsizes.font100,
                        lineHeight: "1.4rem",
                        color: theming.colors.basecolor.grey.grey7,
                        marginBottom: theming.measures.measure050,
                        display: "flex",
                        width: "auto"
                    };
                    CalendarShareStyles.containerStyle = {
                        display: "inline-block"
                    };
                    CalendarShareStyles.copyLinkButtonStyle = {
                        fontFamily: theming.fontfamilies.regular,
                        color: "#315fa2",
                        textDecoration: "none",
                        border: "none",
                        padding: "0px",
                        background: "none"
                    };
                    CalendarShareStyles.emailLinkButtonStyle = {
                        fontFamily: theming.fontfamilies.regular,
                        color: "#315fa2",
                        marginRight: "9px",
                        textDecoration: "none",
                        border: "none",
                        padding: "0px",
                        background: "none"
                    };
                    CalendarShareStyles.copyAndEmailHighContrastIconsStyle = {
                        display: "none",
                        height: "20px",
                        marginRight: "7px",
                        width: "16px"
                    };
                    if (isRTL) {
                        CalendarShareStyles.copyAndEmailIconsStyle = {
                            height: "20px",
                            marginLeft: "7px",
                            width: "16px"
                        };
                    }
                    else {
                        CalendarShareStyles.copyAndEmailIconsStyle = {
                            height: "20px",
                            marginRight: "7px",
                            width: "16px"
                        };
                    }
                };
                return CalendarShareStyles;
            }());
            CustomerServiceSchedule.CalendarShareStyles = CalendarShareStyles;
        })(CustomerServiceSchedule = AppCommon.CustomerServiceSchedule || (AppCommon.CustomerServiceSchedule = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CustomerServiceSchedule;
        (function (CustomerServiceSchedule) {
            'use strict';
            var CalendarShareConstants;
            (function (CalendarShareConstants) {
                //keys and ids
                CalendarShareConstants.TOPMOST_CONTAINERID = "CSC_TopMostContainer";
                CalendarShareConstants.SHARELABELID = "CSC_ShareLabel";
                CalendarShareConstants.SHARELABELCONTAINERID = "CSS_ShareLabelContainerID";
                CalendarShareConstants.HYPERLINK_LINKCONTAINERID = "CSC_HyperLinkContainer";
                CalendarShareConstants.EMAIL_LINKBUTTONID = "CSC_EmailLinkButton";
                CalendarShareConstants.COPY_LINKBUTTONID = "CSC_CopyLinkButton";
                CalendarShareConstants.BUTTONSCONTAINERID = "CSC_ButtonsContainer";
                CalendarShareConstants.COPYLINKICONID = "CSC_CopyLinkIconID";
                CalendarShareConstants.COPYLINKHCICONID = "CSC_CopyLinkHighContrastIconID";
                CalendarShareConstants.EMAILLINKICONID = "CSC_EmailLinkIconID";
                CalendarShareConstants.EMAILLINKHCICONID = "CSC_EmailLinkHighContrastIconID";
            })(CalendarShareConstants = CustomerServiceSchedule.CalendarShareConstants || (CustomerServiceSchedule.CalendarShareConstants = {}));
            var CalendarShareLocaleConstans;
            (function (CalendarShareLocaleConstans) {
                // Keys of Variables for resx file
                CalendarShareLocaleConstans.ResourceKey_EmailLink_Key = "CC_EmailLinkText";
                CalendarShareLocaleConstans.ResourceKey_CopyLink_Key = "CC_CopyLinkText";
                CalendarShareLocaleConstans.ResourceKey_ConfirmButtonText = "CC_ConfirmButtonText";
                CalendarShareLocaleConstans.ResourceKey_Error_GenericErrorOccurred = "CC_Error_GenericErrorOccurred";
                CalendarShareLocaleConstans.ResourceKey_ShareLabel_Key = "CC_ShareLabelText";
            })(CalendarShareLocaleConstans = CustomerServiceSchedule.CalendarShareLocaleConstans || (CustomerServiceSchedule.CalendarShareLocaleConstans = {}));
        })(CustomerServiceSchedule = AppCommon.CustomerServiceSchedule || (AppCommon.CustomerServiceSchedule = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="CalendarShareControl.ts" />
/// <reference path="CalendarShareStyles.ts" />
/// <reference path="CalendarShareConstants.ts" /> 
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var CustomerServiceSchedule;
        (function (CustomerServiceSchedule) {
            /**
             * Class refers to the path of all the icon resources uploaded as WebResource.
             */
            var ResourcePath = (function () {
                function ResourcePath() {
                }
                Object.defineProperty(ResourcePath, "EmailLinkIcon", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/CalendarShare/EmailLink.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "CopyLinkIcon", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/CalendarShare/CopyLink.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "EmailLinkHighContrastIcon", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/CalendarShare/EmailLinkHC.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourcePath, "CopyLinkHighContrastIcon", {
                    get: function () {
                        return "../../WebResources/AppCommon/ControlWS/CalendarShare/CopyLinkHC.svg";
                    },
                    enumerable: true,
                    configurable: true
                });
                return ResourcePath;
            }());
            CustomerServiceSchedule.ResourcePath = ResourcePath;
        })(CustomerServiceSchedule = AppCommon.CustomerServiceSchedule || (AppCommon.CustomerServiceSchedule = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=CalendarShareControl.js.map