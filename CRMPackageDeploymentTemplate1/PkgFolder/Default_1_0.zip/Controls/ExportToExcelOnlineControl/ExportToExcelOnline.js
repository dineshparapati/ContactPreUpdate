var ODataContract;
(function (ODataContract) {
    var Object = (function () {
        function Object(type, value) {
            this.Type = type;
            this.Value = value;
        }
        Object.prototype.getMetadata = function () {
            var metadata = {
                boundParameter: null,
                parameterTypes: {
                    "Type": {
                        "typeName": "Edm.String",
                        "structuralProperty": 1,
                    },
                    "Value": {
                        "typeName": "Edm.String",
                        "structuralProperty": 1,
                    },
                },
                operationName: null,
                operationType: null,
            };
            return metadata;
        };
        return Object;
    }());
    ODataContract.Object = Object;
})(ODataContract || (ODataContract = {}));
///<reference path="./Object.ts" />
var ODataContract;
(function (ODataContract) {
    var InputArgument = (function () {
        function InputArgument(count, isReadOnly, keys, values) {
            this.Count = count;
            this.IsReadOnly = isReadOnly;
            this.Keys = keys;
            this.Values = values;
        }
        InputArgument.prototype.getMetadata = function () {
            var metadata = {
                boundParameter: null,
                parameterTypes: {
                    "Count": {
                        "typeName": "Edm.Int32",
                        "structuralProperty": 1,
                    },
                    "IsReadOnly": {
                        "typeName": "Edm.Boolean",
                        "structuralProperty": 1,
                    },
                    "Keys": {
                        "typeName": "Edm.String",
                        "structuralProperty": 4,
                    },
                    "Values": {
                        "typeName": "mscrm.Object",
                        "structuralProperty": 4,
                    },
                },
                operationName: null,
                operationType: null,
            };
            return metadata;
        };
        return InputArgument;
    }());
    ODataContract.InputArgument = InputArgument;
})(ODataContract || (ODataContract = {}));
///<reference path="./InputArgument.ts" />
var ODataContract;
(function (ODataContract) {
    var InputArgumentCollection = (function () {
        function InputArgumentCollection(args) {
            this.Arguments = args;
        }
        InputArgumentCollection.prototype.getMetadata = function () {
            var metadata = {
                boundParameter: null,
                parameterTypes: {
                    "Arguments": {
                        "typeName": "Microsoft.Dynamics.CRM.InputArgument",
                        "structuralProperty": 2,
                    },
                },
                operationName: null,
                operationType: null,
            };
            return metadata;
        };
        return InputArgumentCollection;
    }());
    ODataContract.InputArgumentCollection = InputArgumentCollection;
})(ODataContract || (ODataContract = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../FREShell/DataContracts/InputArgument.ts" />
/// <reference path="../FREShell/DataContracts/InputArgumentCollection.ts" />
/// <reference path="../../../../../references/external/TypeDefinitions/jquery.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExportToExcelOnline;
        (function (ExportToExcelOnline) {
            'use strict';
            var ExportToExcelOnlineControl = (function () {
                /**
                 * Empty constructor.
                 */
                function ExportToExcelOnlineControl() {
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                ExportToExcelOnlineControl.prototype.init = function (context, notifyOutputChanged, state, container) {
                    // custom code goes here
                    this._renderTemplateData = false;
                    this._context = context;
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                    var OdataView = "";
                    var view = context.parameters.view.raw != null ? context.parameters.view.raw : "";
                    this._fetchXml = context.parameters.fetchXml.raw != null ? context.parameters.fetchXml.raw : "";
                    this._layoutXml = context.parameters.layoutXml.raw != null ? context.parameters.layoutXml.raw : "";
                    this._entityType = context.parameters.entityTypeName.raw != null ? context.parameters.entityTypeName.raw : "";
                    if (view.length > 0) {
                        var XrmGlobalContext = Xrm.Utility.getGlobalContext();
                        var OdataUri = XrmGlobalContext.getClientUrl() + '/api/data/v9.0/';
                        /* Summary
                        /// View is a string like - "savedquery/{00000000-0000-0000-00AA-000010001001}"
                        /// We convert it to odataUri like - "http://<crmbaseuri>/<orgname>/api/data/v9.0/savedqueries(00000000-0000-0000-00AA-000010001001)"
                        /// -------------- Rendering a Template data in Excel Online ---------------------
                        /// Similarly we convert - Template Rendering from "documenttemplate/00000000-0000-0000-00AA-000010001001" to documenttemplates(00000000-0000-0000-00AA-000010001001)
                        /// For PersonalDocument Template i.e "personaldocumenttemplate/00000000-0000-0000-00AA-000010001001" to personaldocumenttemplates(00000000-0000-0000-00AA-000010001001)
                        */
                        if (view.indexOf("documenttemplate") != -1) {
                            //Rendering a Template Data via Excel Online
                            this._renderTemplateData = true;
                            OdataView = OdataUri + view.substr(0, view.indexOf("/")) + 's(' + view.substr(view.indexOf("/") + 1, 36) + ')';
                        }
                        else {
                            OdataView = OdataUri + view.substr(0, view.indexOf("/") - 1) + 'ies(' + view.substr(view.indexOf("/") + 2, 36) + ')';
                        }
                    }
                    else {
                        var excelOnlineControlFailureEvent = new ExportToExcelOnline.ExcelOnlineControlFailureEvent(this._entityType, "", "undefined view passed for export to excel");
                        Xrm.Reporting.reportEvent(excelOnlineControlFailureEvent);
                    }
                    var viewEntityReference = {};
                    viewEntityReference["@odata.id"] = OdataView;
                    this._currentView = viewEntityReference;
                    var excelOnlineControlInitEvent = new ExportToExcelOnline.ExcelOnlineControlInitEvent(this._entityType, view);
                    Xrm.Reporting.reportEvent(excelOnlineControlInitEvent);
                };
                ExportToExcelOnlineControl.prototype.getXrmVersion = function () {
                    return Xrm.Utility.getGlobalContext().getVersion().split('.').slice(0, 2).join('.');
                };
                ExportToExcelOnlineControl.prototype.getCustomControlHeight = function () {
                    var dialog = jQuery("*").find("div[data-id='ExportToExcelOnlineDialog']");
                    var dialogContent = jQuery(dialog).find("div[id^='dialogContentContainer']");
                    var dialogHeader = jQuery(dialog).find("div[data-id='dialogHeader']")[0];
                    var dialogFooter = jQuery(dialog).find("div[data-id='dialogFooter']")[0];
                    var closeIcon = jQuery(dialog).find("button[data-id='dialogCloseIconButton']")[0];
                    return dialogContent.height() - dialogHeader.clientHeight - dialogFooter.clientHeight - closeIcon.clientHeight;
                };
                ExportToExcelOnlineControl.prototype.getFileGenerationTimeDiv = function () {
                    // Create file generation time div
                    var fileGeneratedString = this._context.resources.getString('ExportToExcelOnline_FileGenerated');
                    var dateOnly = this._context.formatting.formatDateShort(new Date(this._fileCreatedOn + " GMT"), false);
                    var dateTime = this._context.formatting.formatTime(new Date(this._fileCreatedOn + " GMT"), 1 /* UserLocal */);
                    var time = dateTime.replace(dateOnly, dateOnly + ',');
                    var generationTimeDiv = document.createElement("div");
                    var dateTimeTitleDiv = document.createElement("div");
                    dateTimeTitleDiv.textContent = fileGeneratedString;
                    var dateTimeDiv = document.createElement("div");
                    dateTimeDiv.textContent = time;
                    var direction = "left";
                    if (this._context.userSettings.isRTL) {
                        dateTimeDiv.style.paddingRight = "5px";
                        dateTimeTitleDiv.style.paddingRight = "5px";
                    }
                    else {
                        direction = "right";
                        dateTimeDiv.style.paddingLeft = "5px";
                        dateTimeTitleDiv.style.paddingLeft = "5px";
                    }
                    dateTimeTitleDiv.setAttribute("aria-label", fileGeneratedString);
                    dateTimeTitleDiv.style.cssFloat = dateTimeDiv.style.cssFloat = generationTimeDiv.style.cssFloat = direction;
                    dateTimeTitleDiv.style.textAlign = generationTimeDiv.style.textAlign = dateTimeDiv.style.textAlign = direction;
                    dateTimeDiv.style.fontSize = dateTimeTitleDiv.style.fontSize = "12px";
                    dateTimeDiv.style.fontFamily = dateTimeTitleDiv.style.fontFamily = "Segoe UI Regular, SegoeUI, Segoe UI";
                    generationTimeDiv.style.display = "table";
                    generationTimeDiv.tabIndex = 0;
                    generationTimeDiv.style.paddingBottom = generationTimeDiv.style.paddingTop = "6px";
                    generationTimeDiv.appendChild(dateTimeDiv);
                    generationTimeDiv.appendChild(dateTimeTitleDiv);
                    return generationTimeDiv;
                };
                // Launch excel online using the uri and access token returned by wopi sdk
                ExportToExcelOnlineControl.prototype.launchExcelOnlineControl = function () {
                    var control = document.getElementsByClassName("customControl MscrmControls AppCommon.ExportToExcelOnline.ExportToExcelOnlineControl");
                    var controlDiv = control[0];
                    var dialogHeight = this.getCustomControlHeight();
                    controlDiv.style.height = dialogHeight + 'px';
                    var wopiFrame = document.createElement("iframe");
                    wopiFrame.setAttribute('id', 'wopi_frame');
                    wopiFrame.setAttribute('name', 'wopi_frame');
                    wopiFrame.style.width = "100%";
                    wopiFrame.style.height = "calc(100% - 28px)";
                    wopiFrame.style.display = "table";
                    var excelForm = document.createElement("form");
                    excelForm.setAttribute('method', "POST");
                    var requestUri = this._excelUri;
                    var accessToken = this._accessToken;
                    excelForm.setAttribute('action', requestUri);
                    excelForm.setAttribute("target", "wopi_frame");
                    var inputToExcelForm = document.createElement("input"); //input element, text
                    inputToExcelForm.setAttribute('type', "hidden");
                    inputToExcelForm.setAttribute('name', "access_token");
                    inputToExcelForm.setAttribute('value', accessToken);
                    excelForm.appendChild(inputToExcelForm);
                    // Create file generation time div
                    var generationTimeDiv = this.getFileGenerationTimeDiv();
                    //and some more input elements here
                    //and dont forget to add a submit button
                    controlDiv.appendChild(generationTimeDiv);
                    controlDiv.appendChild(excelForm);
                    controlDiv.appendChild(wopiFrame);
                    excelForm.submit();
                };
                ExportToExcelOnlineControl.prototype.loadExcelFile = function (fileData) {
                    // custom code goes here
                    // Get Excel online uri and access token using wopi sdk
                    var req = new ODataContract.WopiExcelClientInfoRequest("Excel", "xlsx", this._fileId);
                    var that = this;
                    this._context.webAPI.execute(req).then(function (response) {
                        response.json().then(function (value) {
                            that._excelUri = value.ExcelOnlineUri;
                            that._accessToken = value.AccessToken;
                            that.launchExcelOnlineControl();
                        });
                    }, function (err) {
                        var excelOnlineControlFailureEvent = new ExportToExcelOnline.ExcelOnlineControlFailureEvent(that._entityType, that._fileId, err.message);
                        Xrm.Reporting.reportEvent(excelOnlineControlFailureEvent);
                    });
                };
                ExportToExcelOnlineControl.prototype.convertOfficeDocumentFileToExcelOnlineFile = function () {
                    var XrmGlobalContext = Xrm.Utility.getGlobalContext();
                    var OdataUri = XrmGlobalContext.getClientUrl() + '/api/data/v9.0/';
                    // Use ExportToExcelOnline sdk to get file Id of officeDocument stored in CRM db and file generation time.
                    var inputArg = new ODataContract.InputArgument(0, false, [], []);
                    var inputArguColl = new ODataContract.InputArgumentCollection(inputArg);
                    var req;
                    if (this._renderTemplateData) {
                        req = new ODataContract.ExportTemplateToExcelOnlineRequest(this._currentView, this._fetchXml, "", inputArguColl);
                    }
                    else {
                        req = new ODataContract.ExportToExcelOnlineRequest(this._currentView, this._fetchXml, this._layoutXml, "", inputArguColl);
                    }
                    var that = this;
                    this._context.webAPI.execute(req).then(function (response) {
                        response.json().then(function (value) {
                            var response = JSON.parse(value.EditLink);
                            that._fileCreatedOn = response.OfficeDocumentCreatedOn;
                            that._fileId = response.OfficeDocumentId;
                            that._notifyOutputChanged();
                            var excelOnlineFileCreatedEvent = new ExportToExcelOnline.ExcelOnlineFileCreatedEvent(that._entityType, that._fileCreatedOn, that._fileId);
                            Xrm.Reporting.reportEvent(excelOnlineFileCreatedEvent);
                            that.loadExcelFile(that);
                        });
                    }, function (err) {
                        var excelOnlineControlFailureEvent = new ExportToExcelOnline.ExcelOnlineControlFailureEvent(that._entityType, "", err.message);
                        Xrm.Reporting.reportEvent(excelOnlineControlFailureEvent);
                        var errorMessage = "";
                        if (err.innerror && err.innerror.message) {
                            if (err.innerror.message != "") {
                                errorMessage = err.innerror.message;
                            }
                        }
                        else {
                            errorMessage = err.message;
                        }
                        var errorDialogOptions = {
                            message: errorMessage,
                            errorCode: err.errorCode
                        };
                        Xrm.Page.ui.close();
                        Xrm.Navigation.openErrorDialog(errorDialogOptions);
                    });
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                ExportToExcelOnlineControl.prototype.updateView = function (context) {
                    this.convertOfficeDocumentFileToExcelOnlineFile();
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                ExportToExcelOnlineControl.prototype.getOutputs = function () {
                    this._context.parameters.file_id.raw = this._fileId;
                    var result = {
                        "file_id": this._fileId
                    };
                    return result;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                ExportToExcelOnlineControl.prototype.destroy = function () {
                };
                return ExportToExcelOnlineControl;
            }());
            ExportToExcelOnline.ExportToExcelOnlineControl = ExportToExcelOnlineControl;
        })(ExportToExcelOnline = AppCommon.ExportToExcelOnline || (AppCommon.ExportToExcelOnline = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="ExportToExcelOnline.ts" /> 
///<reference path="../../FREShell/DataContracts/InputArgumentCollection.ts" />
/// <reference path="../../../../../TypeDefinitions/mscrm.d.ts" />
var ODataContract;
(function (ODataContract) {
    /* tslint:disable:crm-force-fields-private */
    var ExportToExcelOnlineRequest = (function () {
        function ExportToExcelOnlineRequest(view /*Microsoft.Dynamics.CRM.crmbaseentity*/, fetchXml, layoutXml, queryApi, queryParameters) {
            this.View = view;
            this.FetchXml = fetchXml;
            this.LayoutXml = layoutXml;
            this.QueryApi = queryApi;
            this.QueryParameters = queryParameters;
        }
        ExportToExcelOnlineRequest.prototype.getMetadata = function () {
            var metadata = {
                boundParameter: null,
                parameterTypes: {
                    "View": {
                        "typeName": "Microsoft.Dynamics.CRM.crmbaseentity",
                        "structuralProperty": 5,
                    },
                    "FetchXml": {
                        "typeName": "Edm.String",
                        "structuralProperty": 1,
                    },
                    "LayoutXml": {
                        "typeName": "Edm.String",
                        "structuralProperty": 1,
                    },
                    "QueryApi": {
                        "typeName": "Edm.String",
                        "structuralProperty": 1,
                    },
                    "QueryParameters": {
                        "typeName": "Microsoft.Dynamics.CRM.InputArgumentCollection",
                        "structuralProperty": 2,
                    },
                },
                operationName: "ExportToExcelOnline",
                operationType: 0,
            };
            return metadata;
        };
        return ExportToExcelOnlineRequest;
    }());
    ODataContract.ExportToExcelOnlineRequest = ExportToExcelOnlineRequest;
})(ODataContract || (ODataContract = {}));
///<reference path="../../FREShell/DataContracts/InputArgumentCollection.ts" />
/// <reference path="../../../../../TypeDefinitions/mscrm.d.ts" />
var ODataContract;
(function (ODataContract) {
    /* tslint:disable:crm-force-fields-private */
    var WopiExcelClientInfoRequest = (function () {
        function WopiExcelClientInfoRequest(DocumentType, FileExtension, FileId) {
            this.DocumentType = DocumentType;
            this.FileExtension = FileExtension;
            this.FileId = FileId;
        }
        WopiExcelClientInfoRequest.prototype.getMetadata = function () {
            var metadata = {
                boundParameter: null,
                parameterTypes: {
                    "DocumentType": {
                        "typeName": "Edm.String",
                        "structuralProperty": 1,
                    },
                    "FileExtension": {
                        "typeName": "Edm.String",
                        "structuralProperty": 1,
                    },
                    "FileId": {
                        "typeName": "Edm.String",
                        "structuralProperty": 1,
                    },
                },
                operationName: "GetWopiExcelClientInfo",
                operationType: 0,
            };
            return metadata;
        };
        return WopiExcelClientInfoRequest;
    }());
    ODataContract.WopiExcelClientInfoRequest = WopiExcelClientInfoRequest;
})(ODataContract || (ODataContract = {}));
///<reference path="../../FREShell/DataContracts/InputArgumentCollection.ts" />
/// <reference path="../../../../../TypeDefinitions/mscrm.d.ts" />
var ODataContract;
(function (ODataContract) {
    /* tslint:disable:crm-force-fields-private */
    var ExportTemplateToExcelOnlineRequest = (function () {
        function ExportTemplateToExcelOnlineRequest(template /*Microsoft.Dynamics.CRM.crmbaseentity*/, fetchXml, queryApi, queryParameters) {
            this.Template = template;
            this.FetchXml = fetchXml;
            this.QueryApi = queryApi;
            this.QueryParameters = queryParameters;
        }
        ExportTemplateToExcelOnlineRequest.prototype.getMetadata = function () {
            var metadata = {
                boundParameter: null,
                parameterTypes: {
                    "Template": {
                        "typeName": "Microsoft.Dynamics.CRM.crmbaseentity",
                        "structuralProperty": 5,
                    },
                    "FetchXml": {
                        "typeName": "Edm.String",
                        "structuralProperty": 1,
                    },
                    "QueryApi": {
                        "typeName": "Edm.String",
                        "structuralProperty": 1,
                    },
                    "QueryParameters": {
                        "typeName": "Microsoft.Dynamics.CRM.InputArgumentCollection",
                        "structuralProperty": 2,
                    },
                },
                operationName: "ExportTemplateToExcelOnline",
                operationType: 0,
            };
            return metadata;
        };
        return ExportTemplateToExcelOnlineRequest;
    }());
    ODataContract.ExportTemplateToExcelOnlineRequest = ExportTemplateToExcelOnlineRequest;
})(ODataContract || (ODataContract = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExportToExcelOnline;
        (function (ExportToExcelOnline) {
            'use strict';
            /**
            * The name of this event which will be reported to Telemetry pipeline
            */
            var ExcelOnlineFileCreated = "ExcelOnlineFileCreated";
            var ExcelOnlineControlInit = "ExcelOnlineControlInit";
            var ExcelOnlineControlFailure = "ExcelOnlineControlFailure";
            var ExcelOnlineFileCreatedEvent = (function () {
                function ExcelOnlineFileCreatedEvent(entityType, fileCreatedOn, fileId) {
                    this.eventName = ExcelOnlineFileCreated;
                    this.eventParameters = [
                        { name: "entityType", value: entityType },
                        { name: "fileCreatedOn", value: fileCreatedOn },
                        { name: "fileId", value: fileId },
                    ];
                }
                return ExcelOnlineFileCreatedEvent;
            }());
            ExportToExcelOnline.ExcelOnlineFileCreatedEvent = ExcelOnlineFileCreatedEvent;
            var ExcelOnlineControlInitEvent = (function () {
                function ExcelOnlineControlInitEvent(entityType, view) {
                    this.eventName = ExcelOnlineControlInit;
                    this.eventParameters = [
                        { name: "entityType", value: entityType },
                        { name: "view", value: view },
                    ];
                }
                return ExcelOnlineControlInitEvent;
            }());
            ExportToExcelOnline.ExcelOnlineControlInitEvent = ExcelOnlineControlInitEvent;
            var ExcelOnlineControlFailureEvent = (function () {
                function ExcelOnlineControlFailureEvent(entityType, fileId, message) {
                    this.eventName = ExcelOnlineControlFailure;
                    this.eventParameters = [
                        { name: "entityType", value: entityType },
                        { name: "fileId", value: fileId },
                        { name: "message", value: message },
                    ];
                }
                return ExcelOnlineControlFailureEvent;
            }());
            ExportToExcelOnline.ExcelOnlineControlFailureEvent = ExcelOnlineControlFailureEvent;
        })(ExportToExcelOnline = AppCommon.ExportToExcelOnline || (AppCommon.ExportToExcelOnline = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var ExportToExcelOnline;
        (function (ExportToExcelOnline) {
            'use strict';
            var Control = (function () {
                /**
                 * Empty constructor.
                 */
                function Control() {
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                Control.prototype.init = function (context, notifyOutputChanged, state) {
                    // custom code goes here
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                Control.prototype.updateView = function (context) {
                    // custom code goes here
                    return null;
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                Control.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return null;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                Control.prototype.destroy = function () {
                };
                return Control;
            }());
            ExportToExcelOnline.Control = Control;
        })(ExportToExcelOnline = AppCommon.ExportToExcelOnline || (AppCommon.ExportToExcelOnline = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=ExportToExcelOnline.js.map