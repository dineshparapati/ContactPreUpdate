/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var LinkedInExtensionControls;
(function (LinkedInExtensionControls) {
    var LinkedInImage;
    (function (LinkedInImage) {
        'use strict';
        var LinkedInImageControl = (function () {
            /**
             * Empty constructor.
             */
            function LinkedInImageControl() {
                this._salesNavigatorMemberProfileCtrl = 'MscrmControls.LinkedInIntegration.LinkedInLeadControl';
                this._showSalesNavigatorButton = false;
                this._dialogContext = null;
                this._context = null;
                this._salesNavMemberCtrlVersion = null;
                this._targetTabName = null;
                this._applyStyles = null;
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            LinkedInImageControl.prototype.init = function (context, notifyOutputChanged, state) {
                var _this = this;
                this._context = context;
                if (context.parameters.Inputs == null || context.parameters.Inputs.raw == null) {
                    return;
                }
                this._applyStyles = new LinkedInImage.LinkedInImageControlStyles(context);
                this.validateSalesNavigatorBtnPresence(context).then(function (entityRecords) {
                    if (entityRecords.entities.length > 0) {
                        _this._showSalesNavigatorButton = true;
                        _this._salesNavMemberCtrlVersion = entityRecords.entities[0].version;
                        LinkedInImage.TelemetryReporter.ReportComponentSuccess(context, LinkedInImage.TelemetryReporter.getSalesNavButtonEventParams(_this._salesNavMemberCtrlVersion, "Button-Visible"));
                        context.utils.requestRender();
                    }
                    else {
                        LinkedInImage.TelemetryReporter.ReportComponentSuccess(context, LinkedInImage.TelemetryReporter.getSalesNavButtonEventParams(_this._salesNavMemberCtrlVersion, "Button-NotVisible"));
                    }
                }, ClientUtility.ActionFailedHandler.actionFailedErrorDialog);
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            LinkedInImageControl.prototype.updateView = function (context) {
                if (context.parameters.Inputs == null || context.parameters.Inputs.raw == null) {
                    return;
                }
                var childContainers = new Array();
                var imageContainer = this.getProfileImageControl(context);
                if (imageContainer != null) {
                    childContainers.push(imageContainer);
                    // form the button container.
                    var buttonContainer = this.getSalesNavigatorButton(context);
                    if (buttonContainer != null) {
                        childContainers.push(buttonContainer);
                    }
                    return context.factory.createElement("CONTAINER", {
                        key: "maincontainer",
                        id: "maincontainer",
                        style: this._applyStyles.BaseContainerStyle()
                    }, childContainers);
                }
                return null;
            };
            LinkedInImageControl.prototype.getSalesNavigatorButton = function (context) {
                var buttonElement = null;
                // Proceed to form button only if dialogContext and the tab name exist.
                if (this._showSalesNavigatorButton && context.parameters.Inputs.raw.FormContext && context.parameters.Inputs.raw.TargetTabName) {
                    this._dialogContext = context.parameters.Inputs.raw.FormContext;
                    this._targetTabName = context.parameters.Inputs.raw.TargetTabName;
                    //LinkedIn Logo on Sales Navigator button
                    var buttonLogo = context.factory.createElement("MICROSOFTICON", {
                        key: "navigator_icon",
                        id: "navigator_icon",
                        type: 309,
                        style: this._applyStyles.LogoStyle()
                    });
                    var buttonText = context.factory.createElement("CONTAINER", {
                        key: "navigator_text",
                        id: "navigator_text",
                        style: this._applyStyles.ButtonTextStyle(),
                    }, "Sales Navigator");
                    buttonElement = context.factory.createElement("BUTTON", {
                        key: "navigator_button",
                        id: "navigator_button",
                        tabIndex: 0,
                        accessibilityLabel: "Sales Navigator",
                        style: this._applyStyles.ButtonStyle(),
                        onClick: this.salesNavigatorBtnClick.bind(this)
                    }, [buttonLogo, buttonText]);
                }
                return buttonElement;
            };
            LinkedInImageControl.prototype.salesNavigatorBtnClick = function () {
                // move to the target tab.
                LinkedInImage.TelemetryReporter.ReportComponentSuccess(this._context, LinkedInImage.TelemetryReporter.getSalesNavButtonEventParams(this._salesNavMemberCtrlVersion, "Button-Clicked"));
                this._dialogContext.ui.moveTo(this._targetTabName);
                var HeaderControl = this._dialogContext.ui.controls.get(LinkedInImage.LinkedInImageConstants.DialogHeaderID);
                if (HeaderControl) {
                    HeaderControl.setLabel(LinkedInImage.LinkedInImageConstants.SalesNavigatorHeader);
                }
            };
            LinkedInImageControl.prototype.getProfileImageControl = function (context) {
                // Form image container.
                var imageContainer = null;
                var recordImageIcon = context.factory.createElement("ENTITYIMAGE", {
                    id: "record_image",
                    key: "record_image",
                    title: context.parameters.Inputs.raw.FullName,
                    accessibilityLabel: context.parameters.Inputs.raw.FullName,
                    style: this._applyStyles.ImageStyle(),
                    imageSrc: context.parameters.Inputs.raw.ImageUrl,
                    entityPrimaryField: context.parameters.Inputs.raw.FullName,
                    hasPrimaryImageField: true
                }, []);
                imageContainer = context.factory.createElement("CONTAINER", {
                    key: "image_container",
                    id: "image_container",
                    style: this._applyStyles.ImageContainerStyle()
                }, [recordImageIcon]);
                return imageContainer;
            };
            LinkedInImageControl.prototype.validateSalesNavigatorBtnPresence = function (context) {
                // if the org contains Sales navigator control, display the LinkedIn button
                return context.webAPI.retrieveMultipleRecords('customcontrol', "?$select=customcontrolid,version&$filter=name eq '" + this._salesNavigatorMemberProfileCtrl + "'");
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            LinkedInImageControl.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                return null;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            LinkedInImageControl.prototype.destroy = function () {
            };
            return LinkedInImageControl;
        }());
        LinkedInImage.LinkedInImageControl = LinkedInImageControl;
    })(LinkedInImage = LinkedInExtensionControls.LinkedInImage || (LinkedInExtensionControls.LinkedInImage = {}));
})(LinkedInExtensionControls || (LinkedInExtensionControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="LinkedInImageControl.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var LinkedInExtensionControls;
(function (LinkedInExtensionControls) {
    var LinkedInImage;
    (function (LinkedInImage) {
        var LinkedInImageControlStyles = (function () {
            function LinkedInImageControlStyles(context) {
                this._contactImageStyleProperties = {};
                this._imageContainerStyleProperties = {};
                this._baseContainerStyleProperties = {};
                this._buttonStyleProperties = {};
                this._buttonTextStyleProperties = {};
                this._logoStyleProperties = {};
                this._context = context;
                this._contactImageStyleProperties = null;
                this._imageContainerStyleProperties = null;
                this._baseContainerStyleProperties = null;
                this._buttonStyleProperties = null;
                this._buttonTextStyleProperties = null;
                this._logoStyleProperties = null;
            }
            LinkedInImageControlStyles.prototype.ImageStyle = function () {
                if (this._context.utils.isNullOrUndefined(this._contactImageStyleProperties)) {
                    this._contactImageStyleProperties = {};
                    this._contactImageStyleProperties["border-radius"] = "50%";
                    this._contactImageStyleProperties["background-clip"] = "padding-box";
                    this._contactImageStyleProperties["alignSelf"] = "center";
                    this._contactImageStyleProperties["border"] = "7px solid #F2F2F2";
                    this._contactImageStyleProperties["width"] = "60px";
                    this._contactImageStyleProperties["height"] = "60px";
                    this._contactImageStyleProperties["margin"] = "auto";
                    this._contactImageStyleProperties["textAlign"] = "center";
                    this._contactImageStyleProperties["fontWeight"] = this._context.theming.fontfamilies.bold;
                    this._contactImageStyleProperties["lineHeight"] = "21px";
                    this._contactImageStyleProperties["color"] = "white";
                    this._contactImageStyleProperties["fontSize"] = "18px";
                    this._contactImageStyleProperties["fontFamily"] = this._context.theming.normalfontfamily;
                    this._contactImageStyleProperties["textTransform"] = "uppercase";
                    this._contactImageStyleProperties["display"] = "flex";
                    this._contactImageStyleProperties["justify-content"] = "center";
                    this._contactImageStyleProperties["align-items"] = "center";
                }
                return this._contactImageStyleProperties;
            };
            LinkedInImageControlStyles.prototype.ImageContainerStyle = function () {
                if (this._context.utils.isNullOrUndefined(this._imageContainerStyleProperties)) {
                    this._imageContainerStyleProperties = {};
                    this._imageContainerStyleProperties["textAlign"] = "center";
                    this._imageContainerStyleProperties["verticalAlign"] = "center";
                }
                return this._imageContainerStyleProperties;
            };
            LinkedInImageControlStyles.prototype.ButtonStyle = function () {
                if (this._context.utils.isNullOrUndefined(this._buttonStyleProperties)) {
                    this._buttonStyleProperties = {};
                    this._buttonStyleProperties["border-width"] = "1px";
                    this._buttonStyleProperties["border-style"] = "solid";
                    this._buttonStyleProperties["border-radius"] = "3px";
                    this._buttonStyleProperties["border-color"] = "#EAEAEA";
                    this._buttonStyleProperties["background-color"] = "#F2F2F2";
                    this._buttonStyleProperties["width"] = "140px";
                    this._buttonStyleProperties["height"] = "28px";
                    this._buttonStyleProperties["padding"] = "0px";
                    this._buttonStyleProperties["margin-top"] = "15px";
                    this._buttonStyleProperties["margin-left"] = "auto";
                    this._buttonStyleProperties["margin-right"] = "auto";
                    this._buttonStyleProperties["margin-bottom"] = "15px";
                    // Hover Styling
                    var _buttonStyleHover = {};
                    _buttonStyleHover["cursor"] = "pointer";
                    this._buttonStyleProperties[":hover"] = _buttonStyleHover;
                }
                return this._buttonStyleProperties;
            };
            LinkedInImageControlStyles.prototype.ButtonTextStyle = function () {
                if (this._context.utils.isNullOrUndefined(this._buttonTextStyleProperties)) {
                    this._buttonTextStyleProperties = {};
                    this._buttonTextStyleProperties["width"] = "96px";
                    this._buttonTextStyleProperties["height"] = "18px";
                    this._buttonTextStyleProperties["line-height"] = "16px";
                    this._buttonTextStyleProperties["margin-top"] = "4px";
                    this._buttonTextStyleProperties["margin-bottom"] = "6px";
                    this._buttonTextStyleProperties["font-family"] = "Segoe UI";
                    this._buttonTextStyleProperties["font-style"] = "normal";
                    this._buttonTextStyleProperties["font-size"] = "14px";
                    this._buttonTextStyleProperties["align-items"] = "center";
                }
                return this._buttonTextStyleProperties;
            };
            LinkedInImageControlStyles.prototype.LogoStyle = function () {
                if (this._context.utils.isNullOrUndefined(this._logoStyleProperties)) {
                    this._logoStyleProperties = {};
                    this._logoStyleProperties["color"] = "#3B79B7";
                    this._logoStyleProperties["margin-top"] = "6px";
                    this._logoStyleProperties["margin-bottom"] = "5px";
                    this._logoStyleProperties["margin-left"] = "10px";
                    this._logoStyleProperties["margin-right"] = "10px";
                }
                return this._logoStyleProperties;
            };
            LinkedInImageControlStyles.prototype.BaseContainerStyle = function () {
                if (this._context.utils.isNullOrUndefined(this._baseContainerStyleProperties)) {
                    this._baseContainerStyleProperties = {};
                    this._baseContainerStyleProperties["width"] = "220px";
                    this._baseContainerStyleProperties["height"] = "auto";
                    this._baseContainerStyleProperties["display"] = "table";
                    this._baseContainerStyleProperties["margin"] = "auto";
                }
                return this._baseContainerStyleProperties;
            };
            return LinkedInImageControlStyles;
        }());
        LinkedInImage.LinkedInImageControlStyles = LinkedInImageControlStyles;
    })(LinkedInImage = LinkedInExtensionControls.LinkedInImage || (LinkedInExtensionControls.LinkedInImage = {}));
})(LinkedInExtensionControls || (LinkedInExtensionControls = {}));
/**

* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
var LinkedInExtensionControls;
(function (LinkedInExtensionControls) {
    var LinkedInImage;
    (function (LinkedInImage) {
        'use strict';
        var LinkedInImageConstants = (function () {
            function LinkedInImageConstants() {
            }
            Object.defineProperty(LinkedInImageConstants, "DialogHeaderID", {
                get: function () {
                    return "header_id";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(LinkedInImageConstants, "SalesNavigatorHeader", {
                get: function () {
                    return "LinkedIn Sales Navigator";
                },
                enumerable: true,
                configurable: true
            });
            return LinkedInImageConstants;
        }());
        LinkedInImage.LinkedInImageConstants = LinkedInImageConstants;
    })(LinkedInImage = LinkedInExtensionControls.LinkedInImage || (LinkedInExtensionControls.LinkedInImage = {}));
})(LinkedInExtensionControls || (LinkedInExtensionControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
var LinkedInExtensionControls;
(function (LinkedInExtensionControls) {
    var LinkedInImage;
    (function (LinkedInImage) {
        'use strict';
        var TelemetryReporter = (function () {
            function TelemetryReporter() {
            }
            TelemetryReporter.getSalesNavButtonEventParams = function (controlVersion, operation) {
                var params = new Array();
                params.push({ name: "LinkedInLeadControlVersion", value: controlVersion });
                params.push({ name: "SalesNavButton", value: operation });
                return params;
            };
            TelemetryReporter.ReportComponentSuccess = function (context, params) {
                // push data to uciMonitorSuccess
                context.reporting.reportSuccess("LinkedInExtensionControls.LinkedInImage.LinkedInImageControl", params);
            };
            return TelemetryReporter;
        }());
        LinkedInImage.TelemetryReporter = TelemetryReporter;
    })(LinkedInImage = LinkedInExtensionControls.LinkedInImage || (LinkedInExtensionControls.LinkedInImage = {}));
})(LinkedInExtensionControls || (LinkedInExtensionControls = {}));
//# sourceMappingURL=LinkedInImageControl.js.map