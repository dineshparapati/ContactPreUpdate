var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t;
    return { next: verb(0), "throw": verb(1), "return": verb(2) };
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var EmailTemplate;
    (function (EmailTemplate) {
        var ActivityTypesExtractor = (function () {
            function ActivityTypesExtractor(context) {
                this.context = context;
            }
            // activity types comes as comma separated string
            // if there is several activity types we should use only global (systemuser)
            // if activity types count is 1 then we should show this type + global (systemuser)
            ActivityTypesExtractor.prototype.extract = function () {
                var result = [];
                if (this.context.parameters.activityType.formatted.length) {
                    var activityTypes = this.context.parameters.activityType.formatted.split(",");
                    if (activityTypes.length === 1) {
                        result.push(activityTypes[0]);
                    }
                }
                result.push("systemuser");
                return result;
            };
            return ActivityTypesExtractor;
        }());
        EmailTemplate.ActivityTypesExtractor = ActivityTypesExtractor;
    })(EmailTemplate = MscrmControls.EmailTemplate || (MscrmControls.EmailTemplate = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var EmailTemplate;
    (function (EmailTemplate) {
        var EmailTemplateSelectorConstants = (function () {
            function EmailTemplateSelectorConstants() {
            }
            return EmailTemplateSelectorConstants;
        }());
        EmailTemplateSelectorConstants.AllLanguagesValue = "0";
        EmailTemplate.EmailTemplateSelectorConstants = EmailTemplateSelectorConstants;
    })(EmailTemplate = MscrmControls.EmailTemplate || (MscrmControls.EmailTemplate = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
// tslint:disable:no-string-literal
var MscrmControls;
(function (MscrmControls) {
    var EmailTemplate;
    (function (EmailTemplate) {
        var ControlsBuilder = (function () {
            function ControlsBuilder(context) {
                this.context = context;
            }
            ControlsBuilder.prototype.buildLabel = function (labelId, title, forElementId, className) {
                var properties = {
                    key: labelId
                };
                if (!this.context.utils.isNullOrUndefined(forElementId)) {
                    properties.forElementId = forElementId;
                }
                if (!this.context.utils.isNullOrUndefined(className)) {
                    properties.className = className;
                }
                return this.context.factory.createElement("LABEL", properties, title);
            };
            ControlsBuilder.prototype.buildContainer = function (containerId, children, className) {
                var properties = {
                    id: containerId,
                    key: containerId
                };
                if (this.context.utils.isNullOrUndefined(className)) {
                    properties.className = className;
                }
                return this.context.factory.createElement("CONTAINER", properties, children);
            };
            ControlsBuilder.prototype.buildSelectControl = function (controlName, options, value, onChange, onError) {
                var entityKeysProps = {
                    key: controlName,
                    id: controlName + (controlName + "id"),
                    labelledByElementId: controlName + "label",
                    describedByElementId: controlName + "label",
                    onChange: onChange,
                    onError: onError,
                    disabled: false,
                    autoFocus: true,
                    options: options,
                    value: value,
                    style: this.selectControlStyle()
                };
                var entityKeysComboBox = this.context.factory.createElement("SELECT", entityKeysProps, null);
                return entityKeysComboBox;
            };
            ControlsBuilder.prototype.selectControlStyle = function () {
                var _a = this.context.theming, noneborderstyle = _a.noneborderstyle, textbox = _a.textbox;
                var backgroundColor = textbox.backgroundcolor;
                var color = textbox.contentcolor;
                var selectStyle = {
                    appearance: "normal",
                    width: "100%",
                    paddingTop: textbox.verticalpadding,
                    paddingBottom: textbox.verticalpadding,
                    paddingLeft: textbox.horizontalpadding,
                    paddingRight: textbox.horizontalpadding,
                    fontSize: textbox.fontsize,
                    fontWeight: textbox.fontweight,
                    backgroundColor: this.context.theming.colors.whitebackground,
                    color: color
                };
                var optionStyle = {
                    backgroundColor: backgroundColor,
                    color: color
                };
                return {
                    selectStyle: selectStyle,
                    optionStyle: optionStyle
                };
            };
            return ControlsBuilder;
        }());
        EmailTemplate.ControlsBuilder = ControlsBuilder;
    })(EmailTemplate = MscrmControls.EmailTemplate || (MscrmControls.EmailTemplate = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var EmailTemplate;
    (function (EmailTemplate) {
        var EmailTemplateSelectorControl = (function () {
            function EmailTemplateSelectorControl() {
                var _this = this;
                this.languages = [];
                this.emailTemplates = [];
                this.populateLanguages = function () { return __awaiter(_this, void 0, void 0, function () {
                    var _this = this;
                    return __generator(this, function (_a) {
                        return [2 /*return*/, new Promise(function (resolve, reject) {
                                _this.emailTemplatesRepository.getSupportedLanguageCodes().then(function (languageCodes) {
                                    _this.languageRepository.getLanguageByCode(EmailTemplate.EmailTemplateSelectorConstants.AllLanguagesValue).then(function (allLanguagesOption) {
                                        _this.languages.push({ Label: allLanguagesOption.language, Value: allLanguagesOption.languageCode });
                                        for (var _i = 0, languageCodes_1 = languageCodes; _i < languageCodes_1.length; _i++) {
                                            var languageCode = languageCodes_1[_i];
                                            _this.languageRepository.getLanguageByCode(languageCode).then(function (language) {
                                                _this.languages.push({ Label: language.language, Value: language.languageCode });
                                            });
                                        }
                                        resolve();
                                    }).catch(reject);
                                }).catch(reject);
                            })];
                    });
                }); };
                this.populateEmailTemplates = function () { return __awaiter(_this, void 0, void 0, function () {
                    var _this = this;
                    return __generator(this, function (_a) {
                        return [2 /*return*/, new Promise(function (resolve, reject) {
                                _this.emailTemplatesRepository.getAllTemplates().then(function (templates) {
                                    _this.emailTemplates = [];
                                    for (var _i = 0, templates_1 = templates; _i < templates_1.length; _i++) {
                                        var template = templates_1[_i];
                                        if (_this.selectedLanguageCode === EmailTemplate.EmailTemplateSelectorConstants.AllLanguagesValue || template.languageCode === _this.selectedLanguageCode) {
                                            _this.emailTemplates.push({ Value: template.templateId, Label: template.title });
                                        }
                                    }
                                    resolve();
                                }).catch(reject);
                            })];
                    });
                }); };
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputChanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The container for the element
             */
            EmailTemplateSelectorControl.prototype.init = function (context, notifyOutputChanged, state, container) {
                var _this = this;
                this.context = context;
                var activityTypes = new EmailTemplate.ActivityTypesExtractor(context).extract();
                var clientUrl = context.page.getClientUrl();
                this.emailTemplatesRepository = new EmailTemplate.EmailTemplateRepository(clientUrl, activityTypes);
                this.languageRepository = new EmailTemplate.LanguageRepository(clientUrl, context.resources.getString("Email_Template_Selector_All_Languages_Label"));
                this.userRepository = new EmailTemplate.UserRepository(clientUrl);
                this.controlBuilder = new EmailTemplate.ControlsBuilder(context);
                this.populateLanguages()
                    .then(function () { return _this.selectedLanguageCode = _this.languages[0].Value; })
                    .then(function () { return _this.populateEmailTemplates()
                    .then(function () { return _this.selectedEmailTemplate = _this.emailTemplates[0]; })
                    .then(function () {
                    _this.container = container;
                    _this.notifyOutputChanged = notifyOutputChanged;
                    _this.renderControls(context);
                    _this.notifyOutputChanged();
                }); });
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            EmailTemplateSelectorControl.prototype.updateView = function (context) { };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *     value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            EmailTemplateSelectorControl.prototype.getOutputs = function () {
                return {
                    selectedTemplateId: this.selectedEmailTemplate.Value,
                    selectedTemplateTitle: this.selectedEmailTemplate.Label
                };
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            EmailTemplateSelectorControl.prototype.destroy = function () {
                this.container.remove();
                this.container = null;
            };
            EmailTemplateSelectorControl.prototype.renderControls = function (context) {
                var _this = this;
                var onLanguageChange = function (language) {
                    _this.selectedLanguageCode = language.Value;
                    _this.populateEmailTemplates();
                    _this.renderControls(context);
                    _this.notifyOutputChanged();
                };
                var onEmailTemplateChange = function (selectedEmailTemplate) {
                    _this.selectedEmailTemplate = selectedEmailTemplate;
                    _this.renderControls(context);
                    _this.notifyOutputChanged();
                };
                this.languageRepository.getLanguageByCode(this.selectedLanguageCode).then(function (selectedLanguage) {
                    _this.emailTemplatesRepository.getTemplateById(_this.selectedEmailTemplate.Value).then(function (selectedTemplate) {
                        _this.userRepository.getById(selectedTemplate.createdBy).then(function (createdBy) {
                            var languageControlLabel = context.resources.getString("Email_Template_Selector_Language_Label");
                            var selectLanguageControlLabel = _this.controlBuilder.buildLabel("selectLanguageControlLabel", languageControlLabel);
                            var selectLanguageControl = _this.controlBuilder.buildSelectControl("selectLanguageControl", _this.languages, { Label: selectedLanguage.language, Value: selectedLanguage.languageCode }, onLanguageChange, _this.onError);
                            var selectLanguageGroup = _this.controlBuilder.buildContainer("selectLanguageGroup", [selectLanguageControlLabel, selectLanguageControl]);
                            var templateControlLabel = context.resources.getString("Email_Template_Selector_Template_Label");
                            var selectEmailTemplateControlLabel = _this.controlBuilder.buildLabel("selectEmailTemplateControlLabel", templateControlLabel);
                            var selectEmailTemplateControl = _this.controlBuilder.buildSelectControl("selectEmailTemplateControl", _this.emailTemplates, { Label: selectedTemplate.title, Value: selectedTemplate.templateId }, onEmailTemplateChange, _this.onError);
                            var selectEmailTemplateGroup = _this.controlBuilder.buildContainer("selectEmailTemplateGroup", [selectEmailTemplateControlLabel, selectEmailTemplateControl]);
                            var typeLabelPrefix = context.resources.getString("Email_Template_Selector_Type_Label_Prefix");
                            var detailsTypeLabel = _this.controlBuilder.buildLabel("detailsTypeLabel", typeLabelPrefix + selectedTemplate.templateTypeCode);
                            var detailsTypeLabelGroup = _this.controlBuilder.buildContainer("detailsTypeLabelGroup", [detailsTypeLabel]);
                            var createdByLabelPrefix = context.resources.getString("Email_Template_Selector_CreatedBy_Label_Prefix");
                            var detailsCreatedByLabel = _this.controlBuilder.buildLabel("detailsCreatedByLabel", createdByLabelPrefix + createdBy.fullName);
                            var detailsCreatedByLabelGroup = _this.controlBuilder.buildContainer("detailsCreatedByLabelGroup", [detailsCreatedByLabel]);
                            var createdOnLabelPrefix = context.resources.getString("Email_Template_Selector_CreatedOn_Label_Prefix");
                            var createdOn = new Date(selectedTemplate.createdOn).toLocaleDateString();
                            var detailsCreatedOnLabel = _this.controlBuilder.buildLabel("detailsCreatedOnLabel", createdOnLabelPrefix + createdOn);
                            var detailsCreatedOnLabelGroup = _this.controlBuilder.buildContainer("detailsCreatedOnLabelGroup", [detailsCreatedOnLabel]);
                            var descriptionLabelPrefix = context.resources.getString("Email_Template_Selector_Description_Label_Prefix");
                            var description = selectedTemplate.description != null ? selectedTemplate.description : "";
                            var detailsDescriptionLabel = _this.controlBuilder.buildLabel("detailsDescriptionLabel", descriptionLabelPrefix + description);
                            var detailsDescriptionLabelGroup = _this.controlBuilder.buildContainer("detailsDescriptionLabelGroup", [detailsDescriptionLabel]);
                            var detailsGroup = _this.controlBuilder.buildContainer("detailsGroup", [detailsTypeLabelGroup, detailsCreatedByLabelGroup, detailsCreatedOnLabelGroup, detailsDescriptionLabelGroup]);
                            var emailSelectorGroup = _this.controlBuilder.buildContainer("emailSelectorGroup", [selectLanguageGroup, selectEmailTemplateGroup, detailsGroup]);
                            context.utils.bindDOMElement(emailSelectorGroup, _this.container);
                        });
                    });
                });
            };
            EmailTemplateSelectorControl.prototype.onError = function (errorDetails) {
                throw new Error(errorDetails);
            };
            return EmailTemplateSelectorControl;
        }());
        EmailTemplate.EmailTemplateSelectorControl = EmailTemplateSelectorControl;
    })(EmailTemplate = MscrmControls.EmailTemplate || (MscrmControls.EmailTemplate = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var EmailTemplate;
    (function (EmailTemplate) {
        var InputBag = (function () {
            function InputBag() {
            }
            return InputBag;
        }());
        EmailTemplate.InputBag = InputBag;
    })(EmailTemplate = MscrmControls.EmailTemplate || (MscrmControls.EmailTemplate = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var EmailTemplate;
    (function (EmailTemplate) {
        var OutputBag = (function () {
            function OutputBag() {
            }
            return OutputBag;
        }());
        EmailTemplate.OutputBag = OutputBag;
    })(EmailTemplate = MscrmControls.EmailTemplate || (MscrmControls.EmailTemplate = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var EmailTemplate;
    (function (EmailTemplate) {
        var UserRepository = (function () {
            function UserRepository(clientUrl) {
                var _this = this;
                this.clientUrl = clientUrl;
                this.usersCache = [];
                this.getById = function (id) { return __awaiter(_this, void 0, void 0, function () {
                    var _this = this;
                    return __generator(this, function (_a) {
                        return [2 /*return*/, new Promise(function (resolve, reject) {
                                for (var _i = 0, _a = _this.usersCache; _i < _a.length; _i++) {
                                    var u = _a[_i];
                                    if (u.id === id) {
                                        resolve(u);
                                        return;
                                    }
                                }
                                Xrm.WebApi.retrieveMultipleRecords("systemuser", "?$select=fullname&$filter=systemuserid eq " + id).then(function (response) {
                                    if (!response || !response.entities || !response.entities.length) {
                                        reject();
                                        return;
                                    }
                                    var user = {
                                        id: id,
                                        fullName: response.entities[0].fullname
                                    };
                                    _this.usersCache.push(user);
                                    resolve(user);
                                }, reject);
                            })];
                    });
                }); };
            }
            return UserRepository;
        }());
        EmailTemplate.UserRepository = UserRepository;
    })(EmailTemplate = MscrmControls.EmailTemplate || (MscrmControls.EmailTemplate = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var EmailTemplate;
    (function (EmailTemplate) {
        var EmailTemplateRepository = (function () {
            function EmailTemplateRepository(clientUrl, activityTypes) {
                var _this = this;
                this.clientUrl = clientUrl;
                this.activityTypes = activityTypes;
                this.getAllTemplates = function () { return __awaiter(_this, void 0, void 0, function () {
                    return __generator(this, function (_a) {
                        return [2 /*return*/, this.populateEmailTemplatesCacheIfRequired()];
                    });
                }); };
                this.getTemplateById = function (id) { return __awaiter(_this, void 0, void 0, function () {
                    var _this = this;
                    return __generator(this, function (_a) {
                        return [2 /*return*/, new Promise(function (resolve, reject) {
                                _this.populateEmailTemplatesCacheIfRequired().then(function (templates) {
                                    var result = templates.filter(function (template) { return template.templateId === id; })[0];
                                    if (!result) {
                                        reject();
                                        return;
                                    }
                                    resolve(result);
                                }).catch(reject);
                            })];
                    });
                }); };
                this.getSupportedLanguageCodes = function () { return __awaiter(_this, void 0, void 0, function () {
                    var _this = this;
                    return __generator(this, function (_a) {
                        return [2 /*return*/, new Promise(function (resolve, reject) {
                                _this.getAllTemplates().then(function (templates) {
                                    if (!templates) {
                                        reject();
                                        return;
                                    }
                                    var languages = templates.map(function (item) { return item.languageCode; }).slice();
                                    resolve(languages);
                                }, reject);
                            })];
                    });
                }); };
                this.populateEmailTemplatesCacheIfRequired = function () { return __awaiter(_this, void 0, void 0, function () {
                    var _this = this;
                    return __generator(this, function (_a) {
                        return [2 /*return*/, new Promise(function (resolve, reject) {
                                if (_this.emailTemlpatesCache != null) {
                                    resolve(_this.emailTemlpatesCache);
                                    return;
                                }
                                Xrm.WebApi.retrieveMultipleRecords("template", "?$select=languagecode,templateid,createdon,templatetypecode,_createdby_value,description,title" + _this.buildFilter()).then(function (response) {
                                    if (!response || !response.entities) {
                                        reject();
                                        return;
                                    }
                                    var result = [];
                                    for (var _i = 0, _a = response.entities; _i < _a.length; _i++) {
                                        var element = _a[_i];
                                        var template = {
                                            languageCode: element.languagecode,
                                            templateId: element.templateid,
                                            createdOn: element.createdon,
                                            description: element.description,
                                            templateTypeCode: element.templatetypecode,
                                            createdBy: element._createdby_value,
                                            title: element.title
                                        };
                                        result.push(template);
                                    }
                                    _this.emailTemlpatesCache = result;
                                    resolve(_this.emailTemlpatesCache);
                                }, reject);
                            })];
                    });
                }); };
            }
            EmailTemplateRepository.prototype.buildFilter = function () {
                var filter = "";
                if (this.activityTypes.length > 0) {
                    filter = "&$filter=";
                    for (var i = 0; i < this.activityTypes.length; i++) {
                        if (i !== 0) {
                            filter += " or ";
                        }
                        filter += "templatetypecode eq '" + this.activityTypes[i] + "'";
                    }
                }
                return filter;
            };
            return EmailTemplateRepository;
        }());
        EmailTemplate.EmailTemplateRepository = EmailTemplateRepository;
    })(EmailTemplate = MscrmControls.EmailTemplate || (MscrmControls.EmailTemplate = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var EmailTemplate;
    (function (EmailTemplate) {
        var LanguageRepository = (function () {
            function LanguageRepository(clientUrl, allLanguagesLabel) {
                var _this = this;
                this.clientUrl = clientUrl;
                this.allLanguagesLabel = allLanguagesLabel;
                this.getLanguageByCode = function (languageCode) { return __awaiter(_this, void 0, void 0, function () {
                    var _this = this;
                    return __generator(this, function (_a) {
                        return [2 /*return*/, new Promise(function (resolve, reject) {
                                if (languageCode === EmailTemplate.EmailTemplateSelectorConstants.AllLanguagesValue) {
                                    resolve(_this.getOverallLanguage());
                                    return;
                                }
                                Xrm.WebApi.retrieveMultipleRecords("languagelocale", "?$select=language&$filter=localeid eq " + languageCode).then(function (response) {
                                    if (!response || !response.entities || !response.entities.length) {
                                        return null;
                                    }
                                    var result = {
                                        languageCode: languageCode,
                                        language: response.entities[0].language
                                    };
                                    resolve(result);
                                }, reject);
                            })];
                    });
                }); };
            }
            LanguageRepository.prototype.getOverallLanguage = function () {
                var result = {
                    languageCode: EmailTemplate.EmailTemplateSelectorConstants.AllLanguagesValue,
                    language: this.allLanguagesLabel
                };
                return result;
            };
            return LanguageRepository;
        }());
        EmailTemplate.LanguageRepository = LanguageRepository;
    })(EmailTemplate = MscrmControls.EmailTemplate || (MscrmControls.EmailTemplate = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=EmailTemplateSelector.js.map