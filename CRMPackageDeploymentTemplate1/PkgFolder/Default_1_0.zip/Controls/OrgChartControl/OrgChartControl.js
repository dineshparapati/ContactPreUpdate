/**

* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
var LinkedInExtensionControls;
(function (LinkedInExtensionControls) {
    var OrgChart;
    (function (OrgChart) {
        'use strict';
        var ControlStrings = (function () {
            function ControlStrings() {
            }
            Object.defineProperty(ControlStrings, "ControlName", {
                get: function () {
                    return "LinkedInExtensionControls.OrgChart.OrgChartControl";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlStrings, "PageLoadingID", {
                get: function () {
                    return "PageLoading";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlStrings, "CommandBarId", {
                get: function () {
                    return "CommandBarId";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlStrings, "CommandBarContainer", {
                get: function () {
                    return "commandBarContainer";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlStrings, "JQueryHierarchyControlContainer", {
                get: function () {
                    return "jqueryHierarchyControlContainer";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlStrings, "OrgChartMaincontainer", {
                get: function () {
                    return "orgChartMaincontainer";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlStrings, "BodyContainer", {
                get: function () {
                    return "BodyContainer";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlStrings, "BlueGhostImageURL", {
                get: function () {
                    return "/WebResources/LinkedInExtensions/OrgChart/LinkedInExtensions_BlueGhost.svg";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlStrings, "YellowGhostImageURL", {
                get: function () {
                    return "/WebResources/LinkedInExtensions/OrgChart/LinkedInExtensions_YellowGhost.svg";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlStrings, "RedGhostImageURL", {
                get: function () {
                    return "/WebResources/LinkedInExtensions/OrgChart/LinkedInExtensions_RedGhost.svg";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlStrings, "GhostChartLoadingImageURL", {
                get: function () {
                    return "/WebResources/LinkedInExtensions/OrgChart/LinkedInExtensions_OrgChartLoading.svg";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlStrings, "AddIconImageURL", {
                get: function () {
                    return "/WebResources/LinkedInExtensions/OrgChart/LinkedInExtensions_AddIcon.svg";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlStrings, "RefreshCmdId", {
                get: function () {
                    return "RefreshOrgChartButton";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlStrings, "RemoveNodeCmdId", {
                get: function () {
                    return "RemoveNodeButton";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlStrings, "SaveCmdId", {
                get: function () {
                    return "SaveOrgChartButton";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlStrings, "OrgChartHeader", {
                get: function () {
                    return "OrgChartHeader";
                },
                enumerable: true,
                configurable: true
            });
            return ControlStrings;
        }());
        OrgChart.ControlStrings = ControlStrings;
        var OrgChartNodeTypes = (function () {
            function OrgChartNodeTypes() {
            }
            Object.defineProperty(OrgChartNodeTypes, "GhostManagerDummyState", {
                get: function () {
                    return "GhostManagerDummyState";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(OrgChartNodeTypes, "GhostManagerLooseHierarchies", {
                get: function () {
                    return "GhostManagerLooseHierarchies";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(OrgChartNodeTypes, "DummyStaff", {
                get: function () {
                    return "DummyStaff";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(OrgChartNodeTypes, "CRMRootNode", {
                get: function () {
                    return "CRMRootNode";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(OrgChartNodeTypes, "CRMContact", {
                get: function () {
                    return "CRMContact";
                },
                enumerable: true,
                configurable: true
            });
            return OrgChartNodeTypes;
        }());
        OrgChart.OrgChartNodeTypes = OrgChartNodeTypes;
        var TelemetryConstants = (function () {
            function TelemetryConstants() {
            }
            Object.defineProperty(TelemetryConstants, "AccountParam", {
                get: function () {
                    return "AccountId";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "ParentAttrName", {
                get: function () {
                    return "ParentAttrName";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "CmdList", {
                get: function () {
                    return "CmdList";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "CommandId", {
                get: function () {
                    return "CommandId";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "CommandEventType", {
                get: function () {
                    return "CommandEventType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "ControlEventTypes", {
                get: function () {
                    return "ControlEventTypes";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "ContactParam", {
                get: function () {
                    return "ContactId";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "RootNodeTypeParam", {
                get: function () {
                    return "RootNodeTypeParam";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "RootNodeHeightParam", {
                get: function () {
                    return "RootNodeHeightParam";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "NodeTypeParam", {
                get: function () {
                    return "NodeType";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "ActionParam", {
                get: function () {
                    return "Action";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "OriginParam", {
                get: function () {
                    return "Origin";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "SidePanelNodeStateCodeParam", {
                get: function () {
                    return "SidePanelNodeStateCodeParam";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "SidePanelNodeImageAvailableParam", {
                get: function () {
                    return "SidePanelNodeImageAvailableParam";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "SidePanelNodeManagerCount", {
                get: function () {
                    return "SidePanelNodeManagerCount";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "SidePanelNodeStaffMemberCount", {
                get: function () {
                    return "SidePanelNodeStaffMemberCount";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "GhostMgrChildrenCount", {
                get: function () {
                    return "GhostMgrChildrenCount";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "OldParentContactId", {
                get: function () {
                    return "oldParentContactId";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "NewParentContactId", {
                get: function () {
                    return "newParentContactId";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "ChildrenCount", {
                get: function () {
                    return "childrenCount";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(TelemetryConstants, "RecordsUpdatedCount", {
                get: function () {
                    return "recordsUpdatedCount";
                },
                enumerable: true,
                configurable: true
            });
            return TelemetryConstants;
        }());
        OrgChart.TelemetryConstants = TelemetryConstants;
        var ControlEventTypes = (function () {
            function ControlEventTypes() {
            }
            Object.defineProperty(ControlEventTypes, "DoubleClick", {
                get: function () {
                    return "dblClick";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlEventTypes, "SingleClick", {
                get: function () {
                    return "singleClick";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlEventTypes, "Init", {
                get: function () {
                    return "init";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlEventTypes, "DataInit", {
                get: function () {
                    return "data-init";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlEventTypes, "NodeFocusOut", {
                get: function () {
                    return "nodeFocusOut";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ControlEventTypes, "NodeDrop", {
                get: function () {
                    return "nodedrop";
                },
                enumerable: true,
                configurable: true
            });
            return ControlEventTypes;
        }());
        OrgChart.ControlEventTypes = ControlEventTypes;
        var ResourceKeys = (function () {
            function ResourceKeys() {
            }
            Object.defineProperty(ResourceKeys, "ControlLoadingKey", {
                get: function () {
                    return "ControlLoadingKey";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "EmptyStateNodeName", {
                get: function () {
                    return "EmptyStateNodeName";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "EmptyStateManagerTitle", {
                get: function () {
                    return "EmptyStateManagerTitle";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "EmptyStateStaffTitle", {
                get: function () {
                    return "EmptyStateStaffTitle";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "RefreshOrgChartCommand", {
                get: function () {
                    return "RefreshOrgChartCommand";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "RefreshOrgChartCommandToolTip", {
                get: function () {
                    return "RefreshOrgChartCommandToolTip";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "RemoveNodeCommand", {
                get: function () {
                    return "RemoveNodeCommand";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "RemoveNodeCommandToolTip", {
                get: function () {
                    return "RemoveNodeCommandToolTip";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "RemoveNodeDlgTitle", {
                get: function () {
                    return "RemoveNodeDlgTitle";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "RemoveNodeDlgText", {
                get: function () {
                    return "RemoveNodeDlgText";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "RemoveNodeDlgConfirmBtn", {
                get: function () {
                    return "RemoveNodeDlgConfirmBtn";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "RemoveNodeDlgCancelBtn", {
                get: function () {
                    return "RemoveNodeDlgCancelBtn";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "OrgChartUpdatedSuccessfully", {
                get: function () {
                    return "OrgChartUpdatedSuccessfully";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "SaveOrgChartCommand", {
                get: function () {
                    return "SaveOrgChartCommand";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "SaveOrgChartCommandToolTip", {
                get: function () {
                    return "SaveOrgChartCommandToolTip";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "SavingMessage", {
                get: function () {
                    return "SavingMessage";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ResourceKeys, "OrgChartHeading", {
                get: function () {
                    return "OrgChartHeading";
                },
                enumerable: true,
                configurable: true
            });
            return ResourceKeys;
        }());
        OrgChart.ResourceKeys = ResourceKeys;
        var DialogConstants = (function () {
            function DialogConstants() {
            }
            Object.defineProperty(DialogConstants, "SelectedNodeParameter", {
                get: function () {
                    return "selected_node";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(DialogConstants, "DialogOkId", {
                get: function () {
                    return "ok_id";
                },
                enumerable: true,
                configurable: true
            });
            return DialogConstants;
        }());
        OrgChart.DialogConstants = DialogConstants;
        var EntityNames = (function () {
            function EntityNames() {
            }
            Object.defineProperty(EntityNames, "Contact", {
                get: function () {
                    return "contact";
                },
                enumerable: true,
                configurable: true
            });
            return EntityNames;
        }());
        OrgChart.EntityNames = EntityNames;
    })(OrgChart = LinkedInExtensionControls.OrgChart || (LinkedInExtensionControls.OrgChart = {}));
})(LinkedInExtensionControls || (LinkedInExtensionControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
var LinkedInExtensionControls;
(function (LinkedInExtensionControls) {
    var OrgChart;
    (function (OrgChart) {
        'use strict';
        var HierarchyControlInputs = (function () {
            function HierarchyControlInputs() {
            }
            return HierarchyControlInputs;
        }());
        OrgChart.HierarchyControlInputs = HierarchyControlInputs;
    })(OrgChart = LinkedInExtensionControls.OrgChart || (LinkedInExtensionControls.OrgChart = {}));
})(LinkedInExtensionControls || (LinkedInExtensionControls = {}));
var LinkedInExtensionDataContracts;
(function (LinkedInExtensionDataContracts) {
    /* tslint:disable:crm-force-fields-private */
    var RetrieveOrgChartDataRequest = (function () {
        function RetrieveOrgChartDataRequest(RecordId, ColumnSet) {
            this.RecordId = RecordId;
            this.ColumnSet = ColumnSet;
        }
        RetrieveOrgChartDataRequest.prototype.getMetadata = function () {
            var metadata = {
                boundParameter: null,
                parameterTypes: {
                    "RecordId": {
                        "typeName": "Edm.Guid",
                        "structuralProperty": 1,
                    },
                    "ColumnSet": {
                        "typeName": "Microsoft.Dynamics.CRM.ColumnSet",
                        "structuralProperty": 2,
                    },
                },
                operationName: "RetrieveOrgChartData",
                operationType: 1,
            };
            return metadata;
        };
        return RetrieveOrgChartDataRequest;
    }());
    LinkedInExtensionDataContracts.RetrieveOrgChartDataRequest = RetrieveOrgChartDataRequest;
})(LinkedInExtensionDataContracts || (LinkedInExtensionDataContracts = {}));
var LinkedInExtensionDataContracts;
(function (LinkedInExtensionDataContracts) {
    /* tslint:disable:crm-force-fields-private */
    var UpdateOrgChartDataRequest = (function () {
        function UpdateOrgChartDataRequest(RecordsDetail, ReferencingAttributeName) {
            this.RecordsDetail = RecordsDetail;
            this.ReferencingAttributeName = ReferencingAttributeName;
        }
        UpdateOrgChartDataRequest.prototype.getMetadata = function () {
            var metadata = {
                boundParameter: null,
                parameterTypes: {
                    "RecordsDetail": {
                        "typeName": "Edm.String",
                        "structuralProperty": 1,
                    },
                    "ReferencingAttributeName": {
                        "typeName": "Edm.String",
                        "structuralProperty": 1,
                    },
                },
                operationName: "UpdateOrgChartData",
                operationType: 0,
            };
            return metadata;
        };
        return UpdateOrgChartDataRequest;
    }());
    LinkedInExtensionDataContracts.UpdateOrgChartDataRequest = UpdateOrgChartDataRequest;
})(LinkedInExtensionDataContracts || (LinkedInExtensionDataContracts = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="../../../Common/DataContracts/RetrieveOrgChartDataRequest.ts" />
/// <reference path="../../../Common/DataContracts/UpdateOrgChartDataRequest.ts" />
/// <reference path="../../../../../../references/internal/TypeDefinitions/XrmClientApi/XrmInternalApi.d.ts" />
var LinkedInExtensionControls;
(function (LinkedInExtensionControls) {
    var OrgChart;
    (function (OrgChart) {
        'use strict';
        var InternalUtils = (function () {
            function InternalUtils() {
            }
            /**
             * Gets the data parameter from context of the custom control
             */
            InternalUtils.getContextDataParameter = function (context, key) {
                var rVal = null;
                var controlMode = context.mode;
                if (controlMode != null && controlMode._fullPageParam != null && controlMode._fullPageParam[key] != null) {
                    rVal = controlMode._fullPageParam[key];
                }
                return rVal;
            };
            /**
            * Create inputs to JQueryHierarchy control for dummy state.
            */
            InternalUtils.getInputForGhostState = function (ctrlContext) {
                var datasource = InternalUtils.getGhostManager(ctrlContext);
                datasource['nodeType'] = OrgChart.OrgChartNodeTypes.GhostManagerDummyState;
                datasource['children'] = [
                    {
                        'fullname': ctrlContext.resources.getString(OrgChart.ResourceKeys.EmptyStateNodeName),
                        'jobtitle': ctrlContext.resources.getString(OrgChart.ResourceKeys.EmptyStateStaffTitle),
                        'entityimage_url': ctrlContext.page.getClientUrl() + OrgChart.ControlStrings.BlueGhostImageURL,
                        'nodeType': OrgChart.OrgChartNodeTypes.DummyStaff
                    },
                    {
                        'fullname': ctrlContext.resources.getString(OrgChart.ResourceKeys.EmptyStateNodeName),
                        'jobtitle': ctrlContext.resources.getString(OrgChart.ResourceKeys.EmptyStateStaffTitle),
                        'entityimage_url': ctrlContext.page.getClientUrl() + OrgChart.ControlStrings.RedGhostImageURL,
                        'nodeType': OrgChart.OrgChartNodeTypes.DummyStaff
                    },
                    {
                        'fullname': ctrlContext.resources.getString(OrgChart.ResourceKeys.EmptyStateNodeName),
                        'jobtitle': ctrlContext.resources.getString(OrgChart.ResourceKeys.EmptyStateStaffTitle),
                        'entityimage_url': ctrlContext.page.getClientUrl() + OrgChart.ControlStrings.YellowGhostImageURL,
                        'nodeType': OrgChart.OrgChartNodeTypes.DummyStaff
                    }
                ];
                var dummyStateInputs = new OrgChart.HierarchyControlInputs();
                dummyStateInputs.JsonData = datasource;
                dummyStateInputs.NodeTemplateFn = this.getNodeTemplate();
                dummyStateInputs.AllowDragDrop = true;
                dummyStateInputs.AllowPan = true;
                dummyStateInputs.AllowZoom = true;
                return dummyStateInputs;
            };
            /**
            * Create inputs to JQueryHierarchy control for dummy state.
            */
            InternalUtils.getInputForOrgChart = function (ctrlContext, orgChartDataResponse, parentAttribute) {
                var datasource = InternalUtils.processInputForOrgChart(ctrlContext, orgChartDataResponse, parentAttribute);
                var OrgChartInputs = new OrgChart.HierarchyControlInputs();
                OrgChartInputs.JsonData = datasource;
                OrgChartInputs.NodeTemplateFn = this.getNodeTemplate();
                OrgChartInputs.AllowDragDrop = true;
                OrgChartInputs.AllowPan = true;
                OrgChartInputs.AllowZoom = true;
                OrgChartInputs.LoadChildrenFromJsonData = true;
                OrgChartInputs.PrimaryField = "fullname";
                return OrgChartInputs;
            };
            /**
             * orgChartDataResponse.length
             * 1: corresponds to single Hierachy with only one root node
             * greater than 1: corresponds to multiple loose hierarchies, add ghost manager as root
             */
            InternalUtils.processInputForOrgChart = function (ctrlContext, orgChartDataResponse, parentAttribute) {
                // remove parent value for root nodes 
                for (var i = 0; i < orgChartDataResponse.length; i++) {
                    orgChartDataResponse[i][parentAttribute] = "";
                }
                if (orgChartDataResponse.length == 1) {
                    orgChartDataResponse[0].nodeType = OrgChart.OrgChartNodeTypes.CRMRootNode;
                    return orgChartDataResponse[0];
                }
                else if (orgChartDataResponse.length > 1) {
                    var datasource = InternalUtils.getGhostManager(ctrlContext);
                    datasource['nodeType'] = OrgChart.OrgChartNodeTypes.GhostManagerLooseHierarchies;
                    datasource["children"] = orgChartDataResponse;
                    return datasource;
                }
            };
            InternalUtils.getGhostManager = function (ctrlContext) {
                var datasource = {
                    'fullname': ctrlContext.resources.getString(OrgChart.ResourceKeys.EmptyStateNodeName),
                    'jobtitle': ctrlContext.resources.getString(OrgChart.ResourceKeys.EmptyStateManagerTitle),
                    'entityimage_url': ctrlContext.page.getClientUrl() + OrgChart.ControlStrings.AddIconImageURL
                };
                return datasource;
            };
            /**
            * Create the HTML template for nodes in JQueryHierarchy control.
            */
            InternalUtils.getNodeTemplate = function () {
                var nodeTemplate = function (data) {
                    return "<span>\n\t\t\t\t\t<div class=\"title\">" + CrmEncodeDecode.CrmHtmlEncode(data.fullname) + "</div>\n\t\t\t\t\t<div class=\"content\">" + CrmEncodeDecode.CrmHtmlEncode(data.jobtitle) + "</div>\n\t\t\t\t\t</span>";
                };
                return nodeTemplate;
            };
            /**
            * Invokes handleGhostManagerAddition and update account for the current contact.
            */
            InternalUtils.handleGhostManagerAddition = function (ctrlContext, currentAccountId, nodeType, childrenArray, parentAttrName) {
                var contactsDisplayFilter = "";
                if (nodeType == OrgChart.OrgChartNodeTypes.GhostManagerDummyState) {
                    contactsDisplayFilter = "<filter type=\"and\"><condition attribute=\"accountid\" operator=\"null\" /></filter>";
                }
                else if (nodeType == OrgChart.OrgChartNodeTypes.GhostManagerLooseHierarchies) {
                    contactsDisplayFilter = "<filter type=\"or\"><condition attribute=\"accountid\" operator=\"null\" /><condition attribute=\"accountid\" operator=\"eq\" value=\"" + currentAccountId + "\" /></filter>";
                }
                return this.InvokeLookUpObjects(ctrlContext, contactsDisplayFilter).then(function (selectedValues) {
                    if (selectedValues.length == 0) {
                        return window.Promise.resolve(false);
                    }
                    else {
                        // update account for the selected contact.
                        var selectedContact_1 = selectedValues[0];
                        // Gather data for invoking 'Save' SDK.
                        var updatedRecords_1 = {};
                        updatedRecords_1[selectedContact_1.id] = {};
                        // update the account of selected contact.
                        updatedRecords_1[selectedContact_1.id]["accountid"] = currentAccountId;
                        // update parent of children of ghost manager.
                        childrenArray.forEach(function (child) {
                            // Convert the guids child.id and selectedContact.id to lowercase and remove braces {} if any for ease in comparison
                            if (child.id.toLowerCase().replace(/[{}]/g, '') != selectedContact_1.id.toLowerCase().replace(/[{}]/g, '')) {
                                updatedRecords_1[child.id] = {};
                                updatedRecords_1[child.id][parentAttrName] = selectedContact_1.id;
                            }
                        });
                        // report the 'Save' click to telemetry
                        OrgChart.TelemetryReporter.ReportComponentSuccess(ctrlContext, OrgChart.TelemetryReporter.getSaveLookUpDlgEventParams(selectedContact_1.id, nodeType, childrenArray.length));
                        var updatedRecordsDetail = JSON.stringify(updatedRecords_1);
                        console.log(updatedRecordsDetail);
                        var UpdateOrgChartReq = new LinkedInExtensionDataContracts.UpdateOrgChartDataRequest(updatedRecordsDetail, parentAttrName);
                        return Xrm.WebApi.online.execute(UpdateOrgChartReq).then(function (response) {
                            ctrlContext.utils.addGlobalNotification(1 /* toast */, 1 /* success */, ctrlContext.resources.getString(OrgChart.ResourceKeys.OrgChartUpdatedSuccessfully), null, null);
                            return window.Promise.resolve(true);
                        }, function (error) {
                            return window.Promise.reject(error);
                        });
                    }
                }, function (error) {
                    return window.Promise.reject(error);
                });
            };
            /**
            * Opens the look up dialog, displays the list of contacts per disply filters. Returns the selected records.
            * The length of array returned will be zero for Cancel and 'x'.
            */
            InternalUtils.InvokeLookUpObjects = function (ctrlContext, contactsDisplayFilter) {
                var lookUpCtrlInputs = { "entityTypes": [OrgChart.EntityNames.Contact], "filters": [{ "filterXml": contactsDisplayFilter }], "disableMru": true };
                return ctrlContext.utils.lookupObjects(lookUpCtrlInputs).then(function (selectedValues) {
                    return window.Promise.resolve(selectedValues);
                }, function (error) {
                    return window.Promise.reject(error);
                });
            };
            /**
            * Gets the data from CRM to display on Org Chart.
            */
            InternalUtils.getOrgChartDataRequest = function (accountId) {
                accountId = accountId.replace("{", "").replace("}", "");
                var columns = ["fullname", "lastname", "firstname", "jobtitle", "entityimage_url", "statecode", "emailaddress1"];
                var columnSet = new ODataContract.ColumnSet(false, columns);
                var RetrieveOrgChartReq = new LinkedInExtensionDataContracts.RetrieveOrgChartDataRequest({ guid: accountId }, columnSet);
                return Xrm.WebApi.online.execute(RetrieveOrgChartReq);
            };
            /**
            * Generate Dialog Parametrs to open Dialog and report telemetry for double click.
            */
            InternalUtils.getDialogParams = function (context, selectedValue, parentAttribute) {
                var staffMembers = [];
                for (var i = 0; i < selectedValue.children.length; i++) {
                    staffMembers.push({ id: selectedValue.children[i].id, name: selectedValue.children[i].fullname, entityType: OrgChart.EntityNames.Contact });
                }
                var manager = [];
                if (selectedValue[parentAttribute] != null && selectedValue[parentAttribute] != "") {
                    manager = [{ id: selectedValue[parentAttribute].Id, name: selectedValue[parentAttribute].Name, entityType: selectedValue[parentAttribute].LogicalName }];
                }
                var dialogParams = [];
                dialogParams[OrgChart.DialogConstants.SelectedNodeParameter] = {
                    full_name: selectedValue.fullname,
                    job_title: selectedValue.jobtitle == "" ? null : selectedValue.jobtitle,
                    email_id: selectedValue.emailaddress1 == "" ? null : selectedValue.emailaddress1,
                    image_url: selectedValue.entityimage_url,
                    entity_records: staffMembers,
                    selected_record: manager,
                    is_sidepane_disabled: selectedValue.statecode.Value ? true : false,
                    account_id: InternalUtils.getContextDataParameter(context, 'AccountId'),
                    account_name: InternalUtils.getContextDataParameter(context, 'AccountName'),
                    first_name: selectedValue.firstname,
                    last_name: selectedValue.lastname,
                    contact_id: selectedValue.contactid,
                    parentattribute_name: parentAttribute,
                    children_list: selectedValue.children
                };
                // report double click to telemetry
                var isImageAvailable = (selectedValue.entityimage_url != null && selectedValue.entityimage_url != "") ? true : false;
                OrgChart.TelemetryReporter.ReportComponentSuccess(context, OrgChart.TelemetryReporter.getContactDetailsDlgEventParams(selectedValue.statecode.Value, isImageAvailable, manager.length, staffMembers.length));
                return dialogParams;
            };
            InternalUtils.getSelectedRecordsAttributes = function () {
                return {
                    DisplayName: null,
                    LogicalName: "cc_selectedAttributes_id",
                    Type: "string",
                    IsSecured: false,
                    RequiredLevel: 0,
                    MaxLength: 2147483647,
                    EntityLogicalName: "",
                    Format: null,
                    ImeMode: -1,
                    Behavior: null
                };
            };
            return InternalUtils;
        }());
        OrgChart.InternalUtils = InternalUtils;
    })(OrgChart = LinkedInExtensionControls.OrgChart || (LinkedInExtensionControls.OrgChart = {}));
})(LinkedInExtensionControls || (LinkedInExtensionControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="Utils/Constants.ts" />
/// <reference path="Utils/HierarchyCtrlInputs.ts" />
/// <reference path="Utils/InternalUtils.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var LinkedInExtensionControls;
(function (LinkedInExtensionControls) {
    var OrgChart;
    (function (OrgChart) {
        'use strict';
        var ContactHierarchyDetailsMDDUniqueName = "ContactHierarchyDetails";
        var OrgChartControl = (function () {
            /**
             * Empty constructor.
             */
            function OrgChartControl() {
                this._controlId = "OrgChartControl";
                this._isHierarchyInputReady = false;
                this._currentAccountId = null;
                this._orgChartData = null;
                this._commandBarStyle = null;
                this._currentEventType = null;
                this._currentSelectedNode = null;
                this._cachedJQueryHierarchyControl = null;
                this._jqueryHierarchyCtrlContext = null;
                this._isCanvasDirty = null;
                this._referencingAttribute = null;
                this._orgChartUpdates = {};
                this._applyStyles = null;
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            OrgChartControl.prototype.init = function (context, notifyOutputChanged, state) {
                this._context = context;
                this._commandBarStyle = new OrgChart.CommandBarStyles(context);
                this._applyStyles = new OrgChart.OrgChartControlStyles(context);
                this._currentAccountId = OrgChart.InternalUtils.getContextDataParameter(context, 'AccountId');
                this._isCanvasDirty = false;
                if (this._currentAccountId == null) {
                    throw new Error("One or more mandatory inputs were was not specified");
                }
                this._referencingAttribute = OrgChart.InternalUtils.getContextDataParameter(context, 'ReferencingAttribute');
                if (this._referencingAttribute == null || this._referencingAttribute == "") {
                    this._context.reporting.reportFailure(OrgChart.ControlStrings.ControlName + "_init", Error("Referencing Atrribute Name is null or empty"));
                }
                else {
                    this.getOrgChartDataAndRequestRender();
                }
            };
            OrgChartControl.prototype.getOrgChartDataAndRequestRender = function () {
                var _this = this;
                OrgChart.InternalUtils.getOrgChartDataRequest(this._currentAccountId).then(function (response) {
                    if (response != null) {
                        response.json().then(function (jsonResponse) {
                            if (jsonResponse != null) {
                                var orgChartDataResponse = JSON.parse(jsonResponse.Result);
                                if (orgChartDataResponse != null && orgChartDataResponse.length > 0) {
                                    _this._orgChartData = OrgChart.InternalUtils.getInputForOrgChart(_this._context, orgChartDataResponse, _this._referencingAttribute);
                                }
                                else {
                                    _this._orgChartData = OrgChart.InternalUtils.getInputForGhostState(_this._context);
                                }
                                _this._isHierarchyInputReady = true;
                                // render again by resetting the cached tree.
                                _this._cachedJQueryHierarchyControl = null;
                                OrgChart.TelemetryReporter.ReportComponentSuccess(_this._context, OrgChart.TelemetryReporter.getOrgChartDataInitEventParams(_this._orgChartData.JsonData.nodeType, _this._orgChartData.JsonData.height));
                                _this._currentEventType = null;
                                _this._currentSelectedNode = null;
                                _this._context.utils.requestRender();
                            }
                            else {
                                _this._context.reporting.reportFailure(OrgChart.ControlStrings.ControlName + "_getOrgChartDataAndRequestRender", Error("\'jsonResponse\' is null"));
                            }
                        });
                    }
                    else {
                        _this._context.reporting.reportFailure(OrgChart.ControlStrings.ControlName + "_getOrgChartDataAndRequestRender", Error("\'response\' is null"));
                    }
                }, ClientUtility.ActionFailedHandler.actionFailedErrorDialog);
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            OrgChartControl.prototype.updateView = function (context) {
                if (this._isHierarchyInputReady) {
                    return this.createOrgChartComponents(context);
                }
                else {
                    return this.createLoadingContainer(context);
                }
            };
            OrgChartControl.prototype.showLoadingContainer = function () {
                this._isHierarchyInputReady = false;
                this._context.utils.requestRender();
            };
            /**
            * Rendering the Loading Body container
            */
            OrgChartControl.prototype.createLoadingContainer = function (context) {
                var loadingImgContainer = context.factory.createElement("IMG", {
                    id: OrgChart.ControlStrings.PageLoadingID,
                    key: OrgChart.ControlStrings.PageLoadingID,
                    source: context.page.getClientUrl() + OrgChart.ControlStrings.GhostChartLoadingImageURL,
                    altText: context.resources.getString(OrgChart.ResourceKeys.ControlLoadingKey),
                    style: this._applyStyles.ImageStyle()
                }, []);
                return context.factory.createElement("CONTAINER", {
                    id: OrgChart.ControlStrings.BodyContainer,
                    key: OrgChart.ControlStrings.BodyContainer,
                    style: this._applyStyles.ImageContainerStyle()
                }, [loadingImgContainer]);
            };
            /**
             * This function creates the command bar and JQueryHierarchy control.
             */
            OrgChartControl.prototype.createOrgChartComponents = function (context) {
                var OrgChartHeader = context.factory.createElement("TEXT", {
                    id: OrgChart.ControlStrings.OrgChartHeader,
                    key: OrgChart.ControlStrings.OrgChartHeader,
                    semanticTag: "h1",
                    style: {
                        height: "0",
                        overflow: "hidden",
                        position: "absolute"
                    }
                }, context.resources.getString(OrgChart.ResourceKeys.OrgChartHeading));
                var commandBar = context.factory.createElement("COMMANDBAR", {
                    id: OrgChart.ControlStrings.CommandBarId,
                    key: OrgChart.ControlStrings.CommandBarId,
                    iconPosition: 1 /* Left */,
                    addedCommandList: this.getCommandList(context),
                    ribbonId: null,
                    selectedRecords: "",
                    width: 10000,
                    commandBarStyle: this._commandBarStyle.commandBarStyle
                });
                var commandBarContainer = context.factory.createElement("CONTAINER", {
                    key: OrgChart.ControlStrings.CommandBarContainer,
                    id: OrgChart.ControlStrings.CommandBarContainer,
                    style: {
                        display: "flex",
                        width: "100%"
                    }
                }, commandBar);
                // Do not re-create the control to preserve its current state. Re-creation will only be triggered for changes in data.
                if (!this._cachedJQueryHierarchyControl) {
                    this._cachedJQueryHierarchyControl = context.factory.createElement("CONTAINER", {
                        key: OrgChart.ControlStrings.JQueryHierarchyControlContainer,
                        id: OrgChart.ControlStrings.JQueryHierarchyControlContainer,
                        style: {
                            height: "100%"
                        }
                    }, this.buildJQueryHierarchyControl(context));
                }
                var mainContainer = context.factory.createElement("CONTAINER", {
                    key: OrgChart.ControlStrings.OrgChartMaincontainer,
                    id: OrgChart.ControlStrings.OrgChartMaincontainer,
                    style: {
                        width: "100%",
                        height: "100%",
                        position: "absolute",
                        display: "block"
                    }
                }, [OrgChartHeader, commandBarContainer, this._cachedJQueryHierarchyControl]);
                return mainContainer;
            };
            /**
             * This function instantiates the LinkedInExtensionControls.JQueryHierarchy.JQueryHierarchyControl
             */
            OrgChartControl.prototype.buildJQueryHierarchyControl = function (context) {
                var hierarchyCtrlInputs = this._orgChartData;
                var properties = {
                    "parameters": {
                        ControlOutput: {
                            Usage: 3,
                            Static: true, Type: "SingleLine.Text", Value: "", Callback: this.jqueryHierarchyOutputCallBack.bind(this), Attributes: OrgChart.InternalUtils.getSelectedRecordsAttributes()
                        },
                        JsonData: {
                            Static: true, Type: "IInputNode", Value: hierarchyCtrlInputs.JsonData, Primary: false,
                        },
                        NodeTemplateFn: {
                            Static: true, Type: "IInputNode", Value: hierarchyCtrlInputs.NodeTemplateFn, Primary: false,
                        },
                        LoadChildrenFromJsonData: {
                            Static: hierarchyCtrlInputs, Type: "IInputNode", Value: hierarchyCtrlInputs.LoadChildrenFromJsonData, Primary: false,
                        },
                        AllowZoom: {
                            Static: hierarchyCtrlInputs, Type: "IInputNode", Value: hierarchyCtrlInputs.AllowZoom, Primary: false,
                        },
                        AllowDragDrop: {
                            Static: true, Type: "IInputNode", Value: hierarchyCtrlInputs.AllowDragDrop, Primary: false,
                        },
                        AllowPan: {
                            Static: true, Type: "IInputNode", Value: hierarchyCtrlInputs.AllowPan, Primary: false,
                        },
                        PrimaryField: {
                            Static: true, Type: "IInputNode", Value: hierarchyCtrlInputs.PrimaryField, Primary: false,
                        }
                    }
                };
                // Create a new controlId so that the init of control is invoked. The previous control will be removed from the virtual dom.
                var controlSuffix = new Date().getTime().toString();
                return context.factory.createComponent("LinkedInExtensionControls.JQueryHierarchy.JQueryHierarchyControl", this._controlId + controlSuffix, properties);
            };
            /**
            * Create the command list that needs to be displayed.
            */
            OrgChartControl.prototype.getCommandList = function (context) {
                var refreshCmd = {
                    Icon: "Refresh",
                    DisplayText: context.resources.getString(OrgChart.ResourceKeys.RefreshOrgChartCommand),
                    Id: OrgChart.ControlStrings.RefreshCmdId,
                    Tooltip: { title: context.resources.getString(OrgChart.ResourceKeys.RefreshOrgChartCommandToolTip), description: "" },
                    execute: this.refreshChart.bind(this)
                };
                var cmdList = new Array();
                cmdList.push(refreshCmd);
                if (this._isCanvasDirty == true) {
                    var saveCmd = {
                        Icon: "Save",
                        DisplayText: context.resources.getString(OrgChart.ResourceKeys.SaveOrgChartCommand),
                        Id: OrgChart.ControlStrings.SaveCmdId,
                        Tooltip: { title: context.resources.getString(OrgChart.ResourceKeys.SaveOrgChartCommandToolTip), description: "" },
                        execute: this.saveOrgChart.bind(this)
                    };
                    cmdList.push(saveCmd);
                }
                if (this._currentSelectedNode != null) {
                    var removeCmd = {
                        Icon: "Remove",
                        DisplayText: context.resources.getString(OrgChart.ResourceKeys.RemoveNodeCommand),
                        Id: OrgChart.ControlStrings.RemoveNodeCmdId,
                        Tooltip: { title: context.resources.getString(OrgChart.ResourceKeys.RemoveNodeCommandToolTip), description: "" },
                        execute: this.removeNode.bind(this)
                    };
                    cmdList.push(removeCmd);
                }
                OrgChart.TelemetryReporter.ReportComponentSuccess(this._context, OrgChart.TelemetryReporter.getCmdListEventParams(cmdList));
                return cmdList;
            };
            OrgChartControl.prototype.refreshChart = function () {
                if (this._isCanvasDirty == true) {
                    this.saveOrgChart();
                }
                else {
                    this.showLoadingContainer();
                    this.getOrgChartDataAndRequestRender();
                }
                OrgChart.TelemetryReporter.ReportComponentSuccess(this._context, OrgChart.TelemetryReporter.getCmdSuccessEventParams(OrgChart.ControlStrings.RefreshCmdId));
            };
            OrgChartControl.prototype.removeNode = function () {
                var _this = this;
                if (this._currentSelectedNode) {
                    //Open a confirmation dialog
                    var confirmDialogStrings = {
                        title: this._context.resources.getString(OrgChart.ResourceKeys.RemoveNodeDlgTitle),
                        text: this._context.resources.getString(OrgChart.ResourceKeys.RemoveNodeDlgText),
                        confirmButtonLabel: this._context.resources.getString(OrgChart.ResourceKeys.RemoveNodeDlgConfirmBtn),
                        cancelButtonLabel: this._context.resources.getString(OrgChart.ResourceKeys.RemoveNodeDlgCancelBtn)
                    };
                    this._context.navigation.openConfirmDialog(confirmDialogStrings).then(function (result) {
                        if (result.confirmed) {
                            var nodeData = _this._currentSelectedNode.data && _this._currentSelectedNode.data('nodeData') ? _this._currentSelectedNode.data('nodeData') : null;
                            if (nodeData) {
                                var childrenArray = _this._currentSelectedNode.data('nodeData').children ? _this._currentSelectedNode.data('nodeData').children : null;
                                var that = _this;
                                // Update all children of the removed node such that the children now point to parent of removed node
                                childrenArray && childrenArray.forEach(function (value) {
                                    that._orgChartUpdates[value.contactid] = {};
                                    that._orgChartUpdates[value.contactid][that._referencingAttribute] = nodeData.parentId ? nodeData.parentId : null;
                                });
                                var removedNodeContactId = nodeData.contactid ? nodeData.contactid : null;
                                if (removedNodeContactId) {
                                    // Update the removed node such that its parent and account both are null. 
                                    _this._orgChartUpdates[removedNodeContactId] = {};
                                    _this._orgChartUpdates[removedNodeContactId]["accountid"] = null;
                                    _this._orgChartUpdates[removedNodeContactId][_this._referencingAttribute] = null;
                                    OrgChart.TelemetryReporter.ReportComponentSuccess(_this._context, OrgChart.TelemetryReporter.getCmdSuccessEventParams(OrgChart.ControlStrings.RemoveNodeCmdId, removedNodeContactId, childrenArray.length));
                                    _this.saveOrgChart();
                                }
                                else {
                                    _this._context.reporting.reportFailure(OrgChart.ControlStrings.ControlName + "removeNode", Error("Removed Node Contact Id is null"));
                                }
                            }
                            else {
                                _this._context.reporting.reportFailure(OrgChart.ControlStrings.ControlName + "removeNode", Error("CurrentSelectedNode NodeData is null"));
                            }
                        }
                    });
                }
                else {
                    this._context.reporting.reportFailure(OrgChart.ControlStrings.ControlName + "removeNode", Error("\'this._currentSelectedNode\' is null on click of Remove button."));
                }
            };
            OrgChartControl.prototype.saveOrgChart = function () {
                var _this = this;
                OrgChart.TelemetryReporter.ReportComponentSuccess(this._context, OrgChart.TelemetryReporter.getCmdSuccessEventParams(OrgChart.ControlStrings.SaveCmdId, null, null, Object.keys(this._orgChartUpdates).length));
                Xrm.Utility.showProgressIndicator(this._context.resources.getString(OrgChart.ResourceKeys.SavingMessage));
                var updatedRecordsDetail = JSON.stringify(this._orgChartUpdates);
                var UpdateOrgChartReq = new LinkedInExtensionDataContracts.UpdateOrgChartDataRequest(updatedRecordsDetail, this._referencingAttribute);
                return Xrm.WebApi.online.execute(UpdateOrgChartReq).then(function (response) {
                    Xrm.Utility.closeProgressIndicator();
                    _this.showLoadingContainer();
                    _this._context.utils.addGlobalNotification(1 /* toast */, 1 /* success */, _this._context.resources.getString(OrgChart.ResourceKeys.OrgChartUpdatedSuccessfully), null, null);
                    _this._orgChartUpdates = {};
                    _this._isCanvasDirty = false;
                    _this.getOrgChartDataAndRequestRender();
                    return window.Promise.resolve(true);
                }, function (errorResponse) {
                    Xrm.Utility.closeProgressIndicator();
                    ClientUtility.ActionFailedHandler.actionFailedErrorDialog(errorResponse);
                });
            };
            /**
            * Callback on user interactions happening in JQueryHierarchy control.
            */
            OrgChartControl.prototype.jqueryHierarchyOutputCallBack = function (output) {
                switch (output.event) {
                    case OrgChart.ControlEventTypes.Init:
                        this._jqueryHierarchyCtrlContext = output.context;
                        OrgChart.TelemetryReporter.ReportComponentSuccess(this._context, OrgChart.TelemetryReporter.getOrgChartUserInteractionEventParams(output.event));
                        break;
                    case OrgChart.ControlEventTypes.DoubleClick:
                        OrgChart.TelemetryReporter.ReportComponentSuccess(this._context, OrgChart.TelemetryReporter.getOrgChartUserInteractionEventParams(output.event, output.nodeData.nodeType, output.nodeData.contactid));
                        this.handleDblClickEvent(output.nodeData);
                        break;
                    case OrgChart.ControlEventTypes.SingleClick:
                        OrgChart.TelemetryReporter.ReportComponentSuccess(this._context, OrgChart.TelemetryReporter.getOrgChartUserInteractionEventParams(output.event, output.nodeData.nodeType, output.nodeData.contactid));
                        var selectedNodeType = output.nodeData.nodeType;
                        if (selectedNodeType == OrgChart.OrgChartNodeTypes.GhostManagerDummyState || selectedNodeType == OrgChart.OrgChartNodeTypes.GhostManagerLooseHierarchies
                            || selectedNodeType == OrgChart.OrgChartNodeTypes.DummyStaff || selectedNodeType == OrgChart.OrgChartNodeTypes.CRMRootNode) {
                            // reset the eventType and selected node.
                            this._currentEventType = null;
                            this._currentSelectedNode = null;
                        }
                        else {
                            // set the current event type as single click so that command bar shows correct contextual commands.
                            this._currentEventType = OrgChart.ControlEventTypes.SingleClick;
                            this._currentSelectedNode = output.node;
                        }
                        // re-render for the changes to reflect.
                        this._context.utils.requestRender();
                        break;
                    case OrgChart.ControlEventTypes.NodeFocusOut:
                        OrgChart.TelemetryReporter.ReportComponentSuccess(this._context, OrgChart.TelemetryReporter.getOrgChartUserInteractionEventParams(output.event));
                        // Remove the contextual commands that showed up for single click.
                        this._currentEventType = OrgChart.ControlEventTypes.NodeFocusOut;
                        this._currentSelectedNode = null;
                        this._context.utils.requestRender();
                        break;
                    case OrgChart.ControlEventTypes.NodeDrop:
                        var draggedNodeData = output.dragDropData.draggedNode.data() && output.dragDropData.draggedNode.data().nodeData ? output.dragDropData.draggedNode.data().nodeData : null;
                        var dragZoneData = output.dragDropData.dragZone.data() && output.dragDropData.dragZone.data().nodeData ? output.dragDropData.dragZone.data().nodeData : null;
                        var dropZoneData = output.dragDropData.dropZone.data() && output.dragDropData.dropZone.data().nodeData ? output.dragDropData.dropZone.data().nodeData : null;
                        this._currentEventType = OrgChart.ControlEventTypes.NodeDrop;
                        if (draggedNodeData) {
                            if (draggedNodeData.nodeType != OrgChart.OrgChartNodeTypes.DummyStaff) {
                                if (draggedNodeData.contactid) {
                                    var dropZoneContactId = dropZoneData && dropZoneData.contactid ? dropZoneData.contactid : null;
                                    // to update the details of parent stored in the dragged node 
                                    if (dropZoneContactId != null) {
                                        var newParentDetails = {};
                                        newParentDetails["Id"] = dropZoneContactId;
                                        newParentDetails["LogicalName"] = "contact";
                                        newParentDetails["Name"] = dropZoneData.fullname;
                                        output.dragDropData.draggedNode.data().nodeData[this._referencingAttribute] = newParentDetails;
                                    }
                                    else {
                                        output.dragDropData.draggedNode.data().nodeData[this._referencingAttribute] = "";
                                    }
                                    OrgChart.TelemetryReporter.ReportComponentSuccess(this._context, OrgChart.TelemetryReporter.getOrgChartUserInteractionEventParams(output.event, draggedNodeData.nodeType, draggedNodeData.contactid, dragZoneData ? dragZoneData.contactid : null, dropZoneContactId));
                                    this._orgChartUpdates[draggedNodeData.contactid] = {};
                                    this._orgChartUpdates[draggedNodeData.contactid][this._referencingAttribute] = dropZoneContactId;
                                    this._isCanvasDirty = true;
                                }
                                else {
                                    this._context.reporting.reportFailure(OrgChart.ControlStrings.ControlName + "jqueryHierarchyOutputCallBack_NodeDropEvent", Error("Dragged Node Data Contact Id is null"));
                                }
                            }
                        }
                        else {
                            this._context.reporting.reportFailure(OrgChart.ControlStrings.ControlName + "jqueryHierarchyOutputCallBack_NodeDropEvent", Error("Dragged Node Data is null"));
                        }
                        this._context.utils.requestRender();
                        break;
                }
            };
            /**
            * Handle double click event on JQueryHierarchy control node.
            */
            OrgChartControl.prototype.handleDblClickEvent = function (selectedValue) {
                var _this = this;
                if (this._isCanvasDirty) {
                    this.saveOrgChart().then(function (result) {
                        if (result) {
                            // Open the panel when double clicked on any node
                            _this.openSidePanel(selectedValue);
                        }
                    });
                }
                else {
                    this.openSidePanel(selectedValue);
                }
            };
            OrgChartControl.prototype.openSidePanel = function (selectedValue) {
                var _this = this;
                // Handle the event based on the node type
                var nodeType = selectedValue.nodeType;
                if (nodeType == OrgChart.OrgChartNodeTypes.DummyStaff) {
                    return;
                }
                else if (nodeType == OrgChart.OrgChartNodeTypes.GhostManagerDummyState || nodeType == OrgChart.OrgChartNodeTypes.GhostManagerLooseHierarchies) {
                    var ghostMgrChildrenNodes = (nodeType == OrgChart.OrgChartNodeTypes.GhostManagerDummyState) ? [] : selectedValue.children;
                    OrgChart.InternalUtils.handleGhostManagerAddition(this._context, this._currentAccountId, nodeType, ghostMgrChildrenNodes, this._referencingAttribute).then(function (result) {
                        if (result) {
                            _this.showLoadingContainer();
                            _this.getOrgChartDataAndRequestRender();
                        }
                        else {
                            _this._jqueryHierarchyCtrlContext.$chart.find('.node')[0].focus();
                        }
                    }, ClientUtility.ActionFailedHandler.actionFailedErrorDialog);
                }
                else {
                    var dialogOptions = {
                        width: 380,
                        height: 600,
                        position: 2
                    };
                    var dialogParameters = OrgChart.InternalUtils.getDialogParams(this._context, selectedValue, this._referencingAttribute);
                    Xrm.Navigation.openDialog(ContactHierarchyDetailsMDDUniqueName, dialogOptions, dialogParameters)
                        .then(function (dialogResult) {
                        if (dialogResult.parameters.last_button_clicked == OrgChart.DialogConstants.DialogOkId) {
                            _this.showLoadingContainer();
                            _this.getOrgChartDataAndRequestRender();
                        }
                        else {
                            _this._jqueryHierarchyCtrlContext.$chart.find('#' + selectedValue.id).focus();
                        }
                    });
                }
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            OrgChartControl.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                return null;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            OrgChartControl.prototype.destroy = function () {
            };
            return OrgChartControl;
        }());
        OrgChart.OrgChartControl = OrgChartControl;
    })(OrgChart = LinkedInExtensionControls.OrgChart || (LinkedInExtensionControls.OrgChart = {}));
})(LinkedInExtensionControls || (LinkedInExtensionControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="OrgChartControl.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../privatereferences.ts"/>
var LinkedInExtensionControls;
(function (LinkedInExtensionControls) {
    var OrgChart;
    (function (OrgChart) {
        var OrgChartControlStyles = (function () {
            function OrgChartControlStyles(context) {
                this._contactImageStyleProperties = {};
                this._imageContainerStyleProperties = {};
                this._context = context;
                this._contactImageStyleProperties = null;
                this._imageContainerStyleProperties = null;
            }
            OrgChartControlStyles.prototype.ImageStyle = function () {
                if (this._context.utils.isNullOrUndefined(this._contactImageStyleProperties)) {
                    this._contactImageStyleProperties = {};
                    this._contactImageStyleProperties["width"] = "350px";
                    this._contactImageStyleProperties["height"] = "410px";
                }
                return this._contactImageStyleProperties;
            };
            OrgChartControlStyles.prototype.ImageContainerStyle = function () {
                if (this._context.utils.isNullOrUndefined(this._imageContainerStyleProperties)) {
                    this._imageContainerStyleProperties = {};
                    this._imageContainerStyleProperties["margin"] = "auto";
                }
                return this._imageContainerStyleProperties;
            };
            return OrgChartControlStyles;
        }());
        OrgChart.OrgChartControlStyles = OrgChartControlStyles;
    })(OrgChart = LinkedInExtensionControls.OrgChart || (LinkedInExtensionControls.OrgChart = {}));
})(LinkedInExtensionControls || (LinkedInExtensionControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
var LinkedInExtensionControls;
(function (LinkedInExtensionControls) {
    var OrgChart;
    (function (OrgChart) {
        var CommandBarStyles = (function () {
            function CommandBarStyles(context) {
                this._theme = context.theming;
                this._context = context;
            }
            Object.defineProperty(CommandBarStyles.prototype, "commandBarStyle", {
                get: function () {
                    return {
                        container: {
                            "height": this._theme.measures.measure300,
                            "width": "10000px",
                            "color": this._theme.colors.basecolor.grey["grey1"],
                            "marginLeft": "0px",
                            "marginRight": "0px",
                            "borderColor": this._theme.colors.basecolor.grey["grey1"],
                            "borderStyle": "none",
                            "borderWidth": "1px",
                            "backgroundColor": this._theme.colors.basecolor.blue["blue3"]
                        },
                        list: {
                            "marginLeft": "0px",
                            "marginRight": this._theme.measures.measure100,
                            "marginTop": "0px",
                            "marginBottom": "0px",
                            "color": this._theme.colors.basecolor.grey["grey1"],
                            "listStyleType": "none"
                        },
                        listItem: {
                            "lineHeight": this._theme.measures.measure100,
                            "height": this._theme.measures.measure300,
                            "marginRight": "0px",
                            ":last-child": {
                                "marginLeft": "0px",
                                "marginRight": "0px"
                            },
                            "[aria-expanded=true]": {
                                "backgroundColor": this._theme.colors.basecolor.blue["blue3"]
                            },
                            "[data-expanded= true]": {
                                "backgroundColor": this._theme.colors.basecolor.grey["grey2"],
                            },
                            "[data-expanded=true]": {
                                "backgroundColor": this._theme.colors.basecolor.blue["blue3"]
                            }
                        },
                        moreIcon: {
                            "marginRight": this._theme.measures.measure100,
                            "marginLeft": this._theme.measures.measure100,
                            "color": this._theme.colors.basecolor.white
                        },
                        overflowFlyoutMoreButton: {
                            "backgroundColor": "transparent",
                            "lineHeight": this._theme.measures.measure100,
                            "height": this._theme.measures.measure300,
                            "borderWidth": 0,
                            "padding": 0,
                            "cursor": "pointer",
                            "alignItems": "center",
                            ":hover": {
                                "backgroundColor": this._theme.colors.basecolor.blue["blue3"]
                            }
                        },
                        listItemBody: {
                            "button": {
                                "backgroundColor": "transparent",
                                "lineHeight": this._theme.measures.measure100,
                                "height": this._theme.measures.measure300,
                                "borderWidth": "0px",
                                "cursor": "pointer",
                                ":hover": {
                                    "backgroundColor": this._theme.colors.basecolor.blue["blue3"]
                                },
                                "alignItems": "center",
                                "paddingLeft": this._theme.measures.measure100,
                                "paddingRight": this._theme.measures.measure100
                            },
                            "icon": {
                                "lineHeight": this._theme.measures.measure150,
                                "height": "16px",
                                "color": this._theme.colors.basecolor.white,
                                "width": "16px"
                            },
                            "text": {
                                "fontSize": this._theme.measures.measure100,
                                "color": this._theme.colors.basecolor.white,
                                "lineHeight": this._theme.measures.measure150,
                                "whiteSpace": "nowrap",
                                "textOverflow": "ellipsis",
                                "maxWidth": "200px",
                                "fontFamily": "'Segoe UI Regular', 'SegoeUI', 'Segoe UI'"
                            },
                            "iconWrapperStyles": {
                                "marginRight": this._theme.measures.measure100,
                                "fontSize": this._theme.measures.measure100,
                                "lineHeight": this._theme.measures.measure150,
                                "minWidth": "16px",
                                "color": this._theme.colors.basecolor.white
                            },
                            "splitButtonChevronIconWrapper": {
                                "lineHeight": this._theme.measures.measure100,
                                "minWidth": "16px",
                                "borderStyle": "solid",
                                "borderLeftWidth": "1px",
                                "borderLeftColor": this._theme.colors.basecolor.white,
                                "paddingLeft": this._theme.measures.measure050,
                                "paddingRight": this._theme.measures.measure050
                            },
                            "flyoutButtonChevronIconWrapper": {
                                "lineHeight": this._theme.measures.measure100,
                                "minWidth": "16px",
                                "paddingLeft": this._theme.measures.measure050,
                                "paddingRight": this._theme.measures.measure050
                            },
                            "buttonContentWrapperStyle": {
                                "flexGrow": 1
                            }
                        },
                        primaryOfSplitButton: {
                            "lineHeight": this._theme.measures.measure100,
                            "height": this._theme.measures.measure100,
                            "paddingRight": "0px"
                        },
                        splitbuttonicon: {
                            "height": "8px",
                            "width": "8px",
                            "color": this._theme.colors.basecolor.white,
                            "marginRight": this._theme.measures.measure200,
                            "marginLeft": this._theme.measures.measure050
                        },
                        splitbuttonOverflowButton: {
                            "minWidth": this._theme.measures.measure250,
                            "marginLeft": "0px",
                            "[aria-expanded=true]": {
                                "backgroundColor": this._theme.colors.basecolor.blue["blue3"]
                            },
                            "[data-expanded=true]": {
                                "backgroundColor": this._theme.colors.basecolor.blue["blue3"]
                            }
                        },
                        flyoutStyles: {
                            "flyoutContainerStyles": {},
                            "flyoutListItemBody": {
                                "text": {
                                    "fontSize": this._theme.measures.measure100,
                                    "color": this._theme.colors.basecolor.grey["grey7"],
                                    "lineHeight": this._theme.measures.measure150,
                                    "fontFamily": "'Segoe UI Regular', 'SegoeUI', 'Segoe UI'",
                                    "whiteSpace": "nowrap",
                                    "overflow": "hidden",
                                    "textOverflow": "ellipsis",
                                    "maxWidth": "180px"
                                },
                                "icon": {
                                    "lineHeight": this._theme.measures.measure100,
                                    "height": "16px",
                                    "color": this._theme.colors.basecolor.grey["grey7"],
                                    "width": "16px"
                                },
                                "iconWrapperStyles": {
                                    "lineHeight": this._theme.measures.measure100,
                                    "marginRight": this._theme.measures.measure100,
                                    "minWidth": "16px"
                                },
                                "splitButtonChevronIconWrapper": {
                                    "lineHeight": this._theme.measures.measure100,
                                    "minWidth": "16px",
                                    "borderStyle": "solid",
                                    "borderLeftWidth": "1px",
                                    "borderLeftColor": this._theme.colors.basecolor.grey["grey4"],
                                    "paddingLeft": this._theme.measures.measure050,
                                    "paddingRight": this._theme.measures.measure050,
                                    "color": this._theme.colors.basecolor.white,
                                    ":hover": {
                                        "backgroundColor": this._theme.colors.basecolor.grey["grey3"]
                                    }
                                },
                                "flyoutButtonChevronIconWrapper": {
                                    "lineHeight": this._theme.measures.measure100,
                                    "minWidth": "16px",
                                    "paddingLeft": this._theme.measures.measure050,
                                    "paddingRight": this._theme.measures.measure050,
                                    "color": this._theme.colors.basecolor.white,
                                    "paddingTop": this._theme.measures.measure025
                                },
                                "button": {
                                    "lineHeight": this._theme.measures.measure150,
                                    "height": this._theme.measures.measure250,
                                    "backgroundColor": "transparent",
                                    "borderWidth": 0,
                                    "cursor": "pointer",
                                    "paddingLeft": this._theme.measures.measure150,
                                    "paddingRight": this._theme.measures.measure075,
                                    "paddingTop": this._theme.measures.measure050,
                                    "paddingBottom": this._theme.measures.measure050,
                                    "width": "100%",
                                    "alignItems": "center",
                                    ":hover": {
                                        "backgroundColor": this._theme.colors.basecolor.grey["grey3"]
                                    }
                                }
                            },
                            "flyoutListItemStyles": {
                                "height": this._theme.measures.measure250
                            },
                            "flyoutListStyles": {
                                ":first-child": {
                                    "marginTop": this._theme.measures.measure100
                                },
                                ":last-child": {
                                    "marginBottom": this._theme.measures.measure100
                                },
                                "listStyleType": "none",
                                "display": "flex",
                                "flexDirection": "column",
                                "cursor": "pointer",
                                "marginBottom": this._theme.measures.measure075
                            },
                            "flyoutChevronStyle": {
                                "minWidth": "16px",
                                "lineHeight": this._theme.measures.measure100,
                                "color": this._theme.colors.basecolor.grey["grey6"]
                            },
                            "flyoutPrimaryOfSplitButton": {
                                "lineHeight": this._theme.measures.measure100,
                                "height": this._theme.measures.measure100,
                                "flexGrow": 1
                            },
                            "flyoutBackButtonStyle": {
                                "marginTop": this._theme.measures.measure150,
                                "minWidth": "16px",
                                "minHeight": this._theme.measures.measure250,
                                "cursor": "pointer",
                                "display": "flex",
                                "paddingLeft": this._theme.measures.measure100,
                                "paddingRight": this._theme.measures.measure100,
                                ":hover": {
                                    "backgroundColor": this._theme.colors.basecolor.grey["grey3"]
                                },
                                "alignItems": "center"
                            },
                            "flyoutBackButtonTextStyle": {
                                "color": this._theme.colors.basecolor.black,
                                "fontWeight": this._theme.fontfamilies.bold,
                                "paddingLeft": this._theme.measures.measure075
                            }
                        }
                    };
                },
                enumerable: true,
                configurable: true
            });
            return CommandBarStyles;
        }());
        OrgChart.CommandBarStyles = CommandBarStyles;
    })(OrgChart = LinkedInExtensionControls.OrgChart || (LinkedInExtensionControls.OrgChart = {}));
})(LinkedInExtensionControls || (LinkedInExtensionControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
var LinkedInExtensionControls;
(function (LinkedInExtensionControls) {
    var OrgChart;
    (function (OrgChart) {
        'use strict';
        var TelemetryReporter = (function () {
            function TelemetryReporter() {
            }
            TelemetryReporter.getOrgChartDataInitEventParams = function (rootNodeType, rootNodeHeight) {
                var params = new Array();
                params.push({ name: OrgChart.TelemetryConstants.ControlEventTypes, value: OrgChart.ControlEventTypes.DataInit });
                params.push({ name: OrgChart.TelemetryConstants.RootNodeTypeParam, value: rootNodeType });
                params.push({ name: OrgChart.TelemetryConstants.RootNodeHeightParam, value: rootNodeHeight });
                return params;
            };
            TelemetryReporter.getOrgChartUserInteractionEventParams = function (eventType, nodeType, currentContactId, oldParentContactId, newParentContactId) {
                var params = new Array();
                params.push({ name: OrgChart.TelemetryConstants.ControlEventTypes, value: eventType });
                nodeType && params.push({ name: OrgChart.TelemetryConstants.NodeTypeParam, value: nodeType });
                currentContactId && params.push({ name: OrgChart.TelemetryConstants.ContactParam, value: currentContactId });
                oldParentContactId && params.push({ name: OrgChart.TelemetryConstants.OldParentContactId, value: oldParentContactId });
                newParentContactId && params.push({ name: OrgChart.TelemetryConstants.NewParentContactId, value: newParentContactId });
                return params;
            };
            TelemetryReporter.getContactDetailsDlgEventParams = function (stateCode, isImageAvailable, managerCount, staffMembersCount) {
                var params = new Array();
                params.push({ name: OrgChart.TelemetryConstants.NodeTypeParam, value: OrgChart.OrgChartNodeTypes.CRMContact });
                params.push({ name: OrgChart.TelemetryConstants.ActionParam, value: OrgChart.ControlEventTypes.DoubleClick });
                params.push({ name: OrgChart.TelemetryConstants.SidePanelNodeStateCodeParam, value: stateCode });
                params.push({ name: OrgChart.TelemetryConstants.SidePanelNodeImageAvailableParam, value: isImageAvailable });
                params.push({ name: OrgChart.TelemetryConstants.SidePanelNodeManagerCount, value: managerCount });
                params.push({ name: OrgChart.TelemetryConstants.SidePanelNodeStaffMemberCount, value: staffMembersCount });
                return params;
            };
            TelemetryReporter.getSaveLookUpDlgEventParams = function (contactId, nodeType, childrenCount) {
                var params = new Array();
                params.push({ name: OrgChart.TelemetryConstants.OriginParam, value: "LookupDialog" });
                params.push({ name: OrgChart.TelemetryConstants.ActionParam, value: "Add-Click" });
                params.push({ name: OrgChart.TelemetryConstants.GhostMgrChildrenCount, value: childrenCount });
                params.push({ name: OrgChart.TelemetryConstants.ContactParam, value: contactId });
                params.push({ name: OrgChart.TelemetryConstants.NodeTypeParam, value: nodeType });
                return params;
            };
            TelemetryReporter.getCmdListEventParams = function (cmdList) {
                var params = new Array();
                var commandList = [];
                cmdList.forEach(function (cmd) {
                    commandList.push(cmd.Id);
                });
                params.push({ name: OrgChart.TelemetryConstants.CmdList, value: commandList.toString() });
                return params;
            };
            TelemetryReporter.getCmdSuccessEventParams = function (cmdId, currentContactId, childrenCount, recordsCount) {
                var params = new Array();
                params.push({ name: OrgChart.TelemetryConstants.CommandId, value: cmdId });
                params.push({ name: OrgChart.TelemetryConstants.CommandEventType, value: "CommandCompletion" });
                childrenCount && params.push({ name: OrgChart.TelemetryConstants.ChildrenCount, value: childrenCount });
                currentContactId && params.push({ name: OrgChart.TelemetryConstants.ContactParam, value: currentContactId });
                recordsCount && params.push({ name: OrgChart.TelemetryConstants.RecordsUpdatedCount, value: recordsCount });
                return params;
            };
            TelemetryReporter.ReportComponentSuccess = function (context, params) {
                // add extra information
                params.push({ name: OrgChart.TelemetryConstants.AccountParam, value: OrgChart.InternalUtils.getContextDataParameter(context, 'AccountId') });
                params.push({ name: OrgChart.TelemetryConstants.ParentAttrName, value: OrgChart.InternalUtils.getContextDataParameter(context, 'ReferencingAttribute') });
                // push data to uciMonitorSuccess
                context.reporting.reportSuccess(OrgChart.ControlStrings.ControlName, params);
            };
            return TelemetryReporter;
        }());
        OrgChart.TelemetryReporter = TelemetryReporter;
    })(OrgChart = LinkedInExtensionControls.OrgChart || (LinkedInExtensionControls.OrgChart = {}));
})(LinkedInExtensionControls || (LinkedInExtensionControls = {}));
//# sourceMappingURL=OrgChartControl.js.map