var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SvcConfigSettings;
        (function (SvcConfigSettings) {
            /**
            * A select box can contain multiple list. At a time, only one list can be rendered by the select box.
            * On an event, we can change list pointer to the list which need to be rendered by select box.
            */
            var SelectBox = (function () {
                /**
                *
                * @param currentListId:creates a list and make it as current list.
                */
                function SelectBox(currentListId) {
                    //It contains set of list to be rendered in select box.
                    this._optionsList = {};
                    this._currentListId = currentListId;
                    this._optionsList[currentListId] = new Array();
                    this.currentOptions = new Array();
                    this.currentOptions = this._optionsList[currentListId];
                }
                Object.defineProperty(SelectBox, "DEFAULTLISTID", {
                    get: function () {
                        return "defaultId";
                    },
                    enumerable: true,
                    configurable: true
                });
                /**
                * This function changes the listPointer of select box to the new list @currentListId
                * @param currentListId: The new listId which is to be rendered in the select box
                */
                SelectBox.prototype.changeCurrentListId = function (currentListId) {
                    this._currentListId = currentListId;
                    this.currentOptions = this._optionsList[currentListId];
                };
                /**
                * It creates element displayed in select box.
                * Each element in select box is composed of text and value
                * @param _text:The text rendered in the select box on the screen
                * @param _value:The value corresponding to the text
                */
                SelectBox.prototype.createOption = function (_text, _value) {
                    var x = _value;
                    return { Label: _text, Value: x };
                };
                /**
                *If list doesnot exist, then it creates new list, adds the element in list and returns true
                *else simply adds the value and text in the list and return false.
                *If listId not specified, it takes currentListId.
                * @param id use to identify the list from collection of list
                * @param key by which resource will be fetched from resource file
                * @param value value used by select box
                */
                SelectBox.prototype.addItems = function (text, value, listId) {
                    var b = false;
                    if (listId === undefined)
                        listId = this._currentListId;
                    if (this._optionsList[listId] === undefined) {
                        this._optionsList[listId] = new Array();
                        b = true;
                    }
                    this._optionsList[listId].push(this.createOption(text, value));
                    return b;
                };
                return SelectBox;
            }());
            SvcConfigSettings.SelectBox = SelectBox;
        })(SvcConfigSettings = AppCommon.SvcConfigSettings || (AppCommon.SvcConfigSettings = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SvcConfigSettings;
        (function (SvcConfigSettings) {
            'use strict';
            //imports
            var FREShell = MscrmControls.AppCommon.FREShell;
            var SvcConfigSettingsControl = (function () {
                /**
                * Empty constructor.
                */
                function SvcConfigSettingsControl(notifyOutputChanged) {
                    this._supressSLASelectedValue = null;
                    this._autoApplySLASelectedValue = null;
                    this._slaEnabledEntitySelectedValue = SvcConfigSettings.SvcSettingsHelper.getDefaultEntityLogicalName();
                    this._autoApplyDefaultOnCaseUpdateSelectedValue = null;
                    this._autoApplyDefaultOnCaseCreateSelectedValue = null;
                    this._dualListControlIdOrKey = SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_DUALLIST_CONTAINER;
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                }
                /**
                * This function should be used for any initial setup necessary for your control.
                * @params context The "Input Bag" containing the parameters and other control metadata.
                * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                * @params state The user state for this control set from setState in the last session
                * @params container The div element to draw this control in
                */
                SvcConfigSettingsControl.prototype.init = function (context, notifyOutputChanged, state) {
                    var _this = this;
                    // custom code goes here
                    this._context = context;
                    SvcConfigSettings.SvcConfigSettingsStyles.initialize(this._context.theming, this._context.client.isRTL);
                    SvcConfigSettings.SvcConfigSettingsLocale.initialize(function (id) { return _this._context.resources.getString(id); });
                    this.InitializingServiceSettingsDDL();
                    this._freShell = new FREShell(context, SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_ServiceConfigSettings);
                };
                /**
                * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                * as well as resource, client, and theming info (see mscrm.d.ts)
                * @params context The "Input Bag" as described above
                */
                SvcConfigSettingsControl.prototype.updateView = function (context) {
                    return this._freShell.getVirtualComponents(this.getChildControls(context));
                };
                /**
                * This function will return an "Output Bag" to the Crm Infrastructure
                * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                * {
                *		value: myvalue
                * };
                * @returns The "Output Bag" containing values to pass to the infrastructure
                */
                SvcConfigSettingsControl.prototype.getOutputs = function () {
                    return null;
                };
                /**
                * This function will be called when the control is destroyed
                * It should be used for cleanup and releasing any memory the control is using
                */
                SvcConfigSettingsControl.prototype.destroy = function () {
                };
                /**
                * This function returns all controls of the Service settings page or a blank container incase of error.
                * @params context The "Input Bag" containing the parameters and other control metadata.
                * @returns The "Container" containing all controls of Service settings page
                */
                SvcConfigSettingsControl.prototype.getChildControls = function (context) {
                    this._context = context;
                    var params = {};
                    params.normalIconImagePath = SvcConfigSettings.SvcConfigSettingsConstants.SVC_CONFIGSETTINGS_HEADER_ICON_IMAGE;
                    params.highContrastIconImagePath = SvcConfigSettings.SvcConfigSettingsConstants.SVC_CONFIGSETTINGS_HEADER_ICON_HIGHCONTRAST_IMAGE;
                    params.areaLabel = SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_Sub_Header;
                    params.subAreaLabel = SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_Header;
                    var innerBodyContainer;
                    if (this._context.utils.isNullOrUndefined(this._svcSettingsDataHandler)) {
                        this._svcSettingsDataHandler = new SvcConfigSettings.SvcSettingsDataHandler(this._context);
                        innerBodyContainer = this.renderBlankContainerPage();
                    }
                    else if (this._svcSettingsDataHandler.getSLAEnabledEntities().length > 0) {
                        var slaEntities = this._svcSettingsDataHandler.getSLAEnabledEntities();
                        this._slaEnabledEntitiesDDL = new SvcConfigSettings.SelectBox(SvcConfigSettings.SelectBox.DEFAULTLISTID);
                        var isCaseEntityPresent = false;
                        for (var i = 0; i < slaEntities.length; i++) {
                            this._slaEnabledEntitiesDDL.addItems(slaEntities[i].DisplayName, slaEntities[i].LogicalName);
                            if (slaEntities[i].LogicalName === this._slaEnabledEntitySelectedValue) {
                                isCaseEntityPresent = true;
                            }
                        }
                        this._slaEnabledEntitySelectedValue = isCaseEntityPresent == false ? (slaEntities[0].LogicalName) : this._slaEnabledEntitySelectedValue;
                        this._supressSLASelectedValue = this._supressSLASelectedValue == null ? (this._svcSettingsDataHandler.getSvcConfigOrgSetting(SvcConfigSettings.BoolOrgSettings.suppresssla) == true ? SvcConfigSettings.BoolOrgValues[0] : SvcConfigSettings.BoolOrgValues[1]) : this._supressSLASelectedValue;
                        this._autoApplySLASelectedValue = this._autoApplySLASelectedValue == null ? (this._svcSettingsDataHandler.getSvcConfigOrgSetting(SvcConfigSettings.BoolOrgSettings.autoapplysla) == true ? SvcConfigSettings.BoolOrgValues[0] : SvcConfigSettings.BoolOrgValues[1]) : this._autoApplySLASelectedValue;
                        this._autoApplyDefaultOnCaseCreateSelectedValue = this._autoApplyDefaultOnCaseCreateSelectedValue == null ? (this._svcSettingsDataHandler.getSvcConfigOrgSetting(SvcConfigSettings.BoolOrgSettings.autoapplydefaultoncasecreate) == true ? SvcConfigSettings.BoolOrgValues[0] : SvcConfigSettings.BoolOrgValues[1]) : this._autoApplyDefaultOnCaseCreateSelectedValue;
                        this._autoApplyDefaultOnCaseUpdateSelectedValue = this._autoApplyDefaultOnCaseUpdateSelectedValue == null ? (this._svcSettingsDataHandler.getSvcConfigOrgSetting(SvcConfigSettings.BoolOrgSettings.autoapplydefaultoncaseupdate) == true ? SvcConfigSettings.BoolOrgValues[0] : SvcConfigSettings.BoolOrgValues[1]) : this._autoApplyDefaultOnCaseUpdateSelectedValue;
                        innerBodyContainer = this.renderControlPage();
                    }
                    else {
                        innerBodyContainer = this.renderBlankContainerPage();
                    }
                    params.contentContainerChild = innerBodyContainer;
                    params.headerRightContainerChild = this.createHeaderRightContainer();
                    this._freShell.stopPerformanceStopWatch();
                    return params;
                };
                /**
                * This function returns empty container.
                * @returns The "Container" containing all controls of Service settings page
                */
                SvcConfigSettingsControl.prototype.renderBlankContainerPage = function () {
                    var blankContainer = this._context.factory.createElement("CONTAINER", {
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_BLANK_CONTAINER,
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_BLANK_CONTAINER
                    }, []);
                    return blankContainer;
                };
                /**
                * This function returns container which contains the controls of the Service settings page.
                * @returns The "Container" containing all controls of Service settings page
                */
                SvcConfigSettingsControl.prototype.renderControlPage = function () {
                    var disableSLALabel = this._context.factory.createElement("LABEL", {
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_DisableSLA_LABEL,
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_DisableSLA_LABEL,
                        role: "heading",
                        style: SvcConfigSettings.SvcConfigSettingsStyles.labelStyle
                    }, SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_DisableSLALabel);
                    var supressSLAContainer = this.createDDLComponentAndLabel(SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSettings_Supress_SLA, SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_Supress_SLA, this._serviceSettingsSupressSLA_DDL, this._supressSLASelectedValue, this.SupressSLADropDownChange);
                    var disableSLAContainer = this._context.factory.createElement("CONTAINER", {
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_DisableSLA_CONTAINER,
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_DisableSLA_CONTAINER
                    }, [disableSLALabel, supressSLAContainer]);
                    var mappingEntities = this._svcSettingsDataHandler.getMappingForEntity(this._slaEnabledEntitySelectedValue);
                    var mappedEntities = this._svcSettingsDataHandler.getMappedAttributesOfEntity(this._slaEnabledEntitySelectedValue);
                    var properties = {
                        "parameters": {
                            JsonOptions: {
                                Usage: 3,
                                Static: true,
                                Type: "SingleLine.Text",
                                Value: JSON.stringify(mappingEntities.mappingItems.map(function (c) {
                                    return {
                                        Id: c.Id,
                                        DisplayName: c.DisplayName
                                    };
                                })),
                                Attributes: {
                                    DisplayName: null,
                                    LogicalName: "all_attributes",
                                    Type: "string",
                                    IsSecured: false,
                                    RequiredLevel: 0,
                                    MaxLength: 2147483647,
                                    EntityLogicalName: "",
                                    Format: "text",
                                    ImeMode: -1,
                                    Behavior: null
                                }
                            },
                            Selection: {
                                Usage: 3,
                                Static: true,
                                Type: "SingleLine.Text",
                                Value: mappedEntities,
                                Callback: this.callBackOnDualListSelectionChange.bind(this),
                                Attributes: {
                                    DisplayName: null,
                                    LogicalName: "cc_selectedAttributes_id",
                                    Type: "string",
                                    IsSecured: false,
                                    RequiredLevel: 0,
                                    MaxLength: 2147483647,
                                    EntityLogicalName: "",
                                    Format: null,
                                    ImeMode: -1,
                                    Behavior: null
                                }
                            },
                            SelectionOrderBy: {
                                Usage: 3,
                                Static: true,
                                Type: "Enum",
                                Raw: "0",
                                Attributes: {},
                            },
                            OptionSet: {
                                Usage: 3,
                                Static: true,
                                Type: null,
                                attributes: {},
                            }
                        }
                    };
                    var dualListContainer = this._context.factory.createElement("CONTAINER", {
                        id: this._dualListControlIdOrKey,
                        key: this._dualListControlIdOrKey
                    }, this._context.factory.createComponent("MscrmControls.DualListSelection.DualListSelectionControl", "DualListSelectionControl", properties));
                    var applySLAManuallyLabel = this._context.factory.createElement("LABEL", {
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_APPLYSLA_LABEL,
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_APPLYSLA_LABEL,
                        role: "heading",
                        style: SvcConfigSettings.SvcConfigSettingsStyles.labelStyle
                    }, SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_ApplyLabel);
                    var automaticallyApplySLA = this.createDDLComponentAndLabel(SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_AutomaticallyApplySLA, SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_AutomaticallyApplySLALabel, this._serviceSettingsAutoApplySLA_DDL, this._autoApplySLASelectedValue, this.AutoApplySLADDropDownChange);
                    var applySLAContainer = this._context.factory.createElement("CONTAINER", {
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_ApplySLA_CONTAINER,
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_ApplySLA_CONTAINER
                    }, [applySLAManuallyLabel, automaticallyApplySLA]);
                    var slaStatusLabel = this._context.factory.createElement("LABEL", {
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSettings_SLAStatusLabel,
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSettings_SLAStatusLabel,
                        role: "heading",
                        style: SvcConfigSettings.SvcConfigSettingsStyles.labelStyle
                    }, SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_SLAStatusLabel);
                    var slaEnabledEntity = this.createDDLComponentAndLabel(SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSettings_SLAEnabledEntitySelectionApplyLabel, SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_SLAEnabledEntitySelectionApplyLabel, this._slaEnabledEntitiesDDL, this._slaEnabledEntitySelectedValue, this.SLAEnabledEntityDDChange);
                    var slaStatusContainer = this._context.factory.createElement("CONTAINER", {
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_SLAStatus_CONTAINER,
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_SLAStatus_CONTAINER
                    }, [slaStatusLabel, slaEnabledEntity]);
                    var slaCalculationLabel = this._context.factory.createElement("LABEL", {
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSettings_SLAEnabledEntityCalculationLabel,
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSettings_SLAEnabledEntityCalculationLabel,
                        role: "heading",
                        style: SvcConfigSettings.SvcConfigSettingsStyles.labelStyle
                    }, SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_SLAEnabledEntityCalculationLabel);
                    var slaCalculationLabelContainer = this._context.factory.createElement("CONTAINER", {
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_SlaCalculationLabelContainer_CONTAINER,
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_SlaCalculationLabelContainer_CONTAINER
                    }, [slaCalculationLabel]);
                    var automaticallyApplyEntitlementLabel = this._context.factory.createElement("LABEL", {
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSettings_AutomaticallyApplyEntitlementLabel,
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSettings_AutomaticallyApplyEntitlementLabel,
                        role: "heading",
                        style: SvcConfigSettings.SvcConfigSettingsStyles.labelStyle
                    }, SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_AutomaticallyApplyEntitlementLabel);
                    var applyDefaultOnCaseCreateContainer = this.createDDLComponentAndLabel(SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSettings_AutomaticallyApplyDefaultOnCaseCreationLabel, SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_AutomaticallyApplyEntitlementOnCaseCreationLabel, this._serviceSettingsAutoApplyDefaultOnCaseCreation_DDL, this._autoApplyDefaultOnCaseCreateSelectedValue, this.AutoApplyDefaultOnCaseCreateDDChange);
                    var applyDefaultOnCaseUpdateContainer = this.createDDLComponentAndLabel(SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSettings_AutomaticallyApplyDefaultOnCaseUpdationLabel, SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_AutomaticallyApplyEntitlementOnCaseUpdationLabel, this._serviceSettingsAutoApplyDefaultOnCaseUpdation_DDL, this._autoApplyDefaultOnCaseUpdateSelectedValue, this.AutoApplyDefaultOnCaseUpdateDDChange);
                    var applyEntitlementContainer = this._context.factory.createElement("CONTAINER", {
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_ApplyEntitlement_CONTAINER,
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_ApplyEntitlement_CONTAINER
                    }, [automaticallyApplyEntitlementLabel, applyDefaultOnCaseCreateContainer, applyDefaultOnCaseUpdateContainer]);
                    var mainContainer = this._context.factory.createElement("CONTAINER", {
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_MAIN_CONTAINER,
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_MAIN_CONTAINER,
                        style: SvcConfigSettings.SvcConfigSettingsStyles.SvcConfigSettingsContentContainer
                    }, [disableSLAContainer, applySLAContainer, slaStatusContainer, slaCalculationLabelContainer, dualListContainer, applyEntitlementContainer]);
                    return mainContainer;
                };
                /**
                 * This function gets executed when there is selection change in dual list control.
                 * @param newValue
                 */
                SvcConfigSettingsControl.prototype.callBackOnDualListSelectionChange = function (newValue) {
                    this._svcSettingsDataHandler.setMappingForEntity(this._slaEnabledEntitySelectedValue, { mappedAttributes: newValue });
                    this._context.utils.requestRender();
                };
                SvcConfigSettingsControl.prototype.onSaveButtonClicked = function () {
                    this._svcSettingsDataHandler.updateServiceSettings();
                };
                /**
                * This function will be called when Supress SLA Dropdown is changed.
                * @params selectedOption The "SelectBoxOption" containing the metadata.
                * @returns The selected value of Supress SLA Dropdown
                */
                SvcConfigSettingsControl.prototype.SupressSLADropDownChange = function (selectedOption) {
                    this._supressSLASelectedValue = selectedOption.Value;
                    this._svcSettingsDataHandler.setSvcConfigOrgSetting(SvcConfigSettings.BoolOrgSettings.suppresssla, selectedOption.Value == SvcConfigSettings.BoolOrgValues[0] ? true : false);
                };
                /**
                * This function will be called when Supress SLA Dropdown is changed.
                * @params selectedOption The "SelectBoxOption" containing the metadata.
                * @returns The selected value of Supress SLA Dropdown
                */
                SvcConfigSettingsControl.prototype.AutoApplySLADDropDownChange = function (selectedOption) {
                    this._autoApplySLASelectedValue = selectedOption.Value;
                    this._svcSettingsDataHandler.setSvcConfigOrgSetting(SvcConfigSettings.BoolOrgSettings.autoapplysla, selectedOption.Value == SvcConfigSettings.BoolOrgValues[0] ? true : false);
                };
                /**
                * This function will be called when Supress SLA Enabled Entity Dropdown is changed.
                * @params selectedOption The "SelectBoxOption" containing the metadata.
                * @returns The selected value of Supress SLA Dropdown
                */
                SvcConfigSettingsControl.prototype.SLAEnabledEntityDDChange = function (selectedOption) {
                    this._slaEnabledEntitySelectedValue = selectedOption.Value;
                    // We are generating  new ID for Dual List container as it is not able to re-render with the same ID.
                    this._dualListControlIdOrKey = SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_DUALLIST_CONTAINER + Date.now();
                    this._svcSettingsDataHandler.fetchMappingForEntity(this._slaEnabledEntitySelectedValue);
                };
                /**
                * This function will be called when Case creation Dropdown is changed.
                * @params selectedOption The "SelectBoxOption" containing the metadata.
                * @returns The selected value of Supress SLA Dropdown
                */
                SvcConfigSettingsControl.prototype.AutoApplyDefaultOnCaseCreateDDChange = function (selectedOption) {
                    this._autoApplyDefaultOnCaseCreateSelectedValue = selectedOption.Value;
                    this._svcSettingsDataHandler.setSvcConfigOrgSetting(SvcConfigSettings.BoolOrgSettings.autoapplydefaultoncasecreate, selectedOption.Value == SvcConfigSettings.BoolOrgValues[0] ? true : false);
                };
                /**
                * This function will be called when Case updation Dropdown is changed.
                * @params selectedOption The "SelectBoxOption" containing the metadata.
                * @returns The selected value of Supress SLA Dropdown
                */
                SvcConfigSettingsControl.prototype.AutoApplyDefaultOnCaseUpdateDDChange = function (selectedOption) {
                    this._autoApplyDefaultOnCaseUpdateSelectedValue = selectedOption.Value;
                    this._svcSettingsDataHandler.setSvcConfigOrgSetting(SvcConfigSettings.BoolOrgSettings.autoapplydefaultoncaseupdate, selectedOption.Value == SvcConfigSettings.BoolOrgValues[0] ? true : false);
                };
                /**
                * This function will return the Container which contains Dropdown and Label.
                * @params key The "SelectBoxOption" containing the metadata.
                * @params label The "SelectBoxOption" containing the metadata.
                * @params selectBox The "SelectBoxOption" containing the metadata.
                * @params selectedValue The "SelectBoxOption" containing the metadata.
                * @params callBack The "SelectBoxOption" containing the metadata.
                * @returns The container which contains Dropdown and Label
                */
                SvcConfigSettingsControl.prototype.createDDLComponentAndLabel = function (key, label, selectBox, selectedValue, callBack) {
                    selectBox.controlProps = {
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_DDL_CONTROL_PROPS + key,
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_DDL_CONTROL_PROPS + key,
                        freeTextMode: true,
                        value: { Value: selectedValue, Color: null },
                        onChange: callBack.bind(this),
                        options: selectBox.currentOptions,
                        tabIndex: 1,
                        style: SvcConfigSettings.SvcConfigSettingsStyles.ddlPropsStyle
                    };
                    selectBox.component = this._context.factory.createElement("SELECT", selectBox.controlProps, null);
                    var dropDownListAssosciatedLabel = this._context.factory.createElement("LABEL", {
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_DDL_LBL + key,
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_DDL_LBL + key,
                        style: SvcConfigSettings.SvcConfigSettingsStyles.ddlAssosciatedLabelStyle,
                        forElementId: this._context.accessibility.getUniqueId(SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_DDL_CONTROL_PROPS + key)
                    }, label);
                    var dropDownListContainer = this._context.factory.createElement("CONTAINER", {
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_DDL_CONTAINER + key,
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_DDL_CONTAINER + key,
                        style: SvcConfigSettings.SvcConfigSettingsStyles.ddlLabelContainer
                    }, [dropDownListAssosciatedLabel, selectBox.component]);
                    return dropDownListContainer;
                };
                /**
                * This function will initialise all the Dropdown Values of the Service Settings page.
                */
                SvcConfigSettingsControl.prototype.InitializingServiceSettingsDDL = function () {
                    /*Initialzing the ClouserPreferenceDDL */
                    this._serviceSettingsSupressSLA_DDL = new SvcConfigSettings.SelectBox(SvcConfigSettings.SelectBox.DEFAULTLISTID);
                    this._serviceSettingsSupressSLA_DDL.addItems(SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_Yes_Text, SvcConfigSettings.BoolOrgValues[0]);
                    this._serviceSettingsSupressSLA_DDL.addItems(SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_No_Text, SvcConfigSettings.BoolOrgValues[1]);
                    this._serviceSettingsAutoApplySLA_DDL = new SvcConfigSettings.SelectBox(SvcConfigSettings.SelectBox.DEFAULTLISTID);
                    this._serviceSettingsAutoApplySLA_DDL.addItems(SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_Yes_Text, SvcConfigSettings.BoolOrgValues[0]);
                    this._serviceSettingsAutoApplySLA_DDL.addItems(SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_No_Text, SvcConfigSettings.BoolOrgValues[1]);
                    this._serviceSettingsAutoApplyDefaultOnCaseCreation_DDL = new SvcConfigSettings.SelectBox(SvcConfigSettings.SelectBox.DEFAULTLISTID);
                    this._serviceSettingsAutoApplyDefaultOnCaseCreation_DDL.addItems(SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_Yes_Text, SvcConfigSettings.BoolOrgValues[0]);
                    this._serviceSettingsAutoApplyDefaultOnCaseCreation_DDL.addItems(SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_No_Text, SvcConfigSettings.BoolOrgValues[1]);
                    this._serviceSettingsAutoApplyDefaultOnCaseUpdation_DDL = new SvcConfigSettings.SelectBox(SvcConfigSettings.SelectBox.DEFAULTLISTID);
                    this._serviceSettingsAutoApplyDefaultOnCaseUpdation_DDL.addItems(SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_Yes_Text, SvcConfigSettings.BoolOrgValues[0]);
                    this._serviceSettingsAutoApplyDefaultOnCaseUpdation_DDL.addItems(SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_No_Text, SvcConfigSettings.BoolOrgValues[1]);
                    this._slaEnabledEntitiesDDL = new SvcConfigSettings.SelectBox(SvcConfigSettings.SelectBox.DEFAULTLISTID);
                };
                /**
                * Creates RightContainer for header
                */
                SvcConfigSettingsControl.prototype.createHeaderRightContainer = function () {
                    var saveIconContainer = this._context.factory.createElement("CONTAINER", {
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_SAVEICONCONTAINERKEY,
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_SAVEICONCONTAINERKEY,
                        style: SvcConfigSettings.SvcConfigSettingsStyles.freRightButtonIconContainer
                    }, []);
                    var saveButton = this._context.factory.createElement("BUTTON", {
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_SAVE_BUTTON,
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_SAVE_BUTTON,
                        onClick: this.onSaveButtonClicked.bind(this),
                        tabIndex: 1,
                        style: SvcConfigSettings.SvcConfigSettingsStyles.freHeaderRightButtonStyle
                    }, [saveIconContainer, SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_Save]);
                    var headerSeparatorContainer = this._context.factory.createElement("CONTAINER", {
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_HEADERSEPARATORCONTAINERKEY,
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_HEADERSEPARATORCONTAINERKEY,
                        style: SvcConfigSettings.SvcConfigSettingsStyles.freHeaderSeparatorContainer
                    }, []);
                    var headerRightContainer = this._context.factory.createElement("CONTAINER", {
                        key: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_HEADERRIGHTCONTAINERKEY,
                        id: SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_HEADERRIGHTCONTAINERKEY,
                        style: SvcConfigSettings.SvcConfigSettingsStyles.freHeaderRightContainer
                    }, [headerSeparatorContainer, saveButton]);
                    return headerRightContainer;
                };
                return SvcConfigSettingsControl;
            }());
            SvcConfigSettings.SvcConfigSettingsControl = SvcConfigSettingsControl;
        })(SvcConfigSettings = AppCommon.SvcConfigSettings || (AppCommon.SvcConfigSettings = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SvcConfigSettings;
        (function (SvcConfigSettings) {
            'use strict';
            var SvcConfigSettingsStyles = (function (_super) {
                __extends(SvcConfigSettingsStyles, _super);
                function SvcConfigSettingsStyles() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                SvcConfigSettingsStyles.initialize = function (theming, isRTL) {
                    SvcConfigSettingsStyles.labelStyle = {
                        fontFamily: theming.fontfamilies.semibold,
                        fontSize: theming.fontsizes.font100,
                        lineHeight: "1.4rem",
                        color: theming.colors.basecolor.grey.grey7,
                        marginBottom: theming.measures.measure100,
                        marginLeft: theming.measures.measure100,
                        marginTop: theming.measures.measure100,
                        display: "block"
                    };
                    SvcConfigSettingsStyles.SvcConfigSettingsContentContainer = {
                        display: "flex",
                        flex: "1 1 auto",
                        backgroundColor: "#FFFFFF",
                        flexDirection: "column",
                        overflow: "auto"
                    };
                    SvcConfigSettingsStyles.ddlPropsStyle = {
                        width: "200px",
                        height: "25px",
                        backgroundColor: theming.colors.basecolor.white,
                        fontFamily: theming.fontfamilies.regular,
                        fontSize: theming.fontsizes.font100,
                        color: theming.colors.basecolor.grey.grey7,
                        display: "block"
                    };
                    SvcConfigSettingsStyles.ddlAssosciatedLabelStyle = {
                        fontFamily: theming.fontfamilies.regular,
                        fontSize: theming.fontsizes.font100,
                        lineHeight: "1.4rem",
                        color: theming.colors.basecolor.grey.grey7,
                        marginBottom: theming.measures.measure100,
                        display: "block",
                        width: "60%"
                    };
                    SvcConfigSettingsStyles.ddlLabelContainer = {
                        display: "-webkit-inline-box",
                        backgroundColor: "transparent",
                        flexDirection: "column",
                        marginLeft: theming.measures.measure100,
                        marginTop: theming.measures.measure150,
                        width: "100%",
                    };
                    SvcConfigSettingsStyles.freRightButtonIconContainer = {
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        backgroundColor: "transparent",
                        margin: theming.measures.measure025
                    };
                    SvcConfigSettingsStyles.freHeaderSeparatorContainer = {
                        borderRight: theming.borders.border02,
                        width: "1px",
                        height: "2.1rem",
                        alignSelf: "center"
                    };
                    SvcConfigSettingsStyles.freHeaderRightContainer = {
                        display: "flex",
                        alignItems: "center",
                        margin: theming.measures.measure075
                    };
                    SvcConfigSettingsStyles.freHeaderRightButtonStyleHover = {
                        fontFamily: theming.fontfamilies.semibold
                    };
                    SvcConfigSettingsStyles.freHeaderRightButtonStyleFocus = {
                        fontFamily: theming.fontfamilies.semibold,
                        border: "1px solid #666666",
                        outline: "none"
                    };
                    SvcConfigSettingsStyles.freHeaderRightButtonStyleDisabled = {
                        color: theming.colors.basecolor.grey.grey5,
                        fontFamily: theming.fontfamilies.regular,
                    };
                    SvcConfigSettingsStyles.freHeaderRightButtonStyle = {
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        alignSelf: "center",
                        border: "none",
                        backgroundColor: "transparent",
                        cursor: "pointer",
                        padding: "2px",
                        marginLeft: theming.measures.measure075,
                        marginRight: theming.measures.measure075,
                        fontFamily: theming.fontfamilies.regular,
                        fontSize: theming.fontsizes.font100,
                        color: "#0063B1",
                        lineHeight: "1.4rem",
                        whiteSpace: "nowrap",
                        hover: this.freHeaderRightButtonStyleHover,
                        focus: this.freHeaderRightButtonStyleFocus,
                        disabled: this.freHeaderRightButtonStyleDisabled,
                    };
                };
                return SvcConfigSettingsStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            SvcConfigSettingsStyles.labelStyle = {};
            SvcConfigSettingsStyles.SvcConfigSettingsContentContainer = {};
            SvcConfigSettingsStyles.ddlPropsStyle = {};
            SvcConfigSettingsStyles.freRightButtonIconContainer = {};
            SvcConfigSettingsStyles.ddlAssosciatedLabelStyle = {};
            SvcConfigSettingsStyles.ddlLabelContainer = {};
            SvcConfigSettingsStyles.freHeaderRightButtonStyle = {};
            SvcConfigSettingsStyles.freHeaderSeparatorContainer = {};
            SvcConfigSettingsStyles.freHeaderRightButtonStyleHover = {};
            SvcConfigSettingsStyles.freHeaderRightButtonStyleFocus = {};
            SvcConfigSettingsStyles.freHeaderRightButtonStyleDisabled = {};
            SvcConfigSettingsStyles.freHeaderRightContainer = {};
            SvcConfigSettings.SvcConfigSettingsStyles = SvcConfigSettingsStyles;
        })(SvcConfigSettings = AppCommon.SvcConfigSettings || (AppCommon.SvcConfigSettings = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SvcConfigSettings;
        (function (SvcConfigSettings) {
            'use strict';
            var SvcConfigSettingsLocale = (function () {
                function SvcConfigSettingsLocale() {
                }
                /*
                 * Initializes the Case Settings labels.
                */
                SvcConfigSettingsLocale.initialize = function (getString) {
                    SvcConfigSettingsLocale.SvcConfigSettings_Header = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_Header);
                    SvcConfigSettingsLocale.SvcConfigSettings_Sub_Header = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_Sub_Header);
                    SvcConfigSettingsLocale.SvcConfigSettings_ApplyLabel = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_ApplySLA);
                    SvcConfigSettingsLocale.SvcConfigSettings_DisableSLALabel = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_DisableSLA);
                    SvcConfigSettingsLocale.SvcConfigSettings_Supress_SLA = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_SupressSLA);
                    SvcConfigSettingsLocale.SvcConfigSettings_AutomaticallyApplySLALabel = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_AutomaticallyApplySLA);
                    SvcConfigSettingsLocale.SvcConfigSettings_SLAStatusLabel = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_SLAStatus);
                    SvcConfigSettingsLocale.SvcConfigSettings_SLAEnabledEntitySelectionApplyLabel = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_SLAEnabledEntitySelection);
                    SvcConfigSettingsLocale.SvcConfigSettings_SLAEnabledEntityCalculationLabel = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_SLAEnabledEntityCalculation);
                    SvcConfigSettingsLocale.SvcConfigSettings_AutomaticallyApplyEntitlementLabel = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_AutomaticallyApplyEntitlement);
                    SvcConfigSettingsLocale.SvcConfigSettings_AutomaticallyApplyEntitlementOnCaseCreationLabel = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_AutomaticallyApplyEntitlementOnCaseCreation);
                    SvcConfigSettingsLocale.SvcConfigSettings_AutomaticallyApplyEntitlementOnCaseUpdationLabel = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_AutomaticallyApplyEntitlementOnCaseUpdation);
                    SvcConfigSettingsLocale.SvcConfigSettings_Yes_Text = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_Yes);
                    SvcConfigSettingsLocale.SvcConfigSettings_No_Text = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_No);
                    SvcConfigSettingsLocale.SvcConfigSettings_Save = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_Save);
                    SvcConfigSettingsLocale.SvcConfigSettings_ServiceConfigSettings = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_ServiceConfigSettings_Text);
                    SvcConfigSettingsLocale.SvcConfigSettings_SucessfullSave = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_SucessfullSave_Message);
                    SvcConfigSettingsLocale.SvcConfigSettings_Error_Message = getString(SvcConfigSettings.SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_Error_Message);
                };
                return SvcConfigSettingsLocale;
            }());
            SvcConfigSettings.SvcConfigSettingsLocale = SvcConfigSettingsLocale;
        })(SvcConfigSettings = AppCommon.SvcConfigSettings || (AppCommon.SvcConfigSettings = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SvcConfigSettings;
        (function (SvcConfigSettings) {
            'use strict';
            var SvcConfigSettingsLabellId = (function () {
                function SvcConfigSettingsLabellId() {
                }
                return SvcConfigSettingsLabellId;
            }());
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_Header = "SvcConfigSettings_Header";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_Sub_Header = "SvcConfigSettings_Sub_Header";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_ApplySLA = "SvcConfigSettings_ApplySLA";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_DisableSLA = "SvcConfigSettings_DisableSLA";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_SupressSLA = "SvcConfigSettings_DisableSLAEnabledEntityRecords";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_AutomaticallyApplySLA = "SvcConfigSettings_AutomaticallyApplySLA";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_SLAStatus = "SvcConfigSettings_SLAStatus";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_SLAEnabledEntitySelection = "SvcConfigSettings_SLAEnabledEntitySelection";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_SLAEnabledEntityCalculation = "SvcConfigSettings_SLAEnabledEntityCalculation";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_AutomaticallyApplyEntitlement = "SvcConfigSettings_AutomaticallyApplyEntitlement";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_AutomaticallyApplyEntitlementOnCaseCreation = "SvcConfigSettings_AutomaticallyApplyEntitlementOnCaseCreation";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_AutomaticallyApplyEntitlementOnCaseUpdation = "SvcConfigSettings_AutomaticallyApplyEntitlementOnCaseUpdation";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_Save = "SvcConfigSettings_Save";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_Yes = "SvcConfigSettings_Yes_Text";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_No = "SvcConfigSettings_No_Text";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_ServiceConfigSettings_Text = "SvcConfigSettings_ServiceConfigSettings_Text";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_SucessfullSave_Message = "SvcConfigSettings_SucessfullSave_Message";
            SvcConfigSettingsLabellId.ResourceKey_SvcConfigSettings_Error_Message = "SvcConfigSettings_Error_Message";
            SvcConfigSettings.SvcConfigSettingsLabellId = SvcConfigSettingsLabellId;
        })(SvcConfigSettings = AppCommon.SvcConfigSettings || (AppCommon.SvcConfigSettings = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="SvcConfigSettingsControl.ts" />
/// <reference path="SvcConfigSettingsStyles.ts" />
/// <reference path="SvcConfigSettingsLocale.ts" />
/// <reference path="SvcConfigSettingsLabelId.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/**
* Telemetry library that takes dynamic parameter lists as event parameters in addition to fixed required parameters relavent to classify verticals association with Entities
* and pushes to crminsightsdev.cloudapp.net endpoint.  All one needs to do is Register your telemetry event with InsightsEndpoint repo (Events.xml and MdsConfig-CloudService.xml
* and start pushing event data using below APIs
*
* Sample calls for the APIs - caller : non-custom control eg: Ribbon commands
* AppsTelemetryUtility.reportData(EventList.EntitlementEvent, ModuleList.service, EntityList.entitlement, "Activation", null, { "CurrentState": "Activate", "UpdateMode": "Mouse"})
* AppsTelemetryUtility.reportData("CSHEntitlements", "Service", "Entitlement", "Deactivate", null, { "CurrentState": "Inactive", "UpdateMode": "KeyBoard"})
* Similarly ReportSuccess and Report Failure calls using either Enums (preferred) or string values.
* AppsTelemetryUtility.reportSuccess(EventList.EntitlementEvent, ModuleList.service, EntityList.entitlement, "TestAction", null, { "CurrentState": "Activate", "UpdateMode": "Mouse"})
* AppsTelemetryUtility.reportFailure(EventList.EntitlementEvent, ModuleList.service, EntityList.entitlement, "TestAction", null, { "CurrentState": "Activate", "UpdateMode": "Mouse"})
*
* Sample calls for the APIs - caller Custom Controls
* AppsTelemetryUtility.ReportSuccess(EventList.SubjectEvent, ModuleList.service, EntityList.CSSEvent, "AddBreak", this.context, {"Duration": 30, "Timezone": "PST"});
* AppsTelemetryUtility.ReportFailure("CSH_Subject", "Service", "Subject", "AddChild", this.context, {"name": "myRegarding", "parent": "myEntity"});
*
* In above samples for non-custom control calls, null is expected to be passed as part of event call for two reasons 1. Generic API for custom & non-custom control
*/
var AppsTelemetryLib;
(function (AppsTelemetryLib) {
    'use strict';
    /**
    * To format the outer payload for telemetry data according to the event schema
    */
    var TelemetryPayload = (function () {
        function TelemetryPayload() {
        }
        return TelemetryPayload;
    }());
    AppsTelemetryLib.TelemetryPayload = TelemetryPayload;
    /**
    * To format the inner payload for telemetry data according to the event schema
    */
    var TelemetryParameter = (function () {
        function TelemetryParameter() {
        }
        return TelemetryParameter;
    }());
    AppsTelemetryLib.TelemetryParameter = TelemetryParameter;
    /**
    * Declaring this key value pair to make it easy for callers
    */
    var ExtraParams = (function () {
        function ExtraParams() {
        }
        return ExtraParams;
    }());
    AppsTelemetryLib.ExtraParams = ExtraParams;
    /**
    * ENUMs tracking EventTypes
    */
    var EventTypes = (function () {
        function EventTypes() {
        }
        return EventTypes;
    }());
    EventTypes.Success = "Success";
    EventTypes.Failure = "Failure";
    EventTypes.EventData = "EventData";
    AppsTelemetryLib.EventTypes = EventTypes;
    /**
    * ENUMs tracking Vertical Events. Callers of Client Telemetry APIs can use ENUMs to pass required parameters
    * Currently listed with registered Customer Service Module List
    */
    var EventList = (function () {
        function EventList() {
        }
        return EventList;
    }());
    EventList.QueueEvent = "CSHQueues";
    EventList.RoutingRuleEvent = "CSHRoutingRules";
    EventList.ARCEvent = "CSHAutoRecordCreation";
    EventList.SubjectEvent = "CSHSubject";
    EventList.HSEvent = "CSHHolidaySchedule";
    EventList.CSSEvent = "CSHCustomerServiceSchedule";
    EventList.SettingsEvent = "CSHSettings";
    EventList.EntitlementEvent = "CSHEntitlements";
    EventList.IncidentEvent = "CSHIncident";
    EventList.EventAgnostic = "CSHMisc";
    AppsTelemetryLib.EventList = EventList;
    /**
    * ENUMs tracking Vertical/Module List
    */
    var ModuleList = (function () {
        function ModuleList() {
        }
        return ModuleList;
    }());
    ModuleList.service = "Service";
    ModuleList.sales = "Sales";
    ModuleList.marketing = "Marketing";
    ModuleList.verticalAgnostic = "VerticalAgnostic";
    AppsTelemetryLib.ModuleList = ModuleList;
    /**
    * ENUMs tracking Entity List
    * Currently listing entities list part of Customer Service Module shipping in Enterprise Release
    */
    var EntityList = (function () {
        function EntityList() {
        }
        return EntityList;
    }());
    EntityList.queue = "Queue";
    EntityList.queueItem = "QueueItem";
    EntityList.convertRule = "ConvertRule";
    EntityList.convertRuleItem = "ConvertRuleItem";
    EntityList.routingRule = "RoutingRule";
    EntityList.routingRuleItem = "RoutingRuleItem";
    EntityList.entitlement = "Entitlement";
    EntityList.entitlementTemplate = "EntitlementTemplate";
    EntityList.sla = "SLA";
    EntityList.slaItem = "SLAItem";
    EntityList.calendar = "Calendar";
    EntityList.calendarRule = "CalendarRule";
    EntityList.subject = "Subject";
    EntityList.incident = "Incident";
    EntityList.organization = "organization";
    AppsTelemetryLib.EntityList = EntityList;
    /**
    * ENUMs tracking Action
    */
    var Action = (function () {
        function Action() {
        }
        return Action;
    }());
    Action.create = "Create";
    Action.update = "Update";
    Action.retrieve = "Retrieve";
    Action.delete = "Delete";
    Action.clickedGridCommand = "ClickedGridCommand";
    AppsTelemetryLib.Action = Action;
    var AppsTelemetryUtility = (function () {
        function AppsTelemetryUtility() {
        }
        /**
        * @function reportEventData send telemetry data to the crminsightsdev.cloudapp.net endpoint.
        * @description send telemetry data to the telemetry endpoint.
        * @param appName - service / sales / any other XRM based app
        * @param context -  A reference to the context of custom entity; null for non-custom entity calls
        */
        AppsTelemetryUtility.reportData = function (eventName, appName, entityName, actionName, context, eventSpecificParams) {
            var telemetrydata = AppsTelemetryUtility.getTelemetryData(eventName, EventTypes.EventData, appName, entityName, actionName, context, eventSpecificParams);
            // Async calls be made to reportEvent call and error scenarios are expected to be handled within reportEvent infra
            if (context != null && context.reporting != null) {
                context.reporting.reportEvent(telemetrydata);
            }
            else {
                Xrm.Reporting.reportEvent(telemetrydata);
            }
        };
        ;
        AppsTelemetryUtility.reportFailure = function (eventName, appName, entityName, actionName, context, eventSpecificParams) {
            var telemetrydata = AppsTelemetryUtility.getTelemetryData(eventName, EventTypes.Failure, appName, entityName, actionName, context, eventSpecificParams);
            if (context != null && context.reporting != null) {
                context.reporting.reportEvent(telemetrydata);
            }
            else {
                Xrm.Reporting.reportEvent(telemetrydata);
            }
        };
        ;
        AppsTelemetryUtility.reportError = function (eventName, appName, entityName, actionName, context, errorMessage, errorTrace) {
            var eventSpecificParams = {};
            eventSpecificParams["errorMessage"] = errorMessage;
            eventSpecificParams["errorTrace"] = errorTrace ? JSON.stringify(errorTrace, Object.getOwnPropertyNames(errorTrace)) : "";
            AppsTelemetryUtility.reportFailure(eventName, appName, entityName, actionName, context, eventSpecificParams);
        };
        ;
        AppsTelemetryUtility.reportSuccess = function (eventName, appName, entityName, actionName, context, eventSpecificParams) {
            var telemetrydata = AppsTelemetryUtility.getTelemetryData(eventName, EventTypes.Success, appName, entityName, actionName, context, eventSpecificParams);
            if (context != null && context.reporting != null) {
                context.reporting.reportEvent(telemetrydata);
            }
            else {
                Xrm.Reporting.reportEvent(telemetrydata);
            }
        };
        ;
        AppsTelemetryUtility.getTelemetryData = function (_eventName, _telemetryDatatype, _appName, _entityName, _actionName, _context, _eventSpecificParams) {
            var payload = {
                eventName: _eventName,
                eventParameters: []
            };
            var para1 = { name: "EventType", value: _telemetryDatatype };
            var para2 = { name: "appName", value: _appName };
            var para3 = { name: "entityName", value: _entityName };
            var para4 = { name: "actionName", value: _actionName };
            var para5 = { name: "context", value: _context };
            payload.eventParameters.push(para1);
            payload.eventParameters.push(para2);
            payload.eventParameters.push(para3);
            payload.eventParameters.push(para4);
            payload.eventParameters.push(para5);
            var __eventSpecificParams = JSON.stringify(_eventSpecificParams);
            var para6 = { name: "eventSpecificParams", value: __eventSpecificParams };
            payload.eventParameters.push(para6);
            return payload;
        };
        return AppsTelemetryUtility;
    }());
    AppsTelemetryLib.AppsTelemetryUtility = AppsTelemetryUtility;
})(AppsTelemetryLib || (AppsTelemetryLib = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../../../../ClientUtility/Client/Common/AppsTelemetrylib.ts" />
/// <reference path="../../../../TypeDefinitions/AppCommon/Controls/FREShell/libs/FREShell.d.ts" /> 
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SvcConfigSettings;
        (function (SvcConfigSettings) {
            var SvcSettingsDataHandler = (function () {
                /**
                * constructor of Service settings data handler
                */
                function SvcSettingsDataHandler(context) {
                    this._slaEntitiesInDefaultApp = null;
                    // this property is used to hold the entity object ids available in current app
                    this._entityIDsInCurrentApp = null;
                    this._origOrgSettingsSLA = [];
                    this._currentOrgSettingsSLA = [];
                    this._entitiesMappingDetails = {};
                    this._entityStatusOptions = {};
                    this._slaEnabledEntitiesInCurrentApp = [];
                    this._context = context;
                    this._initializeRequestsCounter = 0;
                    this._expectedTotalResponseCount = 3;
                    this.init();
                }
                /**
                 * This function returns the mapped attributes of entity name which is passed
                 * @param entityName
                 */
                SvcSettingsDataHandler.prototype.getMappedAttributesOfEntity = function (entityName) {
                    return this._context.utils.isNullOrUndefined(this._entitiesMappingDetails[entityName]) ? "" : this._entitiesMappingDetails[entityName].mappedAttributes;
                };
                /**
                 * Returns true or false for given boolean org setting
                 * @param name
                 */
                SvcSettingsDataHandler.prototype.getSvcConfigOrgSetting = function (name) {
                    return this._origOrgSettingsSLA[name];
                };
                /**
                 * Update the boolean setting to given value
                 * @param name
                 * @param value
                 */
                SvcSettingsDataHandler.prototype.setSvcConfigOrgSetting = function (name, value) {
                    this._currentOrgSettingsSLA[name] = value;
                };
                /**
                 * retrieves SLA enabled entities in current app context
                 */
                SvcSettingsDataHandler.prototype.getSLAEnabledEntities = function () {
                    return this._slaEnabledEntitiesInCurrentApp;
                };
                /**
                 * fetches status mapping information for the newly selected entity
                 * @param logicalName
                 */
                SvcSettingsDataHandler.prototype.fetchMappingForEntity = function (logicalName) {
                    var _this = this;
                    var mappingDetails = { mappingItems: [] };
                    if (this._context.utils.isNullOrUndefined(this._entityStatusOptions[logicalName])) {
                        var attributesURL = this._context.utils.createCrmUri(SvcConfigSettings.SvcSettingsHelper.getAttributesOfEntityURL(logicalName));
                        this.sendRequest(attributesURL).then(function (data) {
                            if (!_this._context.utils.isNullOrUndefined(data) && !_this._context.utils.isNullOrUndefined(data.value) && data.value.length > 0) {
                                if (!_this._context.utils.isNullOrUndefined(data.value[0].OptionSet) && !_this._context.utils.isNullOrUndefined(data.value[0].OptionSet.Options) && data.value[0].OptionSet.Options.length > 0) {
                                    var options = data.value[0].OptionSet.Options;
                                    for (var i = 0; i < options.length; i++) {
                                        if (!_this._context.utils.isNullOrUndefined(options[i])) {
                                            if (options[i].State == SvcConfigSettings.SvcConfigSettingsConstants.SvcConfigSETTINGS_ZeroValue) {
                                                var option = options[i];
                                                var label = option.Label.UserLocalizedLabel.Label;
                                                var id = options[i].Value;
                                                mappingDetails.mappingItems.push({ Id: id, DisplayName: label });
                                            }
                                        }
                                    }
                                    _this._entityStatusOptions[logicalName] = mappingDetails;
                                    _this._initializeRequestsCounter++;
                                    _this.checkRequestCounterForRerendering();
                                }
                            }
                        }, function (error) {
                            var errMessage = "Retrieval of Entity Attributes call Failed.";
                            _this.reportErrorTelemetry(_this._context, errMessage, error);
                        });
                    }
                    else {
                        this.checkRequestCounterForRerendering();
                    }
                };
                /**
                 * returns status mapping information for the newly selected entity
                 * @param logicalName
                 */
                SvcSettingsDataHandler.prototype.getMappingForEntity = function (logicalName) {
                    return this._entityStatusOptions[logicalName];
                };
                /**
                 * Updates mapping information for the given entity
                 * @param logicalName
                 * @param mappingDetails
                 */
                SvcSettingsDataHandler.prototype.setMappingForEntity = function (logicalName, mappingDetails) {
                    this._entitiesMappingDetails[logicalName] = mappingDetails;
                };
                /**
                * This method will do initialisation of data
                */
                SvcSettingsDataHandler.prototype.init = function () {
                    this.retrieveSLAEnabledEntitiesForCurrentApp();
                    this.fetchMappingForEntity(SvcConfigSettings.SvcSettingsHelper.getDefaultEntityLogicalName());
                    this.retrieveOrgSettingValues();
                };
                /**
                 * This function retrives the SLA Enabled Entities for the current app
                 */
                SvcSettingsDataHandler.prototype.retrieveSLAEnabledEntitiesForCurrentApp = function () {
                    this.retrieveSLAEnabledEntitiesInDefaultApp();
                    this.getEntitiesInCurrentApp();
                };
                /**
                 * This method updates the mapped entities XML
                 */
                SvcSettingsDataHandler.prototype.updateSLAPauseStatesXML = function () {
                    var xml = "<entitiesstates>";
                    for (var index = 0; index < this._slaEnabledEntitiesInCurrentApp.length; index++) {
                        var entityName = this._slaEnabledEntitiesInCurrentApp[index].LogicalName;
                        if (!this._context.utils.isNullOrUndefined(this._entitiesMappingDetails[entityName])) {
                            var mappedAttributes = this._entitiesMappingDetails[entityName].mappedAttributes;
                            if (mappedAttributes != null && mappedAttributes != undefined && mappedAttributes != "") {
                                mappedAttributes = mappedAttributes.replace(/,/g, ";");
                                xml = xml + "<entity value=\"" + entityName + "\">" + mappedAttributes + "</entity>";
                            }
                            else {
                                xml = xml + "<entity value=\"" + entityName + "\" />";
                            }
                        }
                    }
                    xml = xml + "</entitiesstates>";
                    this._currentSLAPauseState = xml;
                };
                /**
                * updates the Service Setting information
                */
                SvcSettingsDataHandler.prototype.updateServiceSettings = function () {
                    var _this = this;
                    this.updateSLAPauseStatesXML();
                    //Status Update for OrgSettings
                    if (this.isOrgsettingUpdated() || !(this._origSLAPauseState === this._currentSLAPauseState)) {
                        var statusUpdateEntity = {};
                        var orgindex;
                        for (orgindex = 0; orgindex < 4; orgindex++) {
                            statusUpdateEntity[SvcConfigSettings.BoolOrgSettings[orgindex]] = this._currentOrgSettingsSLA[orgindex];
                        }
                        statusUpdateEntity["slapausestates"] = this._currentSLAPauseState;
                        this._context.webAPI.updateRecord("organization", this._organizationId, statusUpdateEntity).then(function (success) {
                            _this._context.utils.addGlobalNotification(1 /* toast */, 1 /* success */, SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_SucessfullSave, null, null);
                            // after execution refresh the OrgSetting Values 
                            _this.refreshOrgSettingsValueAfterSaveAttempt(SvcConfigSettings.OrgSettingsSavedAttempt.SUCCESS);
                            //Adding Telemetry
                            _this.reportSvcConfigSettingsTelemetry();
                        }, function (error) {
                            var errorMessage;
                            if (!_this._context.utils.isNullOrUndefined(error.message)) {
                                errorMessage = error.message;
                            }
                            else {
                                errorMessage = SvcConfigSettings.SvcConfigSettingsLocale.SvcConfigSettings_Error_Message;
                            }
                            var alertMessage = {
                                text: errorMessage
                            };
                            _this._context.navigation.openAlertDialog(alertMessage);
                            // after execution refresh the OrgSetting Values 
                            _this.refreshOrgSettingsValueAfterSaveAttempt(SvcConfigSettings.OrgSettingsSavedAttempt.FAILURE);
                            //Adding Telemetry
                            _this.reportErrorTelemetry(_this._context, errorMessage, error);
                        });
                    }
                };
                /**
                *Is current org settings different from original org settings.
                */
                SvcSettingsDataHandler.prototype.isOrgsettingUpdated = function () {
                    var orgindex;
                    for (orgindex = 0; orgindex < 4; orgindex++) {
                        if (this._origOrgSettingsSLA[orgindex] != this._currentOrgSettingsSLA[orgindex]) {
                            return true;
                        }
                    }
                    return false;
                };
                /*
                * This method retrieve OrgSettings
                */
                SvcSettingsDataHandler.prototype.retrieveOrgSettingValues = function () {
                    var _this = this;
                    this._context.webAPI.retrieveMultipleRecords("organization", SvcConfigSettings.SvcSettingsHelper.getorgSettingsUpdateValueRequest()).then(function (data) {
                        try {
                            _this._organizationId = data.entities["0"].organizationid;
                            _this.setOrigandCurrOrgSettingsValue(data);
                            _this._initializeRequestsCounter = _this._initializeRequestsCounter + 1;
                            _this.checkRequestCounterForRerendering();
                        }
                        catch (statusUpdateValueexpcetion) {
                            var errorMessage = "Error Fetching StatusUpdate Value from Organization.";
                            _this.reportErrorTelemetry(_this._context, errorMessage, statusUpdateValueexpcetion);
                        }
                    }, function (error) {
                        var errMessage = "Retrieval of StatusUpdateValues call Failed.";
                    });
                };
                /*
                * Setting the Original and current OrgSettings values when data is retreived.
                */
                SvcSettingsDataHandler.prototype.setOrigandCurrOrgSettingsValue = function (data) {
                    this._origOrgSettingsSLA[0] = data.entities["0"].suppresssla;
                    this._origOrgSettingsSLA[1] = data.entities["0"].autoapplysla;
                    this._origOrgSettingsSLA[2] = data.entities["0"].autoapplydefaultoncasecreate;
                    this._origOrgSettingsSLA[3] = data.entities["0"].autoapplydefaultoncaseupdate;
                    this._currentOrgSettingsSLA[0] = data.entities["0"].suppresssla;
                    this._currentOrgSettingsSLA[1] = data.entities["0"].autoapplysla;
                    this._currentOrgSettingsSLA[2] = data.entities["0"].autoapplydefaultoncasecreate;
                    this._currentOrgSettingsSLA[3] = data.entities["0"].autoapplydefaultoncaseupdate;
                    this._currentSLAPauseState = data.entities["0"].slapausestates;
                    this._origSLAPauseState = data.entities["0"].slapausestates;
                    if (!this._context.utils.isNullOrUndefined(data.entities["0"].slapausestates)) {
                        this._xmlDocument = (new DOMParser()).parseFromString(data.entities["0"].slapausestates, "text/xml");
                        this.setMappedAttributesOfEntities();
                    }
                };
                /**
                * Setting the Original and Current Organization Values according to the Save Attempt
                **/
                SvcSettingsDataHandler.prototype.refreshOrgSettingsValueAfterSaveAttempt = function (attempt) {
                    if (attempt == SvcConfigSettings.OrgSettingsSavedAttempt.SUCCESS) {
                        this._origOrgSettingsSLA[0] = this._currentOrgSettingsSLA[0];
                        this._origOrgSettingsSLA[1] = this._currentOrgSettingsSLA[1];
                        this._origOrgSettingsSLA[2] = this._currentOrgSettingsSLA[2];
                        this._origOrgSettingsSLA[3] = this._currentOrgSettingsSLA[3];
                        this._origSLAPauseState = this._currentSLAPauseState;
                    }
                    else if (attempt == SvcConfigSettings.OrgSettingsSavedAttempt.FAILURE) {
                        this._currentOrgSettingsSLA[0] = this._origOrgSettingsSLA[0];
                        this._currentOrgSettingsSLA[1] = this._origOrgSettingsSLA[1];
                        this._currentOrgSettingsSLA[2] = this._origOrgSettingsSLA[2];
                        this._currentOrgSettingsSLA[3] = this._origOrgSettingsSLA[3];
                        this._currentSLAPauseState = this._origSLAPauseState;
                        this._context.utils.requestRender();
                    }
                };
                /**
                 * This function will parse the XML response of mapped entities and store in a variable
                 */
                SvcSettingsDataHandler.prototype.setMappedAttributesOfEntities = function () {
                    if (this._xmlDocument.documentElement.childNodes != null && this._xmlDocument.documentElement.childNodes.length > 0) {
                        for (var index = 0; index < this._xmlDocument.documentElement.childNodes.length; index++) {
                            if (this.validateChildNodes(index)) {
                                var entityName = this._xmlDocument.documentElement.childNodes[index].attributes.getNamedItem("value").nodeValue;
                                var result = this._xmlDocument.documentElement.childNodes[index].textContent;
                                result = result.replace(/;/g, ",");
                                this._entitiesMappingDetails[entityName] = { mappedAttributes: result };
                            }
                        }
                    }
                };
                /**
                 * This function validates the null check conditions for nodes.
                 * @param index
                 */
                SvcSettingsDataHandler.prototype.validateChildNodes = function (index) {
                    return this._xmlDocument.documentElement.childNodes[index] != null && this._xmlDocument.documentElement.childNodes[index].attributes != null && this._xmlDocument.documentElement.childNodes[index].attributes.getNamedItem("value") != null;
                };
                /**
                 * This method is used to fetch the SLA Enabled Entities with OData call. //TODO Change func name
                 */
                SvcSettingsDataHandler.prototype.retrieveSLAEnabledEntitiesInDefaultApp = function () {
                    var _this = this;
                    var fetchEntitiesUrl = this._context.utils.createCrmUri(SvcConfigSettings.SvcSettingsHelper.getEntitiesUrl());
                    this.sendRequest(fetchEntitiesUrl).then(function (data) {
                        var entities = data.value;
                        _this._slaEntitiesInDefaultApp = {};
                        for (var index = 0; index < entities.length; index++) {
                            var currentEntity = entities[index];
                            if (_this.validateEntity(currentEntity)) {
                                _this._slaEntitiesInDefaultApp[currentEntity.MetadataId] =
                                    {
                                        DisplayName: currentEntity.DisplayName.LocalizedLabels[0].Label,
                                        LogicalName: currentEntity.LogicalName
                                    };
                            }
                        }
                        _this.filterSLAEnabledEntitiesForApp();
                    }, function (error) {
                        var errMessage = "Retrieval of EntityDefinitios call Failed.";
                        _this.reportErrorTelemetry(_this._context, errMessage, error);
                    });
                };
                /**
                * The function will make odata call and get the app module components with the help of app unique id.
                **/
                SvcSettingsDataHandler.prototype.getEntitiesInCurrentApp = function () {
                    //fetching all entities from the current app
                    var that = this;
                    var requestUri = that._context.utils.createCrmUri(SvcConfigSettings.SvcSettingsHelper.getAppModulesURL(that._context.page.appId));
                    this.sendRequest(requestUri).then(function (appUniqueIdResp) {
                        if (that._context.utils.isNullOrUndefined(appUniqueIdResp) || that._context.utils.isNullOrUndefined(appUniqueIdResp.value) || appUniqueIdResp.value.length < 1) {
                            var errMessage = "AppModuleIdUnique record is not found in successful response.";
                            that.reportErrorTelemetry(that._context, errMessage, "");
                            return;
                        }
                        var appUniqueIdUnpublished = appUniqueIdResp.value[0].appmoduleidunique;
                        var appModuleComponentsUrl = that._context.utils.createCrmUri(SvcConfigSettings.SvcSettingsHelper.getAppModuleComponents(appUniqueIdUnpublished));
                        that.sendRequest(appModuleComponentsUrl).then(function (respAppModuleRecords) {
                            if (!that._context.utils.isNullOrUndefined(respAppModuleRecords)) {
                                that._entityIDsInCurrentApp = respAppModuleRecords.value.map(function (appModule) { return appModule.objectid; });
                                that.filterSLAEnabledEntitiesForApp();
                            }
                            else {
                                var errMessage = "getAppModuleComponents() has an unsuccessful response.";
                                that.reportErrorTelemetry(that._context, errMessage, "");
                                return;
                            }
                        }, function (error) {
                            var errMessage = "Retrieval of getAppModuleComponents call Failed.";
                            that.reportErrorTelemetry(that._context, errMessage, error);
                        });
                    }, function (error) {
                        var errMessage = "Retrieval of getEntitiesInCurrentApp() Failed.";
                        that.reportErrorTelemetry(that._context, errMessage, error);
                    });
                };
                /**
                 * This function helps in setting the SLA Entities
                 */
                SvcSettingsDataHandler.prototype.filterSLAEnabledEntitiesForApp = function () {
                    if (this._entityIDsInCurrentApp != null && this._slaEntitiesInDefaultApp != null) {
                        for (var i = 0; i < this._entityIDsInCurrentApp.length; i++) {
                            var objectId = this._entityIDsInCurrentApp[i];
                            var entity = this._slaEntitiesInDefaultApp[objectId];
                            if (!this._context.utils.isNullOrUndefined(entity)) {
                                this._slaEnabledEntitiesInCurrentApp.push({ DisplayName: entity.DisplayName, LogicalName: entity.LogicalName });
                            }
                        }
                        this._initializeRequestsCounter++;
                        this.checkRequestCounterForRerendering();
                    }
                };
                /**
                * Reporting Telemtry Data when SvcConfigSettings is updated
                */
                SvcSettingsDataHandler.prototype.reportSvcConfigSettingsTelemetry = function () {
                    try {
                        var svcConfigSettingsTelemetry = {};
                        var orgindex;
                        for (orgindex = 0; orgindex < this._currentOrgSettingsSLA.length; orgindex++) {
                            svcConfigSettingsTelemetry[SvcConfigSettings.BoolOrgSettings[orgindex]] = this._currentOrgSettingsSLA[orgindex].valueOf();
                        }
                        AppsTelemetryLib.AppsTelemetryUtility.reportData(AppsTelemetryLib.EventList.SettingsEvent, AppsTelemetryLib.ModuleList.service, AppsTelemetryLib.EntityList.organization, AppsTelemetryLib.Action.update, this._context, svcConfigSettingsTelemetry);
                    }
                    catch (telemetryException) { }
                };
                /**
                * Logs error telemetry
                * @param context The "Input Bag" containing the parameters and other control metadata.
                * @param errorMessage error message to be reported
                * @param errorTrace stack trace information about error
                */
                SvcSettingsDataHandler.prototype.reportErrorTelemetry = function (context, errorMessage, errorTrace) {
                    AppsTelemetryLib.AppsTelemetryUtility.reportError(AppsTelemetryLib.EventList.IncidentEvent, AppsTelemetryLib.ModuleList.service, AppsTelemetryLib.EntityList.incident, AppsTelemetryLib.Action.update, context, errorMessage, errorTrace);
                };
                /**
                * This method validates the entity that was being passed to it
                * @param entity The "Input Bag" containing the parameters and other control metadata.
                *.@returns the boolean value
                */
                SvcSettingsDataHandler.prototype.validateEntity = function (entity) {
                    if (entity != null && entity.DisplayName != null && entity.DisplayName.LocalizedLabels != null && entity.DisplayName.LocalizedLabels.length > 0) {
                        return true;
                    }
                    else {
                        return false;
                    }
                };
                /**
                * checks for the request counter and if initialize Requests Counter matches with expected Response Counter then it will rerender the page
                */
                SvcSettingsDataHandler.prototype.checkRequestCounterForRerendering = function () {
                    if (this._initializeRequestsCounter >= this._expectedTotalResponseCount) {
                        this._context.utils.requestRender();
                    }
                };
                /**
                * This method is used to send request with the specified url
                * @param url The url paramemer.
                */
                SvcSettingsDataHandler.prototype.sendRequest = function (url) {
                    return $.ajax({
                        url: encodeURI(url),
                        type: 'GET',
                        async: true,
                        contentType: "application/json",
                        dataType: "json",
                    });
                };
                return SvcSettingsDataHandler;
            }());
            SvcConfigSettings.SvcSettingsDataHandler = SvcSettingsDataHandler;
        })(SvcConfigSettings = AppCommon.SvcConfigSettings || (AppCommon.SvcConfigSettings = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SvcConfigSettings;
        (function (SvcConfigSettings) {
            'use strict';
            var SvcConfigSettingsConstants;
            (function (SvcConfigSettingsConstants) {
                SvcConfigSettingsConstants.SvcConfigSETTINGS_APPLYSLA_LABEL = "SvcConfigSETTINGS_APPLYSLA_LABEL";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_DisableSLA_LABEL = "SvcConfigSETTINGS_DisableSLA_LABEL";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_DUALLIST_CONTAINER = "SvcConfigSETTINGS_DUALLIST_CONTAINER";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_AutomaticallyApplySLA = "SvcConfigSETTINGS_AutomaticallyApplySLA";
                SvcConfigSettingsConstants.SvcConfigSettings_Supress_SLA = "SvcConfigSettings_Supress_SLA";
                SvcConfigSettingsConstants.SvcConfigSettings_SLAStatusLabel = "SvcConfigSettings_SLAStatusLabel";
                SvcConfigSettingsConstants.SvcConfigSettings_SLAEnabledEntitySelectionApplyLabel = "SvcConfigSettings_SLAEnabledEntitySelectionApplyLabel";
                SvcConfigSettingsConstants.SvcConfigSettings_SLAEnabledEntityCalculationLabel = "SvcConfigSettings_SLAEnabledEntityCalculationLabel";
                SvcConfigSettingsConstants.SvcConfigSettings_AutomaticallyApplyEntitlementLabel = "SvcConfigSettings_AutomaticallyApplyEntitlementLabel";
                SvcConfigSettingsConstants.SvcConfigSettings_AutomaticallyApplyDefaultOnCaseCreationLabel = "SvcConfigSettings_AutomaticallyApplyEntitlementOnCaseCreationLabel";
                SvcConfigSettingsConstants.SvcConfigSettings_AutomaticallyApplyDefaultOnCaseUpdationLabel = "SvcConfigSettings_AutomaticallyApplyEntitlementOnCaseUpdationLabel";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_MAIN_CONTAINER = "SvcConfigSETTINGS_MAIN_CONTAINER";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_DDL_CONTROL_PROPS = "SvcConfigSETTINGS_DDL_CONTROL_PROPS";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_DDL_LBL = "SvcConfigSETTINGS_DDL_LBL";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_DDL_CONTAINER = "SvcConfigSETTINGS_DDL_CONTAINER";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_SAVEICONCONTAINERKEY = "SvcConfigSETTINGS_SAVEICONCONTAINERKEY";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_SAVE_BUTTON = "SvcConfigSETTINGS_SAVE_BUTTON";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_HEADERSEPARATORCONTAINERKEY = "SvcConfigSETTINGS_HEADERSEPARATORCONTAINERKEY";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_HEADERRIGHTCONTAINERKEY = "SvcConfigSETTINGS_HEADERRIGHTCONTAINERKEY";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_BLANK_CONTAINER = "SvcConfigSETTINGSBlankContainer";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_DisableSLA_CONTAINER = "SvcConfigSETTINGS_DisableSLA_CONTAINER";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_ApplySLA_CONTAINER = "SvcConfigSETTINGS_ApplySLA_CONTAINER";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_SLAStatus_CONTAINER = "SvcConfigSETTINGS_SLAStatus_CONTAINER";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_ApplyEntitlement_CONTAINER = "SvcConfigSETTINGS_ApplyEntitlement_CONTAINER";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_SlaCalculationLabelContainer_CONTAINER = "SvcConfigSETTINGS_SlaCalculationLabelContainer_CONTAINER";
                SvcConfigSettingsConstants.SvcConfigSETTINGS_ZeroValue = "0";
                SvcConfigSettingsConstants.SVC_CONFIGSETTINGS_HEADER_ICON_IMAGE = "../../WebResources/AppCommon/ControlWS/HeaderIconImages/ServiceConfig.svg";
                SvcConfigSettingsConstants.SVC_CONFIGSETTINGS_HEADER_ICON_HIGHCONTRAST_IMAGE = "../../WebResources/AppCommon/ControlWS/HeaderIconImages/ServiceConfig_HC.svg";
            })(SvcConfigSettingsConstants = SvcConfigSettings.SvcConfigSettingsConstants || (SvcConfigSettings.SvcConfigSettingsConstants = {}));
        })(SvcConfigSettings = AppCommon.SvcConfigSettings || (AppCommon.SvcConfigSettings = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SvcConfigSettings;
        (function (SvcConfigSettings) {
            'use strict';
            var BoolOrgSettings;
            (function (BoolOrgSettings) {
                BoolOrgSettings[BoolOrgSettings["suppresssla"] = 0] = "suppresssla";
                BoolOrgSettings[BoolOrgSettings["autoapplysla"] = 1] = "autoapplysla";
                BoolOrgSettings[BoolOrgSettings["autoapplydefaultoncasecreate"] = 2] = "autoapplydefaultoncasecreate";
                BoolOrgSettings[BoolOrgSettings["autoapplydefaultoncaseupdate"] = 3] = "autoapplydefaultoncaseupdate";
            })(BoolOrgSettings = SvcConfigSettings.BoolOrgSettings || (SvcConfigSettings.BoolOrgSettings = {}));
            var OrgSettingsSavedAttempt;
            (function (OrgSettingsSavedAttempt) {
                OrgSettingsSavedAttempt[OrgSettingsSavedAttempt["SUCCESS"] = 0] = "SUCCESS";
                OrgSettingsSavedAttempt[OrgSettingsSavedAttempt["FAILURE"] = 1] = "FAILURE";
            })(OrgSettingsSavedAttempt = SvcConfigSettings.OrgSettingsSavedAttempt || (SvcConfigSettings.OrgSettingsSavedAttempt = {}));
            var BoolOrgValues;
            (function (BoolOrgValues) {
                BoolOrgValues[BoolOrgValues["YES"] = 0] = "YES";
                BoolOrgValues[BoolOrgValues["NO"] = 1] = "NO";
            })(BoolOrgValues = SvcConfigSettings.BoolOrgValues || (SvcConfigSettings.BoolOrgValues = {}));
        })(SvcConfigSettings = AppCommon.SvcConfigSettings || (AppCommon.SvcConfigSettings = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SvcConfigSettings;
        (function (SvcConfigSettings) {
            'use strict';
            var SvcSettingsHelper = (function () {
                function SvcSettingsHelper() {
                }
                /**
                 * This method returns the entities URL
                 */
                SvcSettingsHelper.getEntitiesUrl = function () {
                    return "/api/data/v9.0/EntityDefinitions?$select=MetadataId,DisplayName,LogicalName&$filter=IsSLAEnabled eq true";
                };
                /**
                 * This method returns the Appmodules URL
                 */
                SvcSettingsHelper.getAppModulesURL = function (appId) {
                    return "/api/data/v9.0/appmodules/Microsoft.Dynamics.CRM.RetrieveUnpublishedMultiple?$select=appmoduleidunique&$filter=appmoduleid eq " + appId;
                };
                SvcSettingsHelper.getAppModuleComponents = function (appUniqueId) {
                    return "/api/data/v9.0/appmodulecomponents?$select=objectid&$filter=componenttype eq 1 and _appmoduleidunique_value eq " + appUniqueId;
                };
                SvcSettingsHelper.getAttributesOfEntityURL = function (entityName) {
                    return "/api/data/v9.0/EntityDefinitions(LogicalName='" + entityName + "')/Attributes/Microsoft.Dynamics.CRM.StatusAttributeMetadata?$select=LogicalName&$expand=OptionSet";
                };
                SvcSettingsHelper.getDefaultEntityLogicalName = function () {
                    return "incident";
                };
                SvcSettingsHelper.getorgSettingsUpdateValueRequest = function () {
                    return "?$select=suppresssla,autoapplysla,autoapplydefaultoncasecreate,autoapplydefaultoncaseupdate,slapausestates";
                };
                return SvcSettingsHelper;
            }());
            SvcConfigSettings.SvcSettingsHelper = SvcSettingsHelper;
        })(SvcConfigSettings = AppCommon.SvcConfigSettings || (AppCommon.SvcConfigSettings = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=SvcConfigSettingsControl.js.map