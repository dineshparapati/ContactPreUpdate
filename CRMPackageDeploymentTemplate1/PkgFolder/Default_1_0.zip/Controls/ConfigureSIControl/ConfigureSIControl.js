/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var SocialInsightsControl;
    (function (SocialInsightsControl) {
        "use strict";
        var MSEUtils = (function () {
            function MSEUtils() {
            }
            MSEUtils.prototype.init = function (successCallback, failureCallback, context) {
                var _this = this;
                this.context = context;
                this.isMobile = this.context.client.getClient() == 'Mobile';
                //check for default errors
                if (this.context.mode.isOffline) {
                    failureCallback(this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.SolutionNotOnlineLabel));
                    return;
                }
                //get the mse solution config
                Xrm.WebApi.online.retrieveMultipleRecords("organization", '?$select=socialinsightsinstance,socialinsightsenabled').then(function (response) {
                    var config = _this.parseMSEConfig(response.entities[0]);
                    var enabled = response.entities[0].socialinsightsenabled;
                    if (enabled && config != null && (config.Netbreeze_UserUrl != null || config.SignalUrl != null)) {
                        if (config.Netbreeze_UserUrl != null) {
                            _this.mseUrl = config.Netbreeze_UserUrl;
                        }
                        else if (config.SignalUrl != null) {
                            _this.mseUrl = _this.computeMSEUrlFromSignalUrl(config.SignalUrl, config.SolutionId);
                        }
                        _this.mseApiUrl = config.ApiUrl;
                        successCallback();
                    }
                    else {
                        failureCallback();
                    }
                }, function (response, status) {
                    var errorMessage = _this.context.resources.getString(status === 503
                        ? SocialInsightsControl.SocialInsightsConstants.RestError503Label
                        : SocialInsightsControl.SocialInsightsConstants.GeneralErrorLabel);
                    failureCallback(errorMessage);
                });
            };
            MSEUtils.prototype.setContext = function (context) {
                this.context = context;
            };
            MSEUtils.prototype.computeMSEUrlFromSignalUrl = function (signalUrl, solutionId) {
                var mseUrl = signalUrl;
                if (mseUrl.indexOf('/app/') === -1) {
                    if (mseUrl.charAt(mseUrl.length - 1) !== '/') {
                        mseUrl += '/';
                    }
                    mseUrl = mseUrl + 'app/' + solutionId;
                }
                return mseUrl;
            };
            MSEUtils.prototype.handleErrorsForIFrame = function (iframe) {
                var _this = this;
                var iFrameDoc = iframe.contentDocument || iframe.contentWindow.document;
                var isIntegrationSiteLoaded = false;
                if (iFrameDoc.readyState !== "interactive" && iFrameDoc.readyState !== "complete") {
                    //add readystate handler
                    iFrameDoc.onreadystatechange = function () {
                        if (iFrameDoc.readyState === "interactive" || iFrameDoc.readyState === "complete") {
                            isIntegrationSiteLoaded = true;
                            _this.cleanErrors();
                        }
                        else {
                            _this.showErrorMessage(_this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.CannotConnectToMseLabel));
                        }
                    };
                    //add handler for browser which not have readystate
                    iframe.onload = function () {
                        isIntegrationSiteLoaded = true;
                        _this.cleanErrors();
                    };
                    //show error if onload and readystate is not completed after 5 seconds
                    setTimeout(function () {
                        if (!isIntegrationSiteLoaded) {
                            _this.showErrorMessage(_this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.CannotConnectToMseLabel));
                        }
                    }, 5000);
                }
            };
            MSEUtils.prototype.createFPIEndpointUrl = function (componentId, mseUrl, apiUrl) {
                var env = this.getEnvironmentType();
                var integrationSiteAuthenticationParam = this.isMobile ? 'moca' : 'web';
                var integrationSiteURL = "https://" + this.getIntegrationSiteDomain(env) + "/MSE/8.2/Runtime.html";
                var apiParm = apiUrl != null ? '&api=' + encodeURIComponent(apiUrl) : '';
                var integrationFrameUrl = integrationSiteURL + "?env=" + env + "&" + integrationSiteAuthenticationParam + "=true&componentId=" + componentId + "&mseUrl=" + encodeURIComponent(mseUrl) + apiParm;
                return integrationFrameUrl;
            };
            //returns a config object
            MSEUtils.prototype.parseMSEConfig = function (organization) {
                var mseConfigString = organization.socialinsightsinstance;
                if (mseConfigString == null) {
                    return null;
                }
                var mseConfigs = JSON.parse(mseConfigString)["<Parameters>k__BackingField"];
                var mseConfig = {};
                for (var i = 0; i < mseConfigs.length; i++) {
                    mseConfig[mseConfigs[i].Key] = mseConfigs[i].Value;
                }
                return mseConfig;
            };
            MSEUtils.prototype.getMSEUrl = function () {
                return this.mseUrl;
            };
            MSEUtils.prototype.getMSEApiUrl = function () {
                return this.mseApiUrl;
            };
            MSEUtils.prototype.cleanErrors = function () {
                $(this.errorContainer).text('');
                this.errorContainer.style.display = 'none';
            };
            MSEUtils.prototype.showErrorMessage = function (message) {
                this.errorContainer.style.display = 'block';
                this.errorContainer.style.padding = '10px';
                $(this.errorContainer).empty();
                $(this.errorContainer).text(message);
            };
            MSEUtils.prototype.showNotConnectedErrorMessage = function () {
                this.errorContainer.style.display = 'block';
                this.errorContainer.style.padding = '10px';
                $(this.errorContainer).empty();
                var $label = $('<h4>')
                    .text(this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.NoMSEHeader))
                    .addClass("SocialInsightsControl-Error-Header")
                    .css("font-family", SocialInsightsControl.UCITheming.getSemibold(this.context));
                var $paragraph = $('<p>')
                    .text(this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.NoMSEParagraph))
                    .addClass("SocialInsightsControl-Error-Paragraph")
                    .css("font-family", SocialInsightsControl.UCITheming.getRegular(this.context));
                var $list = $('<ul>')
                    .addClass("SocialInsightsControl-Error-List");
                $list.append($('<li>')
                    .append($('<span>')
                    .css("font-family", SocialInsightsControl.UCITheming.getRegular(this.context))
                    .text(this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.NoMSEBullet1Text)))
                    .append($('<a>')
                    .attr("href", "https://go.microsoft.com/fwlink/?linkid=2030987")
                    .attr("target", "_blank")
                    .append($('<span>')
                    .css("font-family", SocialInsightsControl.UCITheming.getRegular(this.context))
                    .addClass("SocialInsightsControl-Error-Link")
                    .text(this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.NoMSEBullet1LinkText)))));
                $list.append($('<li>')
                    .append($('<span>')
                    .css("font-family", SocialInsightsControl.UCITheming.getRegular(this.context))
                    .text(this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.NoMSEBullet2Text)))
                    .append($('<a>')
                    .attr("href", "https://go.microsoft.com/fwlink/?linkid=2030988")
                    .attr("target", "_blank")
                    .append($('<span>')
                    .css("font-family", SocialInsightsControl.UCITheming.getRegular(this.context))
                    .addClass("SocialInsightsControl-Error-Link")
                    .text(this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.NoMSEBullet2LinkText)))));
                $(this.errorContainer).append($label);
                $(this.errorContainer).append($paragraph);
                $(this.errorContainer).append($list);
            };
            MSEUtils.prototype.createErrorContainer = function () {
                this.errorContainer = document.createElement('div');
                this.errorContainer.className = 'SocialInsightsControl-Error';
                return this.errorContainer;
            };
            MSEUtils.prototype.initFPIWidgets = function (componentId, iframe, widgetsUrl) {
                var iframeSrc = this.createFPIEndpointUrl(componentId, widgetsUrl);
                this.initAuthenticationAndLoadFPI(componentId, iframe, iframeSrc);
            };
            MSEUtils.prototype.initFPIData = function (componentId, iframe, apiUrl) {
                var iframeSrc = this.createFPIEndpointUrl(componentId, this.mseUrl + '/embedded_ajax.html', apiUrl);
                this.initAuthenticationAndLoadFPI(componentId, iframe, iframeSrc);
            };
            MSEUtils.prototype.initAuthenticationAndLoadFPI = function (componentId, iframe, iframeSrc) {
                var _this = this;
                if (this.isMobile) {
                    // Code for CRM for phones and tablets only goes here.
                    // (window.parent.Xrm as any).Utility.beginSecureSessionForResource(
                    this.context.utils.beginSecureSessionForResource("https://listening.microsoft.com/", componentId, this.getIntegrationSiteDomain(this.getEnvironmentType())).then(function () {
                        iframe.src = iframeSrc;
                        _this.handleErrorsForIFrame(iframe);
                    }, function (err) {
                        //6 is BeginSecureSessionResponseCode.FeatureDisabled
                        if (err === 6) {
                            _this.showErrorMessage(_this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.MocaShimOutdatedLabel));
                        }
                    });
                }
                else {
                    // Code for web browser or CRM for Outlook only goes here.
                    iframe.src = iframeSrc;
                }
            };
            MSEUtils.prototype.getDomain = function () {
                var a = document.createElement("a");
                a.href = window.location.href;
                var integrationDomain = a.host;
                $(a).remove();
                return integrationDomain;
            };
            MSEUtils.prototype.getIntegrationSiteDomain = function (env) {
                return MSEUtils.AuthResourceByEnv[env];
            };
            MSEUtils.prototype.getEnvironmentType = function () {
                var domain = this.getDomain();
                var env = "ppe";
                if (this.stringEndsWith(domain, "extest.microsoft.com"))
                    env = "ppe";
                else if (this.stringEndsWith(domain, "crmlivetie.com"))
                    env = "ppe";
                else if (this.stringEndsWith(domain, "crmlivetoday.com"))
                    env = "ppe";
                else if (this.stringEndsWith(domain, "1boxtest.com"))
                    env = "ppe";
                else if (this.stringEndsWith(domain, "dynamics-int.com"))
                    env = "int";
                else if (this.stringEndsWith(domain, "crm9.dynamics.com"))
                    env = "gcc";
                else if (this.stringEndsWith(domain, "dynamics.com"))
                    env = "prod";
                return env;
            };
            MSEUtils.prototype.stringEndsWith = function (base, search) {
                return base.length >= search.length
                    && base.substr(base.length - search.length, search.length) === search;
            };
            return MSEUtils;
        }());
        MSEUtils.AuthResourceByEnv = {
            "dev": "www.crmdynint-livetie.com",
            "ppe": "www.crmdynint-livetie.com",
            "int": "www.crmdynint-int.com",
            "prod": "www.crmdynint.com"
        };
        SocialInsightsControl.MSEUtils = MSEUtils;
    })(SocialInsightsControl = MscrmControls.SocialInsightsControl || (MscrmControls.SocialInsightsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var SocialInsightsControl;
    (function (SocialInsightsControl) {
        "use strict";
        var RestResourceManager = (function () {
            function RestResourceManager(url, mseUtils, uniqueName) {
                this.isMessageEventInitialized = false;
                this.onMessageReceive = this.onMessageReceive.bind(this);
                this.url = url;
                this.componentId = 'SocialInsightsRest-' + uniqueName;
                this.mseUtils = mseUtils;
            }
            RestResourceManager.prototype.initMessageHandler = function () {
                if (!this.isMessageEventInitialized) {
                    window.addEventListener('message', this.onMessageReceive);
                    this.isMessageEventInitialized = true;
                }
            };
            RestResourceManager.prototype.onMessageReceive = function (event) {
                var data = event.data;
                if (data.ajax === this.url) {
                    if (data.error != null) {
                        this.errorCallback(data);
                    }
                    else if (data.name === 'MSE:rest') {
                        this.successCallback(data);
                    }
                    this.cleanup();
                }
            };
            RestResourceManager.prototype.cleanup = function () {
                window.removeEventListener('message', this.onMessageReceive);
                var element = document.getElementById(this.componentId);
                if (element) {
                    document.body.removeChild(element);
                }
            };
            RestResourceManager.prototype.done = function (callback) {
                this.successCallback = callback;
                this.initMessageHandler();
                var iframe = this.createHiddenIframe();
                document.body.appendChild(iframe);
                this.mseUtils.initFPIData(this.componentId, iframe, this.url);
                return this;
            };
            RestResourceManager.prototype.fail = function (callback) {
                this.errorCallback = callback;
                return this;
            };
            RestResourceManager.prototype.createHiddenIframe = function () {
                var iframe = document.createElement('iframe');
                iframe.style.visibility = 'hidden';
                iframe.width = '1px';
                iframe.height = '1px';
                iframe.style.position = 'absolute';
                iframe.style.top = '-10px';
                iframe.style.left = '-10px';
                iframe.id = this.componentId;
                iframe.setAttribute('aria-hidden', 'true');
                return iframe;
            };
            return RestResourceManager;
        }());
        SocialInsightsControl.RestResourceManager = RestResourceManager;
    })(SocialInsightsControl = MscrmControls.SocialInsightsControl || (MscrmControls.SocialInsightsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var SocialInsightsControl;
    (function (SocialInsightsControl) {
        "use strict";
        var SocialInsightsConstants = (function () {
            function SocialInsightsConstants() {
            }
            return SocialInsightsConstants;
        }());
        SocialInsightsConstants.SolutionNotOnlineLabel = "SocialInsightsControl.SolutionNotOnline";
        SocialInsightsConstants.MocaShimOutdatedLabel = "SocialInsightsControl.MocaShimOutdated";
        SocialInsightsConstants.NotConfiguredInCrmLabel = "SocialInsightsControl.NotConfiguredInCrm";
        SocialInsightsConstants.CannotConnectToMseLabel = "SocialInsightsControl.CannotConnectToMse";
        SocialInsightsConstants.RestError503Label = "SocialInsightsControl.RestError503";
        SocialInsightsConstants.GeneralErrorLabel = "SocialInsightsControl.GeneralError";
        SocialInsightsConstants.ControlIsNotConfiguredLabel = "SocialInsightsControl.ControlIsNotConfigured";
        SocialInsightsConstants.ConfigureButtonLabel = "SocialInsightsControl.ConfigureButton";
        SocialInsightsConstants.RemoveDataLabel = "SocialInsightsControl.RemoveData";
        SocialInsightsConstants.PleaseConfigureSocialInsightsLabel = "SocialInsightsControl.PleaseConfigureSocialInsights";
        SocialInsightsConstants.CreateNewTopicLabel = "SocialInsightsControl.CreateNewTopic";
        SocialInsightsConstants.CreateNewTopicPart1Label = "SocialInsightsControl.CreateNewTopicPart1";
        SocialInsightsConstants.CreateNewTopicPart2Label = "SocialInsightsControl.CreateNewTopicPart2";
        SocialInsightsConstants.OrCreateNewTopicLabel = "SocialInsightsControl.OrCreateNewTopic";
        SocialInsightsConstants.NoMSEHeader = "SocialInsightsControl.NoMSEHeader";
        SocialInsightsConstants.NoMSEParagraph = "SocialInsightsControl.NoMSEParagraph";
        SocialInsightsConstants.NoMSEBullet1Text = "SocialInsightsControl.NoMSEBullet1Text";
        SocialInsightsConstants.NoMSEBullet2Text = "SocialInsightsControl.NoMSEBullet2Text";
        SocialInsightsConstants.NoMSEBullet1LinkText = "SocialInsightsControl.NoMSEBullet1LinkText";
        SocialInsightsConstants.NoMSEBullet2LinkText = "SocialInsightsControl.NoMSEBullet2LinkText";
        SocialInsightsConstants.TopicPickerTitleLabel = "TopicPickerControl.Title";
        SocialInsightsConstants.AllCategoriesLabel = "TopicPickerControl.AllCategories";
        SocialInsightsConstants.AddLabel = "WidgetPickerControl.Add";
        SocialInsightsConstants.ChooseWidgetLabel = "WidgetPickerControl.ChooseWidget";
        SocialInsightsConstants.RemoveWidgetLabel = "WidgetPickerControl.RemoveWidget";
        SocialInsightsConstants.MoveWidgetDownLabel = "WidgetPickerControl.MoveWidgetDown";
        SocialInsightsConstants.MoveWidgetUpLabel = "WidgetPickerControl.MoveWidgetUp";
        SocialInsightsConstants.NoWidgetsAddedLabel = "WidgetPickerControl.NoWidgetsAdded";
        SocialInsightsConstants.NoWidgetsLeftLabel = "WidgetPickerControl.NoWidgetsLeft";
        SocialInsightsConstants.WidgetPickerTitleLabel = "WidgetPickerControl.Title";
        SocialInsightsConstants.WidgetsLabel = "WidgetPickerControl.Widgets";
        SocialInsightsConstants.SPACE = 32;
        SocialInsightsConstants.LEFT = 37;
        SocialInsightsConstants.UP = 38;
        SocialInsightsConstants.RIGHT = 39;
        SocialInsightsConstants.DOWN = 40;
        SocialInsightsControl.SocialInsightsConstants = SocialInsightsConstants;
    })(SocialInsightsControl = MscrmControls.SocialInsightsControl || (MscrmControls.SocialInsightsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var SocialInsightsControl;
    (function (SocialInsightsControl) {
        "use strict";
        var UCITheming = (function () {
            function UCITheming() {
            }
            UCITheming.getRegular = function (context) {
                if (context && context.theming && context.theming.fontfamilies && context.theming.fontfamilies.regular) {
                    return context.theming.fontfamilies.regular;
                }
                return "'Segoe UI Regular', 'SegoeUI', 'Segoe UI'";
            };
            UCITheming.getSemibold = function (context) {
                if (context && context.theming && context.theming.fontfamilies && context.theming.fontfamilies.semibold) {
                    return context.theming.fontfamilies.semibold;
                }
                return "'SegoeUI-Semibold', 'Segoe UI Semibold', 'Segoe UI Regular', 'Segoe UI'";
            };
            UCITheming.getColorGray01 = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.grays && context.theming.colors.grays.gray01) {
                    context.theming.colors.statuscolor.gray01;
                }
                return '#efefef';
            };
            UCITheming.getColorGray02 = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.grays && context.theming.colors.grays.gray02) {
                    context.theming.colors.statuscolor.gray02;
                }
                return '#e2e2e2';
            };
            UCITheming.getColorGray03 = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.grays && context.theming.colors.grays.gray03) {
                    context.theming.colors.statuscolor.gray03;
                }
                return '#d8d8d8';
            };
            UCITheming.getColorGray04 = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.grays && context.theming.colors.grays.gray04) {
                    context.theming.colors.statuscolor.gray04;
                }
                return '#b3b3b3';
            };
            UCITheming.getColorGray05 = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.grays && context.theming.colors.grays.gray05) {
                    context.theming.colors.statuscolor.gray05;
                }
                return '#666666';
            };
            UCITheming.getColorGray06 = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.grays && context.theming.colors.grays.gray06) {
                    context.theming.colors.statuscolor.gray06;
                }
                return '#444444';
            };
            UCITheming.getColorGray07 = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.grays && context.theming.colors.grays.gray07) {
                    context.theming.colors.statuscolor.gray07;
                }
                return '#333333';
            };
            UCITheming.getColorAlert1Text = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.statuscolor && context.theming.colors.statuscolor.alert1 && context.theming.colors.statuscolor.alert1.text) {
                    context.theming.colors.statuscolor.alert1.text;
                }
                return 'white';
            };
            UCITheming.getColorAlert1Fill = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.statuscolor && context.theming.colors.statuscolor.alert1 && context.theming.colors.statuscolor.alert1.fill) {
                    context.theming.colors.statuscolor.alert1.fill;
                }
                return 'red';
            };
            UCITheming.getActioniconbutton01 = function (context) {
                if (context && context.theming && context.theming.buttons.actioniconbutton01) {
                    return context.theming.buttons.actioniconbutton01;
                }
                return { "height": "2.50rem", "width": "2.50rem", "borderStyle": "none", "backgroundColor": "transparent", "justifyContent": "center", "alignItems": "center", "cursor": "pointer" };
            };
            return UCITheming;
        }());
        SocialInsightsControl.UCITheming = UCITheming;
    })(SocialInsightsControl = MscrmControls.SocialInsightsControl || (MscrmControls.SocialInsightsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var ConfigureSIControl;
    (function (ConfigureSIControl) {
        "use strict";
        var MSEUtils = MscrmControls.SocialInsightsControl.MSEUtils;
        var RestResourceManager = MscrmControls.SocialInsightsControl.RestResourceManager;
        var SocialInsightsConstants = MscrmControls.SocialInsightsControl.SocialInsightsConstants;
        var UCITheming = MscrmControls.SocialInsightsControl.UCITheming;
        var TopicPickerControl = (function () {
            function TopicPickerControl(loaded) {
                this.mseUtils = new MSEUtils();
                this.categories = [];
                this.searchTopics = [];
                this.categoriesRetrieved = false;
                this.searchTopicsRetrieved = false;
                this.loaded = loaded;
            }
            TopicPickerControl.prototype.init = function (context, notifyOutputChanged, state, container) {
                var _this = this;
                this.context = context;
                this.notifyOutputChanged = notifyOutputChanged;
                this.container = container;
                this.mseUtils.init(function () {
                    // Get categories
                    new RestResourceManager(_this.mseUtils.getMSEApiUrl() + '/categories', _this.mseUtils, 'TopicPickerCategories').done(function (data) {
                        _this.categories = data.result;
                        _this.categoriesRetrieved = true;
                        if (_this.categoriesRetrieved && _this.searchTopicsRetrieved) {
                            _this.initControl();
                        }
                    }).fail(function (error) {
                        var errorMessage = _this.context.resources.getString(error.status === 503
                            ? SocialInsightsConstants.RestError503Label
                            : SocialInsightsConstants.GeneralErrorLabel);
                        _this.mseUtils.showErrorMessage(errorMessage);
                    });
                    // Get search items
                    new RestResourceManager(_this.mseUtils.getMSEApiUrl() + '/searchitems', _this.mseUtils, 'TopicPickerSearchItems').done(function (data) {
                        _this.searchTopics = data.result;
                        _this.searchTopicsRetrieved = true;
                        if (_this.categoriesRetrieved && _this.searchTopicsRetrieved) {
                            _this.initControl();
                        }
                    }).fail(function (error) {
                        var errorMessage = _this.context.resources.getString(error.status === 503
                            ? SocialInsightsConstants.RestError503Label
                            : SocialInsightsConstants.GeneralErrorLabel);
                        _this.mseUtils.showErrorMessage(errorMessage);
                    });
                }, function (errorMessage) {
                    _this.mseUtils.showErrorMessage(errorMessage);
                }, this.context);
            };
            TopicPickerControl.prototype.initControl = function () {
                var _this = this;
                $(this.container).append($('<label>').text(this.context.resources.getString(SocialInsightsConstants.TopicPickerTitleLabel)).attr('for', TopicPickerControl.TopicPickerSelectId).addClass("TopicPickerControl-Title"));
                var $topicPickerActions = $('<div>').addClass("TopicPickerControl-Actions");
                var $topicSelector = this.createTopicSelector();
                $topicSelector.on('change', function () {
                    _this.topicId = $topicSelector.val();
                    _this.notifyOutputChanged();
                });
                this.loaded();
                $topicPickerActions.append($topicSelector);
                $topicPickerActions.append($('<a>')
                    .attr("href", this.mseUtils.getMSEUrl() + "/#search")
                    .attr("target", "_blank")
                    .addClass("symbolFont New-symbol")
                    .addClass("TopicPickerControl-Actions-CreateNew")
                    .append($('<span>')
                    .css("font-family", UCITheming.getRegular(this.context))
                    .text(this.context.resources.getString(SocialInsightsConstants.CreateNewTopicLabel))));
                $(this.container).append($topicPickerActions);
            };
            TopicPickerControl.prototype.prepareCategoriesAndTopics = function () {
                var categoriesAndTopics = [{
                        id: "4",
                        name: this.context.resources.getString(SocialInsightsConstants.AllCategoriesLabel)
                    }];
                for (var _i = 0, _a = this.categories; _i < _a.length; _i++) {
                    var category = _a[_i];
                    categoriesAndTopics.push(category);
                    for (var _b = 0, _c = this.searchTopics; _b < _c.length; _b++) {
                        var searchTopic = _c[_b];
                        if (searchTopic.parentId == category.id) {
                            categoriesAndTopics.push(searchTopic);
                        }
                    }
                }
                return categoriesAndTopics;
            };
            TopicPickerControl.prototype.createTopicSelector = function () {
                var categoriesAndTopics = this.prepareCategoriesAndTopics();
                var $topicSelector = $('<select>')
                    .attr('id', TopicPickerControl.TopicPickerSelectId)
                    .addClass("TopicPickerControl-Actions-Select")
                    .css('color', UCITheming.getColorGray05(this.context));
                for (var _i = 0, categoriesAndTopics_1 = categoriesAndTopics; _i < categoriesAndTopics_1.length; _i++) {
                    var topicOrCategory = categoriesAndTopics_1[_i];
                    var isSelected = topicOrCategory.id == this.context.parameters.topicId.raw;
                    // do not indent categories, indent topics:
                    var indent = '';
                    if (this.isTopic(topicOrCategory)) {
                        indent += '&nbsp; ';
                    }
                    $topicSelector.append("<option value=\"" + topicOrCategory.id + "\" " + (isSelected ? 'selected' : '') + ">" + indent + topicOrCategory.name + "</option>");
                }
                return $topicSelector;
            };
            TopicPickerControl.prototype.isTopic = function (topicOrCategory) {
                return topicOrCategory.parentId && topicOrCategory.parentId != "4";
            };
            TopicPickerControl.prototype.updateView = function (context) {
            };
            TopicPickerControl.prototype.getOutputs = function () {
                return {
                    topicId: this.topicId
                };
            };
            TopicPickerControl.prototype.destroy = function () {
            };
            return TopicPickerControl;
        }());
        TopicPickerControl.TopicPickerSelectId = 'MSETopicPickerSelect';
        ConfigureSIControl.TopicPickerControl = TopicPickerControl;
    })(ConfigureSIControl = MscrmControls.ConfigureSIControl || (MscrmControls.ConfigureSIControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var ConfigureSIControl;
    (function (ConfigureSIControl) {
        "use strict";
        var MSEUtils = MscrmControls.SocialInsightsControl.MSEUtils;
        var RestResourceManager = MscrmControls.SocialInsightsControl.RestResourceManager;
        var SocialInsightsConstants = MscrmControls.SocialInsightsControl.SocialInsightsConstants;
        var UCITheming = MscrmControls.SocialInsightsControl.UCITheming;
        var WidgetPickerControl = (function () {
            function WidgetPickerControl(loaded) {
                this.mseUtils = new MSEUtils();
                this.loaded = loaded;
            }
            WidgetPickerControl.prototype.init = function (context, notifyOutputChanged, state, container) {
                var _this = this;
                this.context = context;
                this.notifyOutputChanged = notifyOutputChanged;
                this.mseUtils.init(function () {
                    // Get widgets
                    var widgetApiUrl = (_this.mseUtils.getMSEApiUrl() + '/widgets').replace('/api/', '/widgetapi/');
                    new RestResourceManager(widgetApiUrl, _this.mseUtils, WidgetPickerControl.ControlName).done(function (data) {
                        _this.widgetList = data.result;
                        _this.widgetList.forEach(function (widget) {
                            return widget.links.filter(function (link) { return link.rel == "graphics"; }).forEach(function (graphicsLink) { return widget.iconUrl = graphicsLink.ref; });
                        });
                        var selectedWidgets = _this.selected(context.parameters.widgetName.raw);
                        $(container).append($('<h2>')
                            .text(_this.context.resources.getString(SocialInsightsConstants.WidgetPickerTitleLabel))
                            .addClass("WidgetPickerControl-Section-Title")
                            .css('color', UCITheming.getColorGray07(_this.context)));
                        $(container).append(_this.createHeader(selectedWidgets));
                        _this.$widgetPickerContent = _this.createContent(selectedWidgets);
                        $(container).append(_this.$widgetPickerContent);
                        _this.showInfoWhenNoSelectedWidgets();
                        _this.showInfoWhenNoAvailableWidgets();
                        _this.loaded();
                    }).fail(function (error) {
                        var errorMessage = _this.context.resources.getString(error.status === 503
                            ? SocialInsightsConstants.RestError503Label
                            : SocialInsightsConstants.GeneralErrorLabel);
                        _this.mseUtils.showErrorMessage(errorMessage);
                    });
                }, function (errorMessage) {
                    _this.mseUtils.showErrorMessage(errorMessage);
                }, this.context);
            };
            WidgetPickerControl.prototype.findWidgetsWithLowerIndex = function (selectedWidget) {
                var found = false;
                var widgetsWithLowerIndex = [];
                this.widgetList.forEach(function (widget) {
                    if (selectedWidget.key === widget.key) {
                        found = true;
                    }
                    if (!found) {
                        widgetsWithLowerIndex.push(widget);
                    }
                });
                return widgetsWithLowerIndex;
            };
            WidgetPickerControl.prototype.upClicked = function () {
                var $prev = this.$selectedWidget.prev();
                if ($prev) {
                    this.$selectedWidget.insertBefore($prev);
                }
            };
            WidgetPickerControl.prototype.downClicked = function () {
                var $next = this.$selectedWidget.next();
                if ($next) {
                    this.$selectedWidget.insertAfter($next);
                }
            };
            WidgetPickerControl.prototype.removeClicked = function () {
                var _this = this;
                var removedWidget = this.widgetList.filter(function (widget) { return _this.$selectedWidget.attr("data-widget-id") === widget.key; })[0];
                this.$selectedWidget.remove();
                this.$selectedWidget = undefined;
                if (this.getSelectedWidgetIds().length > 0) {
                    this.$widgetPickerContent.children().first().attr("tabindex", "0");
                }
                this.setListButtonsEnabled(false);
                this.addWidgetBackToAvailable(removedWidget);
                this.showInfoWhenNoSelectedWidgets();
                this.showInfoWhenNoAvailableWidgets();
                this.notifyOutputChanged();
            };
            WidgetPickerControl.prototype.addClicked = function () {
                var _this = this;
                var widgets = this.widgetList.filter(function (widget) { return widget.key === _this.$widgetPickerSelect.val(); });
                if (widgets.length > 0) {
                    $(".WidgetPickerControl-Header-Actions-Select option[value='" + widgets[0].key + "']").each(function (index, $element) { return $element.remove(); });
                    this.$widgetPickerContent.append(this.createWidget(widgets[0], this.getSelectedWidgetIds().length === 0));
                    this.showInfoWhenNoAvailableWidgets();
                    this.showInfoWhenNoSelectedWidgets();
                    this.notifyOutputChanged();
                }
            };
            WidgetPickerControl.prototype.showInfoWhenNoSelectedWidgets = function () {
                var $selectedWidgets = this.$widgetPickerContent.children();
                if ($selectedWidgets.length === 0) {
                    this.$widgetPickerContent.append($('<div>').text(this.context.resources.getString(SocialInsightsConstants.NoWidgetsAddedLabel)).addClass("WidgetPickerControl-Content-Empty"));
                }
                else if ($selectedWidgets.length >= 1) {
                    // At least one widget is present, remove the empty if present
                    $('.WidgetPickerControl-Content-Empty').each(function (index, $element) { return $element.remove(); });
                }
            };
            WidgetPickerControl.prototype.showInfoWhenNoAvailableWidgets = function () {
                var $availableWidgets = this.$widgetPickerSelect.children();
                if ($availableWidgets.length === 0) {
                    this.$widgetPickerSelect.append($('<option>')
                        .text(this.context.resources.getString(SocialInsightsConstants.NoWidgetsLeftLabel)).val("")
                        .attr({ "disabled": true, "selected": true })
                        .addClass("WidgetPickerControl-Header-Actions-Select-Empty"));
                    this.$addButton.prop("disabled", true);
                    this.$widgetPickerSelect.prop("disabled", true);
                }
                else if ($availableWidgets.length >= 1) {
                    // At least one widget is present, remove the empty if present
                    this.$addButton.prop("disabled", false);
                    this.$widgetPickerSelect.prop("disabled", false);
                    $('.WidgetPickerControl-Header-Actions-Select-Empty').each(function (index, $element) { return $element.remove(); });
                }
            };
            WidgetPickerControl.prototype.addWidgetBackToAvailable = function (widget) {
                var $preceedingWidget;
                var widgetsWithLowerIndex = this.findWidgetsWithLowerIndex(widget);
                widgetsWithLowerIndex.forEach(function (widget) {
                    var foundWidgets = $(".WidgetPickerControl-Header-Actions-Select option[value='" + widget.key + "']");
                    if (foundWidgets.length > 0) {
                        $preceedingWidget = foundWidgets.first();
                    }
                });
                if ($preceedingWidget) {
                    $preceedingWidget.after(this.createOption(widget));
                }
                else {
                    this.$widgetPickerSelect.prepend(this.createOption(widget));
                }
            };
            WidgetPickerControl.prototype.setListButtonsEnabled = function (enabled) {
                this.$upButton.prop("aria-disabled", !enabled);
                this.$downButton.prop("aria-disabled", !enabled);
                this.$removeButton.prop("aria-disabled", !enabled);
                if (!enabled) {
                    this.$upButton.prop("tabindex", -1);
                    this.$downButton.prop("tabindex", -1);
                    this.$removeButton.prop("tabindex", -1);
                }
                else {
                    this.$upButton.removeAttr('tabindex');
                    this.$downButton.removeAttr('tabindex');
                    this.$removeButton.removeAttr('tabindex');
                }
            };
            WidgetPickerControl.prototype.createOption = function (widget) {
                return $('<option>').text(widget.title).val(widget.key);
            };
            WidgetPickerControl.prototype.createWidget = function (widget, first) {
                var $widgetPickerContentWidget = $('<div>')
                    .addClass("WidgetPickerControl-Content-Widget")
                    .attr("data-widget-id", widget.key)
                    .attr("role", "radio")
                    .attr("tabindex", first ? "0" : "-1")
                    .attr("aria-checked", "false");
                $widgetPickerContentWidget.append($('<img>')
                    .attr("src", widget.iconUrl)
                    .attr("alt", "")
                    .attr("role", "presentation")
                    .addClass("WidgetPickerControl-Content-Widget-Img"));
                var $widgetPickerContentWidgetText = $('<div>').addClass("WidgetPickerControl-Content-Widget-Text");
                $widgetPickerContentWidgetText.append($('<h3>')
                    .text(widget.title)
                    .addClass("WidgetPickerControl-Content-Widget-Text-Header")
                    .css('color', UCITheming.getColorGray07(this.context)));
                $widgetPickerContentWidgetText.append($('<div>')
                    .text(widget.description)
                    .addClass("WidgetPickerControl-Content-Widget-Text-Content")
                    .css('color', UCITheming.getColorGray05(this.context)));
                $widgetPickerContentWidget.append($widgetPickerContentWidgetText);
                return $widgetPickerContentWidget;
            };
            WidgetPickerControl.prototype.getSelectedWidgetIds = function () {
                var widgetIds = [];
                $('.WidgetPickerControl-Content-Widget').each(function (index, $widget) { return widgetIds.push($widget.getAttribute("data-widget-id")); });
                return widgetIds;
            };
            WidgetPickerControl.prototype.createHeader = function (selectedWidgets) {
                var _this = this;
                var $widgetPickerHeader = $('<div>').addClass("WidgetPickerControl-Header");
                $widgetPickerHeader.append($('<label>').text(this.context.resources.getString(SocialInsightsConstants.ChooseWidgetLabel)).attr('for', WidgetPickerControl.WidgetPickerSelectId).addClass("WidgetPickerControl-Header-Title"));
                var $widgetPickerAddActions = $('<div>').addClass("WidgetPickerControl-Header-Actions");
                this.$widgetPickerSelect = $('<select>')
                    .attr('id', WidgetPickerControl.WidgetPickerSelectId)
                    .addClass("WidgetPickerControl-Header-Actions-Select")
                    .css('color', UCITheming.getColorGray05(this.context));
                for (var _i = 0, _a = this.widgetList.filter(function (widget) { return !selectedWidgets.some(function (selectedWidget) { return selectedWidget.key === widget.key; }); }); _i < _a.length; _i++) {
                    var widget = _a[_i];
                    this.$widgetPickerSelect.append(this.createOption(widget));
                }
                this.$addButton = $('<button>')
                    .addClass("symbolFont New-symbol")
                    .addClass("WidgetPickerControl-Header-Actions-Add")
                    .click(function () { return _this.addClicked(); })
                    .append($('<span>')
                    .css("font-family", UCITheming.getRegular(this.context))
                    .text(this.context.resources.getString(SocialInsightsConstants.AddLabel)));
                $widgetPickerAddActions.append(this.$widgetPickerSelect);
                $widgetPickerAddActions.append(this.$addButton);
                var $widgetPickerListActions = $('<div>').addClass("WidgetPickerControl-Header-ListActions");
                this.$upButton = $('<button>')
                    .addClass("symbolFont UpArrow-symbol")
                    .attr("aria-controls", "WidgetPickerControl-Content")
                    .attr("aria-label", this.context.resources.getString(SocialInsightsConstants.MoveWidgetUpLabel))
                    .css('color', UCITheming.getColorGray05(this.context))
                    .click(function () { return _this.upClicked(); });
                this.$downButton = $('<button>')
                    .addClass("symbolFont DownArrow-symbol")
                    .attr("aria-controls", "WidgetPickerControl-Content")
                    .attr("aria-label", this.context.resources.getString(SocialInsightsConstants.MoveWidgetDownLabel))
                    .css('color', UCITheming.getColorGray05(this.context))
                    .click(function () { return _this.downClicked(); });
                this.$removeButton = $('<button>')
                    .addClass("symbolFont Delete-symbol")
                    .attr("aria-controls", "WidgetPickerControl-Content")
                    .attr("aria-label", this.context.resources.getString(SocialInsightsConstants.RemoveWidgetLabel))
                    .css('color', UCITheming.getColorGray05(this.context))
                    .click(function () { return _this.removeClicked(); });
                this.setListButtonsEnabled(false);
                $widgetPickerListActions.append(this.$upButton).append(this.$downButton).append(this.$removeButton);
                $widgetPickerHeader.append($widgetPickerAddActions).append($widgetPickerListActions);
                return $widgetPickerHeader;
            };
            WidgetPickerControl.prototype.createContent = function (selectedWidgets) {
                var _this = this;
                var $widgetPickerContent = $('<div>')
                    .addClass("WidgetPickerControl-Content")
                    .attr("id", "WidgetPickerControl-Content")
                    .attr("role", "radiogroup")
                    .attr("aria-label", this.context.resources.getString(SocialInsightsConstants.WidgetsLabel));
                for (var i = 0; i < selectedWidgets.length; i++) {
                    $widgetPickerContent.append(this.createWidget(selectedWidgets[i], i === 0));
                }
                $widgetPickerContent.keydown(function (e) {
                    switch (e.keyCode) {
                        case SocialInsightsConstants.UP:
                        case SocialInsightsConstants.LEFT:
                            var selected = e.target.previousElementSibling ? e.target.previousElementSibling : e.currentTarget.lastElementChild;
                            _this.setSelected($(selected));
                            e.preventDefault();
                            e.stopPropagation();
                            break;
                        case SocialInsightsConstants.DOWN:
                        case SocialInsightsConstants.RIGHT:
                            var selected = e.target.nextElementSibling ? e.target.nextElementSibling : e.currentTarget.firstElementChild;
                            _this.setSelected($(selected));
                            e.preventDefault();
                            e.stopPropagation();
                            break;
                        case SocialInsightsConstants.SPACE:
                            _this.setSelected($(e.target));
                            e.preventDefault();
                            e.stopPropagation();
                            break;
                    }
                });
                $widgetPickerContent.click(function (e) {
                    var $clickedWidget = $(e.target).hasClass("WidgetPickerControl-Content-Widget") ? $(e.target) : $(e.target).parents(".WidgetPickerControl-Content-Widget");
                    _this.setSelected($clickedWidget);
                });
                return $widgetPickerContent;
            };
            WidgetPickerControl.prototype.setSelected = function ($element) {
                this.clear();
                $element.addClass("WidgetPickerControl-Content-Widget-Selected")
                    .attr('tabindex', "0")
                    .attr('aria-checked', "true")
                    .focus();
                this.$selectedWidget = $element;
                this.setListButtonsEnabled(true);
            };
            WidgetPickerControl.prototype.clear = function () {
                this.$widgetPickerContent.children().removeClass("WidgetPickerControl-Content-Widget-Selected")
                    .attr('tabindex', "-1")
                    .attr('aria-checked', "false");
            };
            WidgetPickerControl.prototype.selected = function (widgetName) {
                var _this = this;
                var selectedWidgets = [];
                if (widgetName) {
                    widgetName.split("-").forEach(function (name) { return _this.widgetList.forEach(function (widget) {
                        if (widget.key === name) {
                            selectedWidgets.push(widget);
                        }
                    }); });
                }
                return selectedWidgets;
            };
            WidgetPickerControl.prototype.updateView = function (context) {
                this.context = context;
            };
            WidgetPickerControl.prototype.getOutputs = function () {
                return {
                    widgetName: this.getSelectedWidgetIds().join("-")
                };
            };
            WidgetPickerControl.prototype.destroy = function () {
            };
            return WidgetPickerControl;
        }());
        WidgetPickerControl.ControlName = 'WidgetPickerControl';
        WidgetPickerControl.WidgetPickerSelectId = 'MSEWidgetPickerSelect';
        ConfigureSIControl.WidgetPickerControl = WidgetPickerControl;
    })(ConfigureSIControl = MscrmControls.ConfigureSIControl || (MscrmControls.ConfigureSIControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="../SocialInsightsControl/Shared/MSEUtils.ts" />
/// <reference path="../SocialInsightsControl/Shared/RestResourceManager.ts" />
/// <reference path="../SocialInsightsControl/Shared/SocialInsightsConstants.ts" />
/// <reference path="../SocialInsightsControl/Shared/UCITheming.ts" />
/// <reference path="Interfaces/IInputBag.ts" />
/// <reference path="Interfaces/IOutputBag.ts" />
/// <reference path="TopicPickerControl.ts" />
/// <reference path="WidgetPickerControl.ts" />
/// <reference path="../../../../../references/external/TypeDefinitions/jquery.d.ts" />
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var ConfigureSIControl;
    (function (ConfigureSIControl_1) {
        "use strict";
        var ConfigureSIControl = (function () {
            function ConfigureSIControl() {
                this.instanceIsInitialized = false;
            }
            ConfigureSIControl.prototype.init = function (context, notifyOutputChanged, state, container) {
                var _this = this;
                if (!ConfigureSIControl.isInitialized) {
                    // Note that only one of these controls are allowed to be opened at the same time, since the select keys otherwise would be duplicate
                    // UCI might create two when one is needed.
                    ConfigureSIControl.isInitialized = true;
                    this.instanceIsInitialized = true;
                    this.$progressElement = $('<div>').addClass("SocialInsightsIndeterminateProgressBar");
                    for (var i = 0; i < 5; i++) {
                        this.$progressElement.append($('<div>').addClass("SocialInsightsProgressDot").append($('<div>')));
                    }
                    $(container).append(this.$progressElement);
                    this.$topicPicker = $('<div>').addClass("TopicPickerControl");
                    $(container).append(this.$topicPicker);
                    this.$widgetPicker = $('<div>').addClass("WidgetPickerControl");
                    $(container).append(this.$widgetPicker);
                    this.$topicPicker.hide();
                    this.$widgetPicker.hide();
                    this.topicPicker = new ConfigureSIControl_1.TopicPickerControl(function () { return _this.topicPickerLoaded(); });
                    this.widgetPicker = new ConfigureSIControl_1.WidgetPickerControl(function () { return _this.widgetPickerLoaded(); });
                    this.topicPicker.init(context, notifyOutputChanged, state, this.$topicPicker[0]);
                    this.widgetPicker.init(context, notifyOutputChanged, state, this.$widgetPicker[0]);
                }
            };
            ConfigureSIControl.prototype.updateView = function (context) {
                if (this.instanceIsInitialized) {
                    this.topicPicker.updateView(context);
                    this.widgetPicker.updateView(context);
                }
            };
            ConfigureSIControl.prototype.getOutputs = function () {
                if (this.instanceIsInitialized) {
                    return {
                        topicId: this.topicPicker.getOutputs().topicId,
                        widgetName: this.widgetPicker.getOutputs().widgetName,
                    };
                }
            };
            ConfigureSIControl.prototype.destroy = function () {
                if (this.instanceIsInitialized) {
                    this.topicPicker.destroy();
                    this.widgetPicker.destroy();
                    ConfigureSIControl.isInitialized = false;
                }
            };
            ConfigureSIControl.prototype.topicPickerLoaded = function () {
                this.isTopicPickerLoaded = true;
                this.tryHideProgressElement();
            };
            ConfigureSIControl.prototype.widgetPickerLoaded = function () {
                this.isWidgetPickerLoaded = true;
                this.tryHideProgressElement();
            };
            ConfigureSIControl.prototype.tryHideProgressElement = function () {
                if (this.isTopicPickerLoaded && this.isWidgetPickerLoaded) {
                    this.$progressElement.hide();
                    this.$topicPicker.show();
                    this.$widgetPicker.show();
                }
            };
            return ConfigureSIControl;
        }());
        ConfigureSIControl.isInitialized = false;
        ConfigureSIControl_1.ConfigureSIControl = ConfigureSIControl;
    })(ConfigureSIControl = MscrmControls.ConfigureSIControl || (MscrmControls.ConfigureSIControl = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=ConfigureSIControl.js.map