/**
 * This code was generated from a script.
 * Manual changes to this file will be overwritten if the code is regenerated.
 *
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var StatusCode;
        (function (StatusCode) {
            StatusCode[StatusCode["Error"] = 0] = "Error";
            StatusCode[StatusCode["NoInsight"] = 1] = "NoInsight";
            StatusCode[StatusCode["SuccessfullyRetrievedInsight"] = 2] = "SuccessfullyRetrievedInsight";
            StatusCode[StatusCode["Loading"] = 3] = "Loading";
            StatusCode[StatusCode["CreatePage"] = 4] = "CreatePage";
        })(StatusCode = TalkingPointsControl.StatusCode || (TalkingPointsControl.StatusCode = {}));
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var Category;
        (function (Category) {
            Category[Category["Sports"] = 0] = "Sports";
            Category[Category["Health"] = 1] = "Health";
            Category[Category["Entertainment"] = 2] = "Entertainment";
            Category[Category["Family"] = 3] = "Family";
            Category[Category["OOF"] = 4] = "OOF";
        })(Category = TalkingPointsControl.Category || (TalkingPointsControl.Category = {}));
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var InsightDetail;
        (function (InsightDetail) {
            InsightDetail[InsightDetail["Twoline"] = 0] = "Twoline";
            InsightDetail[InsightDetail["Threeline"] = 1] = "Threeline";
            InsightDetail[InsightDetail["Multiline"] = 2] = "Multiline";
        })(InsightDetail = TalkingPointsControl.InsightDetail || (TalkingPointsControl.InsightDetail = {}));
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var ComponentType;
        (function (ComponentType) {
            ComponentType[ComponentType["Carousel"] = 0] = "Carousel";
            ComponentType[ComponentType["List"] = 1] = "List";
        })(ComponentType = TalkingPointsControl.ComponentType || (TalkingPointsControl.ComponentType = {}));
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var StyleUtil = (function () {
            function StyleUtil() {
            }
            StyleUtil.headerContactLabel = function (isRTL) {
                var padding = "0em 0em 0em 0.3em";
                if (isRTL) {
                    padding = "0em 0.3em 0em 0em";
                }
                return {
                    padding: padding,
                    fontSize: "1em",
                    fontFamily: StyleUtil.weightSb,
                    color: "#333333"
                };
            };
            StyleUtil.insightFirstColumn = function (color, isRTL) {
                var margin = "0em 1em 0em 0em";
                if (isRTL) {
                    margin = "0em 0em 0em 1em";
                }
                return {
                    backgroundColor: color,
                    minWidth: "2.5em",
                    minHeight: "2.5em",
                    maxHeight: "2.5em",
                    lineHeight: "2.5em",
                    borderRadius: "50%",
                    margin: margin,
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center"
                };
            };
            StyleUtil.iconBarItem = function (backgroundColor) {
                return {
                    minWidth: "2.25em",
                    minHeight: "2.25em",
                    borderRadius: "50%",
                    backgroundColor: backgroundColor,
                    textAlign: "center",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center"
                };
            };
            StyleUtil.previousRightInsightSecondColumn = function (isRTL) {
                if (!isRTL) {
                    return {
                        display: "flex",
                        flexDirection: "column",
                        visibility: "hidden",
                        marginLeft: "100%",
                        marginRight: "-100%",
                        width: "0px",
                        maxWidth: "0px"
                    };
                }
                else {
                    return {
                        display: "flex",
                        flexDirection: "column",
                        visibility: "hidden",
                        marginLeft: "-100%",
                        marginRight: "100%",
                        width: "0px",
                        maxWidth: "0px"
                    };
                }
            };
            StyleUtil.getInsightFirstRowStyle = function (insightDetail, isCarousel) {
                var style = {};
                if (isCarousel) {
                    switch (insightDetail) {
                        case TalkingPointsControl.InsightDetail.Threeline:
                            return {
                                display: "flex",
                                whiteSpace: "pre-wrap",
                                minHeight: "4em",
                                maxHeight: "4em",
                                lineHeight: "1.4em",
                                overflow: "hidden",
                                marginBottom: "0.25em",
                                wordBreak: "break-word",
                                wordWrap: "break-word",
                                marginLeft: "inherit",
                                marginRight: "inherit",
                                transitionProperty: "margin-left marign-right",
                                transitionTimingFunction: "ease-in",
                                transitionDuration: "0.25s"
                            };
                        case TalkingPointsControl.InsightDetail.Multiline:
                            return {
                                display: "flex",
                                whiteSpace: "pre-wrap",
                                marginBottom: "0.25em",
                                minHeight: "4em",
                                lineHeight: "1.4em",
                                maxHeight: "18em",
                                overflow: "auto",
                                wordBreak: "break-word",
                                wordWrap: "break-word",
                                marginLeft: "inherit",
                                marginRight: "inherit",
                                transitionProperty: "margin-left margin-right",
                                transitionTimingFunction: "ease-in",
                                transitionDuration: "0.25s"
                            };
                        default:
                            return {};
                    }
                }
                switch (insightDetail) {
                    case TalkingPointsControl.InsightDetail.Twoline:
                        return {
                            display: "flex",
                            whiteSpace: "pre-wrap",
                            paddingBottom: "0.25em",
                            maxHeight: "2.5em",
                            lineHeight: "1.4em",
                            overflow: "hidden",
                            wordBreak: "break-word",
                            wordWrap: "break-word"
                        };
                    case TalkingPointsControl.InsightDetail.Multiline:
                        return {
                            display: "flex",
                            whiteSpace: "pre-wrap",
                            paddingBottom: "0.25em",
                            lineHeight: "1.4em",
                            maxHeight: "18em",
                            overflow: "auto",
                            wordBreak: "break-word",
                            wordWrap: "break-word"
                        };
                    default:
                        return {};
                }
            };
            StyleUtil.insightMetadataSuffix = function (isRTL) {
                var padding = "0em 0em 0em 0.25em";
                if (isRTL) {
                    padding = "0em 0.25em 0em 0em";
                }
                return {
                    fontSize: "1em",
                    color: "#666666",
                    fontFamily: StyleUtil.weightSb,
                    padding: padding
                };
            };
            StyleUtil.getInsightSecondColumnCss = function (isCarouselView, isPreviousInsight, insightOnLeft, isRTL) {
                if (!isCarouselView) {
                    return this.insightSecondColumnListView;
                }
                if (!isPreviousInsight) {
                    return this.currentInsightSecondColumn;
                }
                return this.previousRightInsightSecondColumn(isRTL);
            };
            return StyleUtil;
        }());
        StyleUtil.weightSb = "'SegoeUI-Semibold', 'Segoe UI Semibold', 'Segoe UI Regular', 'Segoe UI'";
        StyleUtil.weightR = "'SegoeUI-Regular', 'Segoe UI Regular', 'Segoe UI'";
        StyleUtil.talkingPoint = {
            display: "flex",
            flexDirection: "column",
            width: "100%"
        };
        StyleUtil.header = {
            lineHeight: "2.5em",
            display: "flex",
            justifyContent: "space-between"
        };
        StyleUtil.errorContainer = {
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            textAlign: "center",
            borderTop: "1px solid #d8d8d8",
            paddingTop: "1em"
        };
        StyleUtil.insight = {
            borderTop: "1px solid #d8d8d8",
            display: "flex",
            flexDirection: "row",
            paddingTop: "1em"
        };
        StyleUtil.iconBar = {
            display: "flex",
            height: "2.25em",
            justifyContent: "center",
            alignItems: "center",
            textAlign: "center"
        };
        StyleUtil.headerPrefix = {
            fontSize: "1em",
            fontFamily: StyleUtil.weightR,
            color: "#333333"
        };
        StyleUtil.overflowHidden = {
            overflow: "hidden"
        };
        StyleUtil.errorText = {
            display: "inline-block",
            fontSize: "1em",
            fontFamily: StyleUtil.weightR,
            color: "#333333",
            whiteSpace: "pre-wrap"
        };
        StyleUtil.iconBox = {
            width: "2.5em",
            height: "2.5em",
            lineHeight: "2.5em",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            border: "none",
            backgroundColor: "Transparent"
        };
        StyleUtil.emptyButton = {
            border: "none",
            padding: "0px 0px 0px 0px",
            backgroundColor: "Transparent",
            outline: "none",
            marginLeft: "0.5em",
            marginRight: "0.5em"
        };
        StyleUtil.icon = {
            width: "16px",
            height: "16px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center"
        };
        StyleUtil.whiteIcon = {
            width: "16px",
            height: "16px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            color: "white"
        };
        StyleUtil.loadingIcon = {
            width: "32px",
            height: "32px",
            color: "#b3b3b3",
            display: "flex",
            justifyContent: "center",
            alignItems: "center"
        };
        StyleUtil.loadingMessage = {
            fontSize: "1em",
            fontFamily: StyleUtil.weightR,
            color: "#b3b3b3"
        };
        StyleUtil.loadingContainer = {
            minHeight: "5em",
            width: "100%",
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center"
        };
        StyleUtil.insightSecondColumnListView = {
            display: "flex",
            flexDirection: "column"
        };
        StyleUtil.currentInsightSecondColumn = {
            display: "flex",
            flexDirection: "column",
            marginLeft: "0%",
            marginRight: "0%",
            visibility: "visible",
            opacity: "1"
        };
        StyleUtil.insightText = {
            fontSize: "1em",
            fontFamily: StyleUtil.weightR,
            fontStyle: "italic",
            color: "#333333",
            display: "flex",
            flexDirection: "column"
        };
        StyleUtil.italicText = {
            fontSize: "1em",
            fontFamily: StyleUtil.weightR,
            fontStyle: "italic",
            color: "#333333"
        };
        StyleUtil.regularText = {
            fontFamily: StyleUtil.weightR,
            fontSize: "1em",
            color: "#333333"
        };
        StyleUtil.insightTextContainer = {
            display: "flex",
            flexDirection: "column"
        };
        StyleUtil.insightTextSubject = {
            fontFamily: StyleUtil.weightSb,
            fontStyle: "initial",
            color: "#333333",
            textDecoration: "none",
            paddingBottom: "0.25em"
        };
        StyleUtil.insightTextBody = {
            whiteSpace: "pre-line",
            fontStyle: "initial",
            fontFamily: StyleUtil.weightR,
            fontSize: "1em",
            color: "#333333"
        };
        StyleUtil.insightActionIcons = {
            float: "right"
        };
        StyleUtil.insightMetadata = {
            display: "flex"
        };
        StyleUtil.insightMetadataPrefix = {
            fontSize: "1em",
            color: "#333333",
            fontFamily: StyleUtil.weightR
        };
        StyleUtil.insightSecondRow = {
            display: "flex",
            justifyContent: "space-between",
            lineHeight: "2.5em",
            width: "100%"
        };
        StyleUtil.insightCarouselContainer = {
            display: "flex",
            flexDirection: "row"
        };
        TalkingPointsControl.StyleUtil = StyleUtil;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var TalkingPointsConstants = (function () {
            function TalkingPointsConstants() {
            }
            return TalkingPointsConstants;
        }());
        TalkingPointsConstants.SPORTS_COLOR = "#358717";
        TalkingPointsConstants.HEALTH_COLOR = "#008992";
        TalkingPointsConstants.FAMILY_COLOR = "#b26491";
        TalkingPointsConstants.ENTERTAINMENT_COLOR = "#bf991f";
        TalkingPointsConstants.OTHER_COLOR = "#ffffff";
        TalkingPointsConstants.INACTIVE_CATEGORY_COLOR = "#e2e2e2";
        TalkingPointsConstants.LIST_VIEW_ICON = 190;
        TalkingPointsConstants.COLLAPSE_ICON = 199;
        TalkingPointsConstants.EXPAND_ICON = 200;
        TalkingPointsConstants.LOADING_ICON = 90;
        TalkingPointsConstants.HEALTH_CATEGORY_ICON = 310;
        TalkingPointsConstants.FAMILY_CATEGORY_ICON = 311;
        TalkingPointsConstants.SPORTS_CATEGORY_ICON = 312;
        TalkingPointsConstants.ENTERTAINMENT_CATEGORY_ICON = 313;
        TalkingPointsConstants.CAROUSEL_VIEW_ICON = 315;
        TalkingPointsConstants.LIKE_EMPTY_ICON = 316;
        TalkingPointsConstants.LIKE_FILLED_ICON = 317;
        TalkingPointsConstants.TALKING_POINTS_ROOT = "TalkingPointsView";
        TalkingPointsConstants.LIST_VIEW_ROOT = "ListView";
        TalkingPointsConstants.CAROUSEL_VIEW_ROOT = "CarouselView";
        TalkingPointsConstants.ICON_BAR_VIEW_ROOT = "IconBarView";
        TalkingPointsConstants.HEADER_VIEW_ROOT = "HeaderView";
        TalkingPointsConstants.HEADING_ROOT = "HeadingView";
        TalkingPointsConstants.HEADING_PREFIX_ROOT = "HeadingPrefixView";
        TalkingPointsConstants.CONTACT_LABEL_ROOT = "ContactLabelView";
        TalkingPointsConstants.COMPONENT_SWITCHER_ICON_ROOT = "ComponentSwitcherIconView";
        TalkingPointsConstants.MICROSOFT_ICON_COMPONENT_SWTICHER_ROOT = "MicrosoftIconComponentSwticherView";
        TalkingPointsConstants.INSIGHT_VIEW_ROOT = "InsightView";
        TalkingPointsConstants.INSIGHT_CATEGORY_ICON_VIEW_ROOT = "InsightCategoryIconView";
        TalkingPointsConstants.MICROSOFT_ICON_INSIGHT_CATEGORY_VIEW_ROOT = "MicrosoftIconInsightCategoryView";
        TalkingPointsConstants.CONTENT_ROOT = "ContentView";
        TalkingPointsConstants.SUBJECT_ROOT = "SubjectView";
        TalkingPointsConstants.BODY_ROOT = "BodyView";
        TalkingPointsConstants.METADATA_ROOT = "MetadataView";
        TalkingPointsConstants.METADATA_PREFIX_ROOT = "MetadataPrefixView";
        TalkingPointsConstants.METADATA_SUFFIX_ROOT = "MetadataSuffixView";
        TalkingPointsConstants.INSIGHT_DETAIL_SWITCHER_ICON_ROOT = "InsightDetailSwitcherIconView";
        TalkingPointsConstants.MICROSOFT_ICON_INSIGHT_DETAIL_SWITCHER_ROOT = "MicrosoftIconInsightDetailSwitcherView";
        TalkingPointsConstants.FAVOURITE_SWITCHER_ICON_ROOT = "FavouriteSwitcherIconView";
        TalkingPointsConstants.MICROSOFT_ICON_FAVOURITE_SWITCHER_ROOT = "MicrosoftIconFavouriteSwitcherView";
        TalkingPointsConstants.CATEGORY_ICON_VIEW_ROOT = "CategoryIconView";
        TalkingPointsConstants.SPACE = " ";
        TalkingPointsConstants.FULL_STOP = ".";
        TalkingPointsConstants.COMMA = ", ";
        TalkingPointsConstants.AGO_ABOUT = "AgoAbout";
        TalkingPointsConstants.AVAILABLE = "Available";
        TalkingPointsConstants.CAROUSEL_VIEW = "CarouselView";
        TalkingPointsConstants.COLLAPSE = "Collapse";
        TalkingPointsConstants.ENTERTAINMENT = "Entertainment";
        TalkingPointsConstants.EXPAND = "Expand";
        TalkingPointsConstants.FAMILY = "Family";
        TalkingPointsConstants.FEATURE_NAME = "Talking points";
        TalkingPointsConstants.FOR = "For";
        TalkingPointsConstants.HEALTH = "Health";
        TalkingPointsConstants.HIGHLIGHTED = "Highlighted";
        TalkingPointsConstants.LIKE = "Like";
        TalkingPointsConstants.LIST_VIEW = "ListView";
        TalkingPointsConstants.LOADING = "Loading";
        TalkingPointsConstants.NO = "No";
        TalkingPointsConstants.NOT_HIGHLIGHTED = "NotHighlighted";
        TalkingPointsConstants.OR = "Or";
        TalkingPointsConstants.PLEASE_TRY = "PleaseTry";
        TalkingPointsConstants.SPORTS = "Sports";
        TalkingPointsConstants.UNABLE_TO = "UnableTo";
        TalkingPointsConstants.UNLIKE = "Unlike";
        TalkingPointsConstants.WILL_APPEAR = "WillAppear";
        TalkingPointsConstants.CREATE_VIEW_ERROR = "CreateViewError";
        TalkingPointsControl.TalkingPointsConstants = TalkingPointsConstants;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var TalkingPointsRequest = (function () {
            function TalkingPointsRequest() {
            }
            TalkingPointsRequest.prototype.getMetadata = function () {
                var metadata = {
                    boundParameter: null,
                    operationName: "msdyn_GetTalkingPoints",
                    operationType: 0,
                    parameterTypes: {
                        "entityId": {
                            typeName: "Edm.String",
                            structuralProperty: 1 /* PrimitiveType */
                        },
                        "entityType": {
                            typeName: "Edm.String",
                            structuralProperty: 1 /* PrimitiveType */
                        }
                    }
                };
                return metadata;
            };
            return TalkingPointsRequest;
        }());
        TalkingPointsControl.TalkingPointsRequest = TalkingPointsRequest;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var SetTalkingPointLikedStatusRequest = (function () {
            function SetTalkingPointLikedStatusRequest() {
            }
            SetTalkingPointLikedStatusRequest.prototype.getMetadata = function () {
                var metadata = {
                    boundParameter: null,
                    operationName: "msdyn_SetTalkingPointLikedStatus",
                    operationType: 0,
                    parameterTypes: {
                        "MessageId": {
                            typeName: "Edm.String",
                            structuralProperty: 1 /* PrimitiveType */
                        },
                        "InferredMessageId": {
                            typeName: "Edm.String",
                            structuralProperty: 1 /* PrimitiveType */
                        },
                        "IsLiked": {
                            typeName: "Edm.Boolean",
                            structuralProperty: 1 /* PrimitiveType */
                        }
                    }
                };
                return metadata;
            };
            return SetTalkingPointLikedStatusRequest;
        }());
        TalkingPointsControl.SetTalkingPointLikedStatusRequest = SetTalkingPointLikedStatusRequest;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../../jsreferences/external/TypeDefinitions/moment.d.ts" />
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var TimeUtil = (function () {
            function TimeUtil() {
            }
            TimeUtil.GetTimeDifference = function (dateTime) {
                var momentDateTime = moment(dateTime);
                moment.updateLocale('en', {
                    relativeTime: {
                        future: "in %s",
                        past: "%s",
                        s: "%d seconds",
                        m: "%d minutes",
                        mm: "%d minutes",
                        h: "%d hours",
                        hh: "%d hours",
                        d: "%d days",
                        dd: "%d days",
                        M: "%d months",
                        MM: "%d months",
                        y: "%d years",
                        yy: "%d years"
                    }
                });
                var ans = momentDateTime.fromNow();
                if (ans.charAt(0) == '1' && ans.charAt(1) == ' ') {
                    ans = ans.substring(0, ans.length - 1);
                }
                return ans;
            };
            return TimeUtil;
        }());
        TalkingPointsControl.TimeUtil = TimeUtil;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var EllipsisUtil = (function () {
            function EllipsisUtil() {
                this.canvas = document.createElement("canvas");
                this.canvas_context = this.canvas.getContext("2d");
            }
            EllipsisUtil.prototype.getFontSize = function () {
                if (this.actualFontSize > 0)
                    return this.actualFontSize;
                return this.calculateFontSize();
            };
            EllipsisUtil.prototype.init = function (fontfamily) {
                this.fontSizeContext = this.getFontSize();
                var font = [
                    "normal",
                    "normal",
                    this.fontSizeContext + "px",
                    fontfamily
                ].join(" ");
                this.canvas_context.font = font;
            };
            EllipsisUtil.prototype.setActualFontSize = function (fontsize) {
                this.actualFontSize = fontsize;
            };
            EllipsisUtil.prototype.calculateFontSize = function () {
                var aTempElement = document.createElement("span");
                aTempElement.style.fontSize = "1rem";
                document.body.appendChild(aTempElement);
                var fontSize = window.getComputedStyle(aTempElement).fontSize;
                this.actualFontSize = parseInt(fontSize);
                aTempElement.parentNode.removeChild(aTempElement);
                return this.actualFontSize;
            };
            EllipsisUtil.prototype.measureWidth = function (text) {
                return this.canvas_context.measureText(text).width;
            };
            EllipsisUtil.prototype.getTruncatedText = function (content, numLines, context) {
                var retobj = this.getLines(content, numLines, context);
                var linestr = "";
                if (retobj.lines) {
                    for (var i = 0; i < retobj.lines.length; i++) {
                        if (i > 0) {
                            linestr += retobj.splitModes[i - 1];
                        }
                        linestr += retobj.lines[i];
                    }
                    retobj.lines = linestr;
                }
                return retobj;
            };
            EllipsisUtil.prototype.getLines = function (text, numLines, context) {
                if (!text || text.length <= 0)
                    return { 'Text': "", 'Istruncated': false };
                var allocatedWidth = context.client.allocatedWidth;
                if (numLines == 2) {
                    allocatedWidth = allocatedWidth - this.fontSizeContext * 2;
                }
                if (allocatedWidth <= 0)
                    return { 'Text': "", 'Istruncated': false };
                var lines = [];
                var splitModes = [];
                var textLines = text.split("\n").map(function (line) { return (line + "\n").split(" "); });
                //remove the unwanted \n added to the last word of the last line
                var lineCount = textLines.length;
                var lastLineWordCount = textLines[lineCount - 1].length;
                textLines[lineCount - 1][lastLineWordCount - 1] = textLines[lineCount - 1][lastLineWordCount - 1].substr(0, textLines[lineCount - 1][lastLineWordCount - 1].length - 1);
                var didTruncate = false;
                var SPLIT_BY_WORD = " ";
                var SPLIT_BY_CHAR = "";
                var splitMode = SPLIT_BY_WORD;
                for (var line = 1; line <= numLines && textLines.length > 0; line++) {
                    var textWords = textLines[0];
                    // Handle newline
                    if (textWords.length === 0) {
                        lines.push();
                        textLines.shift();
                        splitMode = SPLIT_BY_WORD;
                        line--;
                        continue;
                    }
                    var resultLine = textWords.join(splitMode);
                    if (this.measureWidth(resultLine) <= allocatedWidth) {
                        textLines.shift();
                        if (resultLine[resultLine.length - 1] === '\n') {
                            // the last character is \n so no need to add a space
                            splitModes.push(SPLIT_BY_CHAR);
                        }
                        else {
                            splitModes.push(splitMode);
                        }
                        if (splitMode == SPLIT_BY_CHAR) {
                            textLines[0] = [resultLine].concat(textLines[0]);
                            splitMode = SPLIT_BY_WORD;
                            line--;
                            continue;
                        }
                        else {
                            if (line === numLines) {
                                if (textLines.length > 0) {
                                    didTruncate = true;
                                    if (resultLine[resultLine.length - 1] === '\n') {
                                        resultLine = resultLine.substr(0, resultLine.length - 1);
                                    }
                                    resultLine += "...";
                                }
                            }
                        }
                    }
                    else {
                        var lower = 0;
                        var upper = textWords.length - 1;
                        while (lower <= upper) {
                            var middle = Math.floor((lower + upper) / 2);
                            var testLine = textWords.slice(0, middle + 1).join(splitMode);
                            if (this.measureWidth(testLine) <= allocatedWidth) {
                                lower = middle + 1;
                            }
                            else {
                                upper = middle - 1;
                            }
                        }
                        if (lower === 0) {
                            //unbreakable word start breaking by character
                            var unbreakableWord = textLines[0][0];
                            var unbreakableWordCharArrary = unbreakableWord.split(SPLIT_BY_CHAR);
                            textLines[0].splice(0, 1);
                            if (textLines[0].length === 0) {
                                textLines.shift();
                            }
                            var newTextLines = [unbreakableWordCharArrary].concat(textLines);
                            textLines = newTextLines;
                            splitMode = SPLIT_BY_CHAR;
                            line--;
                            continue;
                        }
                        if (line === numLines) {
                            resultLine = textWords.slice(0, lower).join(splitMode);
                            textLines[0].splice(0, lower);
                            if (textLines.length > 0) {
                                if (resultLine.length >= 3) {
                                    resultLine = resultLine.replace(/...$/, "...");
                                }
                                didTruncate = true;
                            }
                        }
                        else {
                            resultLine = textWords.slice(0, lower).join(splitMode);
                            textLines[0].splice(0, lower);
                        }
                        splitModes.push(splitMode);
                    }
                    lines.push(resultLine);
                }
                return { 'lines': lines, 'Istruncated': didTruncate, 'splitModes': splitModes };
            };
            return EllipsisUtil;
        }());
        TalkingPointsControl.EllipsisUtil = EllipsisUtil;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var InsightModel = (function () {
            function InsightModel(messageId, id, content, time, category, weblink, subject, body, liked) {
                this.messageId = messageId;
                this.id = id;
                this.content = content;
                this.time = MscrmControls.TalkingPointsControl.TimeUtil.GetTimeDifference(time);
                this.setCategory(category);
                this.weblink = weblink;
                this.subject = subject;
                this.body = body;
                this.bodyPrefix = body.split(content, 1)[0];
                this.bodySuffix = body.split(content, 2)[1];
                this.liked = liked;
                this.collapsed = true;
                this.toggleLikedStatusInProgress = false;
            }
            InsightModel.prototype.getMessageId = function () {
                return this.messageId;
            };
            InsightModel.prototype.getId = function () {
                return this.id;
            };
            InsightModel.prototype.getContent = function () {
                return this.content;
            };
            InsightModel.prototype.getTime = function () {
                return this.time;
            };
            InsightModel.prototype.getCategory = function () {
                return this.category;
            };
            InsightModel.prototype.getWeblink = function () {
                return this.weblink;
            };
            InsightModel.prototype.getSubject = function () {
                return this.subject;
            };
            InsightModel.prototype.getBody = function () {
                return this.body;
            };
            InsightModel.prototype.getBodyPrefix = function () {
                return this.bodyPrefix;
            };
            InsightModel.prototype.getBodySuffix = function () {
                return this.bodySuffix;
            };
            InsightModel.prototype.isLiked = function () {
                return this.liked;
            };
            InsightModel.prototype.isToggleLikedStatusInProgress = function () {
                return this.toggleLikedStatusInProgress;
            };
            InsightModel.prototype.setToggleLikedStatusInProgress = function (value) {
                this.toggleLikedStatusInProgress = value;
            };
            InsightModel.prototype.toggleLiked = function () {
                this.liked = !this.liked;
            };
            InsightModel.prototype.isCollapsed = function () {
                return this.collapsed;
            };
            InsightModel.prototype.resetCollapse = function () {
                this.collapsed = true;
            };
            InsightModel.prototype.toggleCollapsed = function () {
                this.collapsed = !this.collapsed;
            };
            InsightModel.prototype.setCategory = function (category) {
                if (category === TalkingPointsControl.TalkingPointsConstants.SPORTS) {
                    this.category = TalkingPointsControl.Category.Sports;
                }
                else if (category === TalkingPointsControl.TalkingPointsConstants.HEALTH) {
                    this.category = TalkingPointsControl.Category.Health;
                }
                else if (category === TalkingPointsControl.TalkingPointsConstants.FAMILY) {
                    this.category = TalkingPointsControl.Category.Family;
                }
                else if (category === TalkingPointsControl.TalkingPointsConstants.ENTERTAINMENT) {
                    this.category = TalkingPointsControl.Category.Entertainment;
                }
            };
            InsightModel.prototype.cleanup = function () {
                this.id = null;
                this.content = null;
                this.time = null;
                this.category = null;
                this.weblink = null;
                this.subject = null;
                this.body = null;
                this.liked = null;
                this.collapsed = null;
            };
            return InsightModel;
        }());
        TalkingPointsControl.InsightModel = InsightModel;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var TalkingPointsModel = (function () {
            function TalkingPointsModel() {
                this.insightIds = [];
                this.insights = {};
                this.carousel = true;
            }
            TalkingPointsModel.prototype.getStatusCode = function () {
                return this.statusCode;
            };
            TalkingPointsModel.prototype.setStatusCode = function (statusCode) {
                this.statusCode = statusCode;
            };
            TalkingPointsModel.prototype.isInsightCollapsed = function (id) {
                var insight = this.getInsight(id);
                return insight.isCollapsed();
            };
            TalkingPointsModel.prototype.isInsightActive = function (id) {
                return (id == this.getActiveInsight());
            };
            TalkingPointsModel.prototype.isInsightLiked = function (id) {
                var insight = this.getInsight(id);
                return insight.isLiked();
            };
            TalkingPointsModel.prototype.getInsightContent = function (id) {
                var insight = this.getInsight(id);
                return insight.getContent();
            };
            TalkingPointsModel.prototype.getInsightSubject = function (id) {
                var insight = this.getInsight(id);
                return insight.getSubject();
            };
            TalkingPointsModel.prototype.getInsightBody = function (id) {
                var insight = this.getInsight(id);
                return insight.getBody();
            };
            TalkingPointsModel.prototype.getInsightWeblink = function (id) {
                var insight = this.getInsight(id);
                return insight.getWeblink();
            };
            TalkingPointsModel.prototype.getInsightTime = function (id) {
                var insight = this.getInsight(id);
                return insight.getTime();
            };
            TalkingPointsModel.prototype.getInsightCategoryIcon = function (id) {
                var insight = this.getInsight(id);
                var category = insight.getCategory();
                switch (category) {
                    case TalkingPointsControl.Category.Entertainment:
                        return TalkingPointsControl.TalkingPointsConstants.ENTERTAINMENT_CATEGORY_ICON;
                    case TalkingPointsControl.Category.Family:
                        return TalkingPointsControl.TalkingPointsConstants.FAMILY_CATEGORY_ICON;
                    case TalkingPointsControl.Category.Health:
                        return TalkingPointsControl.TalkingPointsConstants.HEALTH_CATEGORY_ICON;
                    case TalkingPointsControl.Category.Sports:
                        return TalkingPointsControl.TalkingPointsConstants.SPORTS_CATEGORY_ICON;
                    default:
                        return -1;
                }
            };
            TalkingPointsModel.prototype.getInsightCategoryColor = function (id) {
                var insight = this.getInsight(id);
                var category = insight.getCategory();
                switch (category) {
                    case TalkingPointsControl.Category.Entertainment:
                        return TalkingPointsControl.TalkingPointsConstants.ENTERTAINMENT_COLOR;
                    case TalkingPointsControl.Category.Family:
                        return TalkingPointsControl.TalkingPointsConstants.FAMILY_COLOR;
                    case TalkingPointsControl.Category.Health:
                        return TalkingPointsControl.TalkingPointsConstants.HEALTH_COLOR;
                    case TalkingPointsControl.Category.Sports:
                        return TalkingPointsControl.TalkingPointsConstants.SPORTS_COLOR;
                    default:
                        return TalkingPointsControl.TalkingPointsConstants.OTHER_COLOR;
                }
            };
            TalkingPointsModel.prototype.getInsightCategoryDisplayString = function (id, context) {
                var insight = this.getInsight(id);
                var category = insight.getCategory();
                switch (category) {
                    case TalkingPointsControl.Category.Entertainment:
                        return context.resources.getString(TalkingPointsControl.TalkingPointsConstants.ENTERTAINMENT);
                    case TalkingPointsControl.Category.Family:
                        return context.resources.getString(TalkingPointsControl.TalkingPointsConstants.FAMILY);
                    case TalkingPointsControl.Category.Health:
                        return context.resources.getString(TalkingPointsControl.TalkingPointsConstants.HEALTH);
                    case TalkingPointsControl.Category.Sports:
                        return context.resources.getString(TalkingPointsControl.TalkingPointsConstants.SPORTS);
                    default:
                        return "";
                }
            };
            TalkingPointsModel.prototype.getInsightDetail = function (id) {
                var isCarousel = this.isCarousel();
                var isCollapsed = this.getInsight(id).isCollapsed();
                if (isCollapsed) {
                    if (isCarousel) {
                        return TalkingPointsControl.InsightDetail.Threeline;
                    }
                    else {
                        return TalkingPointsControl.InsightDetail.Twoline;
                    }
                }
                else {
                    return TalkingPointsControl.InsightDetail.Multiline;
                }
            };
            TalkingPointsModel.prototype.setHeaderPrefix = function (headerPrefix) {
                this.headerPrefix = headerPrefix;
            };
            TalkingPointsModel.prototype.setContactLabel = function (contactLabel) {
                this.contactLabel = contactLabel;
            };
            TalkingPointsModel.prototype.addInsight = function (insight) {
                var id = insight.getId();
                if (this.insightIds.length == 0) {
                    this.activeInsight = id;
                }
                this.insightIds.push(id);
                this.insights[id] = insight;
            };
            TalkingPointsModel.prototype.isCarousel = function () {
                return this.carousel;
            };
            TalkingPointsModel.prototype.toggleCarousel = function () {
                this.carousel = !this.carousel;
            };
            TalkingPointsModel.prototype.getHeaderPrefix = function () {
                return this.headerPrefix;
            };
            TalkingPointsModel.prototype.getContactLabel = function () {
                return this.contactLabel;
            };
            TalkingPointsModel.prototype.getActiveInsight = function () {
                return this.activeInsight;
            };
            TalkingPointsModel.prototype.setActiveInsight = function (activeInsightId) {
                this.activeInsight = activeInsightId;
            };
            TalkingPointsModel.prototype.getActiveInsightIndex = function () {
                return this.getInsightById(this.activeInsight);
            };
            TalkingPointsModel.prototype.getInsightIndex = function (insightId) {
                return this.getInsightById(insightId);
            };
            TalkingPointsModel.prototype.getInsightById = function (id) {
                for (var i = 0; i < this.insightIds.length; i++) {
                    if (this.insightIds[i] == id) {
                        return i;
                    }
                }
                return -1;
            };
            TalkingPointsModel.prototype.getPreviousInsightId = function (id) {
                var index = this.getInsightById(id);
                if (index == 0) {
                    return id;
                }
                return this.insightIds[index - 1];
            };
            TalkingPointsModel.prototype.getNextInsightId = function (id) {
                var index = this.getInsightById(id);
                if (index == this.insightIds.length - 1) {
                    return id;
                }
                return this.insightIds[index + 1];
            };
            TalkingPointsModel.prototype.resetCollapse = function (id) {
                for (var i = 0; i < this.insightIds.length; ++i) {
                    if (!id || this.insightIds[i] != id)
                        this.insights[this.insightIds[i]].resetCollapse();
                }
            };
            TalkingPointsModel.prototype.getInsight = function (id) {
                return this.insights[id];
            };
            TalkingPointsModel.prototype.getInsightsCount = function () {
                return this.insightIds.length;
            };
            TalkingPointsModel.prototype.isFirstInsight = function (id) {
                return (this.insightIds.length > 0 && this.insightIds[0] == id);
            };
            TalkingPointsModel.prototype.cleanup = function () {
                this.carousel = null;
                this.headerPrefix = null;
                this.contactLabel = null;
                this.activeInsight = null;
                for (var i = 0; i < this.insightIds.length; i++) {
                    this.insights[i].cleanup();
                }
                this.insightIds = null;
                this.insights = null;
            };
            return TalkingPointsModel;
        }());
        TalkingPointsControl.TalkingPointsModel = TalkingPointsModel;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var ErrorView = (function () {
            function ErrorView(model) {
                this.model = model;
            }
            ErrorView.prototype.getComponent = function (context) {
                var messageLabel = context.factory.createElement("CONTAINER", {
                    style: TalkingPointsControl.StyleUtil.errorText
                }, this.getMessageString(context, this.model.getStatusCode()));
                return context.factory.createElement("CONTAINER", {
                    style: TalkingPointsControl.StyleUtil.errorContainer
                }, messageLabel);
            };
            ErrorView.prototype.getMessageString = function (context, statusCode) {
                var messageString = "";
                switch (statusCode) {
                    case TalkingPointsControl.StatusCode.CreatePage:
                        messageString = context.resources.getString(TalkingPointsControl.TalkingPointsConstants.CREATE_VIEW_ERROR);
                        break;
                    case TalkingPointsControl.StatusCode.NoInsight:
                        if (!context.client.isRTL) {
                            messageString = context.resources.getString(TalkingPointsControl.TalkingPointsConstants.NO)
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + TalkingPointsControl.TalkingPointsConstants.FEATURE_NAME.toLowerCase()
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.AVAILABLE)
                                + TalkingPointsControl.TalkingPointsConstants.FULL_STOP
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + TalkingPointsControl.TalkingPointsConstants.FEATURE_NAME.toLowerCase()
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.WILL_APPEAR)
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.FAMILY)
                                + TalkingPointsControl.TalkingPointsConstants.COMMA
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.HEALTH)
                                + TalkingPointsControl.TalkingPointsConstants.COMMA
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.SPORTS)
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.OR)
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.ENTERTAINMENT)
                                + TalkingPointsControl.TalkingPointsConstants.FULL_STOP;
                        }
                        else {
                            messageString = TalkingPointsControl.TalkingPointsConstants.FULL_STOP
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.ENTERTAINMENT)
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.OR)
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.SPORTS)
                                + TalkingPointsControl.TalkingPointsConstants.COMMA
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.HEALTH)
                                + TalkingPointsControl.TalkingPointsConstants.COMMA
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.FAMILY)
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.WILL_APPEAR)
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + TalkingPointsControl.TalkingPointsConstants.FEATURE_NAME.toLowerCase()
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + TalkingPointsControl.TalkingPointsConstants.FULL_STOP
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.AVAILABLE)
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + TalkingPointsControl.TalkingPointsConstants.FEATURE_NAME.toLowerCase()
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.NO);
                        }
                        break;
                    case TalkingPointsControl.StatusCode.Error:
                        if (!context.client.isRTL) {
                            messageString = context.resources.getString(TalkingPointsControl.TalkingPointsConstants.UNABLE_TO)
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + TalkingPointsControl.TalkingPointsConstants.FEATURE_NAME.toLowerCase()
                                + TalkingPointsControl.TalkingPointsConstants.FULL_STOP
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.PLEASE_TRY)
                                + TalkingPointsControl.TalkingPointsConstants.FULL_STOP;
                        }
                        else {
                            messageString = TalkingPointsControl.TalkingPointsConstants.FULL_STOP
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.PLEASE_TRY)
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + TalkingPointsControl.TalkingPointsConstants.FULL_STOP
                                + TalkingPointsControl.TalkingPointsConstants.FEATURE_NAME.toLowerCase()
                                + TalkingPointsControl.TalkingPointsConstants.SPACE
                                + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.UNABLE_TO);
                        }
                        break;
                }
                return messageString;
            };
            ErrorView.prototype.cleanup = function () {
                this.model = null;
            };
            return ErrorView;
        }());
        TalkingPointsControl.ErrorView = ErrorView;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var LoadingView = (function () {
            function LoadingView() {
            }
            LoadingView.prototype.getComponent = function (context) {
                var icon = context.factory.createElement("CRMICON", {
                    style: TalkingPointsControl.StyleUtil.loadingIcon,
                    type: TalkingPointsControl.TalkingPointsConstants.LOADING_ICON
                });
                var loadingString = context.resources.getString(TalkingPointsControl.TalkingPointsConstants.LOADING);
                var featureName = TalkingPointsControl.TalkingPointsConstants.FEATURE_NAME.toLowerCase();
                var labelString;
                if (!context.client.isRTL) {
                    labelString = loadingString + TalkingPointsControl.TalkingPointsConstants.SPACE + featureName;
                }
                else {
                    labelString = featureName + TalkingPointsControl.TalkingPointsConstants.SPACE + loadingString;
                }
                var label = context.factory.createElement("LABEL", {
                    style: TalkingPointsControl.StyleUtil.loadingMessage
                }, labelString);
                return context.factory.createElement("CONTAINER", {
                    style: TalkingPointsControl.StyleUtil.loadingContainer
                }, [icon, label]);
            };
            LoadingView.prototype.cleanup = function () {
            };
            return LoadingView;
        }());
        TalkingPointsControl.LoadingView = LoadingView;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var HeaderView = (function () {
            function HeaderView(model, observer) {
                this.model = model;
                this.observer = observer;
            }
            HeaderView.prototype.getHeaderSection = function (context) {
                var forString = context.resources.getString(TalkingPointsControl.TalkingPointsConstants.FOR);
                var headerPrefixString = this.model.getHeaderPrefix();
                var label;
                if (this.model.getStatusCode() == TalkingPointsControl.StatusCode.CreatePage) {
                    label = headerPrefixString;
                }
                else {
                    if (!context.client.isRTL) {
                        label = headerPrefixString + TalkingPointsControl.TalkingPointsConstants.SPACE + forString;
                    }
                    else {
                        label = forString + TalkingPointsControl.TalkingPointsConstants.SPACE + headerPrefixString;
                    }
                }
                var headerPrefix = context.factory.createElement("LABEL", {
                    style: TalkingPointsControl.StyleUtil.headerPrefix,
                    id: TalkingPointsControl.TalkingPointsConstants.HEADING_PREFIX_ROOT,
                    key: TalkingPointsControl.TalkingPointsConstants.HEADING_PREFIX_ROOT
                }, label);
                var contactLabel = context.factory.createElement("LABEL", {
                    style: TalkingPointsControl.StyleUtil.headerContactLabel(context.client.isRTL),
                    id: TalkingPointsControl.TalkingPointsConstants.CONTACT_LABEL_ROOT,
                    key: TalkingPointsControl.TalkingPointsConstants.CONTACT_LABEL_ROOT
                }, this.model.getContactLabel());
                return context.factory.createElement("CONTAINER", {
                    id: TalkingPointsControl.TalkingPointsConstants.HEADING_ROOT,
                    key: TalkingPointsControl.TalkingPointsConstants.HEADING_ROOT,
                    style: TalkingPointsControl.StyleUtil.overflowHidden
                }, [headerPrefix, contactLabel]);
            };
            HeaderView.prototype.getIconBox = function (context) {
                var iconType = this.model.isCarousel() ? TalkingPointsControl.TalkingPointsConstants.LIST_VIEW_ICON : TalkingPointsControl.TalkingPointsConstants.CAROUSEL_VIEW_ICON;
                var icon = context.factory.createElement("MICROSOFTICON", {
                    style: TalkingPointsControl.StyleUtil.icon,
                    type: iconType,
                    id: TalkingPointsControl.TalkingPointsConstants.MICROSOFT_ICON_COMPONENT_SWTICHER_ROOT,
                    key: TalkingPointsControl.TalkingPointsConstants.MICROSOFT_ICON_COMPONENT_SWTICHER_ROOT
                });
                var label = this.model.isCarousel()
                    ? context.resources.getString(TalkingPointsControl.TalkingPointsConstants.LIST_VIEW)
                    : context.resources.getString(TalkingPointsControl.TalkingPointsConstants.CAROUSEL_VIEW);
                return context.factory.createElement("BUTTON", {
                    style: TalkingPointsControl.StyleUtil.iconBox,
                    onClick: this.handleClick.bind(this),
                    accessibilityLabel: label,
                    title: label,
                    role: "button",
                    id: TalkingPointsControl.TalkingPointsConstants.COMPONENT_SWITCHER_ICON_ROOT,
                    key: TalkingPointsControl.TalkingPointsConstants.COMPONENT_SWITCHER_ICON_ROOT
                }, icon);
            };
            HeaderView.prototype.handleClick = function () {
                this.observer.publish('TALKINGPOINTS_COMPONENT_SWITCHER_CLICKED');
            };
            HeaderView.prototype.getComponent = function (context) {
                var children = [];
                children.push(this.getHeaderSection(context));
                if (this.model.getStatusCode() == TalkingPointsControl.StatusCode.SuccessfullyRetrievedInsight
                    && this.model.getInsightsCount() > 1) {
                    children.push(this.getIconBox(context));
                }
                return context.factory.createElement("CONTAINER", {
                    style: TalkingPointsControl.StyleUtil.header,
                    id: TalkingPointsControl.TalkingPointsConstants.HEADER_VIEW_ROOT,
                    key: TalkingPointsControl.TalkingPointsConstants.HEADER_VIEW_ROOT
                }, children);
            };
            HeaderView.prototype.cleanup = function () {
                this.model = null;
                this.observer = null;
            };
            return HeaderView;
        }());
        TalkingPointsControl.HeaderView = HeaderView;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var InsightView = (function () {
            function InsightView(id, model, observer, ellipsisUtil) {
                this.id = id;
                this.model = model;
                this.observer = observer;
                this.ellipsisUtil = ellipsisUtil;
            }
            InsightView.prototype.getCategoryIcon = function (context) {
                var iconType = this.model.getInsightCategoryIcon(this.id);
                var icon = context.factory.createElement("MICROSOFTICON", {
                    type: iconType,
                    style: TalkingPointsControl.StyleUtil.whiteIcon,
                    id: TalkingPointsControl.TalkingPointsConstants.MICROSOFT_ICON_INSIGHT_CATEGORY_VIEW_ROOT + this.id,
                    key: TalkingPointsControl.TalkingPointsConstants.MICROSOFT_ICON_INSIGHT_CATEGORY_VIEW_ROOT + this.id
                });
                var color = this.model.getInsightCategoryColor(this.id);
                return context.factory.createElement("CONTAINER", {
                    style: TalkingPointsControl.StyleUtil.insightFirstColumn(color, context.client.isRTL),
                    id: TalkingPointsControl.TalkingPointsConstants.INSIGHT_CATEGORY_ICON_VIEW_ROOT + this.id,
                    key: TalkingPointsControl.TalkingPointsConstants.INSIGHT_CATEGORY_ICON_VIEW_ROOT + this.id
                }, icon);
            };
            InsightView.prototype.getInsightText = function (context) {
                var content = this.model.getInsightContent(this.id);
                if (this.model.isInsightCollapsed(this.id)) {
                    var insightDetail = this.model.getInsightDetail(this.id);
                    var numLines = this.model.isCarousel() ? 3 : 2;
                    var truncatedTextObject = this.ellipsisUtil.getTruncatedText(content, numLines, context);
                    if (truncatedTextObject.lines) {
                        content = truncatedTextObject.lines;
                    }
                    return context.factory.createElement("CONTAINER", {
                        style: TalkingPointsControl.StyleUtil.insightText,
                        id: TalkingPointsControl.TalkingPointsConstants.CONTENT_ROOT + this.id,
                        key: TalkingPointsControl.TalkingPointsConstants.CONTENT_ROOT + this.id
                    }, content);
                }
                else {
                    var subject = this.model.getInsightSubject(this.id);
                    var weblink = this.model.getInsightWeblink(this.id);
                    var subjectContainer = context.factory.createElement("HYPERLINK", {
                        style: TalkingPointsControl.StyleUtil.insightTextSubject,
                        accessibilityLabel: subject,
                        title: subject,
                        id: TalkingPointsControl.TalkingPointsConstants.SUBJECT_ROOT + this.id,
                        key: TalkingPointsControl.TalkingPointsConstants.SUBJECT_ROOT + this.id,
                        onClick: this.handleSubjectClick.bind(this, weblink)
                    }, subject);
                    var bodyChildren = [];
                    var insight = this.model.getInsight(this.id);
                    var bodyPrefix = insight.getBodyPrefix();
                    if (bodyPrefix) {
                        var prefixElement = context.factory.createElement("LABEL", {
                            style: TalkingPointsControl.StyleUtil.regularText
                        }, bodyPrefix);
                        bodyChildren.push(prefixElement);
                    }
                    var contentElement = context.factory.createElement("LABEL", {
                        style: TalkingPointsControl.StyleUtil.italicText
                    }, content);
                    bodyChildren.push(contentElement);
                    var bodySuffix = insight.getBodySuffix();
                    if (bodySuffix) {
                        var suffixElement = context.factory.createElement("LABEL", {
                            style: TalkingPointsControl.StyleUtil.regularText
                        }, bodySuffix);
                        bodyChildren.push(suffixElement);
                    }
                    var bodyContainer = context.factory.createElement("CONTAINER", {
                        id: TalkingPointsControl.TalkingPointsConstants.BODY_ROOT + this.id,
                        key: TalkingPointsControl.TalkingPointsConstants.BODY_ROOT + this.id
                    }, bodyChildren);
                    return context.factory.createElement("CONTAINER", {
                        style: TalkingPointsControl.StyleUtil.insightTextContainer
                    }, [subjectContainer, bodyContainer]);
                }
            };
            InsightView.prototype.getFavouriteIcon = function (context) {
                var iconType = this.model.isInsightLiked(this.id) ? TalkingPointsControl.TalkingPointsConstants.LIKE_FILLED_ICON : TalkingPointsControl.TalkingPointsConstants.LIKE_EMPTY_ICON;
                var icon = context.factory.createElement("MICROSOFTICON", {
                    type: iconType,
                    style: TalkingPointsControl.StyleUtil.icon,
                    id: TalkingPointsControl.TalkingPointsConstants.MICROSOFT_ICON_FAVOURITE_SWITCHER_ROOT + this.id,
                    key: TalkingPointsControl.TalkingPointsConstants.MICROSOFT_ICON_FAVOURITE_SWITCHER_ROOT + this.id
                });
                var label = this.model.isInsightLiked(this.id)
                    ? context.resources.getString(TalkingPointsControl.TalkingPointsConstants.UNLIKE)
                    : context.resources.getString(TalkingPointsControl.TalkingPointsConstants.LIKE);
                return context.factory.createElement("BUTTON", {
                    style: TalkingPointsControl.StyleUtil.iconBox,
                    onClick: this.handleFavouriteIconClick.bind(this),
                    accessibilityLabel: label,
                    title: label,
                    id: TalkingPointsControl.TalkingPointsConstants.FAVOURITE_SWITCHER_ICON_ROOT + this.id,
                    key: TalkingPointsControl.TalkingPointsConstants.FAVOURITE_SWITCHER_ICON_ROOT + this.id
                }, icon);
            };
            InsightView.prototype.handleFavouriteIconClick = function () {
                this.observer.publish('TALKINGPOINTS_TOGGLE_FAVOURITE', this.id);
            };
            InsightView.prototype.handleSubjectClick = function (weblink) {
                this.observer.publish('TALKINGPOINTS_OPEN_WEBLINK', weblink);
            };
            InsightView.prototype.handleKeyDownEvent = function (event) {
                var keyCode = event.keyCode;
                if (keyCode == '38' || keyCode == '40') {
                    var insightId;
                    if (keyCode == '38') {
                        insightId = this.model.getPreviousInsightId(this.id);
                    }
                    else if (keyCode == '40') {
                        insightId = this.model.getNextInsightId(this.id);
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    this.observer.publish('TALKINGPOINTS_FOCUS', insightId);
                }
            };
            InsightView.prototype.getInsightDetailIcon = function (context) {
                var iconType = this.model.isInsightCollapsed(this.id) ? TalkingPointsControl.TalkingPointsConstants.EXPAND_ICON : TalkingPointsControl.TalkingPointsConstants.COLLAPSE_ICON;
                var icon = context.factory.createElement("MICROSOFTICON", {
                    type: iconType,
                    style: TalkingPointsControl.StyleUtil.icon,
                    id: TalkingPointsControl.TalkingPointsConstants.MICROSOFT_ICON_INSIGHT_DETAIL_SWITCHER_ROOT + this.id,
                    key: TalkingPointsControl.TalkingPointsConstants.MICROSOFT_ICON_INSIGHT_DETAIL_SWITCHER_ROOT + this.id
                });
                var label = this.model.isInsightCollapsed(this.id)
                    ? context.resources.getString(TalkingPointsControl.TalkingPointsConstants.EXPAND)
                    : context.resources.getString(TalkingPointsControl.TalkingPointsConstants.COLLAPSE);
                return context.factory.createElement("BUTTON", {
                    style: TalkingPointsControl.StyleUtil.iconBox,
                    onClick: this.handleInsightDetailSwitcherClick.bind(this),
                    accessibilityLabel: label,
                    title: label,
                    id: TalkingPointsControl.TalkingPointsConstants.INSIGHT_DETAIL_SWITCHER_ICON_ROOT + this.id,
                    key: TalkingPointsControl.TalkingPointsConstants.INSIGHT_DETAIL_SWITCHER_ICON_ROOT + this.id
                }, icon);
            };
            InsightView.prototype.handleInsightDetailSwitcherClick = function () {
                this.observer.publish('TALKINGPOINTS_TOGGLE_INSIGHT_DETAIL', this.id);
            };
            InsightView.prototype.getInsight = function (context) {
                var insightDetail = this.model.getInsightDetail(this.id);
                var insightFirstRow = context.factory.createElement("CONTAINER", {
                    style: TalkingPointsControl.StyleUtil.getInsightFirstRowStyle(insightDetail, this.model.isCarousel())
                }, this.getInsightText(context));
                var agoAboutString = context.resources.getString(TalkingPointsControl.TalkingPointsConstants.AGO_ABOUT);
                var timeString = this.model.getInsightTime(this.id);
                var time;
                if (!context.client.isRTL) {
                    time = timeString + TalkingPointsControl.TalkingPointsConstants.SPACE + agoAboutString;
                }
                else {
                    time = agoAboutString + TalkingPointsControl.TalkingPointsConstants.SPACE + timeString;
                }
                var metadataPrefix = context.factory.createElement("LABEL", {
                    style: TalkingPointsControl.StyleUtil.insightMetadataPrefix,
                    id: TalkingPointsControl.TalkingPointsConstants.METADATA_PREFIX_ROOT + this.id,
                    key: TalkingPointsControl.TalkingPointsConstants.METADATA_PREFIX_ROOT + this.id
                }, time);
                var category = this.model.getInsightCategoryDisplayString(this.id, context);
                var metadataSuffix = context.factory.createElement("LABEL", {
                    style: TalkingPointsControl.StyleUtil.insightMetadataSuffix(context.client.isRTL),
                    id: TalkingPointsControl.TalkingPointsConstants.METADATA_SUFFIX_ROOT + this.id,
                    key: TalkingPointsControl.TalkingPointsConstants.METADATA_SUFFIX_ROOT + this.id
                }, category);
                var metadata = context.factory.createElement("CONTAINER", {
                    style: TalkingPointsControl.StyleUtil.insightMetadata,
                    id: TalkingPointsControl.TalkingPointsConstants.METADATA_ROOT + this.id,
                    key: TalkingPointsControl.TalkingPointsConstants.METADATA_ROOT + this.id
                }, [metadataPrefix, metadataSuffix]);
                var actionIcons = context.factory.createElement("CONTAINER", {
                    style: TalkingPointsControl.StyleUtil.insightActionIcons
                }, [this.getFavouriteIcon(context), this.getInsightDetailIcon(context)]);
                var insightSecondRow = context.factory.createElement("CONTAINER", {
                    style: TalkingPointsControl.StyleUtil.insightSecondRow
                }, [metadata, actionIcons]);
                var isPreviousControl = true;
                if (this.model.isInsightActive(this.id)) {
                    isPreviousControl = false;
                }
                var currentIndex = this.model.getActiveInsightIndex();
                var insightIndex = this.model.getInsightIndex(this.id);
                var isCarouselView = this.model.isCarousel();
                var insightSecondColumn = JSON.parse(JSON.stringify(TalkingPointsControl.StyleUtil.getInsightSecondColumnCss(isCarouselView, isPreviousControl, insightIndex < currentIndex, context.client.isRTL)));
                if (!isCarouselView) {
                    insightSecondColumn["width"] = "100%";
                }
                else {
                    if (this.model.isInsightActive(this.id)) {
                        insightSecondColumn["minWidth"] = "100%";
                    }
                }
                return context.factory.createElement("CONTAINER", {
                    style: insightSecondColumn
                }, [insightFirstRow, insightSecondRow]);
            };
            InsightView.prototype.getComponent = function (context) {
                var children = [];
                if (!this.model.isCarousel()) {
                    children.push(this.getCategoryIcon(context));
                }
                children.push(this.getInsight(context));
                var insightStyle = JSON.parse(JSON.stringify(TalkingPointsControl.StyleUtil.insight));
                if (!this.model.isCarousel()) {
                    var tabIndex = -1;
                    insightStyle["width"] = "100%";
                    if (this.model.isFirstInsight(this.id)) {
                        tabIndex = 0;
                    }
                    return context.factory.createElement("LISTITEM", {
                        style: insightStyle,
                        role: "listitem",
                        tabIndex: tabIndex,
                        id: TalkingPointsControl.TalkingPointsConstants.INSIGHT_VIEW_ROOT + this.id,
                        key: TalkingPointsControl.TalkingPointsConstants.INSIGHT_VIEW_ROOT + this.id,
                        onKeyDown: this.handleKeyDownEvent.bind(this)
                    }, children);
                }
                else {
                    var tabIndex = -1;
                    if (this.model.isInsightActive(this.id)) {
                        insightStyle["minWidth"] = "100%";
                        tabIndex = 0;
                    }
                    return context.factory.createElement("LISTITEM", {
                        style: insightStyle,
                        role: "listitem",
                        id: TalkingPointsControl.TalkingPointsConstants.INSIGHT_VIEW_ROOT + this.id,
                        key: TalkingPointsControl.TalkingPointsConstants.INSIGHT_VIEW_ROOT + this.id,
                        tabIndex: tabIndex
                    }, children);
                }
            };
            InsightView.prototype.cleanup = function () {
                this.id = null;
                this.model = null;
                this.observer = null;
                this.ellipsisUtil = null;
            };
            return InsightView;
        }());
        TalkingPointsControl.InsightView = InsightView;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var CategoryIconView = (function () {
            function CategoryIconView(id, model, observer) {
                this.id = id;
                this.model = model;
                this.observer = observer;
            }
            CategoryIconView.prototype.handleClick = function () {
                this.observer.publish('TALKINGPOINTS_CAROUSEL_DISPLAY', this.id);
            };
            CategoryIconView.prototype.getComponent = function (context) {
                var isInsightActive = this.model.isInsightActive(this.id);
                var backgroundColor = TalkingPointsControl.TalkingPointsConstants.INACTIVE_CATEGORY_COLOR;
                if (isInsightActive) {
                    backgroundColor = this.model.getInsightCategoryColor(this.id);
                }
                var iconType = this.model.getInsightCategoryIcon(this.id);
                var iconStyle = TalkingPointsControl.StyleUtil.icon;
                if (isInsightActive) {
                    iconStyle = TalkingPointsControl.StyleUtil.whiteIcon;
                }
                var icon = context.factory.createElement("MICROSOFTICON", {
                    style: iconStyle,
                    type: iconType
                });
                var title = this.model.getInsightCategoryDisplayString(this.id, context);
                var label = title;
                if (isInsightActive) {
                    label += context.resources.getString(TalkingPointsControl.TalkingPointsConstants.HIGHLIGHTED);
                }
                else {
                    label += context.resources.getString(TalkingPointsControl.TalkingPointsConstants.NOT_HIGHLIGHTED);
                }
                var circleContainer = context.factory.createElement("CONTAINER", {
                    style: TalkingPointsControl.StyleUtil.iconBarItem(backgroundColor)
                }, icon);
                return context.factory.createElement("BUTTON", {
                    role: "button",
                    accessibilityLabel: label,
                    title: title,
                    style: TalkingPointsControl.StyleUtil.emptyButton,
                    id: TalkingPointsControl.TalkingPointsConstants.CATEGORY_ICON_VIEW_ROOT + this.id,
                    key: TalkingPointsControl.TalkingPointsConstants.CATEGORY_ICON_VIEW_ROOT + this.id,
                    onClick: this.handleClick.bind(this)
                }, circleContainer);
            };
            CategoryIconView.prototype.cleanup = function () {
                this.id = null;
                this.model = null;
                this.observer = null;
            };
            return CategoryIconView;
        }());
        TalkingPointsControl.CategoryIconView = CategoryIconView;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var TalkingPointsView = (function () {
            function TalkingPointsView(model, observer) {
                this.ids = [];
                this.insightViews = [];
                this.iconBarView = [];
                this.model = model;
                this.observer = observer;
                this.headerView = new TalkingPointsControl.HeaderView(this.model, observer);
                this.errorView = new TalkingPointsControl.ErrorView(this.model);
                this.loadingView = new TalkingPointsControl.LoadingView();
            }
            TalkingPointsView.prototype.addInsight = function (id, ellipsisUtil) {
                this.ids.push(id);
                this.insightViews.push(new TalkingPointsControl.InsightView(id, this.model, this.observer, ellipsisUtil));
                this.iconBarView.push(new TalkingPointsControl.CategoryIconView(id, this.model, this.observer));
            };
            TalkingPointsView.prototype.getIconBarComponent = function (context) {
                var children = [];
                for (var i = 0; i < this.iconBarView.length; i++) {
                    var component = this.iconBarView[i].getComponent(context);
                    children.push(component);
                }
                return context.factory.createElement("CONTAINER", {
                    style: TalkingPointsControl.StyleUtil.iconBar,
                    id: TalkingPointsControl.TalkingPointsConstants.ICON_BAR_VIEW_ROOT,
                    key: TalkingPointsControl.TalkingPointsConstants.ICON_BAR_VIEW_ROOT
                }, children);
            };
            TalkingPointsView.prototype.getComponent = function (context) {
                var statusCode = this.model.getStatusCode();
                if (statusCode == TalkingPointsControl.StatusCode.Loading) {
                    return this.loadingView.getComponent(context);
                }
                var component;
                var children = [];
                /*
                 * Add HeaderView Component to children
                 */
                component = this.headerView.getComponent(context);
                children.push(component);
                if (statusCode != TalkingPointsControl.StatusCode.SuccessfullyRetrievedInsight) {
                    /*
                     * Add Error View Component to children
                     */
                    component = this.errorView.getComponent(context);
                    children.push(component);
                }
                else {
                    var isCarousel = this.model.isCarousel();
                    var noInsights = this.insightViews.length;
                    var insights = [];
                    for (var i = 0; i < noInsights; i++) {
                        component = this.insightViews[i].getComponent(context);
                        insights.push(component);
                    }
                    if (isCarousel && noInsights > 1) {
                        /*
                         * Add Carousel View Component to children
                         */
                        component = context.factory.createElement("CONTAINER", {
                            style: TalkingPointsControl.StyleUtil.insightCarouselContainer,
                            id: TalkingPointsControl.TalkingPointsConstants.CAROUSEL_VIEW_ROOT,
                            key: TalkingPointsControl.TalkingPointsConstants.CAROUSEL_VIEW_ROOT
                        }, insights);
                        children.push(component);
                        /*
                         * Add IconBarView Component to children
                         */
                        component = this.getIconBarComponent(context);
                        children.push(component);
                    }
                    else {
                        /*
                         * Add ListView Component to children
                         */
                        component = context.factory.createElement("LIST", {
                            role: "list",
                            id: TalkingPointsControl.TalkingPointsConstants.LIST_VIEW_ROOT,
                            key: TalkingPointsControl.TalkingPointsConstants.LIST_VIEW_ROOT
                        }, insights);
                        children.push(component);
                    }
                }
                var label = this.model.getHeaderPrefix()
                    + TalkingPointsControl.TalkingPointsConstants.SPACE
                    + context.resources.getString(TalkingPointsControl.TalkingPointsConstants.FOR)
                    + TalkingPointsControl.TalkingPointsConstants.SPACE
                    + this.model.getContactLabel();
                return context.factory.createElement("CONTAINER", {
                    style: TalkingPointsControl.StyleUtil.talkingPoint,
                    id: TalkingPointsControl.TalkingPointsConstants.TALKING_POINTS_ROOT,
                    key: TalkingPointsControl.TalkingPointsConstants.TALKING_POINTS_ROOT,
                    accessibilityLabel: label
                }, children);
            };
            TalkingPointsView.prototype.cleanup = function () {
                this.errorView.cleanup();
                this.headerView.cleanup();
                this.headerView = null;
                this.ids = null;
                for (var i = 0; i < this.insightViews.length; i++) {
                    this.insightViews[i].cleanup();
                }
                this.insightViews = null;
                for (var i = 0; i < this.iconBarView.length; i++) {
                    this.iconBarView[i].cleanup();
                }
                this.iconBarView = null;
                this.model = null;
                this.observer = null;
            };
            return TalkingPointsView;
        }());
        TalkingPointsControl.TalkingPointsView = TalkingPointsView;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var TalkingPointsObserver = (function () {
            function TalkingPointsObserver() {
                this.subscribers = {};
            }
            TalkingPointsObserver.prototype.subscribe = function (event, callback) {
                if (!this.subscribers[event]) {
                    this.subscribers[event] = [];
                }
                this.subscribers[event].push(callback);
            };
            TalkingPointsObserver.prototype.publish = function (event, args) {
                if (!this.subscribers[event] || this.subscribers[event].length < 1)
                    return;
                this.subscribers[event].forEach(function (callback) {
                    try {
                        callback(args || {});
                    }
                    catch (e) {
                    }
                });
            };
            TalkingPointsObserver.prototype.cleanup = function () {
                this.subscribers = {};
            };
            return TalkingPointsObserver;
        }());
        TalkingPointsControl.TalkingPointsObserver = TalkingPointsObserver;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var TalkingPointsController = (function () {
            function TalkingPointsController() {
                this.model = new TalkingPointsControl.TalkingPointsModel();
                this.observer = new TalkingPointsControl.TalkingPointsObserver();
                this.view = new TalkingPointsControl.TalkingPointsView(this.model, this.observer);
                this.ellipsisUtil = new TalkingPointsControl.EllipsisUtil();
                this.addSubscribers();
            }
            TalkingPointsController.prototype.fetchInsights = function (context) {
                this.context = context;
                this.model.setStatusCode(TalkingPointsControl.StatusCode.Loading);
                this.observer.publish('TALKINGPOINTS_RERENDER');
                this.ellipsisUtil.init(context.theming.fontfamilies.semibold);
                var featureName = TalkingPointsControl.TalkingPointsConstants.FEATURE_NAME;
                this.model.setHeaderPrefix(featureName);
                var fullName = context.parameters.fullname.raw;
                if (fullName == null || fullName == "") {
                    this.model.setStatusCode(TalkingPointsControl.StatusCode.CreatePage);
                    this.observer.publish('TALKINGPOINTS_RERENDER');
                    return;
                }
                else {
                    this.model.setContactLabel(fullName);
                }
                var request = new TalkingPointsControl.TalkingPointsRequest();
                request.entityId = context.page.entityId;
                request.entityType = context.page.entityTypeName;
                var that = this;
                context.webAPI.execute(request).then(function (response) {
                    response.json().then(function (responseObject) {
                        try {
                            var response = JSON.parse(responseObject.response);
                            var statusCode = response.statusCode;
                            that.model.setStatusCode(statusCode);
                            var event;
                            var client = that.context.client.getClient();
                            switch (statusCode) {
                                case TalkingPointsControl.StatusCode.NoInsight:
                                    event = new TalkingPointsControl.TalkingPointsCountEvent(0, client);
                                    break;
                                case TalkingPointsControl.StatusCode.SuccessfullyRetrievedInsight:
                                    var insights = JSON.parse(response.value.insights);
                                    var categories = [];
                                    for (var i = 0; i < insights.length; i++) {
                                        var categoryAdded = that.addInsight(insights[i]);
                                        categories.push(categoryAdded);
                                    }
                                    event = new TalkingPointsControl.TalkingPointsCountEvent(insights.length, client, categories);
                                    break;
                                default:
                                    event = new TalkingPointsControl.TalkingPointsCountEvent(-1, client);
                                    break;
                            }
                            that.context.reporting.reportEvent(event);
                            that.observer.publish('TALKINGPOINTS_RERENDER');
                        }
                        catch (e) {
                            that.handleErrorScenario();
                            if (e != null) {
                                console.log("fetchInsights failed with exception:" + e.message);
                            }
                        }
                    });
                }, function (err) {
                    that.handleErrorScenario();
                });
            };
            TalkingPointsController.prototype.toggleLikedForInsight = function (insight, observer, context) {
                if (!insight.isToggleLikedStatusInProgress()) {
                    var getIsLikedStatus = insight.isLiked();
                    var request = new TalkingPointsControl.SetTalkingPointLikedStatusRequest();
                    request.MessageId = insight.getMessageId();
                    request.IsLiked = !getIsLikedStatus;
                    request.InferredMessageId = insight.getId();
                    insight.setToggleLikedStatusInProgress(true);
                    context.webAPI.execute(request).then(function (response) {
                        response.json().then(function (responseObject) {
                            try {
                                if (responseObject.IsSuccessfull) {
                                    insight.toggleLiked();
                                }
                            }
                            finally {
                                insight.setToggleLikedStatusInProgress(false);
                                observer.publish('TALKINGPOINTS_RERENDER');
                            }
                        }, function (err) {
                            insight.setToggleLikedStatusInProgress(false);
                            observer.publish('TALKINGPOINTS_RERENDER');
                        });
                    }, function (err) {
                        insight.setToggleLikedStatusInProgress(false);
                        observer.publish('TALKINGPOINTS_RERENDER');
                    });
                }
            };
            TalkingPointsController.prototype.handleErrorScenario = function () {
                this.model.setStatusCode(TalkingPointsControl.StatusCode.Error);
                var event = new TalkingPointsControl.TalkingPointsCountEvent(-1, this.context.client.getClient());
                this.context.reporting.reportEvent(event);
                this.observer.publish('TALKINGPOINTS_RERENDER');
            };
            TalkingPointsController.prototype.addInsight = function (insight) {
                var model = new TalkingPointsControl.InsightModel(insight.messageId, insight.id, insight.content, insight.time, insight.category, insight.webLink, insight.subject, insight.body, insight.isLiked);
                this.model.addInsight(model);
                this.view.addInsight(insight.id, this.ellipsisUtil);
                return model.getCategory();
            };
            TalkingPointsController.prototype.getView = function (context) {
                this.context = context;
                var fullName = context.parameters.fullname.raw;
                this.model.setContactLabel(fullName);
                return this.view.getComponent(context);
            };
            TalkingPointsController.prototype.cleanup = function () {
                this.context = null;
                this.model.cleanup();
                this.model = null;
                this.view.cleanup();
                this.view = null;
                this.observer.cleanup();
                this.observer = null;
            };
            TalkingPointsController.prototype.addSubscribers = function () {
                var that = this;
                this.observer.subscribe('TALKINGPOINTS_RERENDER', function (callback) {
                    if (typeof callback === "function")
                        that.context.utils.requestRender(callback);
                    else
                        that.context.utils.requestRender();
                });
                this.observer.subscribe('TALKINGPOINTS_COMPONENT_SWITCHER_CLICKED', function () {
                    that.model.resetCollapse();
                    that.model.toggleCarousel();
                    var event = new TalkingPointsControl.TalkingPointsViewSwitchedEvent(that.model.isCarousel() ? TalkingPointsControl.ComponentType.Carousel : TalkingPointsControl.ComponentType.List);
                    that.context.reporting.reportEvent(event);
                    that.observer.publish('TALKINGPOINTS_RERENDER');
                });
                this.observer.subscribe('TALKINGPOINTS_TOGGLE_FAVOURITE', function (id) {
                    var insight = that.model.getInsight(id);
                    var event = new TalkingPointsControl.TalkingPointsMarkedAsFavouriteEvent(insight.getCategory(), !insight.isLiked());
                    that.context.reporting.reportEvent(event);
                    that.toggleLikedForInsight(insight, that.observer, that.context);
                });
                this.observer.subscribe('TALKINGPOINTS_TOGGLE_INSIGHT_DETAIL', function (id) {
                    that.model.resetCollapse(id);
                    var insight = that.model.getInsight(id);
                    insight.toggleCollapsed();
                    var event = new TalkingPointsControl.TalkingPointsExpandedEvent(insight.getCategory(), insight.isCollapsed());
                    that.context.reporting.reportEvent(event);
                    that.observer.publish('TALKINGPOINTS_FOCUS', id);
                });
                this.observer.subscribe('TALKINGPOINTS_CAROUSEL_DISPLAY', function (id) {
                    that.model.resetCollapse();
                    that.model.setActiveInsight(id);
                    var event = new TalkingPointsControl.TalkingPointsCategoryIconClickedEvent(that.model.getInsight(id).getCategory());
                    that.context.reporting.reportEvent(event);
                    that.observer.publish('TALKINGPOINTS_RERENDER');
                });
                this.observer.subscribe('TALKINGPOINTS_FOCUS', function (id) {
                    var callback = function () {
                        that.context.accessibility.focusElementById(TalkingPointsControl.TalkingPointsConstants.INSIGHT_VIEW_ROOT + id);
                    };
                    that.observer.publish('TALKINGPOINTS_RERENDER', callback);
                });
                this.observer.subscribe('TALKINGPOINTS_OPEN_WEBLINK', function (weblink) {
                    that.context.navigation.openUrl(weblink);
                });
            };
            return TalkingPointsController;
        }());
        TalkingPointsControl.TalkingPointsController = TalkingPointsController;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var TalkingPointsEventParameter = (function () {
            function TalkingPointsEventParameter(name, value) {
                this.name = name;
                this.value = value;
            }
            return TalkingPointsEventParameter;
        }());
        TalkingPointsControl.TalkingPointsEventParameter = TalkingPointsEventParameter;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var TalkingPointsCategoryIconClicked = "TalkingPointsCategoryIconClicked";
        var TalkingPointsCategoryIconClickedEvent = (function () {
            function TalkingPointsCategoryIconClickedEvent(category) {
                this.eventParameters = [];
                this.eventName = TalkingPointsCategoryIconClicked;
                this.addEventParameter("type", category);
            }
            TalkingPointsCategoryIconClickedEvent.prototype.addEventParameter = function (name, value) {
                var event = new TalkingPointsControl.TalkingPointsEventParameter(name, value);
                this.eventParameters.push(event);
            };
            return TalkingPointsCategoryIconClickedEvent;
        }());
        TalkingPointsControl.TalkingPointsCategoryIconClickedEvent = TalkingPointsCategoryIconClickedEvent;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var TalkingPointsCount = "TalkingPointsCount";
        var TalkingPointsCountEvent = (function () {
            function TalkingPointsCountEvent(count, client, categories) {
                this.eventParameters = [];
                var uniqueCategories = null;
                if (categories != null && categories != undefined) {
                    uniqueCategories = categories.filter(function (item, pos) {
                        return categories.indexOf(item) == pos;
                    });
                }
                var types = "";
                if (uniqueCategories != null) {
                    types = JSON.stringify(uniqueCategories);
                }
                this.eventName = TalkingPointsCount;
                this.addEventParameter("client", client);
                this.addEventParameter("count", count);
                this.addEventParameter("types", types);
            }
            TalkingPointsCountEvent.prototype.addEventParameter = function (name, value) {
                var event = new TalkingPointsControl.TalkingPointsEventParameter(name, value);
                this.eventParameters.push(event);
            };
            return TalkingPointsCountEvent;
        }());
        TalkingPointsControl.TalkingPointsCountEvent = TalkingPointsCountEvent;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var TalkingPointsExpanded = "TalkingPointsExpanded";
        var TalkingPointsExpandedEvent = (function () {
            function TalkingPointsExpandedEvent(category, isCollapsed) {
                this.eventParameters = [];
                this.eventName = TalkingPointsExpanded;
                this.addEventParameter("isCollapsed", isCollapsed);
                this.addEventParameter("type", category);
            }
            TalkingPointsExpandedEvent.prototype.addEventParameter = function (name, value) {
                var event = new TalkingPointsControl.TalkingPointsEventParameter(name, value);
                this.eventParameters.push(event);
            };
            return TalkingPointsExpandedEvent;
        }());
        TalkingPointsControl.TalkingPointsExpandedEvent = TalkingPointsExpandedEvent;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var TalkingPointsMarkedAsFavourite = "TalkingPointsMarkedAsFavourite";
        var TalkingPointsMarkedAsFavouriteEvent = (function () {
            function TalkingPointsMarkedAsFavouriteEvent(category, isLiked) {
                this.eventParameters = [];
                this.eventName = TalkingPointsMarkedAsFavourite;
                this.addEventParameter("isLiked", isLiked);
                this.addEventParameter("type", category);
            }
            TalkingPointsMarkedAsFavouriteEvent.prototype.addEventParameter = function (name, value) {
                var event = new TalkingPointsControl.TalkingPointsEventParameter(name, value);
                this.eventParameters.push(event);
            };
            return TalkingPointsMarkedAsFavouriteEvent;
        }());
        TalkingPointsControl.TalkingPointsMarkedAsFavouriteEvent = TalkingPointsMarkedAsFavouriteEvent;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var TalkingPointsViewSwitched = "TalkingPointsViewSwitched";
        var TalkingPointsViewSwitchedEvent = (function () {
            function TalkingPointsViewSwitchedEvent(componentType) {
                this.eventParameters = [];
                this.eventName = TalkingPointsViewSwitched;
                this.addEventParameter("switchedTo", componentType);
            }
            TalkingPointsViewSwitchedEvent.prototype.addEventParameter = function (name, value) {
                var event = new TalkingPointsControl.TalkingPointsEventParameter(name, value);
                this.eventParameters.push(event);
            };
            return TalkingPointsViewSwitchedEvent;
        }());
        TalkingPointsControl.TalkingPointsViewSwitchedEvent = TalkingPointsViewSwitchedEvent;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../jsreferences/internal/TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../jsreferences/internal/TypeDefinitions/XrmClientApi.d.ts" />
/// <reference path="CommonReferences.ts" />
/* enum */
/// <reference path="enum/StatusCode.ts" />
/// <reference path="enum/Category.ts" />
/// <reference path="enum/InsightDetail.ts" />
/// <reference path="enum/ComponentType.ts" />
/* util */
/// <reference path="util/StyleUtil.ts" />
/// <reference path="util/TalkingPointsConstants.ts" />
/// <reference path="util/TalkingPointsRequest.ts" />
/// <reference path="util/SetTalkingPointLikedStatusRequest.ts" />
/// <reference path="util/TimeUtil.ts" />
/// <reference path="util/EllipsisUtil.ts" />
/* model */
/// <reference path="model/InsightModel.ts" />
/// <reference path="model/TalkingPointsModel.ts" />
/* view */
/// <reference path="interface/IView.ts" />
/// <reference path="view/ErrorView.ts" />
/// <reference path="view/LoadingView.ts" />
/// <reference path="view/HeaderView.ts" />
/// <reference path="view/InsightView.ts" />
/// <reference path="view/CategoryIconView.ts" />
/// <reference path="view/TalkingPointsView.ts" />
/* observer */
/// <reference path="observer/TalkingPointsObserver.ts" />
/* controller */
/// <reference path="controller/TalkingPointsController.ts" />
/* telemetry */
/// <reference path="telemetry/TalkingPointsEventParameter.ts" />
/// <reference path="telemetry/TalkingPointsCategoryIconClickedEvent.ts" />
/// <reference path="telemetry/TalkingPointsCountEvent.ts" />
/// <reference path="telemetry/TalkingPointsExpandedEvent.ts" />
/// <reference path="telemetry/TalkingPointsMarkedAsFavouriteEvent.ts" />
/// <reference path="telemetry/TalkingPointsViewSwitchedEvent.ts" />
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var TalkingPointsControl;
    (function (TalkingPointsControl) {
        'use strict';
        var TalkingPoints = (function () {
            /**
             * Empty constructor.
             */
            function TalkingPoints() {
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            TalkingPoints.prototype.init = function (context, notifyOutputChanged, state) {
                if (context.client.getClient() == "Outlook" || context.client.isOffline() == true || Xrm.Internal.isUci() == false)
                    return;
                this.controller = new TalkingPointsControl.TalkingPointsController();
                this.controller.fetchInsights(context);
                context.client.trackContainerResize(true);
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            TalkingPoints.prototype.updateView = function (context) {
                if (context.client.getClient() == "Outlook" || context.client.isOffline() == true || Xrm.Internal.isUci() == false)
                    return context.factory.createElement("CONTAINER", {}, '');
                return this.controller.getView(context);
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            TalkingPoints.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                return null;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            TalkingPoints.prototype.destroy = function () {
                this.controller.cleanup();
                this.controller = null;
            };
            return TalkingPoints;
        }());
        TalkingPointsControl.TalkingPoints = TalkingPoints;
    })(TalkingPointsControl = MscrmControls.TalkingPointsControl || (MscrmControls.TalkingPointsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="TalkingPoints.ts" /> 
