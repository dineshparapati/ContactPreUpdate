/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../../references/internal/TypeDefinitions/CommonControl/CommonControl.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SubjectTreeWrapper;
        (function (SubjectTreeWrapper) {
            'use strict';
            var SubjectTreeWrapperControl = (function () {
                /**
                 * Empty constructor.
                 */
                function SubjectTreeWrapperControl() {
                    this._controlId = "CC_SubjectTree";
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                SubjectTreeWrapperControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                SubjectTreeWrapperControl.prototype.updateView = function (context) {
                    this.disabled = this.disabled || this._context.mode.isControlDisabled;
                    return this.buildSubjectTreeLookupControl(context, this.onSelectionChanged.bind(this));
                };
                SubjectTreeWrapperControl.prototype.buildSubjectTreeLookupControl = function (context, callback) {
                    var SubjectLookupContainer = context.factory.createElement("CONTAINER", {
                        id: "SubjectLookupContainer",
                        key: "SubjectLookupContainer",
                        style: this.getLookupContainerStyle()
                    }, [this.getCheckbox(), this.getTreeLookup(context, callback)]);
                    return SubjectLookupContainer;
                };
                SubjectTreeWrapperControl.prototype.getTreeLookup = function (context, callback) {
                    var SubjectTreeLookup = context.factory.createComponent("MscrmControls.FieldControls.SubjectTreeControl", this._controlId, {
                        configuration: {
                            FormFactor: 3 /* Desktop */,
                            CustomControlId: "MscrmControls.FieldControls.SubjectTreeControl",
                            Name: this._controlId + "-Config",
                            Version: "1.0.0",
                            Parameters: {
                                value: this.getValueParameter(callback)
                            }
                        },
                        controlstates: {
                            isControlDisabled: this.disabled
                        }
                    });
                    return context.factory.createElement("CONTAINER", {
                        id: "TreeLookupContainer",
                        key: "TreeLookupContainer",
                        style: {
                            opacity: this.disabled ? 0.3 : "inherent"
                        }
                    }, SubjectTreeLookup);
                };
                SubjectTreeWrapperControl.prototype.getCheckbox = function () {
                    var checkbox = this._context.factory.createElement("BOOLEAN", {
                        id: "no-parent-checkbox",
                        key: "no-parent-checkbox",
                        name: "no-parent-checkbox",
                        value: this.disabled,
                        onValueChange: this.onValueChanged.bind(this),
                        style: {
                            padding: "4px"
                        }
                    });
                    var checkboxLabel = this._context.factory.createElement("LABEL", {
                        id: "no-parent-checkbox-label",
                        key: "no-parent-checkbox-label",
                        style: {
                            width: "450%",
                            padding: "4px"
                        }
                    }, "No Parent Subject");
                    return this._context.factory.createElement("CONTAINER", {
                        id: "no-parent-checkbox-container",
                        key: "no-parent-checkbox-container",
                        style: {
                            display: "flex",
                        }
                    }, [checkbox, checkboxLabel]);
                };
                SubjectTreeWrapperControl.prototype.onValueChanged = function (e) {
                    this.disabled = e;
                    this._notifyOutputChanged();
                    this._context.utils.requestRender();
                };
                SubjectTreeWrapperControl.prototype.onSelectionChanged = function (e) {
                    if (e[0]) {
                        this.selectedSubject = e[0];
                        this._notifyOutputChanged();
                    }
                    else {
                        console.log("Unexpected value recieved: " + e);
                    }
                };
                SubjectTreeWrapperControl.prototype.getLookupContainerStyle = function () {
                    var lookupStyle = {};
                    lookupStyle["width"] = "calc(100% - 160.5px)";
                    lookupStyle["word-break"] = "break-word";
                    lookupStyle["white-space"] = "normal";
                    lookupStyle["flex"] = "1 1 auto";
                    lookupStyle["display"] = "block";
                    return lookupStyle;
                };
                SubjectTreeWrapperControl.prototype.getValueParameter = function (callback) {
                    var subject = this._context.parameters.selectedSubject.raw;
                    var entityref = null;
                    if (subject && !this.disabled) {
                        entityref = {
                            get_identifier: function () { return subject.id; },
                            Name: subject.name,
                            LogicalName: subject.LogicalName,
                            Id: subject.id
                        };
                    }
                    return {
                        Usage: 3,
                        Static: false,
                        Value: [entityref],
                        Type: "Lookup.Simple",
                        ViewId: "FA1A7EF7-53E4-40A6-97D2-5935ADAF1277",
                        Attributes: {
                            DisplayName: "Subject",
                            LogicalName: "subjectid",
                            Type: "lookup",
                            Targets: ["subject"]
                        },
                        Callback: callback,
                    };
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                SubjectTreeWrapperControl.prototype.getOutputs = function () {
                    // custom code goes here - remove the line below and return the correct output
                    return {
                        selectedSubject: this.disabled ? null : this.selectedSubject
                    };
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                SubjectTreeWrapperControl.prototype.destroy = function () {
                };
                return SubjectTreeWrapperControl;
            }());
            SubjectTreeWrapper.SubjectTreeWrapperControl = SubjectTreeWrapperControl;
        })(SubjectTreeWrapper = AppCommon.SubjectTreeWrapper || (AppCommon.SubjectTreeWrapper = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="SubjectTreeWrapper.ts" /> 
//# sourceMappingURL=SubjectTreeWrapper.js.map