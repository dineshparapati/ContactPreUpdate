/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var SocialInsightsControl;
    (function (SocialInsightsControl_1) {
        "use strict";
        var SocialInsightsControl = (function () {
            function SocialInsightsControl() {
                this.date = 'today';
                this.mseUtils = new SocialInsightsControl_1.MSEUtils();
                this.loaded = false;
                this.iframeId = SocialInsightsControl.iframeIdBase;
                this.topicId = SocialInsightsControl.AllCategories;
                this.widgetNames = SocialInsightsControl.BuzzHistoryHeroWidget;
            }
            SocialInsightsControl.prototype.init = function (context, notifyOutputChanged, state, container) {
                this.context = context;
                this.notifyOutputChanged = notifyOutputChanged;
                this.container = container;
                if (!this.entityIsNotSaved()) {
                    this.initSocialInsightsControl();
                }
            };
            SocialInsightsControl.prototype.updateView = function (context) {
                this.context = context;
                this.mseUtils.setContext(context);
                if (!this.loaded && !this.entityIsNotSaved()) {
                    this.initSocialInsightsControl();
                }
            };
            SocialInsightsControl.prototype.getOutputs = function () {
                return undefined;
            };
            SocialInsightsControl.prototype.destroy = function () {
                $(this.container).empty();
            };
            SocialInsightsControl.prototype.initSocialInsightsControl = function () {
                var _this = this;
                this.loaded = true;
                this.loadSocialInsightsConfiguration(function (socialInsightsConfigurations) {
                    if (socialInsightsConfigurations && socialInsightsConfigurations.length > 0) {
                        _this.socialInsightsConfigurationIdUrl = SocialInsightsControl_1.SocialInsightsODataClient.getUri(_this.context.page.getClientUrl(), "socialinsightsconfigurations", socialInsightsConfigurations[0].socialinsightsconfigurationid);
                        _this.topicId = socialInsightsConfigurations[0].socialdataitemid;
                        _this.widgetNames = socialInsightsConfigurations[0].socialdataparameters;
                    }
                    else {
                        _this.topicId = SocialInsightsControl.AllCategories;
                        _this.widgetNames = SocialInsightsControl.BuzzHistoryHeroWidget;
                    }
                    _this.initControlView();
                    _this.mseUtils.init(function () { return _this.updateWidgetsIframe(); }, function (errorMessage) {
                        if (errorMessage) {
                            _this.mseUtils.showErrorMessage(errorMessage);
                        }
                        else {
                            _this.mseUtils.showNotConnectedErrorMessage();
                            _this.$configureButton.prop("disabled", true).css('cursor', 'default');
                        }
                    }, _this.context);
                });
            };
            SocialInsightsControl.prototype.initControlView = function () {
                if (!this.inDashboard()) {
                    $(this.container).append(this.createHeader());
                }
                $(this.container).append(this.mseUtils.createErrorContainer());
                $(this.container).append(this.createIframe());
            };
            SocialInsightsControl.prototype.updateWidgetsIframe = function () {
                var widgets = this.widgetNames ? this.widgetNames.split('-') : [];
                var widgetsCount = widgets.length;
                //set height of the widget twice, when there is a postlist in, because the postlist has the height of 2 widgets.
                //if there more than 3 widgets (or one postlist and a widget) it will be always maximum the height of 3 widgets.
                if ($.inArray(SocialInsightsControl.RecentPostWidget, widgets) >= 0) {
                    widgetsCount++;
                }
                if (this.inDashboard()) {
                    this.$iframe.height("100%");
                }
                else {
                    var numberOfWidgetsToDisplay = widgetsCount > 3 ? 3 : (widgetsCount < 1 ? 1 : widgetsCount);
                    this.$iframe.height("calc(" + numberOfWidgetsToDisplay + " * " + SocialInsightsControl.WidgetHeight + " + " + SocialInsightsControl.HeaderAndFooterHeight + ")");
                }
                this.$iframe.show();
                this.mseUtils.initFPIWidgets(this.iframeId, this.$iframe.get(0), this.createMSEWidgetURL());
            };
            SocialInsightsControl.prototype.createMSEWidgetURL = function () {
                return "" + this.mseUtils.getMSEUrl() + SocialInsightsControl.WidgetsUrlPath + this.widgetNames + "?date=" + this.date + "&nodeId=" + this.topicId;
            };
            SocialInsightsControl.prototype.entityIsNotSaved = function () {
                return !this.inDashboard() && !this.context.mode.contextInfo.entityId;
            };
            SocialInsightsControl.prototype.inDashboard = function () {
                // ContextInfo when hosted in form
                // UC:  { entityTypeName: "incident", entityId: "dd3719b8-8018-e811-8130-000d3af770a2", entityRecordName: "Test 1" }
                // Web: { entityTypeName: "incident", entityId: "{DD3719B8-8018-E811-8130-000D3AF770A2}", entityRecordName: undefined }
                // ContextInfo when hosted in dashboard
                // UC:  {entityTypeName: undefined, entityId: undefined, entityRecordName: null}
                if (this.context && this.context.mode.contextInfo.entityTypeName) {
                    return false;
                }
                return true;
            };
            SocialInsightsControl.prototype.openConfiguration = function () {
                var _this = this;
                var dialogOptions = {
                    width: 567,
                    height: 584
                };
                //The parameters for our dialog
                var dialogParams = {};
                dialogParams[SocialInsightsControl.DialogParamBaseUrl] = this.mseUtils.getMSEApiUrl();
                dialogParams[SocialInsightsControl.DialogParamTopicId] = this.topicId;
                dialogParams[SocialInsightsControl.DialogParamWidgetName] = this.widgetNames;
                // It appears like the interface is broken swapping options and params.  Anyhow, this works in both web and uc
                this.context.navigation.openDialog(SocialInsightsControl.ConfigurationDialog, dialogOptions, dialogParams)
                    .then(function (dialogResult) {
                    if (dialogResult != null &&
                        dialogResult.parameters[SocialInsightsControl.DialogParamLastButtonClicked] === SocialInsightsControl.DialogOkButton) {
                        _this.topicId = dialogResult.parameters[SocialInsightsControl.DialogParamTopicId];
                        _this.widgetNames = dialogResult.parameters[SocialInsightsControl.DialogParamWidgetName];
                        _this.saveData();
                        _this.updateWidgetsIframe();
                    }
                });
            };
            SocialInsightsControl.prototype.createHeader = function () {
                var _this = this;
                // Note that the label can be hidden in the form editor in which case this.context.mode.labelis not be set
                var $label = $('<h3>')
                    .text(this.context.mode.label || "")
                    .addClass("SocialInsightsControl-Header-Label")
                    .css("font-family", SocialInsightsControl_1.UCITheming.getSemibold(this.context));
                this.$configureButton = $('<button>')
                    .addClass("symbolFont Settings-symbol SocialInsightsControl-Header-Configure-Button")
                    .attr('title', this.context.resources.getString(SocialInsightsControl_1.SocialInsightsConstants.ConfigureButtonLabel))
                    .css(SocialInsightsControl_1.UCITheming.getActioniconbutton01(this.context));
                this.$configureButton.on("click", function () {
                    _this.openConfiguration();
                });
                var $header = $('<div>').addClass("SocialInsightsControl-Header");
                $header.append($label);
                $header.append(this.$configureButton);
                return $header;
            };
            SocialInsightsControl.prototype.createIframe = function () {
                this.$iframe = $('<iframe>').attr('id', this.iframeId).addClass("SocialInsightsControl-iframe").hide();
                this.$iframe.attr('sandbox', 'allow-scripts allow-same-origin allow-popups allow-forms');
                this.$iframe.attr('role', 'presentation');
                return this.$iframe;
            };
            SocialInsightsControl.prototype.loadSocialInsightsConfiguration = function (callback) {
                var queryString;
                if (this.inDashboard()) {
                    queryString = "?$filter=controlid eq '" + this.context.client._customControlProperties.controlId + "'&$orderby=modifiedon desc";
                }
                else {
                    queryString = "?$filter=_regardingobjectid_value eq " + this.context.mode.contextInfo.entityId + " and controlid eq '" + this.context.client._customControlProperties.controlId + "'&$orderby=modifiedon desc";
                }
                var url = SocialInsightsControl_1.SocialInsightsODataClient.getUri(this.context.page.getClientUrl(), "socialinsightsconfigurations", undefined, queryString);
                SocialInsightsControl_1.SocialInsightsODataClient.get(url).then(function (response) { return callback(JSON.parse(response.responseText).value); });
            };
            SocialInsightsControl.prototype.saveData = function () {
                var _this = this;
                if (this.socialInsightsConfigurationIdUrl) {
                    SocialInsightsControl_1.SocialInsightsODataClient.update(this.socialInsightsConfigurationIdUrl, { socialdataitemid: this.topicId, socialdataparameters: this.widgetNames });
                }
                else {
                    var formId_1 = (this.context.client._customControlProperties.formInfo && this.context.client._customControlProperties.formInfo.FormId)
                        || (this.context.client._customControlProperties.personalizationConfiguration && this.context.client._customControlProperties.personalizationConfiguration.formGuid.guid);
                    var pluralNameODataUrl = SocialInsightsControl_1.SocialInsightsODataClient.getUri(this.context.page.getClientUrl(), "EntityDefinitions(LogicalName='" + this.context.mode.contextInfo.entityTypeName + "')/EntitySetName");
                    Promise.all([Xrm.WebApi.online.retrieveRecord("systemform", formId_1), SocialInsightsControl_1.SocialInsightsODataClient.get(pluralNameODataUrl)]).then(function (responses) {
                        var inUserForm = !responses[0] || !responses[0].formid;
                        var entityPluralName = JSON.parse(responses[1].response).value;
                        var requestObject = {};
                        requestObject["socialdataitemid"] = _this.topicId;
                        requestObject["socialdataparameters"] = _this.widgetNames;
                        requestObject["controlid"] = _this.context.client._customControlProperties.controlId;
                        var formIdPropertyName = inUserForm ? "formid_userform@odata.bind" : "formid_systemform@odata.bind";
                        requestObject[formIdPropertyName] = inUserForm ? "/userforms(" + formId_1 + ")" : "/systemforms(" + formId_1 + ")";
                        if (!_this.inDashboard()) {
                            var regardingObjectPropertyName = "regardingobjectid_" + _this.context.mode.contextInfo.entityTypeName + "@odata.bind";
                            requestObject[regardingObjectPropertyName] = "/" + entityPluralName + "(" + _this.context.mode.contextInfo.entityId + ")";
                        }
                        var url = SocialInsightsControl_1.SocialInsightsODataClient.getUri(_this.context.page.getClientUrl(), "socialinsightsconfigurations");
                        SocialInsightsControl_1.SocialInsightsODataClient.post(url, requestObject).then(function (response) {
                            _this.socialInsightsConfigurationIdUrl = response.getResponseHeader("OData-EntityId");
                        });
                    });
                }
            };
            return SocialInsightsControl;
        }());
        SocialInsightsControl.DialogParamBaseUrl = "param_baseUrl";
        SocialInsightsControl.DialogParamTopicId = "param_topicId";
        SocialInsightsControl.DialogParamWidgetName = "param_widgetName";
        SocialInsightsControl.DialogParamLastButtonClicked = "param_lastButtonClicked";
        SocialInsightsControl.ConfigurationDialog = "SocialInsightsConfigurationDialog";
        SocialInsightsControl.iframeIdBase = "social-insights-widget";
        SocialInsightsControl.DialogOkButton = "ok_id";
        SocialInsightsControl.AllCategories = "4";
        SocialInsightsControl.BuzzHistoryHeroWidget = 'volume_history_chart';
        SocialInsightsControl.WidgetsUrlPath = "/embedded_index.html?#widgets:";
        SocialInsightsControl.WidgetHeight = "17vw";
        SocialInsightsControl.RecentPostWidget = 'recent_posts';
        SocialInsightsControl.HalfWidgetHeight = "8.5vw";
        SocialInsightsControl.HeaderAndFooterHeight = "80px";
        SocialInsightsControl_1.SocialInsightsControl = SocialInsightsControl;
    })(SocialInsightsControl = MscrmControls.SocialInsightsControl || (MscrmControls.SocialInsightsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
// Note that this class serves as a workaround because Xrm.WebApi.online.retrieveMultipleRecords does not work for the entity "socialinsightsconfiguration"
var MscrmControls;
(function (MscrmControls) {
    var SocialInsightsControl;
    (function (SocialInsightsControl) {
        "use strict";
        var SocialInsightsODataClient = (function () {
            function SocialInsightsODataClient() {
            }
            SocialInsightsODataClient.getUri = function (baseUrl, entitySetName, id, query) {
                if (id === void 0) { id = undefined; }
                if (query === void 0) { query = undefined; }
                var url = baseUrl + "/api/data/v8.2/" + entitySetName;
                url = id ? url + "(" + id + ")" : url;
                url = query ? url + query : url;
                return url;
            };
            SocialInsightsODataClient.get = function (url) {
                return this.createRequest("GET", url);
            };
            SocialInsightsODataClient.update = function (url, requestData) {
                return this.createRequest("PATCH", url, requestData);
            };
            SocialInsightsODataClient.post = function (url, requestData) {
                return this.createRequest("POST", url, requestData);
            };
            SocialInsightsODataClient.createRequest = function (method, url, requestData) {
                if (requestData === void 0) { requestData = undefined; }
                var deferred = $.Deferred();
                var request = new XMLHttpRequest();
                request.open(method, url, true);
                request.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                request.setRequestHeader("Accept", "application/json");
                request.setRequestHeader("OData-MaxVersion", "4.0");
                request.setRequestHeader("OData-Version", "4.0");
                request.onreadystatechange = function (event) {
                    var currentRequest = event.target;
                    if (currentRequest.readyState === 4 /* complete */) {
                        if (currentRequest.status > 199 && currentRequest.status < 300) {
                            deferred.resolve(currentRequest);
                        }
                        else {
                            deferred.reject(currentRequest, currentRequest.status);
                        }
                    }
                };
                request.send(JSON.stringify(requestData));
                return deferred.promise();
            };
            return SocialInsightsODataClient;
        }());
        SocialInsightsControl.SocialInsightsODataClient = SocialInsightsODataClient;
    })(SocialInsightsControl = MscrmControls.SocialInsightsControl || (MscrmControls.SocialInsightsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var SocialInsightsControl;
    (function (SocialInsightsControl) {
        "use strict";
        var UCITheming = (function () {
            function UCITheming() {
            }
            UCITheming.getRegular = function (context) {
                if (context && context.theming && context.theming.fontfamilies && context.theming.fontfamilies.regular) {
                    return context.theming.fontfamilies.regular;
                }
                return "'Segoe UI Regular', 'SegoeUI', 'Segoe UI'";
            };
            UCITheming.getSemibold = function (context) {
                if (context && context.theming && context.theming.fontfamilies && context.theming.fontfamilies.semibold) {
                    return context.theming.fontfamilies.semibold;
                }
                return "'SegoeUI-Semibold', 'Segoe UI Semibold', 'Segoe UI Regular', 'Segoe UI'";
            };
            UCITheming.getColorGray01 = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.grays && context.theming.colors.grays.gray01) {
                    context.theming.colors.statuscolor.gray01;
                }
                return '#efefef';
            };
            UCITheming.getColorGray02 = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.grays && context.theming.colors.grays.gray02) {
                    context.theming.colors.statuscolor.gray02;
                }
                return '#e2e2e2';
            };
            UCITheming.getColorGray03 = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.grays && context.theming.colors.grays.gray03) {
                    context.theming.colors.statuscolor.gray03;
                }
                return '#d8d8d8';
            };
            UCITheming.getColorGray04 = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.grays && context.theming.colors.grays.gray04) {
                    context.theming.colors.statuscolor.gray04;
                }
                return '#b3b3b3';
            };
            UCITheming.getColorGray05 = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.grays && context.theming.colors.grays.gray05) {
                    context.theming.colors.statuscolor.gray05;
                }
                return '#666666';
            };
            UCITheming.getColorGray06 = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.grays && context.theming.colors.grays.gray06) {
                    context.theming.colors.statuscolor.gray06;
                }
                return '#444444';
            };
            UCITheming.getColorGray07 = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.grays && context.theming.colors.grays.gray07) {
                    context.theming.colors.statuscolor.gray07;
                }
                return '#333333';
            };
            UCITheming.getColorAlert1Text = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.statuscolor && context.theming.colors.statuscolor.alert1 && context.theming.colors.statuscolor.alert1.text) {
                    context.theming.colors.statuscolor.alert1.text;
                }
                return 'white';
            };
            UCITheming.getColorAlert1Fill = function (context) {
                if (context && context.theming && context.theming.colors && context.theming.colors.statuscolor && context.theming.colors.statuscolor.alert1 && context.theming.colors.statuscolor.alert1.fill) {
                    context.theming.colors.statuscolor.alert1.fill;
                }
                return 'red';
            };
            UCITheming.getActioniconbutton01 = function (context) {
                if (context && context.theming && context.theming.buttons.actioniconbutton01) {
                    return context.theming.buttons.actioniconbutton01;
                }
                return { "height": "2.50rem", "width": "2.50rem", "borderStyle": "none", "backgroundColor": "transparent", "justifyContent": "center", "alignItems": "center", "cursor": "pointer" };
            };
            return UCITheming;
        }());
        SocialInsightsControl.UCITheming = UCITheming;
    })(SocialInsightsControl = MscrmControls.SocialInsightsControl || (MscrmControls.SocialInsightsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="SocialInsightsControl.ts" />
/// <reference path="Interfaces/IInputBag.ts" />
/// <reference path="Interfaces/IOutputBag.ts" />
/// <reference path="Shared/SocialInsightsODataClient.ts" />
/// <reference path="Shared/UCITheming.ts" />
/// <reference path="../../../../../references/external/TypeDefinitions/jquery.d.ts" />
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var SocialInsightsControl;
    (function (SocialInsightsControl) {
        var SearchItemType;
        (function (SearchItemType) {
            SearchItemType[SearchItemType["None"] = 0] = "None";
            SearchItemType[SearchItemType["Topic"] = 2] = "Topic";
            SearchItemType[SearchItemType["Category"] = 1] = "Category";
        })(SearchItemType = SocialInsightsControl.SearchItemType || (SocialInsightsControl.SearchItemType = {}));
    })(SocialInsightsControl = MscrmControls.SocialInsightsControl || (MscrmControls.SocialInsightsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var SocialInsightsControl;
    (function (SocialInsightsControl) {
        "use strict";
        var SocialInsightsConstants = (function () {
            function SocialInsightsConstants() {
            }
            return SocialInsightsConstants;
        }());
        SocialInsightsConstants.SolutionNotOnlineLabel = "SocialInsightsControl.SolutionNotOnline";
        SocialInsightsConstants.MocaShimOutdatedLabel = "SocialInsightsControl.MocaShimOutdated";
        SocialInsightsConstants.NotConfiguredInCrmLabel = "SocialInsightsControl.NotConfiguredInCrm";
        SocialInsightsConstants.CannotConnectToMseLabel = "SocialInsightsControl.CannotConnectToMse";
        SocialInsightsConstants.RestError503Label = "SocialInsightsControl.RestError503";
        SocialInsightsConstants.GeneralErrorLabel = "SocialInsightsControl.GeneralError";
        SocialInsightsConstants.ControlIsNotConfiguredLabel = "SocialInsightsControl.ControlIsNotConfigured";
        SocialInsightsConstants.ConfigureButtonLabel = "SocialInsightsControl.ConfigureButton";
        SocialInsightsConstants.RemoveDataLabel = "SocialInsightsControl.RemoveData";
        SocialInsightsConstants.PleaseConfigureSocialInsightsLabel = "SocialInsightsControl.PleaseConfigureSocialInsights";
        SocialInsightsConstants.CreateNewTopicLabel = "SocialInsightsControl.CreateNewTopic";
        SocialInsightsConstants.CreateNewTopicPart1Label = "SocialInsightsControl.CreateNewTopicPart1";
        SocialInsightsConstants.CreateNewTopicPart2Label = "SocialInsightsControl.CreateNewTopicPart2";
        SocialInsightsConstants.OrCreateNewTopicLabel = "SocialInsightsControl.OrCreateNewTopic";
        SocialInsightsConstants.NoMSEHeader = "SocialInsightsControl.NoMSEHeader";
        SocialInsightsConstants.NoMSEParagraph = "SocialInsightsControl.NoMSEParagraph";
        SocialInsightsConstants.NoMSEBullet1Text = "SocialInsightsControl.NoMSEBullet1Text";
        SocialInsightsConstants.NoMSEBullet2Text = "SocialInsightsControl.NoMSEBullet2Text";
        SocialInsightsConstants.NoMSEBullet1LinkText = "SocialInsightsControl.NoMSEBullet1LinkText";
        SocialInsightsConstants.NoMSEBullet2LinkText = "SocialInsightsControl.NoMSEBullet2LinkText";
        SocialInsightsConstants.TopicPickerTitleLabel = "TopicPickerControl.Title";
        SocialInsightsConstants.AllCategoriesLabel = "TopicPickerControl.AllCategories";
        SocialInsightsConstants.AddLabel = "WidgetPickerControl.Add";
        SocialInsightsConstants.ChooseWidgetLabel = "WidgetPickerControl.ChooseWidget";
        SocialInsightsConstants.RemoveWidgetLabel = "WidgetPickerControl.RemoveWidget";
        SocialInsightsConstants.MoveWidgetDownLabel = "WidgetPickerControl.MoveWidgetDown";
        SocialInsightsConstants.MoveWidgetUpLabel = "WidgetPickerControl.MoveWidgetUp";
        SocialInsightsConstants.NoWidgetsAddedLabel = "WidgetPickerControl.NoWidgetsAdded";
        SocialInsightsConstants.NoWidgetsLeftLabel = "WidgetPickerControl.NoWidgetsLeft";
        SocialInsightsConstants.WidgetPickerTitleLabel = "WidgetPickerControl.Title";
        SocialInsightsConstants.WidgetsLabel = "WidgetPickerControl.Widgets";
        SocialInsightsConstants.SPACE = 32;
        SocialInsightsConstants.LEFT = 37;
        SocialInsightsConstants.UP = 38;
        SocialInsightsConstants.RIGHT = 39;
        SocialInsightsConstants.DOWN = 40;
        SocialInsightsControl.SocialInsightsConstants = SocialInsightsConstants;
    })(SocialInsightsControl = MscrmControls.SocialInsightsControl || (MscrmControls.SocialInsightsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var SocialInsightsControl;
    (function (SocialInsightsControl) {
        "use strict";
        var MSEUtils = (function () {
            function MSEUtils() {
            }
            MSEUtils.prototype.init = function (successCallback, failureCallback, context) {
                var _this = this;
                this.context = context;
                this.isMobile = this.context.client.getClient() == 'Mobile';
                //check for default errors
                if (this.context.mode.isOffline) {
                    failureCallback(this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.SolutionNotOnlineLabel));
                    return;
                }
                //get the mse solution config
                Xrm.WebApi.online.retrieveMultipleRecords("organization", '?$select=socialinsightsinstance,socialinsightsenabled').then(function (response) {
                    var config = _this.parseMSEConfig(response.entities[0]);
                    var enabled = response.entities[0].socialinsightsenabled;
                    if (enabled && config != null && (config.Netbreeze_UserUrl != null || config.SignalUrl != null)) {
                        if (config.Netbreeze_UserUrl != null) {
                            _this.mseUrl = config.Netbreeze_UserUrl;
                        }
                        else if (config.SignalUrl != null) {
                            _this.mseUrl = _this.computeMSEUrlFromSignalUrl(config.SignalUrl, config.SolutionId);
                        }
                        _this.mseApiUrl = config.ApiUrl;
                        successCallback();
                    }
                    else {
                        failureCallback();
                    }
                }, function (response, status) {
                    var errorMessage = _this.context.resources.getString(status === 503
                        ? SocialInsightsControl.SocialInsightsConstants.RestError503Label
                        : SocialInsightsControl.SocialInsightsConstants.GeneralErrorLabel);
                    failureCallback(errorMessage);
                });
            };
            MSEUtils.prototype.setContext = function (context) {
                this.context = context;
            };
            MSEUtils.prototype.computeMSEUrlFromSignalUrl = function (signalUrl, solutionId) {
                var mseUrl = signalUrl;
                if (mseUrl.indexOf('/app/') === -1) {
                    if (mseUrl.charAt(mseUrl.length - 1) !== '/') {
                        mseUrl += '/';
                    }
                    mseUrl = mseUrl + 'app/' + solutionId;
                }
                return mseUrl;
            };
            MSEUtils.prototype.handleErrorsForIFrame = function (iframe) {
                var _this = this;
                var iFrameDoc = iframe.contentDocument || iframe.contentWindow.document;
                var isIntegrationSiteLoaded = false;
                if (iFrameDoc.readyState !== "interactive" && iFrameDoc.readyState !== "complete") {
                    //add readystate handler
                    iFrameDoc.onreadystatechange = function () {
                        if (iFrameDoc.readyState === "interactive" || iFrameDoc.readyState === "complete") {
                            isIntegrationSiteLoaded = true;
                            _this.cleanErrors();
                        }
                        else {
                            _this.showErrorMessage(_this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.CannotConnectToMseLabel));
                        }
                    };
                    //add handler for browser which not have readystate
                    iframe.onload = function () {
                        isIntegrationSiteLoaded = true;
                        _this.cleanErrors();
                    };
                    //show error if onload and readystate is not completed after 5 seconds
                    setTimeout(function () {
                        if (!isIntegrationSiteLoaded) {
                            _this.showErrorMessage(_this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.CannotConnectToMseLabel));
                        }
                    }, 5000);
                }
            };
            MSEUtils.prototype.createFPIEndpointUrl = function (componentId, mseUrl, apiUrl) {
                var env = this.getEnvironmentType();
                var integrationSiteAuthenticationParam = this.isMobile ? 'moca' : 'web';
                var integrationSiteURL = "https://" + this.getIntegrationSiteDomain(env) + "/MSE/8.2/Runtime.html";
                var apiParm = apiUrl != null ? '&api=' + encodeURIComponent(apiUrl) : '';
                var integrationFrameUrl = integrationSiteURL + "?env=" + env + "&" + integrationSiteAuthenticationParam + "=true&componentId=" + componentId + "&mseUrl=" + encodeURIComponent(mseUrl) + apiParm;
                return integrationFrameUrl;
            };
            //returns a config object
            MSEUtils.prototype.parseMSEConfig = function (organization) {
                var mseConfigString = organization.socialinsightsinstance;
                if (mseConfigString == null) {
                    return null;
                }
                var mseConfigs = JSON.parse(mseConfigString)["<Parameters>k__BackingField"];
                var mseConfig = {};
                for (var i = 0; i < mseConfigs.length; i++) {
                    mseConfig[mseConfigs[i].Key] = mseConfigs[i].Value;
                }
                return mseConfig;
            };
            MSEUtils.prototype.getMSEUrl = function () {
                return this.mseUrl;
            };
            MSEUtils.prototype.getMSEApiUrl = function () {
                return this.mseApiUrl;
            };
            MSEUtils.prototype.cleanErrors = function () {
                $(this.errorContainer).text('');
                this.errorContainer.style.display = 'none';
            };
            MSEUtils.prototype.showErrorMessage = function (message) {
                this.errorContainer.style.display = 'block';
                this.errorContainer.style.padding = '10px';
                $(this.errorContainer).empty();
                $(this.errorContainer).text(message);
            };
            MSEUtils.prototype.showNotConnectedErrorMessage = function () {
                this.errorContainer.style.display = 'block';
                this.errorContainer.style.padding = '10px';
                $(this.errorContainer).empty();
                var $label = $('<h4>')
                    .text(this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.NoMSEHeader))
                    .addClass("SocialInsightsControl-Error-Header")
                    .css("font-family", SocialInsightsControl.UCITheming.getSemibold(this.context));
                var $paragraph = $('<p>')
                    .text(this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.NoMSEParagraph))
                    .addClass("SocialInsightsControl-Error-Paragraph")
                    .css("font-family", SocialInsightsControl.UCITheming.getRegular(this.context));
                var $list = $('<ul>')
                    .addClass("SocialInsightsControl-Error-List");
                $list.append($('<li>')
                    .append($('<span>')
                    .css("font-family", SocialInsightsControl.UCITheming.getRegular(this.context))
                    .text(this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.NoMSEBullet1Text)))
                    .append($('<a>')
                    .attr("href", "https://go.microsoft.com/fwlink/?linkid=2030987")
                    .attr("target", "_blank")
                    .append($('<span>')
                    .css("font-family", SocialInsightsControl.UCITheming.getRegular(this.context))
                    .addClass("SocialInsightsControl-Error-Link")
                    .text(this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.NoMSEBullet1LinkText)))));
                $list.append($('<li>')
                    .append($('<span>')
                    .css("font-family", SocialInsightsControl.UCITheming.getRegular(this.context))
                    .text(this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.NoMSEBullet2Text)))
                    .append($('<a>')
                    .attr("href", "https://go.microsoft.com/fwlink/?linkid=2030988")
                    .attr("target", "_blank")
                    .append($('<span>')
                    .css("font-family", SocialInsightsControl.UCITheming.getRegular(this.context))
                    .addClass("SocialInsightsControl-Error-Link")
                    .text(this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.NoMSEBullet2LinkText)))));
                $(this.errorContainer).append($label);
                $(this.errorContainer).append($paragraph);
                $(this.errorContainer).append($list);
            };
            MSEUtils.prototype.createErrorContainer = function () {
                this.errorContainer = document.createElement('div');
                this.errorContainer.className = 'SocialInsightsControl-Error';
                return this.errorContainer;
            };
            MSEUtils.prototype.initFPIWidgets = function (componentId, iframe, widgetsUrl) {
                var iframeSrc = this.createFPIEndpointUrl(componentId, widgetsUrl);
                this.initAuthenticationAndLoadFPI(componentId, iframe, iframeSrc);
            };
            MSEUtils.prototype.initFPIData = function (componentId, iframe, apiUrl) {
                var iframeSrc = this.createFPIEndpointUrl(componentId, this.mseUrl + '/embedded_ajax.html', apiUrl);
                this.initAuthenticationAndLoadFPI(componentId, iframe, iframeSrc);
            };
            MSEUtils.prototype.initAuthenticationAndLoadFPI = function (componentId, iframe, iframeSrc) {
                var _this = this;
                if (this.isMobile) {
                    // Code for CRM for phones and tablets only goes here.
                    // (window.parent.Xrm as any).Utility.beginSecureSessionForResource(
                    this.context.utils.beginSecureSessionForResource("https://listening.microsoft.com/", componentId, this.getIntegrationSiteDomain(this.getEnvironmentType())).then(function () {
                        iframe.src = iframeSrc;
                        _this.handleErrorsForIFrame(iframe);
                    }, function (err) {
                        //6 is BeginSecureSessionResponseCode.FeatureDisabled
                        if (err === 6) {
                            _this.showErrorMessage(_this.context.resources.getString(SocialInsightsControl.SocialInsightsConstants.MocaShimOutdatedLabel));
                        }
                    });
                }
                else {
                    // Code for web browser or CRM for Outlook only goes here.
                    iframe.src = iframeSrc;
                }
            };
            MSEUtils.prototype.getDomain = function () {
                var a = document.createElement("a");
                a.href = window.location.href;
                var integrationDomain = a.host;
                $(a).remove();
                return integrationDomain;
            };
            MSEUtils.prototype.getIntegrationSiteDomain = function (env) {
                return MSEUtils.AuthResourceByEnv[env];
            };
            MSEUtils.prototype.getEnvironmentType = function () {
                var domain = this.getDomain();
                var env = "ppe";
                if (this.stringEndsWith(domain, "extest.microsoft.com"))
                    env = "ppe";
                else if (this.stringEndsWith(domain, "crmlivetie.com"))
                    env = "ppe";
                else if (this.stringEndsWith(domain, "crmlivetoday.com"))
                    env = "ppe";
                else if (this.stringEndsWith(domain, "1boxtest.com"))
                    env = "ppe";
                else if (this.stringEndsWith(domain, "dynamics-int.com"))
                    env = "int";
                else if (this.stringEndsWith(domain, "crm9.dynamics.com"))
                    env = "gcc";
                else if (this.stringEndsWith(domain, "dynamics.com"))
                    env = "prod";
                return env;
            };
            MSEUtils.prototype.stringEndsWith = function (base, search) {
                return base.length >= search.length
                    && base.substr(base.length - search.length, search.length) === search;
            };
            return MSEUtils;
        }());
        MSEUtils.AuthResourceByEnv = {
            "dev": "www.crmdynint-livetie.com",
            "ppe": "www.crmdynint-livetie.com",
            "int": "www.crmdynint-int.com",
            "prod": "www.crmdynint.com"
        };
        SocialInsightsControl.MSEUtils = MSEUtils;
    })(SocialInsightsControl = MscrmControls.SocialInsightsControl || (MscrmControls.SocialInsightsControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var SocialInsightsControl;
    (function (SocialInsightsControl) {
        "use strict";
        var RestResourceManager = (function () {
            function RestResourceManager(url, mseUtils, uniqueName) {
                this.isMessageEventInitialized = false;
                this.onMessageReceive = this.onMessageReceive.bind(this);
                this.url = url;
                this.componentId = 'SocialInsightsRest-' + uniqueName;
                this.mseUtils = mseUtils;
            }
            RestResourceManager.prototype.initMessageHandler = function () {
                if (!this.isMessageEventInitialized) {
                    window.addEventListener('message', this.onMessageReceive);
                    this.isMessageEventInitialized = true;
                }
            };
            RestResourceManager.prototype.onMessageReceive = function (event) {
                var data = event.data;
                if (data.ajax === this.url) {
                    if (data.error != null) {
                        this.errorCallback(data);
                    }
                    else if (data.name === 'MSE:rest') {
                        this.successCallback(data);
                    }
                    this.cleanup();
                }
            };
            RestResourceManager.prototype.cleanup = function () {
                window.removeEventListener('message', this.onMessageReceive);
                var element = document.getElementById(this.componentId);
                if (element) {
                    document.body.removeChild(element);
                }
            };
            RestResourceManager.prototype.done = function (callback) {
                this.successCallback = callback;
                this.initMessageHandler();
                var iframe = this.createHiddenIframe();
                document.body.appendChild(iframe);
                this.mseUtils.initFPIData(this.componentId, iframe, this.url);
                return this;
            };
            RestResourceManager.prototype.fail = function (callback) {
                this.errorCallback = callback;
                return this;
            };
            RestResourceManager.prototype.createHiddenIframe = function () {
                var iframe = document.createElement('iframe');
                iframe.style.visibility = 'hidden';
                iframe.width = '1px';
                iframe.height = '1px';
                iframe.style.position = 'absolute';
                iframe.style.top = '-10px';
                iframe.style.left = '-10px';
                iframe.id = this.componentId;
                iframe.setAttribute('aria-hidden', 'true');
                return iframe;
            };
            return RestResourceManager;
        }());
        SocialInsightsControl.RestResourceManager = RestResourceManager;
    })(SocialInsightsControl = MscrmControls.SocialInsightsControl || (MscrmControls.SocialInsightsControl = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=SocialInsightsControl.js.map