/**
 * This code was generated from a script.
 * Manual changes to this file will be overwritten if the code is regenerated.
 *
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../../references/internal/TypeDefinitions/CommonControl/CommonControl.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var ContractCalendar;
    (function (ContractCalendar) {
        'use strict';
        var Constants = (function () {
            function Constants() {
            }
            return Constants;
        }());
        Constants.CALENDARLENGTH = 168; // 24 x 7
        Constants.CALENDARDAYS = 7;
        Constants.CALENDARHOURS = 24;
        Constants.CALENDARHOURSINHALFDAY = 12;
        Constants.CALENDAROFF = "-";
        Constants.CALENDARON = "+";
        Constants.SCOPE_COL = "col";
        Constants.SCOPE_ROW = "row";
        Constants.CALENDARSELECTED = "●";
        Constants.KEY_ENTER = 13;
        Constants.KEY_SPACEBAR = 32;
        ContractCalendar.Constants = Constants;
    })(ContractCalendar = MscrmControls.ContractCalendar || (MscrmControls.ContractCalendar = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var ContractCalendar;
    (function (ContractCalendar) {
        'use strict';
        var ContractCalendarControl = (function () {
            /**
             * Empty constructor.
             */
            function ContractCalendarControl() {
                this.effectiveCalendar = [];
                this.is24x7Checked = false;
                this.controlId = MscrmCommon.ControlUtils.ControlGuidGenerator.newGuid("ContractCalendarControl");
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             */
            ContractCalendarControl.prototype.init = function (context, notifyOutputChanged, state) {
                this.context = context;
                this.dateFormattingInfo = context.client.dateFormattingInfo;
                this.notifyOutputChanged = notifyOutputChanged || (function () { return; });
                ContractCalendar.ContractCalendarLocale.initialize(function (id) { return context.resources.getString(id); });
                ContractCalendar.Styles.initialize(context.theming, context.client.isRTL);
                this.isTwoDigitFormat = (this.dateFormattingInfo.ShortTimePattern.match(new RegExp("h", "gi")) || []).length === 2; // has HH or hh in the format string
                this.is24HourFormat = this.dateFormattingInfo.ShortTimePattern.indexOf("H") >= 0; // has H means 24Hour format
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            ContractCalendarControl.prototype.updateView = function (context) {
                /// Update context with possible changes since initialization.
                this.context = context;
                this.validateAndConvertInput(context.parameters.value.raw);
                var containerComponent = this.createContainer();
                return containerComponent;
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            ContractCalendarControl.prototype.getOutputs = function () {
                var calendarString = this.effectiveCalendar
                    .reduce(function (previous, current) { return previous.concat(current); }) //flatten the 2D array
                    .map(function (x) { return (x ? ContractCalendar.Constants.CALENDARON : ContractCalendar.Constants.CALENDAROFF); }) // convert boolean to the mask string
                    .join(""); // convert the array to the mask string
                if (calendarString.indexOf(ContractCalendar.Constants.CALENDARON) === -1) {
                    // set calendarString to null if it doesn't contains any CALENDARON character
                    calendarString = null;
                }
                return {
                    value: calendarString
                };
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            ContractCalendarControl.prototype.destroy = function () {
                this.context = null;
                this.dateFormattingInfo = null;
                this.effectiveCalendar = null;
                this.notifyOutputChanged = null;
            };
            ContractCalendarControl.prototype.validateAndConvertInput = function (calendarString) {
                this.effectiveCalendar = [];
                var regex = new RegExp(MscrmCommon.ControlUtils.String.Format("^[{0}|{1}]{{2}}$", ContractCalendar.Constants.CALENDAROFF, ContractCalendar.Constants.CALENDARON, ContractCalendar.Constants.CALENDARLENGTH), "g");
                var linearCalendar = [];
                if (regex.test(calendarString)) {
                    linearCalendar = calendarString.split("").map(function (x) { return (x === ContractCalendar.Constants.CALENDARON); });
                }
                else {
                    // The input string is invalid, fallback to empty calendar
                    for (var i = 0; i < ContractCalendar.Constants.CALENDARLENGTH; i++) {
                        linearCalendar.push(false);
                    }
                }
                // Converts the linear array to 2D array
                while (!MscrmCommon.ControlUtils.Object.isNullOrUndefined(linearCalendar[0])) {
                    this.effectiveCalendar.push(linearCalendar.splice(0, ContractCalendar.Constants.CALENDARHOURS));
                }
                this.is24x7Checked = this.isAllOn();
            };
            ContractCalendarControl.prototype.createContainer = function () {
                return this.context.factory.createElement("CONTAINER", {
                    key: this.controlId,
                    title: ContractCalendar.ContractCalendarLocale.contractCalendarAriaLabel,
                    accessibilityLabel: ContractCalendar.ContractCalendarLocale.contractCalendarAriaLabel
                }, [
                    this.createContractCalendar()
                ]);
            };
            ContractCalendarControl.prototype.createContractCalendar = function () {
                return this.context.factory.createElement("TABLE", {
                    key: this.getId("table"),
                    role: "grid",
                    style: ContractCalendar.Styles.table
                }, [
                    this.createTableColumnHeader(),
                    this.createTableBody()
                ]);
            };
            ContractCalendarControl.prototype.createTableColumnHeader = function () {
                return this.context.factory.createElement("TABLEHEADER", {
                    key: this.getId("tableHeader"),
                    style: ContractCalendar.Styles.tableHeader
                }, [
                    this.createTableAmPmHeaderRow(),
                    this.createTableHourHeaderRow()
                ]);
            };
            ContractCalendarControl.prototype.createTableAmPmHeaderRow = function () {
                var tableHeaderRowId = this.getId("tableAmPmHeaderRow");
                return this.context.factory.createElement("TABLEROW", {
                    key: tableHeaderRowId,
                    style: ContractCalendar.Styles.tableColumnHeaderRow
                }, [
                    this.createTableHeaderCell(MscrmCommon.ControlUtils.String.Format("{0}_{1}", tableHeaderRowId, "empty"), "", ContractCalendar.Constants.SCOPE_COL, null, ContractCalendar.Styles.tableHeaderEmptyCell),
                    this.createTableHeaderCell(MscrmCommon.ControlUtils.String.Format("{0}_{1}", tableHeaderRowId, "AM"), this.dateFormattingInfo.AMDesignator, ContractCalendar.Constants.SCOPE_COL, null, ContractCalendar.Styles.tableHeaderAMPMCell),
                    this.createTableHeaderCell(MscrmCommon.ControlUtils.String.Format("{0}_{1}", tableHeaderRowId, "AM_Padding"), "", ContractCalendar.Constants.SCOPE_COL, ContractCalendar.Constants.CALENDARHOURSINHALFDAY - 1, ContractCalendar.Styles.tableHeaderAMPaddingCell),
                    this.createTableHeaderCell(MscrmCommon.ControlUtils.String.Format("{0}_{1}", tableHeaderRowId, "PM"), this.dateFormattingInfo.PMDesignator, ContractCalendar.Constants.SCOPE_COL, null, ContractCalendar.Styles.tableHeaderAMPMCell),
                    this.createTableHeaderCell(MscrmCommon.ControlUtils.String.Format("{0}_{1}", tableHeaderRowId, "PM_Padding"), "", ContractCalendar.Constants.SCOPE_COL, ContractCalendar.Constants.CALENDARHOURSINHALFDAY - 1, ContractCalendar.Styles.tableHeaderPMPaddingCell)
                ]);
            };
            ContractCalendarControl.prototype.createTableHourHeaderRow = function () {
                var tableHeaderRowId = this.getId("tableHourHeaderRow");
                var tableHourHeader = [this.createTableHeaderCell(tableHeaderRowId + "_empty", "", ContractCalendar.Constants.SCOPE_COL, null, ContractCalendar.Styles.tableHeaderHourCell(null))];
                for (var columnNumber = 0; columnNumber < ContractCalendar.Constants.CALENDARHOURS; columnNumber++) {
                    tableHourHeader.push(this.createTableHeaderCell(MscrmCommon.ControlUtils.String.Format("{0}_{1}", tableHeaderRowId, columnNumber), 
                    // Bug 509957: this behavior does not match the legacy code implies, but matches the rendered result
                    this.isTwoDigitFormat ? ("0" + (columnNumber + (this.is24HourFormat ? 1 : 0))).slice(-2) : (columnNumber + (this.is24HourFormat ? 1 : 0)).toString(), ContractCalendar.Constants.SCOPE_COL, null, ContractCalendar.Styles.tableHeaderHourCell(columnNumber), 0, this.context.mode.isControlDisabled ? null : this.onColumnHeaderClick(columnNumber)));
                }
                return this.context.factory.createElement("TABLEROW", {
                    key: tableHeaderRowId,
                    style: ContractCalendar.Styles.tableColumnHeaderRow
                }, tableHourHeader);
            };
            ContractCalendarControl.prototype.createTableBody = function () {
                var tableBodyRows = [];
                var firstDayOfWeek = this.dateFormattingInfo.FirstDayOfWeek; // 0: Sunday; 1: Monday... 6: Saturday
                for (var rowNumber = 0 + firstDayOfWeek; rowNumber < ContractCalendar.Constants.CALENDARDAYS + firstDayOfWeek; rowNumber++) {
                    tableBodyRows.push(this.createTableDataRow(rowNumber % ContractCalendar.Constants.CALENDARDAYS));
                }
                tableBodyRows.push(this.create24x7Row());
                return this.context.factory.createElement("TABLEBODY", {
                    key: this.getId("tableBody")
                }, tableBodyRows);
            };
            ContractCalendarControl.prototype.createTableDataRow = function (rowNumber) {
                var tableRowId = this.getId(MscrmCommon.ControlUtils.String.Format("{0}_{1}", "dataRow", rowNumber));
                var tableBodyRow = [this.createTableHeaderCell(tableRowId, this.dateFormattingInfo.AbbreviatedDayNames[rowNumber], ContractCalendar.Constants.SCOPE_ROW, null, ContractCalendar.Styles.tableHeaderWeekCell, 0, this.context.mode.isControlDisabled ? null : this.onRowHeaderClick(rowNumber), this.dateFormattingInfo.DayNames[rowNumber])];
                for (var columnNumber = 0; columnNumber < ContractCalendar.Constants.CALENDARHOURS; columnNumber++) {
                    tableBodyRow.push(this.createTableDataCell(MscrmCommon.ControlUtils.String.Format("{0}_{1}", tableRowId, columnNumber), rowNumber, columnNumber));
                }
                return this.context.factory.createElement("TABLEROW", {
                    key: tableRowId,
                    style: ContractCalendar.Styles.tableRow
                }, tableBodyRow);
            };
            ContractCalendarControl.prototype.createTableHeaderCell = function (id, content, scope, colSpan, style, tabIndex, onClick, label) {
                if (colSpan === void 0) { colSpan = 1; }
                if (tabIndex === void 0) { tabIndex = -1; }
                var title = MscrmCommon.ControlUtils.Object.isNullOrUndefined(label) ? content : label;
                return this.context.factory.createElement("TABLEHEADERCELL", {
                    id: id,
                    key: id,
                    scope: scope,
                    role: scope ? (scope === ContractCalendar.Constants.SCOPE_COL ? "columnheader" : "rowheader") : null,
                    accessibilityLabel: title,
                    title: title,
                    colSpan: colSpan,
                    onClick: onClick,
                    onKeyDown: this.onKeyDown(onClick),
                    style: style,
                    tabIndex: tabIndex
                }, [
                    content
                ]);
            };
            ContractCalendarControl.prototype.createTableDataCell = function (id, rowNumber, columnNumber) {
                var title = this.effectiveCalendar[rowNumber][columnNumber]
                    ? ContractCalendar.ContractCalendarLocale.contractCalendarOnAriaLabel
                    : ContractCalendar.ContractCalendarLocale.contractCalendarOffAriaLabel;
                var onClick = this.context.mode.isControlDisabled ? null : this.onCellClick(rowNumber, columnNumber);
                return this.context.factory.createElement("TABLECELL", {
                    id: id,
                    key: id,
                    role: "gridcell",
                    accessibilityLabel: title,
                    title: title,
                    onClick: onClick,
                    onKeyDown: this.onKeyDown(onClick),
                    style: ContractCalendar.Styles.tableCell(columnNumber),
                    tabIndex: 0
                }, [
                    this.effectiveCalendar[rowNumber][columnNumber] ? ContractCalendar.Constants.CALENDARSELECTED : " "
                ]);
            };
            ContractCalendarControl.prototype.create24x7Row = function () {
                return this.context.factory.createElement("TABLEROW", {
                    key: this.getId("24x7"),
                    style: ContractCalendar.Styles.table24x7Row
                }, [
                    this.context.factory.createElement("TABLEHEADERCELL", {
                        key: this.getId("24x7_Cell"),
                        role: "gridcell",
                        style: ContractCalendar.Styles.table24x7Checkbox,
                        title: ContractCalendar.ContractCalendarLocale.contractCalendar24x7,
                        accessibilityLabel: ContractCalendar.ContractCalendarLocale.contractCalendar24x7,
                        onKeyDown: this.context.mode.isControlDisabled ? null : this.onKeyDown(this.onCheckBoxValueChange.bind(this)) // Bug 503476: Workaround for accessibility, VDom checkbox should take care of this
                    }, [
                        this.createCheckBox()
                    ]),
                    this.context.factory.createElement("TABLECELL", {
                        key: this.getId("24x7_Label"),
                        role: "gridcell",
                        colSpan: ContractCalendar.Constants.CALENDARHOURS,
                        title: ContractCalendar.ContractCalendarLocale.contractCalendar24x7,
                        style: ContractCalendar.Styles.table24x7Label
                    }, [
                        ContractCalendar.ContractCalendarLocale.contractCalendar24x7
                    ])
                ]);
            };
            ContractCalendarControl.prototype.createCheckBox = function () {
                return this.context.factory.createElement("BOOLEAN", {
                    key: this.getId("checkbox"),
                    title: ContractCalendar.ContractCalendarLocale.contractCalendar24x7,
                    accessibilityLabel: ContractCalendar.ContractCalendarLocale.contractCalendar24x7,
                    value: this.is24x7Checked,
                    disabled: this.context.mode.isControlDisabled,
                    onValueChange: this.context.mode.isControlDisabled ? null : this.onCheckBoxValueChange.bind(this),
                    style: ContractCalendar.Styles.checkboxInput,
                    tabIndex: 0
                });
            };
            ContractCalendarControl.prototype.getId = function (suffix) {
                return MscrmCommon.ControlUtils.String.Format("{0}_{1}", this.controlId, suffix);
            };
            ContractCalendarControl.prototype.isColumnAllOn = function (columnNumber) {
                for (var rowNumber = 0; rowNumber < ContractCalendar.Constants.CALENDARDAYS; rowNumber++) {
                    if (!this.effectiveCalendar[rowNumber][columnNumber]) {
                        return false;
                    }
                    ;
                }
                return true;
            };
            ContractCalendarControl.prototype.isRowAllOn = function (rowNumber) {
                for (var columnNumber = 0; columnNumber < ContractCalendar.Constants.CALENDARHOURS; columnNumber++) {
                    if (!this.effectiveCalendar[rowNumber][columnNumber]) {
                        return false;
                    }
                    ;
                }
                return true;
            };
            ContractCalendarControl.prototype.isAllOn = function () {
                for (var columnNumber = 0; columnNumber < ContractCalendar.Constants.CALENDARHOURS; columnNumber++) {
                    if (!this.isColumnAllOn(columnNumber)) {
                        return false;
                    }
                    ;
                }
                return true;
            };
            ContractCalendarControl.prototype.onCellClick = function (rowNumber, columnNumber) {
                var _this = this;
                return function () {
                    _this.effectiveCalendar[rowNumber][columnNumber] = !_this.effectiveCalendar[rowNumber][columnNumber];
                    _this.notifyOutputChanged();
                };
            };
            ContractCalendarControl.prototype.onColumnHeaderClick = function (columnNumber) {
                var _this = this;
                return function () {
                    var value = !_this.isColumnAllOn(columnNumber);
                    for (var rowNumber = 0; rowNumber < ContractCalendar.Constants.CALENDARDAYS; rowNumber++) {
                        _this.effectiveCalendar[rowNumber][columnNumber] = value;
                    }
                    _this.notifyOutputChanged();
                };
            };
            ContractCalendarControl.prototype.onRowHeaderClick = function (rowNumber) {
                var _this = this;
                return function () {
                    var value = !_this.isRowAllOn(rowNumber);
                    for (var columnNumber = 0; columnNumber < ContractCalendar.Constants.CALENDARHOURS; columnNumber++) {
                        _this.effectiveCalendar[rowNumber][columnNumber] = value;
                    }
                    _this.notifyOutputChanged();
                };
            };
            ContractCalendarControl.prototype.onKeyDown = function (onClick) {
                return function (event) {
                    if (event && event.type === "keydown" &&
                        (event.keyCode === ContractCalendar.Constants.KEY_ENTER || event.keyCode === ContractCalendar.Constants.KEY_SPACEBAR) &&
                        !MscrmCommon.ControlUtils.Object.isNullOrUndefined(onClick)) {
                        onClick();
                    }
                    else {
                        return;
                    }
                };
            };
            ContractCalendarControl.prototype.onCheckBoxValueChange = function () {
                var value = !this.is24x7Checked;
                for (var rowNumber = 0; rowNumber < ContractCalendar.Constants.CALENDARDAYS; rowNumber++) {
                    for (var columnNumber = 0; columnNumber < ContractCalendar.Constants.CALENDARHOURS; columnNumber++) {
                        this.effectiveCalendar[rowNumber][columnNumber] = value;
                    }
                }
                this.notifyOutputChanged();
            };
            return ContractCalendarControl;
        }());
        ContractCalendar.ContractCalendarControl = ContractCalendarControl;
    })(ContractCalendar = MscrmControls.ContractCalendar || (MscrmControls.ContractCalendar = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
///<reference path="privatereferences.ts" />
var MscrmControls;
(function (MscrmControls) {
    var ContractCalendar;
    (function (ContractCalendar) {
        'use strict';
        /**
        * Contract Calendar labels.
        */
        var ContractCalendarLocale = (function () {
            function ContractCalendarLocale() {
            }
            /*
            * Initializes the Contract Calendar labels.
            */
            ContractCalendarLocale.initialize = function (getString) {
                ContractCalendarLocale.contractCalendarAriaLabel = getString(ContractCalendar.LabelId.contractCalendarAria);
                ContractCalendarLocale.contractCalendarOnAriaLabel = getString(ContractCalendar.LabelId.contractCalendarOnAria);
                ContractCalendarLocale.contractCalendarOffAriaLabel = getString(ContractCalendar.LabelId.contractCalendarOffAria);
                ContractCalendarLocale.contractCalendar24x7 = getString(ContractCalendar.LabelId.contractCalendar24x7);
            };
            return ContractCalendarLocale;
        }());
        ContractCalendar.ContractCalendarLocale = ContractCalendarLocale;
    })(ContractCalendar = MscrmControls.ContractCalendar || (MscrmControls.ContractCalendar = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
///<reference path="privatereferences.ts" /> 
var MscrmControls;
(function (MscrmControls) {
    var ContractCalendar;
    (function (ContractCalendar) {
        'use strict';
        var LabelId = (function () {
            function LabelId() {
            }
            return LabelId;
        }());
        /**
         * Contract Calendar ARIA label.
         * Label value: ContractCalendar
         */
        LabelId.contractCalendarAria = "CC_ContractCalendar_Name";
        LabelId.contractCalendarOnAria = "CC_ContractCalendar_On";
        LabelId.contractCalendarOffAria = "CC_ContractCalendar_Off";
        LabelId.contractCalendar24x7 = "CC_ContractCalendar_24x7Support";
        ContractCalendar.LabelId = LabelId;
    })(ContractCalendar = MscrmControls.ContractCalendar || (MscrmControls.ContractCalendar = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var ContractCalendar;
    (function (ContractCalendar) {
        'use strict';
        var Styles = (function () {
            function Styles() {
            }
            Styles.initialize = function (theming, isRtl) {
                Styles.fontSize = "14px";
                Styles.fontColor = theming.colors.grays.gray07;
                Styles.blackBorder = "1px solid black";
                Styles.border = theming.borders.border02;
                Styles.alterColumnColor = theming.colors.hoverlinkeffect;
                var borderPropertyName = isRtl ? "borderLeft" : "borderRight";
                Styles.table = {
                    borderCollapse: "collapse",
                    width: Styles.important("100%"),
                    tableLayout: "fixed"
                };
                Styles.tableCell = function (columnNumber) {
                    return (_a = {
                            borderBottom: Styles.border
                        },
                        _a[borderPropertyName] = Styles.calculateBorderRight(columnNumber),
                        _a.textAlign = "center",
                        _a.verticalAlign = "top",
                        _a.padding = Styles.important("0px"),
                        _a.lineHeight = "normal",
                        _a.fontSize = Styles.important("25px"),
                        _a.color = theming.colors.grays.gray07,
                        _a.overflow = "hidden",
                        _a.backgroundColor = (columnNumber % 2 === 0) ? Styles.alterColumnColor : null,
                        _a);
                    var _a;
                };
                Styles.tableRow = {
                    height: Styles.important("40px")
                };
                Styles.tableColumnHeaderRow = {
                    height: Styles.important("20px")
                };
                Styles.tableHeaderEmptyCell = {
                    width: 60
                };
                Styles.tableHeaderHourCell = function (columnNumber) {
                    return (_a = {
                            backgroundColor: theming.colors.grays.gray01
                        },
                        _a[borderPropertyName] = Styles.calculateBorderRight(columnNumber),
                        _a.textAlign = "center",
                        _a.verticalAlign = "middle",
                        _a.fontSize = Styles.fontSize,
                        _a.cursor = "pointer",
                        _a);
                    var _a;
                };
                Styles.tableHeaderWeekCell = {
                    backgroundColor: theming.colors.grays.gray01,
                    textAlign: "left",
                    paddingLeft: 8,
                    verticalAlign: "middle",
                    color: Styles.fontColor,
                    fontSize: Styles.fontSize,
                    cursor: "pointer"
                };
                Styles.tableHeaderAMPMCell = {
                    backgroundColor: Styles.alterColumnColor,
                    verticalAlign: "middle",
                    textAlign: "center",
                    fontSize: Styles.fontSize
                };
                Styles.tableHeaderAMPaddingCell = (_a = {
                        backgroundColor: Styles.alterColumnColor
                    },
                    _a[borderPropertyName] = Styles.blackBorder,
                    _a);
                Styles.tableHeaderPMPaddingCell = (_b = {
                        backgroundColor: Styles.alterColumnColor
                    },
                    _b[borderPropertyName] = Styles.border,
                    _b);
                Styles.table24x7Row = Styles.tableColumnHeaderRow;
                Styles.table24x7Checkbox = Styles.tableHeaderWeekCell;
                Styles.checkboxInput = {
                    width: "auto"
                };
                Styles.table24x7Label = (_c = {
                        backgroundColor: theming.colors.grays.gray01
                    },
                    _c[borderPropertyName] = Styles.border,
                    _c.verticalAlign = "middle",
                    _c.padding = Styles.important("0px"),
                    _c.fontSize = Styles.important(Styles.fontSize),
                    _c.color = Styles.fontColor,
                    _c);
                Styles.tableHeader = {
                    color: Styles.fontColor
                };
                var _a, _b, _c;
            };
            Styles.calculateBorderRight = function (columnNumber) {
                if (columnNumber === ContractCalendar.Constants.CALENDARHOURSINHALFDAY - 1) {
                    return Styles.blackBorder;
                }
                if (columnNumber === ContractCalendar.Constants.CALENDARHOURS - 1) {
                    return Styles.border;
                }
                return null;
            };
            ;
            Styles.important = function (style) {
                return MscrmCommon.ControlUtils.String.Format("{0} !important", style);
            };
            ;
            return Styles;
        }());
        ContractCalendar.Styles = Styles;
    })(ContractCalendar = MscrmControls.ContractCalendar || (MscrmControls.ContractCalendar = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="Constants.ts" />
/// <reference path="ContractCalendarControl.ts" />
/// <reference path="ContractCalendarLocale.ts" />
/// <reference path="LabelId.ts" />
/// <reference path="Styles.ts" /> 
//# sourceMappingURL=ContractCalendarControl.js.map